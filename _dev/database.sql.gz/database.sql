-- -------------------------------------------------------------
-- TablePlus 2.12(282)
--
-- https://tableplus.com/
--
-- Database: craft-fwork-plus
-- Generation Time: 2020-01-13 14:41:20.4260
-- -------------------------------------------------------------


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;


DROP TABLE IF EXISTS `assetindexdata`;
CREATE TABLE `assetindexdata` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `sessionId` varchar(36) NOT NULL DEFAULT '',
  `volumeId` int(11) NOT NULL,
  `uri` text,
  `size` bigint(20) unsigned DEFAULT NULL,
  `timestamp` datetime DEFAULT NULL,
  `recordId` int(11) DEFAULT NULL,
  `inProgress` tinyint(1) DEFAULT '0',
  `completed` tinyint(1) DEFAULT '0',
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `assetindexdata_sessionId_volumeId_idx` (`sessionId`,`volumeId`),
  KEY `assetindexdata_volumeId_idx` (`volumeId`),
  CONSTRAINT `assetindexdata_volumeId_fk` FOREIGN KEY (`volumeId`) REFERENCES `volumes` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

DROP TABLE IF EXISTS `assets`;
CREATE TABLE `assets` (
  `id` int(11) NOT NULL,
  `volumeId` int(11) DEFAULT NULL,
  `folderId` int(11) NOT NULL,
  `filename` varchar(255) NOT NULL,
  `kind` varchar(50) NOT NULL DEFAULT 'unknown',
  `width` int(11) unsigned DEFAULT NULL,
  `height` int(11) unsigned DEFAULT NULL,
  `size` bigint(20) unsigned DEFAULT NULL,
  `focalPoint` varchar(13) DEFAULT NULL,
  `deletedWithVolume` tinyint(1) DEFAULT NULL,
  `keptFile` tinyint(1) DEFAULT NULL,
  `dateModified` datetime DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `assets_filename_folderId_idx` (`filename`,`folderId`),
  KEY `assets_folderId_idx` (`folderId`),
  KEY `assets_volumeId_idx` (`volumeId`),
  CONSTRAINT `assets_folderId_fk` FOREIGN KEY (`folderId`) REFERENCES `volumefolders` (`id`) ON DELETE CASCADE,
  CONSTRAINT `assets_id_fk` FOREIGN KEY (`id`) REFERENCES `elements` (`id`) ON DELETE CASCADE,
  CONSTRAINT `assets_volumeId_fk` FOREIGN KEY (`volumeId`) REFERENCES `volumes` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

DROP TABLE IF EXISTS `assettransformindex`;
CREATE TABLE `assettransformindex` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `assetId` int(11) NOT NULL,
  `filename` varchar(255) DEFAULT NULL,
  `format` varchar(255) DEFAULT NULL,
  `location` varchar(255) NOT NULL,
  `volumeId` int(11) DEFAULT NULL,
  `fileExists` tinyint(1) NOT NULL DEFAULT '0',
  `inProgress` tinyint(1) NOT NULL DEFAULT '0',
  `dateIndexed` datetime DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `assettransformindex_volumeId_assetId_location_idx` (`volumeId`,`assetId`,`location`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

DROP TABLE IF EXISTS `assettransforms`;
CREATE TABLE `assettransforms` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `handle` varchar(255) NOT NULL,
  `mode` enum('stretch','fit','crop') NOT NULL DEFAULT 'crop',
  `position` enum('top-left','top-center','top-right','center-left','center-center','center-right','bottom-left','bottom-center','bottom-right') NOT NULL DEFAULT 'center-center',
  `width` int(11) unsigned DEFAULT NULL,
  `height` int(11) unsigned DEFAULT NULL,
  `format` varchar(255) DEFAULT NULL,
  `quality` int(11) DEFAULT NULL,
  `interlace` enum('none','line','plane','partition') NOT NULL DEFAULT 'none',
  `dimensionChangeTime` datetime DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `assettransforms_name_unq_idx` (`name`),
  UNIQUE KEY `assettransforms_handle_unq_idx` (`handle`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

DROP TABLE IF EXISTS `categories`;
CREATE TABLE `categories` (
  `id` int(11) NOT NULL,
  `groupId` int(11) NOT NULL,
  `parentId` int(11) DEFAULT NULL,
  `deletedWithGroup` tinyint(1) DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `categories_groupId_idx` (`groupId`),
  KEY `categories_parentId_fk` (`parentId`),
  CONSTRAINT `categories_groupId_fk` FOREIGN KEY (`groupId`) REFERENCES `categorygroups` (`id`) ON DELETE CASCADE,
  CONSTRAINT `categories_id_fk` FOREIGN KEY (`id`) REFERENCES `elements` (`id`) ON DELETE CASCADE,
  CONSTRAINT `categories_parentId_fk` FOREIGN KEY (`parentId`) REFERENCES `categories` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

DROP TABLE IF EXISTS `categorygroups`;
CREATE TABLE `categorygroups` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `structureId` int(11) NOT NULL,
  `fieldLayoutId` int(11) DEFAULT NULL,
  `name` varchar(255) NOT NULL,
  `handle` varchar(255) NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `dateDeleted` datetime DEFAULT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `categorygroups_name_idx` (`name`),
  KEY `categorygroups_handle_idx` (`handle`),
  KEY `categorygroups_structureId_idx` (`structureId`),
  KEY `categorygroups_fieldLayoutId_idx` (`fieldLayoutId`),
  KEY `categorygroups_dateDeleted_idx` (`dateDeleted`),
  CONSTRAINT `categorygroups_fieldLayoutId_fk` FOREIGN KEY (`fieldLayoutId`) REFERENCES `fieldlayouts` (`id`) ON DELETE SET NULL,
  CONSTRAINT `categorygroups_structureId_fk` FOREIGN KEY (`structureId`) REFERENCES `structures` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;

DROP TABLE IF EXISTS `categorygroups_sites`;
CREATE TABLE `categorygroups_sites` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `groupId` int(11) NOT NULL,
  `siteId` int(11) NOT NULL,
  `hasUrls` tinyint(1) NOT NULL DEFAULT '1',
  `uriFormat` text,
  `template` varchar(500) DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `categorygroups_sites_groupId_siteId_unq_idx` (`groupId`,`siteId`),
  KEY `categorygroups_sites_siteId_idx` (`siteId`),
  CONSTRAINT `categorygroups_sites_groupId_fk` FOREIGN KEY (`groupId`) REFERENCES `categorygroups` (`id`) ON DELETE CASCADE,
  CONSTRAINT `categorygroups_sites_siteId_fk` FOREIGN KEY (`siteId`) REFERENCES `sites` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;

DROP TABLE IF EXISTS `content`;
CREATE TABLE `content` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `elementId` int(11) NOT NULL,
  `siteId` int(11) NOT NULL,
  `title` varchar(255) DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  `field_altText` text,
  `field_caption` text,
  `field_heading` text,
  `field_richText` text,
  `field_alignment` varchar(255) DEFAULT NULL,
  `field_textSize` varchar(255) DEFAULT NULL,
  `field_position` varchar(255) DEFAULT NULL,
  `field_summary` text,
  `field_cite` text,
  `field_table` text,
  `field_form` int(11) DEFAULT NULL,
  `field_width` varchar(255) DEFAULT NULL,
  `field_aspect` varchar(255) DEFAULT NULL,
  `field_autoplay` tinyint(1) DEFAULT NULL,
  `field_textColor` varchar(255) DEFAULT NULL,
  `field_backgroundColor` varchar(255) DEFAULT NULL,
  `field_grid` varchar(255) DEFAULT NULL,
  `field_padding` varchar(255) DEFAULT NULL,
  `field_tag` varchar(255) DEFAULT NULL,
  `field_transition` varchar(255) DEFAULT NULL,
  `field_keywords` text,
  `field_confirm` text,
  `field_code` text,
  `field_quote` text,
  `field_button` text,
  `field_location` text,
  `field_phone` text,
  `field_paginate` varchar(255) DEFAULT NULL,
  `field_altTitle` text,
  `field_email` varchar(255) DEFAULT NULL,
  `field_fax` text,
  PRIMARY KEY (`id`),
  UNIQUE KEY `content_elementId_siteId_unq_idx` (`elementId`,`siteId`),
  KEY `content_siteId_idx` (`siteId`),
  KEY `content_title_idx` (`title`),
  CONSTRAINT `content_elementId_fk` FOREIGN KEY (`elementId`) REFERENCES `elements` (`id`) ON DELETE CASCADE,
  CONSTRAINT `content_siteId_fk` FOREIGN KEY (`siteId`) REFERENCES `sites` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=37 DEFAULT CHARSET=utf8;

DROP TABLE IF EXISTS `craftidtokens`;
CREATE TABLE `craftidtokens` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `userId` int(11) NOT NULL,
  `accessToken` text NOT NULL,
  `expiryDate` datetime DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `craftidtokens_userId_fk` (`userId`),
  CONSTRAINT `craftidtokens_userId_fk` FOREIGN KEY (`userId`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

DROP TABLE IF EXISTS `deprecationerrors`;
CREATE TABLE `deprecationerrors` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `key` varchar(255) NOT NULL,
  `fingerprint` varchar(255) NOT NULL,
  `lastOccurrence` datetime NOT NULL,
  `file` varchar(255) NOT NULL,
  `line` smallint(6) unsigned DEFAULT NULL,
  `message` varchar(255) DEFAULT NULL,
  `traces` text,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `deprecationerrors_key_fingerprint_unq_idx` (`key`,`fingerprint`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

DROP TABLE IF EXISTS `drafts`;
CREATE TABLE `drafts` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `sourceId` int(11) DEFAULT NULL,
  `creatorId` int(11) DEFAULT NULL,
  `name` varchar(255) NOT NULL,
  `notes` text,
  PRIMARY KEY (`id`),
  KEY `drafts_creatorId_fk` (`creatorId`),
  KEY `drafts_sourceId_fk` (`sourceId`),
  CONSTRAINT `drafts_creatorId_fk` FOREIGN KEY (`creatorId`) REFERENCES `users` (`id`) ON DELETE SET NULL,
  CONSTRAINT `drafts_sourceId_fk` FOREIGN KEY (`sourceId`) REFERENCES `elements` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

DROP TABLE IF EXISTS `elementindexsettings`;
CREATE TABLE `elementindexsettings` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `type` varchar(255) NOT NULL,
  `settings` text,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `elementindexsettings_type_unq_idx` (`type`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;

DROP TABLE IF EXISTS `elements`;
CREATE TABLE `elements` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `draftId` int(11) DEFAULT NULL,
  `revisionId` int(11) DEFAULT NULL,
  `fieldLayoutId` int(11) DEFAULT NULL,
  `type` varchar(255) NOT NULL,
  `enabled` tinyint(1) NOT NULL DEFAULT '1',
  `archived` tinyint(1) NOT NULL DEFAULT '0',
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `dateDeleted` datetime DEFAULT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `elements_dateDeleted_idx` (`dateDeleted`),
  KEY `elements_fieldLayoutId_idx` (`fieldLayoutId`),
  KEY `elements_type_idx` (`type`),
  KEY `elements_enabled_idx` (`enabled`),
  KEY `elements_archived_dateCreated_idx` (`archived`,`dateCreated`),
  KEY `elements_draftId_fk` (`draftId`),
  KEY `elements_revisionId_fk` (`revisionId`),
  CONSTRAINT `elements_draftId_fk` FOREIGN KEY (`draftId`) REFERENCES `drafts` (`id`) ON DELETE CASCADE,
  CONSTRAINT `elements_fieldLayoutId_fk` FOREIGN KEY (`fieldLayoutId`) REFERENCES `fieldlayouts` (`id`) ON DELETE SET NULL,
  CONSTRAINT `elements_revisionId_fk` FOREIGN KEY (`revisionId`) REFERENCES `revisions` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=37 DEFAULT CHARSET=utf8;

DROP TABLE IF EXISTS `elements_sites`;
CREATE TABLE `elements_sites` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `elementId` int(11) NOT NULL,
  `siteId` int(11) NOT NULL,
  `slug` varchar(255) DEFAULT NULL,
  `uri` varchar(255) DEFAULT NULL,
  `enabled` tinyint(1) NOT NULL DEFAULT '1',
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `elements_sites_elementId_siteId_unq_idx` (`elementId`,`siteId`),
  KEY `elements_sites_siteId_idx` (`siteId`),
  KEY `elements_sites_slug_siteId_idx` (`slug`,`siteId`),
  KEY `elements_sites_enabled_idx` (`enabled`),
  KEY `elements_sites_uri_siteId_idx` (`uri`,`siteId`),
  CONSTRAINT `elements_sites_elementId_fk` FOREIGN KEY (`elementId`) REFERENCES `elements` (`id`) ON DELETE CASCADE,
  CONSTRAINT `elements_sites_siteId_fk` FOREIGN KEY (`siteId`) REFERENCES `sites` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=37 DEFAULT CHARSET=utf8;

DROP TABLE IF EXISTS `entries`;
CREATE TABLE `entries` (
  `id` int(11) NOT NULL,
  `sectionId` int(11) NOT NULL,
  `parentId` int(11) DEFAULT NULL,
  `typeId` int(11) NOT NULL,
  `authorId` int(11) DEFAULT NULL,
  `postDate` datetime DEFAULT NULL,
  `expiryDate` datetime DEFAULT NULL,
  `deletedWithEntryType` tinyint(1) DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `entries_postDate_idx` (`postDate`),
  KEY `entries_expiryDate_idx` (`expiryDate`),
  KEY `entries_authorId_idx` (`authorId`),
  KEY `entries_sectionId_idx` (`sectionId`),
  KEY `entries_typeId_idx` (`typeId`),
  KEY `entries_parentId_fk` (`parentId`),
  CONSTRAINT `entries_authorId_fk` FOREIGN KEY (`authorId`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  CONSTRAINT `entries_id_fk` FOREIGN KEY (`id`) REFERENCES `elements` (`id`) ON DELETE CASCADE,
  CONSTRAINT `entries_parentId_fk` FOREIGN KEY (`parentId`) REFERENCES `entries` (`id`) ON DELETE SET NULL,
  CONSTRAINT `entries_sectionId_fk` FOREIGN KEY (`sectionId`) REFERENCES `sections` (`id`) ON DELETE CASCADE,
  CONSTRAINT `entries_typeId_fk` FOREIGN KEY (`typeId`) REFERENCES `entrytypes` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

DROP TABLE IF EXISTS `entrytypes`;
CREATE TABLE `entrytypes` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `sectionId` int(11) NOT NULL,
  `fieldLayoutId` int(11) DEFAULT NULL,
  `name` varchar(255) NOT NULL,
  `handle` varchar(255) NOT NULL,
  `hasTitleField` tinyint(1) NOT NULL DEFAULT '1',
  `titleLabel` varchar(255) DEFAULT 'Title',
  `titleFormat` varchar(255) DEFAULT NULL,
  `sortOrder` smallint(6) unsigned DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `dateDeleted` datetime DEFAULT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `entrytypes_name_sectionId_idx` (`name`,`sectionId`),
  KEY `entrytypes_handle_sectionId_idx` (`handle`,`sectionId`),
  KEY `entrytypes_sectionId_idx` (`sectionId`),
  KEY `entrytypes_fieldLayoutId_idx` (`fieldLayoutId`),
  KEY `entrytypes_dateDeleted_idx` (`dateDeleted`),
  CONSTRAINT `entrytypes_fieldLayoutId_fk` FOREIGN KEY (`fieldLayoutId`) REFERENCES `fieldlayouts` (`id`) ON DELETE SET NULL,
  CONSTRAINT `entrytypes_sectionId_fk` FOREIGN KEY (`sectionId`) REFERENCES `sections` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8;

DROP TABLE IF EXISTS `fieldgroups`;
CREATE TABLE `fieldgroups` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `fieldgroups_name_unq_idx` (`name`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8;

DROP TABLE IF EXISTS `fieldlabels`;
CREATE TABLE `fieldlabels` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `fieldId` int(11) NOT NULL,
  `fieldLayoutId` int(11) NOT NULL,
  `name` varchar(255) DEFAULT NULL,
  `instructions` text,
  `hideName` tinyint(1) NOT NULL,
  `hideInstructions` tinyint(1) NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `fieldlabels_fieldId_idx` (`fieldId`),
  KEY `fieldlabels_fieldLayoutId_idx` (`fieldLayoutId`),
  CONSTRAINT `fieldlabels_fieldId_fk` FOREIGN KEY (`fieldId`) REFERENCES `fields` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fieldlabels_fieldLayoutId_fk` FOREIGN KEY (`fieldLayoutId`) REFERENCES `fieldlayouts` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=81 DEFAULT CHARSET=utf8;

DROP TABLE IF EXISTS `fieldlayoutfields`;
CREATE TABLE `fieldlayoutfields` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `layoutId` int(11) NOT NULL,
  `tabId` int(11) NOT NULL,
  `fieldId` int(11) NOT NULL,
  `required` tinyint(1) NOT NULL DEFAULT '0',
  `sortOrder` smallint(6) unsigned DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `fieldlayoutfields_layoutId_fieldId_unq_idx` (`layoutId`,`fieldId`),
  KEY `fieldlayoutfields_sortOrder_idx` (`sortOrder`),
  KEY `fieldlayoutfields_tabId_idx` (`tabId`),
  KEY `fieldlayoutfields_fieldId_idx` (`fieldId`),
  CONSTRAINT `fieldlayoutfields_fieldId_fk` FOREIGN KEY (`fieldId`) REFERENCES `fields` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fieldlayoutfields_layoutId_fk` FOREIGN KEY (`layoutId`) REFERENCES `fieldlayouts` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fieldlayoutfields_tabId_fk` FOREIGN KEY (`tabId`) REFERENCES `fieldlayouttabs` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=592 DEFAULT CHARSET=utf8;

DROP TABLE IF EXISTS `fieldlayouts`;
CREATE TABLE `fieldlayouts` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `type` varchar(255) NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `dateDeleted` datetime DEFAULT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `fieldlayouts_dateDeleted_idx` (`dateDeleted`),
  KEY `fieldlayouts_type_idx` (`type`)
) ENGINE=InnoDB AUTO_INCREMENT=44 DEFAULT CHARSET=utf8;

DROP TABLE IF EXISTS `fieldlayouttabs`;
CREATE TABLE `fieldlayouttabs` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `layoutId` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `sortOrder` smallint(6) unsigned DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `fieldlayouttabs_sortOrder_idx` (`sortOrder`),
  KEY `fieldlayouttabs_layoutId_idx` (`layoutId`),
  CONSTRAINT `fieldlayouttabs_layoutId_fk` FOREIGN KEY (`layoutId`) REFERENCES `fieldlayouts` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=363 DEFAULT CHARSET=utf8;

DROP TABLE IF EXISTS `fields`;
CREATE TABLE `fields` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `groupId` int(11) DEFAULT NULL,
  `name` varchar(255) NOT NULL,
  `handle` varchar(64) NOT NULL,
  `context` varchar(255) NOT NULL DEFAULT 'global',
  `instructions` text,
  `searchable` tinyint(1) NOT NULL DEFAULT '1',
  `translationMethod` varchar(255) NOT NULL DEFAULT 'none',
  `translationKeyFormat` text,
  `type` varchar(255) NOT NULL,
  `settings` text,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `fields_handle_context_unq_idx` (`handle`,`context`),
  KEY `fields_groupId_idx` (`groupId`),
  KEY `fields_context_idx` (`context`),
  CONSTRAINT `fields_groupId_fk` FOREIGN KEY (`groupId`) REFERENCES `fieldgroups` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=41 DEFAULT CHARSET=utf8;

DROP TABLE IF EXISTS `freeform_crm_fields`;
CREATE TABLE `freeform_crm_fields` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `integrationId` int(11) NOT NULL,
  `label` varchar(255) NOT NULL,
  `handle` varchar(255) NOT NULL,
  `type` varchar(50) NOT NULL,
  `required` tinyint(1) DEFAULT '0',
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `freeform_crm_fields_type_idx` (`type`),
  KEY `freeform_crm_fields_integrationId_fk` (`integrationId`),
  CONSTRAINT `freeform_crm_fields_integrationId_fk` FOREIGN KEY (`integrationId`) REFERENCES `freeform_integrations` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

DROP TABLE IF EXISTS `freeform_export_profiles`;
CREATE TABLE `freeform_export_profiles` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `formId` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `limit` int(11) DEFAULT NULL,
  `dateRange` varchar(255) DEFAULT NULL,
  `fields` text NOT NULL,
  `filters` text,
  `statuses` text NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `name` (`name`),
  KEY `freeform_export_profiles_formId_fk` (`formId`),
  CONSTRAINT `freeform_export_profiles_formId_fk` FOREIGN KEY (`formId`) REFERENCES `freeform_forms` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

DROP TABLE IF EXISTS `freeform_export_settings`;
CREATE TABLE `freeform_export_settings` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `userId` int(11) NOT NULL,
  `setting` text,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `freeform_export_settings_userId_fk` (`userId`),
  CONSTRAINT `freeform_export_settings_userId_fk` FOREIGN KEY (`userId`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

DROP TABLE IF EXISTS `freeform_fields`;
CREATE TABLE `freeform_fields` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `type` varchar(50) NOT NULL,
  `handle` varchar(255) NOT NULL,
  `label` varchar(255) DEFAULT NULL,
  `required` tinyint(1) DEFAULT '0',
  `instructions` text,
  `metaProperties` text,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `handle` (`handle`),
  KEY `freeform_fields_type_idx` (`type`)
) ENGINE=InnoDB AUTO_INCREMENT=15 DEFAULT CHARSET=utf8;

DROP TABLE IF EXISTS `freeform_forms`;
CREATE TABLE `freeform_forms` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `handle` varchar(100) NOT NULL,
  `spamBlockCount` int(11) unsigned NOT NULL DEFAULT '0',
  `submissionTitleFormat` varchar(255) NOT NULL,
  `description` text,
  `layoutJson` mediumtext,
  `returnUrl` varchar(255) DEFAULT NULL,
  `defaultStatus` int(11) unsigned DEFAULT NULL,
  `formTemplateId` int(11) unsigned DEFAULT NULL,
  `color` varchar(10) DEFAULT NULL,
  `optInDataStorageTargetHash` varchar(20) DEFAULT NULL,
  `limitFormSubmissions` varchar(20) DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  `extraPostUrl` varchar(255) DEFAULT NULL,
  `extraPostTriggerPhrase` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `handle` (`handle`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

DROP TABLE IF EXISTS `freeform_integrations`;
CREATE TABLE `freeform_integrations` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `handle` varchar(255) NOT NULL,
  `type` varchar(50) NOT NULL,
  `class` varchar(255) DEFAULT NULL,
  `accessToken` varchar(255) DEFAULT NULL,
  `settings` text,
  `forceUpdate` tinyint(1) DEFAULT '0',
  `lastUpdate` datetime DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `handle` (`handle`),
  KEY `freeform_integrations_type_idx` (`type`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

DROP TABLE IF EXISTS `freeform_integrations_queue`;
CREATE TABLE `freeform_integrations_queue` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `submissionId` int(11) NOT NULL,
  `integrationType` varchar(50) NOT NULL,
  `status` varchar(50) NOT NULL,
  `fieldHash` varchar(20) DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `freeform_integrations_queue_status_unq_idx` (`status`),
  KEY `freeform_integrations_queue_submissionId_fk` (`submissionId`),
  CONSTRAINT `freeform_integrations_queue_id_fk` FOREIGN KEY (`id`) REFERENCES `freeform_mailing_list_fields` (`id`) ON DELETE CASCADE,
  CONSTRAINT `freeform_integrations_queue_submissionId_fk` FOREIGN KEY (`submissionId`) REFERENCES `freeform_submissions` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

DROP TABLE IF EXISTS `freeform_mailing_list_fields`;
CREATE TABLE `freeform_mailing_list_fields` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `mailingListId` int(11) NOT NULL,
  `label` varchar(255) NOT NULL,
  `handle` varchar(255) NOT NULL,
  `type` varchar(50) NOT NULL,
  `required` tinyint(1) DEFAULT '0',
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `freeform_mailing_list_fields_type_idx` (`type`),
  KEY `freeform_mailing_list_fields_mailingListId_fk` (`mailingListId`),
  CONSTRAINT `freeform_mailing_list_fields_mailingListId_fk` FOREIGN KEY (`mailingListId`) REFERENCES `freeform_mailing_lists` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

DROP TABLE IF EXISTS `freeform_mailing_lists`;
CREATE TABLE `freeform_mailing_lists` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `integrationId` int(11) NOT NULL,
  `resourceId` varchar(255) NOT NULL,
  `name` varchar(255) NOT NULL,
  `memberCount` int(11) DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `freeform_mailing_lists_integrationId_resourceId_unq_idx` (`integrationId`,`resourceId`),
  CONSTRAINT `freeform_mailing_lists_integrationId_fk` FOREIGN KEY (`integrationId`) REFERENCES `freeform_integrations` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

DROP TABLE IF EXISTS `freeform_notifications`;
CREATE TABLE `freeform_notifications` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `handle` varchar(255) NOT NULL,
  `subject` varchar(255) NOT NULL,
  `description` text,
  `fromName` varchar(255) NOT NULL,
  `fromEmail` varchar(255) NOT NULL,
  `replyToEmail` varchar(255) DEFAULT NULL,
  `cc` varchar(255) DEFAULT NULL,
  `bcc` varchar(255) DEFAULT NULL,
  `bodyHtml` text,
  `bodyText` text,
  `includeAttachments` tinyint(1) DEFAULT '1',
  `presetAssets` varchar(255) DEFAULT NULL,
  `sortOrder` int(11) DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `handle` (`handle`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

DROP TABLE IF EXISTS `freeform_payment_gateway_fields`;
CREATE TABLE `freeform_payment_gateway_fields` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `integrationId` int(11) NOT NULL,
  `label` varchar(255) NOT NULL,
  `handle` varchar(255) NOT NULL,
  `type` varchar(50) NOT NULL,
  `required` tinyint(1) DEFAULT '0',
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `freeform_payment_gateway_fields_type_idx` (`type`),
  KEY `freeform_payment_gateway_fields_integrationId_fk` (`integrationId`),
  CONSTRAINT `freeform_payment_gateway_fields_integrationId_fk` FOREIGN KEY (`integrationId`) REFERENCES `freeform_integrations` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

DROP TABLE IF EXISTS `freeform_payments_payments`;
CREATE TABLE `freeform_payments_payments` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `integrationId` int(11) NOT NULL,
  `submissionId` int(11) NOT NULL,
  `subscriptionId` int(11) DEFAULT NULL,
  `resourceId` varchar(50) DEFAULT NULL,
  `amount` float DEFAULT NULL,
  `currency` varchar(3) DEFAULT NULL,
  `last4` smallint(6) DEFAULT NULL,
  `status` varchar(20) DEFAULT NULL,
  `metadata` mediumtext,
  `errorCode` varchar(20) DEFAULT NULL,
  `errorMessage` varchar(255) DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `freeform_payments_payments_integrationId_resourceId_unq_idx` (`integrationId`,`resourceId`),
  KEY `freeform_payments_payments_submissionId_fk` (`submissionId`),
  KEY `freeform_payments_payments_subscriptionId_fk` (`subscriptionId`),
  CONSTRAINT `freeform_payments_payments_integrationId_fk` FOREIGN KEY (`integrationId`) REFERENCES `freeform_integrations` (`id`) ON DELETE CASCADE,
  CONSTRAINT `freeform_payments_payments_submissionId_fk` FOREIGN KEY (`submissionId`) REFERENCES `freeform_submissions` (`id`) ON DELETE CASCADE,
  CONSTRAINT `freeform_payments_payments_subscriptionId_fk` FOREIGN KEY (`subscriptionId`) REFERENCES `freeform_payments_subscriptions` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

DROP TABLE IF EXISTS `freeform_payments_subscription_plans`;
CREATE TABLE `freeform_payments_subscription_plans` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `integrationId` int(11) NOT NULL,
  `resourceId` varchar(255) DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  `status` varchar(20) DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `freeform_payments_subscription_plans_integrationId_fk` (`integrationId`),
  CONSTRAINT `freeform_payments_subscription_plans_integrationId_fk` FOREIGN KEY (`integrationId`) REFERENCES `freeform_integrations` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

DROP TABLE IF EXISTS `freeform_payments_subscriptions`;
CREATE TABLE `freeform_payments_subscriptions` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `integrationId` int(11) NOT NULL,
  `submissionId` int(11) NOT NULL,
  `planId` int(11) NOT NULL,
  `resourceId` varchar(50) DEFAULT NULL,
  `amount` float DEFAULT NULL,
  `currency` varchar(3) DEFAULT NULL,
  `interval` varchar(20) DEFAULT NULL,
  `intervalCount` smallint(6) DEFAULT NULL,
  `last4` smallint(6) DEFAULT NULL,
  `status` varchar(20) DEFAULT NULL,
  `metadata` mediumtext,
  `errorCode` varchar(20) DEFAULT NULL,
  `errorMessage` varchar(255) DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `freeform_payments_subscriptions_integrationId_resourceId_unq_idx` (`integrationId`,`resourceId`),
  KEY `freeform_payments_subscriptions_submissionId_fk` (`submissionId`),
  KEY `freeform_payments_subscriptions_planId_fk` (`planId`),
  CONSTRAINT `freeform_payments_subscriptions_integrationId_fk` FOREIGN KEY (`integrationId`) REFERENCES `freeform_integrations` (`id`) ON DELETE CASCADE,
  CONSTRAINT `freeform_payments_subscriptions_planId_fk` FOREIGN KEY (`planId`) REFERENCES `freeform_payments_subscription_plans` (`id`) ON DELETE CASCADE,
  CONSTRAINT `freeform_payments_subscriptions_submissionId_fk` FOREIGN KEY (`submissionId`) REFERENCES `freeform_submissions` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

DROP TABLE IF EXISTS `freeform_statuses`;
CREATE TABLE `freeform_statuses` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `handle` varchar(255) NOT NULL,
  `color` varchar(30) DEFAULT NULL,
  `isDefault` tinyint(1) DEFAULT NULL,
  `sortOrder` int(11) DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `handle` (`handle`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;

DROP TABLE IF EXISTS `freeform_submission_notes`;
CREATE TABLE `freeform_submission_notes` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `submissionId` int(11) NOT NULL,
  `note` text,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `freeform_submission_notes_submissionId_fk` (`submissionId`),
  CONSTRAINT `freeform_submission_notes_submissionId_fk` FOREIGN KEY (`submissionId`) REFERENCES `freeform_submissions` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

DROP TABLE IF EXISTS `freeform_submissions`;
CREATE TABLE `freeform_submissions` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `incrementalId` int(11) NOT NULL,
  `statusId` int(11) DEFAULT NULL,
  `formId` int(11) NOT NULL,
  `token` varchar(100) NOT NULL,
  `ip` varchar(46) DEFAULT NULL,
  `isSpam` tinyint(1) DEFAULT '0',
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  `field_1` varchar(100) DEFAULT NULL,
  `field_2` varchar(100) DEFAULT NULL,
  `field_3` text,
  `field_4` varchar(100) DEFAULT NULL,
  `field_5` varchar(100) DEFAULT NULL,
  `field_6` varchar(100) DEFAULT NULL,
  `field_7` varchar(100) DEFAULT NULL,
  `field_8` text,
  `field_9` varchar(100) DEFAULT NULL,
  `field_10` varchar(100) DEFAULT NULL,
  `field_11` varchar(100) DEFAULT NULL,
  `field_12` text,
  `field_13` varchar(100) DEFAULT NULL,
  `field_14` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `freeform_submissions_incrementalId_unq_idx` (`incrementalId`),
  UNIQUE KEY `freeform_submissions_token_unq_idx` (`token`),
  KEY `freeform_submissions_formId_fk` (`formId`),
  KEY `freeform_submissions_statusId_fk` (`statusId`),
  CONSTRAINT `freeform_submissions_formId_fk` FOREIGN KEY (`formId`) REFERENCES `freeform_forms` (`id`) ON DELETE CASCADE,
  CONSTRAINT `freeform_submissions_id_fk` FOREIGN KEY (`id`) REFERENCES `elements` (`id`) ON DELETE CASCADE,
  CONSTRAINT `freeform_submissions_statusId_fk` FOREIGN KEY (`statusId`) REFERENCES `freeform_statuses` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

DROP TABLE IF EXISTS `freeform_unfinalized_files`;
CREATE TABLE `freeform_unfinalized_files` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `assetId` int(11) NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

DROP TABLE IF EXISTS `freeform_webhooks`;
CREATE TABLE `freeform_webhooks` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `type` varchar(255) NOT NULL,
  `name` varchar(255) NOT NULL,
  `webhook` varchar(255) NOT NULL,
  `settings` text,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `freeform_webhooks_type_idx` (`type`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

DROP TABLE IF EXISTS `freeform_webhooks_form_relations`;
CREATE TABLE `freeform_webhooks_form_relations` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `webhookId` int(11) NOT NULL,
  `formId` int(11) NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `freeform_webhooks_form_relations_webhookId_idx` (`webhookId`),
  KEY `freeform_webhooks_form_relations_formId_idx` (`formId`),
  CONSTRAINT `freeform_webhooks_form_relations_formId_fk` FOREIGN KEY (`formId`) REFERENCES `freeform_forms` (`id`) ON DELETE CASCADE,
  CONSTRAINT `freeform_webhooks_form_relations_webhookId_fk` FOREIGN KEY (`webhookId`) REFERENCES `freeform_webhooks` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

DROP TABLE IF EXISTS `globalsets`;
CREATE TABLE `globalsets` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `handle` varchar(255) NOT NULL,
  `fieldLayoutId` int(11) DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `globalsets_name_idx` (`name`),
  KEY `globalsets_handle_idx` (`handle`),
  KEY `globalsets_fieldLayoutId_idx` (`fieldLayoutId`),
  CONSTRAINT `globalsets_fieldLayoutId_fk` FOREIGN KEY (`fieldLayoutId`) REFERENCES `fieldlayouts` (`id`) ON DELETE SET NULL,
  CONSTRAINT `globalsets_id_fk` FOREIGN KEY (`id`) REFERENCES `elements` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=16 DEFAULT CHARSET=utf8;

DROP TABLE IF EXISTS `gqlschemas`;
CREATE TABLE `gqlschemas` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `accessToken` varchar(255) NOT NULL,
  `enabled` tinyint(1) NOT NULL DEFAULT '1',
  `expiryDate` datetime DEFAULT NULL,
  `lastUsed` datetime DEFAULT NULL,
  `scope` text,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `gqlschemas_accessToken_unq_idx` (`accessToken`),
  UNIQUE KEY `gqlschemas_name_unq_idx` (`name`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;

DROP TABLE IF EXISTS `info`;
CREATE TABLE `info` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `version` varchar(50) NOT NULL,
  `schemaVersion` varchar(15) NOT NULL,
  `maintenance` tinyint(1) NOT NULL DEFAULT '0',
  `config` mediumtext,
  `configMap` mediumtext,
  `fieldVersion` char(12) NOT NULL DEFAULT '000000000000',
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;

DROP TABLE IF EXISTS `maps`;
CREATE TABLE `maps` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `ownerId` int(11) NOT NULL,
  `ownerSiteId` int(11) DEFAULT NULL,
  `fieldId` int(11) NOT NULL,
  `lat` decimal(11,9) DEFAULT NULL,
  `lng` decimal(12,9) DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `maps_ownerId_ownerSiteId_fieldId_unq_idx` (`ownerId`,`ownerSiteId`,`fieldId`),
  KEY `maps_lat_idx` (`lat`),
  KEY `maps_lng_idx` (`lng`),
  KEY `maps_ownerSiteId_fk` (`ownerSiteId`),
  KEY `maps_fieldId_fk` (`fieldId`),
  CONSTRAINT `maps_fieldId_fk` FOREIGN KEY (`fieldId`) REFERENCES `fields` (`id`) ON DELETE CASCADE,
  CONSTRAINT `maps_ownerId_fk` FOREIGN KEY (`ownerId`) REFERENCES `elements` (`id`) ON DELETE CASCADE,
  CONSTRAINT `maps_ownerSiteId_fk` FOREIGN KEY (`ownerSiteId`) REFERENCES `sites` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;

DROP TABLE IF EXISTS `matrixblocks`;
CREATE TABLE `matrixblocks` (
  `id` int(11) NOT NULL,
  `ownerId` int(11) NOT NULL,
  `fieldId` int(11) NOT NULL,
  `typeId` int(11) NOT NULL,
  `sortOrder` smallint(6) unsigned DEFAULT NULL,
  `deletedWithOwner` tinyint(1) DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `matrixblocks_ownerId_idx` (`ownerId`),
  KEY `matrixblocks_fieldId_idx` (`fieldId`),
  KEY `matrixblocks_typeId_idx` (`typeId`),
  KEY `matrixblocks_sortOrder_idx` (`sortOrder`),
  CONSTRAINT `matrixblocks_fieldId_fk` FOREIGN KEY (`fieldId`) REFERENCES `fields` (`id`) ON DELETE CASCADE,
  CONSTRAINT `matrixblocks_id_fk` FOREIGN KEY (`id`) REFERENCES `elements` (`id`) ON DELETE CASCADE,
  CONSTRAINT `matrixblocks_ownerId_fk` FOREIGN KEY (`ownerId`) REFERENCES `elements` (`id`) ON DELETE CASCADE,
  CONSTRAINT `matrixblocks_typeId_fk` FOREIGN KEY (`typeId`) REFERENCES `matrixblocktypes` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

DROP TABLE IF EXISTS `matrixblocktypes`;
CREATE TABLE `matrixblocktypes` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `fieldId` int(11) NOT NULL,
  `fieldLayoutId` int(11) DEFAULT NULL,
  `name` varchar(255) NOT NULL,
  `handle` varchar(255) NOT NULL,
  `sortOrder` smallint(6) unsigned DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `matrixblocktypes_name_fieldId_unq_idx` (`name`,`fieldId`),
  UNIQUE KEY `matrixblocktypes_handle_fieldId_unq_idx` (`handle`,`fieldId`),
  KEY `matrixblocktypes_fieldId_idx` (`fieldId`),
  KEY `matrixblocktypes_fieldLayoutId_idx` (`fieldLayoutId`),
  CONSTRAINT `matrixblocktypes_fieldId_fk` FOREIGN KEY (`fieldId`) REFERENCES `fields` (`id`) ON DELETE CASCADE,
  CONSTRAINT `matrixblocktypes_fieldLayoutId_fk` FOREIGN KEY (`fieldLayoutId`) REFERENCES `fieldlayouts` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

DROP TABLE IF EXISTS `migrations`;
CREATE TABLE `migrations` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `pluginId` int(11) DEFAULT NULL,
  `type` enum('app','plugin','content') NOT NULL DEFAULT 'app',
  `name` varchar(255) NOT NULL,
  `applyTime` datetime NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `migrations_pluginId_idx` (`pluginId`),
  KEY `migrations_type_pluginId_idx` (`type`,`pluginId`),
  CONSTRAINT `migrations_pluginId_fk` FOREIGN KEY (`pluginId`) REFERENCES `plugins` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=241 DEFAULT CHARSET=utf8;

DROP TABLE IF EXISTS `navigation_navs`;
CREATE TABLE `navigation_navs` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `structureId` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `handle` varchar(255) NOT NULL,
  `instructions` text,
  `sortOrder` smallint(6) unsigned DEFAULT NULL,
  `propagateNodes` tinyint(1) DEFAULT '0',
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `dateDeleted` datetime DEFAULT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `navigation_navs_handle_idx` (`handle`),
  KEY `navigation_navs_structureId_idx` (`structureId`),
  KEY `navigation_navs_dateDeleted_idx` (`dateDeleted`),
  CONSTRAINT `navigation_navs_structureId_fk` FOREIGN KEY (`structureId`) REFERENCES `structures` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;

DROP TABLE IF EXISTS `navigation_nodes`;
CREATE TABLE `navigation_nodes` (
  `id` int(11) NOT NULL,
  `elementId` int(11) DEFAULT NULL,
  `navId` int(11) NOT NULL,
  `parentId` int(11) DEFAULT NULL,
  `url` varchar(255) DEFAULT NULL,
  `type` varchar(255) DEFAULT NULL,
  `classes` varchar(255) DEFAULT NULL,
  `newWindow` tinyint(1) DEFAULT '0',
  `deletedWithNav` tinyint(1) DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `navigation_nodes_navId_idx` (`navId`),
  KEY `navigation_nodes_elementId_fk` (`elementId`),
  CONSTRAINT `navigation_nodes_elementId_fk` FOREIGN KEY (`elementId`) REFERENCES `elements` (`id`) ON DELETE SET NULL,
  CONSTRAINT `navigation_nodes_id_fk` FOREIGN KEY (`id`) REFERENCES `elements` (`id`) ON DELETE CASCADE,
  CONSTRAINT `navigation_nodes_navId_fk` FOREIGN KEY (`navId`) REFERENCES `navigation_navs` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

DROP TABLE IF EXISTS `neoblocks`;
CREATE TABLE `neoblocks` (
  `id` int(11) NOT NULL,
  `ownerId` int(11) NOT NULL,
  `ownerSiteId` int(11) DEFAULT NULL,
  `fieldId` int(11) NOT NULL,
  `typeId` int(11) NOT NULL,
  `deletedWithOwner` tinyint(1) DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `neoblocks_ownerId_idx` (`ownerId`),
  KEY `neoblocks_ownerSiteId_idx` (`ownerSiteId`),
  KEY `neoblocks_fieldId_idx` (`fieldId`),
  KEY `neoblocks_typeId_idx` (`typeId`),
  CONSTRAINT `neoblocks_fieldId_fk` FOREIGN KEY (`fieldId`) REFERENCES `fields` (`id`) ON DELETE CASCADE,
  CONSTRAINT `neoblocks_id_fk` FOREIGN KEY (`id`) REFERENCES `elements` (`id`) ON DELETE CASCADE,
  CONSTRAINT `neoblocks_ownerId_fk` FOREIGN KEY (`ownerId`) REFERENCES `elements` (`id`) ON DELETE CASCADE,
  CONSTRAINT `neoblocks_ownerSiteId_fk` FOREIGN KEY (`ownerSiteId`) REFERENCES `sites` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `neoblocks_typeId_fk` FOREIGN KEY (`typeId`) REFERENCES `neoblocktypes` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

DROP TABLE IF EXISTS `neoblockstructures`;
CREATE TABLE `neoblockstructures` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `structureId` int(11) NOT NULL,
  `ownerId` int(11) NOT NULL,
  `ownerSiteId` int(11) DEFAULT NULL,
  `fieldId` int(11) NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `neoblockstructures_structureId_idx` (`structureId`),
  KEY `neoblockstructures_ownerId_idx` (`ownerId`),
  KEY `neoblockstructures_ownerSiteId_idx` (`ownerSiteId`),
  KEY `neoblockstructures_fieldId_idx` (`fieldId`),
  CONSTRAINT `neoblockstructures_fieldId_fk` FOREIGN KEY (`fieldId`) REFERENCES `fields` (`id`) ON DELETE CASCADE,
  CONSTRAINT `neoblockstructures_ownerId_fk` FOREIGN KEY (`ownerId`) REFERENCES `elements` (`id`) ON DELETE CASCADE,
  CONSTRAINT `neoblockstructures_ownerSiteId_fk` FOREIGN KEY (`ownerSiteId`) REFERENCES `sites` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `neoblockstructures_structureId_fk` FOREIGN KEY (`structureId`) REFERENCES `structures` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;

DROP TABLE IF EXISTS `neoblocktypegroups`;
CREATE TABLE `neoblocktypegroups` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `fieldId` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `sortOrder` smallint(6) unsigned DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `neoblocktypegroups_name_fieldId_idx` (`name`,`fieldId`),
  KEY `neoblocktypegroups_fieldId_idx` (`fieldId`),
  CONSTRAINT `neoblocktypegroups_fieldId_fk` FOREIGN KEY (`fieldId`) REFERENCES `fields` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=56 DEFAULT CHARSET=utf8;

DROP TABLE IF EXISTS `neoblocktypes`;
CREATE TABLE `neoblocktypes` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `fieldId` int(11) NOT NULL,
  `fieldLayoutId` int(11) DEFAULT NULL,
  `name` varchar(255) NOT NULL,
  `handle` varchar(255) NOT NULL,
  `maxBlocks` smallint(6) unsigned DEFAULT NULL,
  `maxChildBlocks` smallint(6) unsigned DEFAULT NULL,
  `childBlocks` text,
  `topLevel` tinyint(1) NOT NULL DEFAULT '1',
  `sortOrder` smallint(6) unsigned DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `neoblocktypes_handle_fieldId_unq_idx` (`handle`,`fieldId`),
  KEY `neoblocktypes_name_fieldId_idx` (`name`,`fieldId`),
  KEY `neoblocktypes_fieldId_idx` (`fieldId`),
  KEY `neoblocktypes_fieldLayoutId_idx` (`fieldLayoutId`),
  CONSTRAINT `neoblocktypes_fieldId_fk` FOREIGN KEY (`fieldId`) REFERENCES `fields` (`id`) ON DELETE CASCADE,
  CONSTRAINT `neoblocktypes_fieldLayoutId_fk` FOREIGN KEY (`fieldLayoutId`) REFERENCES `fieldlayouts` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=34 DEFAULT CHARSET=utf8;

DROP TABLE IF EXISTS `plugins`;
CREATE TABLE `plugins` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `handle` varchar(255) NOT NULL,
  `version` varchar(255) NOT NULL,
  `schemaVersion` varchar(255) NOT NULL,
  `licenseKeyStatus` enum('valid','invalid','mismatched','astray','unknown') NOT NULL DEFAULT 'unknown',
  `licensedEdition` varchar(255) DEFAULT NULL,
  `installDate` datetime NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `plugins_handle_unq_idx` (`handle`)
) ENGINE=InnoDB AUTO_INCREMENT=20 DEFAULT CHARSET=utf8;

DROP TABLE IF EXISTS `queue`;
CREATE TABLE `queue` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `job` longblob NOT NULL,
  `description` text,
  `timePushed` int(11) NOT NULL,
  `ttr` int(11) NOT NULL,
  `delay` int(11) NOT NULL DEFAULT '0',
  `priority` int(11) unsigned NOT NULL DEFAULT '1024',
  `dateReserved` datetime DEFAULT NULL,
  `timeUpdated` int(11) DEFAULT NULL,
  `progress` smallint(6) NOT NULL DEFAULT '0',
  `progressLabel` varchar(255) DEFAULT NULL,
  `attempt` int(11) DEFAULT NULL,
  `fail` tinyint(1) DEFAULT '0',
  `dateFailed` datetime DEFAULT NULL,
  `error` text,
  PRIMARY KEY (`id`),
  KEY `queue_fail_timeUpdated_timePushed_idx` (`fail`,`timeUpdated`,`timePushed`),
  KEY `queue_fail_timeUpdated_delay_idx` (`fail`,`timeUpdated`,`delay`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

DROP TABLE IF EXISTS `relations`;
CREATE TABLE `relations` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `fieldId` int(11) NOT NULL,
  `sourceId` int(11) NOT NULL,
  `sourceSiteId` int(11) DEFAULT NULL,
  `targetId` int(11) NOT NULL,
  `sortOrder` smallint(6) unsigned DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `relations_fieldId_sourceId_sourceSiteId_targetId_unq_idx` (`fieldId`,`sourceId`,`sourceSiteId`,`targetId`),
  KEY `relations_sourceId_idx` (`sourceId`),
  KEY `relations_targetId_idx` (`targetId`),
  KEY `relations_sourceSiteId_idx` (`sourceSiteId`),
  CONSTRAINT `relations_fieldId_fk` FOREIGN KEY (`fieldId`) REFERENCES `fields` (`id`) ON DELETE CASCADE,
  CONSTRAINT `relations_sourceId_fk` FOREIGN KEY (`sourceId`) REFERENCES `elements` (`id`) ON DELETE CASCADE,
  CONSTRAINT `relations_sourceSiteId_fk` FOREIGN KEY (`sourceSiteId`) REFERENCES `sites` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `relations_targetId_fk` FOREIGN KEY (`targetId`) REFERENCES `elements` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

DROP TABLE IF EXISTS `resourcepaths`;
CREATE TABLE `resourcepaths` (
  `hash` varchar(255) NOT NULL,
  `path` varchar(255) NOT NULL,
  PRIMARY KEY (`hash`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

DROP TABLE IF EXISTS `revisions`;
CREATE TABLE `revisions` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `sourceId` int(11) NOT NULL,
  `creatorId` int(11) DEFAULT NULL,
  `num` int(11) NOT NULL,
  `notes` text,
  PRIMARY KEY (`id`),
  UNIQUE KEY `revisions_sourceId_num_unq_idx` (`sourceId`,`num`),
  KEY `revisions_creatorId_fk` (`creatorId`),
  CONSTRAINT `revisions_creatorId_fk` FOREIGN KEY (`creatorId`) REFERENCES `users` (`id`) ON DELETE SET NULL,
  CONSTRAINT `revisions_sourceId_fk` FOREIGN KEY (`sourceId`) REFERENCES `elements` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8;

DROP TABLE IF EXISTS `searchindex`;
CREATE TABLE `searchindex` (
  `elementId` int(11) NOT NULL,
  `attribute` varchar(25) NOT NULL,
  `fieldId` int(11) NOT NULL,
  `siteId` int(11) NOT NULL,
  `keywords` text NOT NULL,
  PRIMARY KEY (`elementId`,`attribute`,`fieldId`,`siteId`),
  FULLTEXT KEY `searchindex_keywords_idx` (`keywords`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

DROP TABLE IF EXISTS `sections`;
CREATE TABLE `sections` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `structureId` int(11) DEFAULT NULL,
  `name` varchar(255) NOT NULL,
  `handle` varchar(255) NOT NULL,
  `type` enum('single','channel','structure') NOT NULL DEFAULT 'channel',
  `enableVersioning` tinyint(1) NOT NULL DEFAULT '0',
  `propagationMethod` varchar(255) NOT NULL DEFAULT 'all',
  `previewTargets` text,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `dateDeleted` datetime DEFAULT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `sections_handle_idx` (`handle`),
  KEY `sections_name_idx` (`name`),
  KEY `sections_structureId_idx` (`structureId`),
  KEY `sections_dateDeleted_idx` (`dateDeleted`),
  CONSTRAINT `sections_structureId_fk` FOREIGN KEY (`structureId`) REFERENCES `structures` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;

DROP TABLE IF EXISTS `sections_sites`;
CREATE TABLE `sections_sites` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `sectionId` int(11) NOT NULL,
  `siteId` int(11) NOT NULL,
  `hasUrls` tinyint(1) NOT NULL DEFAULT '1',
  `uriFormat` text,
  `template` varchar(500) DEFAULT NULL,
  `enabledByDefault` tinyint(1) NOT NULL DEFAULT '1',
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `sections_sites_sectionId_siteId_unq_idx` (`sectionId`,`siteId`),
  KEY `sections_sites_siteId_idx` (`siteId`),
  CONSTRAINT `sections_sites_sectionId_fk` FOREIGN KEY (`sectionId`) REFERENCES `sections` (`id`) ON DELETE CASCADE,
  CONSTRAINT `sections_sites_siteId_fk` FOREIGN KEY (`siteId`) REFERENCES `sites` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;

DROP TABLE IF EXISTS `seomatic_metabundles`;
CREATE TABLE `seomatic_metabundles` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  `bundleVersion` varchar(255) NOT NULL DEFAULT '',
  `sourceBundleType` varchar(255) NOT NULL DEFAULT '',
  `sourceId` int(11) DEFAULT NULL,
  `sourceName` varchar(255) NOT NULL DEFAULT '',
  `sourceHandle` varchar(255) NOT NULL DEFAULT '',
  `sourceType` varchar(64) NOT NULL DEFAULT '',
  `sourceTemplate` varchar(500) DEFAULT '',
  `sourceSiteId` int(11) DEFAULT NULL,
  `sourceAltSiteSettings` text,
  `sourceDateUpdated` datetime NOT NULL,
  `metaGlobalVars` text,
  `metaSiteVars` text,
  `metaSitemapVars` text,
  `metaContainers` text,
  `redirectsContainer` text,
  `frontendTemplatesContainer` text,
  `metaBundleSettings` text,
  PRIMARY KEY (`id`),
  KEY `seomatic_metabundles_sourceBundleType_idx` (`sourceBundleType`),
  KEY `seomatic_metabundles_sourceId_idx` (`sourceId`),
  KEY `seomatic_metabundles_sourceSiteId_idx` (`sourceSiteId`),
  KEY `seomatic_metabundles_sourceHandle_idx` (`sourceHandle`),
  CONSTRAINT `seomatic_metabundles_sourceSiteId_fk` FOREIGN KEY (`sourceSiteId`) REFERENCES `sites` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8;

DROP TABLE IF EXISTS `sequences`;
CREATE TABLE `sequences` (
  `name` varchar(255) NOT NULL,
  `next` int(11) unsigned NOT NULL DEFAULT '1',
  PRIMARY KEY (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

DROP TABLE IF EXISTS `sessions`;
CREATE TABLE `sessions` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `userId` int(11) NOT NULL,
  `token` char(100) NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `sessions_uid_idx` (`uid`),
  KEY `sessions_token_idx` (`token`),
  KEY `sessions_dateUpdated_idx` (`dateUpdated`),
  KEY `sessions_userId_idx` (`userId`),
  CONSTRAINT `sessions_userId_fk` FOREIGN KEY (`userId`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

DROP TABLE IF EXISTS `shunnedmessages`;
CREATE TABLE `shunnedmessages` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `userId` int(11) NOT NULL,
  `message` varchar(255) NOT NULL,
  `expiryDate` datetime DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `shunnedmessages_userId_message_unq_idx` (`userId`,`message`),
  CONSTRAINT `shunnedmessages_userId_fk` FOREIGN KEY (`userId`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

DROP TABLE IF EXISTS `sitegroups`;
CREATE TABLE `sitegroups` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `dateDeleted` datetime DEFAULT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `sitegroups_name_idx` (`name`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;

DROP TABLE IF EXISTS `sites`;
CREATE TABLE `sites` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `groupId` int(11) NOT NULL,
  `primary` tinyint(1) NOT NULL,
  `name` varchar(255) NOT NULL,
  `handle` varchar(255) NOT NULL,
  `language` varchar(12) NOT NULL,
  `hasUrls` tinyint(1) NOT NULL DEFAULT '0',
  `baseUrl` varchar(255) DEFAULT NULL,
  `sortOrder` smallint(6) unsigned DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `dateDeleted` datetime DEFAULT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `sites_dateDeleted_idx` (`dateDeleted`),
  KEY `sites_handle_idx` (`handle`),
  KEY `sites_sortOrder_idx` (`sortOrder`),
  KEY `sites_groupId_fk` (`groupId`),
  CONSTRAINT `sites_groupId_fk` FOREIGN KEY (`groupId`) REFERENCES `sitegroups` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;

DROP TABLE IF EXISTS `structureelements`;
CREATE TABLE `structureelements` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `structureId` int(11) NOT NULL,
  `elementId` int(11) DEFAULT NULL,
  `root` int(11) unsigned DEFAULT NULL,
  `lft` int(11) unsigned NOT NULL,
  `rgt` int(11) unsigned NOT NULL,
  `level` smallint(6) unsigned NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `structureelements_structureId_elementId_unq_idx` (`structureId`,`elementId`),
  KEY `structureelements_root_idx` (`root`),
  KEY `structureelements_lft_idx` (`lft`),
  KEY `structureelements_rgt_idx` (`rgt`),
  KEY `structureelements_level_idx` (`level`),
  KEY `structureelements_elementId_idx` (`elementId`),
  CONSTRAINT `structureelements_elementId_fk` FOREIGN KEY (`elementId`) REFERENCES `elements` (`id`) ON DELETE CASCADE,
  CONSTRAINT `structureelements_structureId_fk` FOREIGN KEY (`structureId`) REFERENCES `structures` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=29 DEFAULT CHARSET=utf8;

DROP TABLE IF EXISTS `structures`;
CREATE TABLE `structures` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `maxLevels` smallint(6) unsigned DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `dateDeleted` datetime DEFAULT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `structures_dateDeleted_idx` (`dateDeleted`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8;

DROP TABLE IF EXISTS `supertableblocks`;
CREATE TABLE `supertableblocks` (
  `id` int(11) NOT NULL,
  `ownerId` int(11) NOT NULL,
  `fieldId` int(11) NOT NULL,
  `typeId` int(11) NOT NULL,
  `sortOrder` smallint(6) unsigned DEFAULT NULL,
  `deletedWithOwner` tinyint(1) DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `supertableblocks_ownerId_idx` (`ownerId`),
  KEY `supertableblocks_fieldId_idx` (`fieldId`),
  KEY `supertableblocks_typeId_idx` (`typeId`),
  KEY `supertableblocks_sortOrder_idx` (`sortOrder`),
  CONSTRAINT `supertableblocks_fieldId_fk` FOREIGN KEY (`fieldId`) REFERENCES `fields` (`id`) ON DELETE CASCADE,
  CONSTRAINT `supertableblocks_id_fk` FOREIGN KEY (`id`) REFERENCES `elements` (`id`) ON DELETE CASCADE,
  CONSTRAINT `supertableblocks_ownerId_fk` FOREIGN KEY (`ownerId`) REFERENCES `elements` (`id`) ON DELETE CASCADE,
  CONSTRAINT `supertableblocks_typeId_fk` FOREIGN KEY (`typeId`) REFERENCES `supertableblocktypes` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

DROP TABLE IF EXISTS `supertableblocktypes`;
CREATE TABLE `supertableblocktypes` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `fieldId` int(11) NOT NULL,
  `fieldLayoutId` int(11) DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `supertableblocktypes_fieldId_idx` (`fieldId`),
  KEY `supertableblocktypes_fieldLayoutId_idx` (`fieldLayoutId`),
  CONSTRAINT `supertableblocktypes_fieldId_fk` FOREIGN KEY (`fieldId`) REFERENCES `fields` (`id`) ON DELETE CASCADE,
  CONSTRAINT `supertableblocktypes_fieldLayoutId_fk` FOREIGN KEY (`fieldLayoutId`) REFERENCES `fieldlayouts` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

DROP TABLE IF EXISTS `systemmessages`;
CREATE TABLE `systemmessages` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `language` varchar(255) NOT NULL,
  `key` varchar(255) NOT NULL,
  `subject` text NOT NULL,
  `body` text NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `systemmessages_key_language_unq_idx` (`key`,`language`),
  KEY `systemmessages_language_idx` (`language`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

DROP TABLE IF EXISTS `taggroups`;
CREATE TABLE `taggroups` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `handle` varchar(255) NOT NULL,
  `fieldLayoutId` int(11) DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `dateDeleted` datetime DEFAULT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `taggroups_name_idx` (`name`),
  KEY `taggroups_handle_idx` (`handle`),
  KEY `taggroups_dateDeleted_idx` (`dateDeleted`),
  KEY `taggroups_fieldLayoutId_fk` (`fieldLayoutId`),
  CONSTRAINT `taggroups_fieldLayoutId_fk` FOREIGN KEY (`fieldLayoutId`) REFERENCES `fieldlayouts` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

DROP TABLE IF EXISTS `tags`;
CREATE TABLE `tags` (
  `id` int(11) NOT NULL,
  `groupId` int(11) NOT NULL,
  `deletedWithGroup` tinyint(1) DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `tags_groupId_idx` (`groupId`),
  CONSTRAINT `tags_groupId_fk` FOREIGN KEY (`groupId`) REFERENCES `taggroups` (`id`) ON DELETE CASCADE,
  CONSTRAINT `tags_id_fk` FOREIGN KEY (`id`) REFERENCES `elements` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

DROP TABLE IF EXISTS `templatecacheelements`;
CREATE TABLE `templatecacheelements` (
  `cacheId` int(11) NOT NULL,
  `elementId` int(11) NOT NULL,
  KEY `templatecacheelements_cacheId_idx` (`cacheId`),
  KEY `templatecacheelements_elementId_idx` (`elementId`),
  CONSTRAINT `templatecacheelements_cacheId_fk` FOREIGN KEY (`cacheId`) REFERENCES `templatecaches` (`id`) ON DELETE CASCADE,
  CONSTRAINT `templatecacheelements_elementId_fk` FOREIGN KEY (`elementId`) REFERENCES `elements` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

DROP TABLE IF EXISTS `templatecachequeries`;
CREATE TABLE `templatecachequeries` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `cacheId` int(11) NOT NULL,
  `type` varchar(255) NOT NULL,
  `query` longtext NOT NULL,
  PRIMARY KEY (`id`),
  KEY `templatecachequeries_cacheId_idx` (`cacheId`),
  KEY `templatecachequeries_type_idx` (`type`),
  CONSTRAINT `templatecachequeries_cacheId_fk` FOREIGN KEY (`cacheId`) REFERENCES `templatecaches` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

DROP TABLE IF EXISTS `templatecaches`;
CREATE TABLE `templatecaches` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `siteId` int(11) NOT NULL,
  `cacheKey` varchar(255) NOT NULL,
  `path` varchar(255) DEFAULT NULL,
  `expiryDate` datetime NOT NULL,
  `body` mediumtext NOT NULL,
  PRIMARY KEY (`id`),
  KEY `templatecaches_cacheKey_siteId_expiryDate_path_idx` (`cacheKey`,`siteId`,`expiryDate`,`path`),
  KEY `templatecaches_cacheKey_siteId_expiryDate_idx` (`cacheKey`,`siteId`,`expiryDate`),
  KEY `templatecaches_siteId_idx` (`siteId`),
  CONSTRAINT `templatecaches_siteId_fk` FOREIGN KEY (`siteId`) REFERENCES `sites` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

DROP TABLE IF EXISTS `tokens`;
CREATE TABLE `tokens` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `token` char(32) NOT NULL,
  `route` text,
  `usageLimit` tinyint(3) unsigned DEFAULT NULL,
  `usageCount` tinyint(3) unsigned DEFAULT NULL,
  `expiryDate` datetime NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `tokens_token_unq_idx` (`token`),
  KEY `tokens_expiryDate_idx` (`expiryDate`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

DROP TABLE IF EXISTS `usergroups`;
CREATE TABLE `usergroups` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `handle` varchar(255) NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `usergroups_handle_unq_idx` (`handle`),
  UNIQUE KEY `usergroups_name_unq_idx` (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

DROP TABLE IF EXISTS `usergroups_users`;
CREATE TABLE `usergroups_users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `groupId` int(11) NOT NULL,
  `userId` int(11) NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `usergroups_users_groupId_userId_unq_idx` (`groupId`,`userId`),
  KEY `usergroups_users_userId_idx` (`userId`),
  CONSTRAINT `usergroups_users_groupId_fk` FOREIGN KEY (`groupId`) REFERENCES `usergroups` (`id`) ON DELETE CASCADE,
  CONSTRAINT `usergroups_users_userId_fk` FOREIGN KEY (`userId`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

DROP TABLE IF EXISTS `userpermissions`;
CREATE TABLE `userpermissions` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `userpermissions_name_unq_idx` (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

DROP TABLE IF EXISTS `userpermissions_usergroups`;
CREATE TABLE `userpermissions_usergroups` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `permissionId` int(11) NOT NULL,
  `groupId` int(11) NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `userpermissions_usergroups_permissionId_groupId_unq_idx` (`permissionId`,`groupId`),
  KEY `userpermissions_usergroups_groupId_idx` (`groupId`),
  CONSTRAINT `userpermissions_usergroups_groupId_fk` FOREIGN KEY (`groupId`) REFERENCES `usergroups` (`id`) ON DELETE CASCADE,
  CONSTRAINT `userpermissions_usergroups_permissionId_fk` FOREIGN KEY (`permissionId`) REFERENCES `userpermissions` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

DROP TABLE IF EXISTS `userpermissions_users`;
CREATE TABLE `userpermissions_users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `permissionId` int(11) NOT NULL,
  `userId` int(11) NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `userpermissions_users_permissionId_userId_unq_idx` (`permissionId`,`userId`),
  KEY `userpermissions_users_userId_idx` (`userId`),
  CONSTRAINT `userpermissions_users_permissionId_fk` FOREIGN KEY (`permissionId`) REFERENCES `userpermissions` (`id`) ON DELETE CASCADE,
  CONSTRAINT `userpermissions_users_userId_fk` FOREIGN KEY (`userId`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

DROP TABLE IF EXISTS `userpreferences`;
CREATE TABLE `userpreferences` (
  `userId` int(11) NOT NULL AUTO_INCREMENT,
  `preferences` text,
  PRIMARY KEY (`userId`),
  CONSTRAINT `userpreferences_userId_fk` FOREIGN KEY (`userId`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;

DROP TABLE IF EXISTS `users`;
CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `username` varchar(100) NOT NULL,
  `photoId` int(11) DEFAULT NULL,
  `firstName` varchar(100) DEFAULT NULL,
  `lastName` varchar(100) DEFAULT NULL,
  `email` varchar(255) NOT NULL,
  `password` varchar(255) DEFAULT NULL,
  `admin` tinyint(1) NOT NULL DEFAULT '0',
  `locked` tinyint(1) NOT NULL DEFAULT '0',
  `suspended` tinyint(1) NOT NULL DEFAULT '0',
  `pending` tinyint(1) NOT NULL DEFAULT '0',
  `lastLoginDate` datetime DEFAULT NULL,
  `lastLoginAttemptIp` varchar(45) DEFAULT NULL,
  `invalidLoginWindowStart` datetime DEFAULT NULL,
  `invalidLoginCount` tinyint(3) unsigned DEFAULT NULL,
  `lastInvalidLoginDate` datetime DEFAULT NULL,
  `lockoutDate` datetime DEFAULT NULL,
  `hasDashboard` tinyint(1) NOT NULL DEFAULT '0',
  `verificationCode` varchar(255) DEFAULT NULL,
  `verificationCodeIssuedDate` datetime DEFAULT NULL,
  `unverifiedEmail` varchar(255) DEFAULT NULL,
  `passwordResetRequired` tinyint(1) NOT NULL DEFAULT '0',
  `lastPasswordChangeDate` datetime DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `users_uid_idx` (`uid`),
  KEY `users_verificationCode_idx` (`verificationCode`),
  KEY `users_email_idx` (`email`),
  KEY `users_username_idx` (`username`),
  KEY `users_photoId_fk` (`photoId`),
  CONSTRAINT `users_id_fk` FOREIGN KEY (`id`) REFERENCES `elements` (`id`) ON DELETE CASCADE,
  CONSTRAINT `users_photoId_fk` FOREIGN KEY (`photoId`) REFERENCES `assets` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

DROP TABLE IF EXISTS `volumefolders`;
CREATE TABLE `volumefolders` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `parentId` int(11) DEFAULT NULL,
  `volumeId` int(11) DEFAULT NULL,
  `name` varchar(255) NOT NULL,
  `path` varchar(255) DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `volumefolders_name_parentId_volumeId_unq_idx` (`name`,`parentId`,`volumeId`),
  KEY `volumefolders_parentId_idx` (`parentId`),
  KEY `volumefolders_volumeId_idx` (`volumeId`),
  CONSTRAINT `volumefolders_parentId_fk` FOREIGN KEY (`parentId`) REFERENCES `volumefolders` (`id`) ON DELETE CASCADE,
  CONSTRAINT `volumefolders_volumeId_fk` FOREIGN KEY (`volumeId`) REFERENCES `volumes` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8;

DROP TABLE IF EXISTS `volumes`;
CREATE TABLE `volumes` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `fieldLayoutId` int(11) DEFAULT NULL,
  `name` varchar(255) NOT NULL,
  `handle` varchar(255) NOT NULL,
  `type` varchar(255) NOT NULL,
  `hasUrls` tinyint(1) NOT NULL DEFAULT '1',
  `url` varchar(255) DEFAULT NULL,
  `settings` text,
  `sortOrder` smallint(6) unsigned DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `dateDeleted` datetime DEFAULT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `volumes_name_idx` (`name`),
  KEY `volumes_handle_idx` (`handle`),
  KEY `volumes_fieldLayoutId_idx` (`fieldLayoutId`),
  KEY `volumes_dateDeleted_idx` (`dateDeleted`),
  CONSTRAINT `volumes_fieldLayoutId_fk` FOREIGN KEY (`fieldLayoutId`) REFERENCES `fieldlayouts` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;

DROP TABLE IF EXISTS `widgets`;
CREATE TABLE `widgets` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `userId` int(11) NOT NULL,
  `type` varchar(255) NOT NULL,
  `sortOrder` smallint(6) unsigned DEFAULT NULL,
  `colspan` tinyint(3) DEFAULT NULL,
  `settings` text,
  `enabled` tinyint(1) NOT NULL DEFAULT '1',
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `widgets_userId_idx` (`userId`),
  CONSTRAINT `widgets_userId_fk` FOREIGN KEY (`userId`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;

INSERT INTO `categorygroups` (`id`, `structureId`, `fieldLayoutId`, `name`, `handle`, `dateCreated`, `dateUpdated`, `dateDeleted`, `uid`) VALUES ('1', '3', '43', 'News Categories', 'newsCategories', '2019-12-16 20:51:28', '2019-12-16 21:35:05', NULL, '18fafec6-ea29-45d3-b653-efadf9123eb9');

INSERT INTO `categorygroups_sites` (`id`, `groupId`, `siteId`, `hasUrls`, `uriFormat`, `template`, `dateCreated`, `dateUpdated`, `uid`) VALUES ('1', '1', '2', '1', 'news/category/{slug}', 'news/category', '2019-12-16 20:51:28', '2019-12-16 21:35:05', 'e48cb070-75fd-4d2d-ba12-81ee6f327f2f');

INSERT INTO `content` (`id`, `elementId`, `siteId`, `title`, `dateCreated`, `dateUpdated`, `uid`, `field_altText`, `field_caption`, `field_heading`, `field_richText`, `field_alignment`, `field_textSize`, `field_position`, `field_summary`, `field_cite`, `field_table`, `field_form`, `field_width`, `field_aspect`, `field_autoplay`, `field_textColor`, `field_backgroundColor`, `field_grid`, `field_padding`, `field_tag`, `field_transition`, `field_keywords`, `field_confirm`, `field_code`, `field_quote`, `field_button`, `field_location`, `field_phone`, `field_paginate`, `field_altTitle`, `field_email`, `field_fax`) VALUES ('1', '1', '2', NULL, '2019-12-12 12:18:01', '2019-12-12 12:21:26', 'd8bf1174-544c-45fd-bcde-d45b5f44e8ed', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO `content` (`id`, `elementId`, `siteId`, `title`, `dateCreated`, `dateUpdated`, `uid`, `field_altText`, `field_caption`, `field_heading`, `field_richText`, `field_alignment`, `field_textSize`, `field_position`, `field_summary`, `field_cite`, `field_table`, `field_form`, `field_width`, `field_aspect`, `field_autoplay`, `field_textColor`, `field_backgroundColor`, `field_grid`, `field_padding`, `field_tag`, `field_transition`, `field_keywords`, `field_confirm`, `field_code`, `field_quote`, `field_button`, `field_location`, `field_phone`, `field_paginate`, `field_altTitle`, `field_email`, `field_fax`) VALUES ('3', '3', '2', 'About Us', '2019-12-16 09:59:38', '2019-12-16 20:46:07', '33ecc375-eb0e-4c97-b310-25b28621db53', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO `content` (`id`, `elementId`, `siteId`, `title`, `dateCreated`, `dateUpdated`, `uid`, `field_altText`, `field_caption`, `field_heading`, `field_richText`, `field_alignment`, `field_textSize`, `field_position`, `field_summary`, `field_cite`, `field_table`, `field_form`, `field_width`, `field_aspect`, `field_autoplay`, `field_textColor`, `field_backgroundColor`, `field_grid`, `field_padding`, `field_tag`, `field_transition`, `field_keywords`, `field_confirm`, `field_code`, `field_quote`, `field_button`, `field_location`, `field_phone`, `field_paginate`, `field_altTitle`, `field_email`, `field_fax`) VALUES ('4', '4', '2', 'About Us', '2019-12-16 09:59:38', '2019-12-16 09:59:38', '49e61e9e-7b01-413f-a9b4-9fb3334b45ca', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO `content` (`id`, `elementId`, `siteId`, `title`, `dateCreated`, `dateUpdated`, `uid`, `field_altText`, `field_caption`, `field_heading`, `field_richText`, `field_alignment`, `field_textSize`, `field_position`, `field_summary`, `field_cite`, `field_table`, `field_form`, `field_width`, `field_aspect`, `field_autoplay`, `field_textColor`, `field_backgroundColor`, `field_grid`, `field_padding`, `field_tag`, `field_transition`, `field_keywords`, `field_confirm`, `field_code`, `field_quote`, `field_button`, `field_location`, `field_phone`, `field_paginate`, `field_altTitle`, `field_email`, `field_fax`) VALUES ('6', '6', '2', 'News', '2019-12-16 09:59:57', '2019-12-16 20:47:53', 'c7b2d2ab-d66a-4849-8d48-d019a61922ea', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO `content` (`id`, `elementId`, `siteId`, `title`, `dateCreated`, `dateUpdated`, `uid`, `field_altText`, `field_caption`, `field_heading`, `field_richText`, `field_alignment`, `field_textSize`, `field_position`, `field_summary`, `field_cite`, `field_table`, `field_form`, `field_width`, `field_aspect`, `field_autoplay`, `field_textColor`, `field_backgroundColor`, `field_grid`, `field_padding`, `field_tag`, `field_transition`, `field_keywords`, `field_confirm`, `field_code`, `field_quote`, `field_button`, `field_location`, `field_phone`, `field_paginate`, `field_altTitle`, `field_email`, `field_fax`) VALUES ('7', '7', '2', 'News', '2019-12-16 09:59:57', '2019-12-16 09:59:57', 'c8cc2677-57d9-4aa6-8e13-e883b6d54363', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO `content` (`id`, `elementId`, `siteId`, `title`, `dateCreated`, `dateUpdated`, `uid`, `field_altText`, `field_caption`, `field_heading`, `field_richText`, `field_alignment`, `field_textSize`, `field_position`, `field_summary`, `field_cite`, `field_table`, `field_form`, `field_width`, `field_aspect`, `field_autoplay`, `field_textColor`, `field_backgroundColor`, `field_grid`, `field_padding`, `field_tag`, `field_transition`, `field_keywords`, `field_confirm`, `field_code`, `field_quote`, `field_button`, `field_location`, `field_phone`, `field_paginate`, `field_altTitle`, `field_email`, `field_fax`) VALUES ('9', '9', '2', 'Contact', '2019-12-16 10:00:07', '2019-12-16 20:46:08', '65b6f735-65cf-4a36-848e-2b10feee7985', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO `content` (`id`, `elementId`, `siteId`, `title`, `dateCreated`, `dateUpdated`, `uid`, `field_altText`, `field_caption`, `field_heading`, `field_richText`, `field_alignment`, `field_textSize`, `field_position`, `field_summary`, `field_cite`, `field_table`, `field_form`, `field_width`, `field_aspect`, `field_autoplay`, `field_textColor`, `field_backgroundColor`, `field_grid`, `field_padding`, `field_tag`, `field_transition`, `field_keywords`, `field_confirm`, `field_code`, `field_quote`, `field_button`, `field_location`, `field_phone`, `field_paginate`, `field_altTitle`, `field_email`, `field_fax`) VALUES ('10', '10', '2', 'Contact', '2019-12-16 10:00:07', '2019-12-16 10:00:07', 'c99127a0-814f-4c36-a5c6-1236e6b8ffae', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO `content` (`id`, `elementId`, `siteId`, `title`, `dateCreated`, `dateUpdated`, `uid`, `field_altText`, `field_caption`, `field_heading`, `field_richText`, `field_alignment`, `field_textSize`, `field_position`, `field_summary`, `field_cite`, `field_table`, `field_form`, `field_width`, `field_aspect`, `field_autoplay`, `field_textColor`, `field_backgroundColor`, `field_grid`, `field_padding`, `field_tag`, `field_transition`, `field_keywords`, `field_confirm`, `field_code`, `field_quote`, `field_button`, `field_location`, `field_phone`, `field_paginate`, `field_altTitle`, `field_email`, `field_fax`) VALUES ('11', '11', '2', 'About Us', '2019-12-16 10:06:29', '2019-12-16 20:46:07', 'd48281f0-43ad-425d-b410-b0253fc3c434', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO `content` (`id`, `elementId`, `siteId`, `title`, `dateCreated`, `dateUpdated`, `uid`, `field_altText`, `field_caption`, `field_heading`, `field_richText`, `field_alignment`, `field_textSize`, `field_position`, `field_summary`, `field_cite`, `field_table`, `field_form`, `field_width`, `field_aspect`, `field_autoplay`, `field_textColor`, `field_backgroundColor`, `field_grid`, `field_padding`, `field_tag`, `field_transition`, `field_keywords`, `field_confirm`, `field_code`, `field_quote`, `field_button`, `field_location`, `field_phone`, `field_paginate`, `field_altTitle`, `field_email`, `field_fax`) VALUES ('12', '12', '2', 'News', '2019-12-16 10:06:36', '2019-12-16 20:47:53', '1c936b16-9d28-4063-a58a-8c346edff030', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO `content` (`id`, `elementId`, `siteId`, `title`, `dateCreated`, `dateUpdated`, `uid`, `field_altText`, `field_caption`, `field_heading`, `field_richText`, `field_alignment`, `field_textSize`, `field_position`, `field_summary`, `field_cite`, `field_table`, `field_form`, `field_width`, `field_aspect`, `field_autoplay`, `field_textColor`, `field_backgroundColor`, `field_grid`, `field_padding`, `field_tag`, `field_transition`, `field_keywords`, `field_confirm`, `field_code`, `field_quote`, `field_button`, `field_location`, `field_phone`, `field_paginate`, `field_altTitle`, `field_email`, `field_fax`) VALUES ('13', '13', '2', 'Contact', '2019-12-16 10:06:41', '2019-12-16 20:46:08', 'a695677f-c618-4932-a89b-4501a00ec026', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO `content` (`id`, `elementId`, `siteId`, `title`, `dateCreated`, `dateUpdated`, `uid`, `field_altText`, `field_caption`, `field_heading`, `field_richText`, `field_alignment`, `field_textSize`, `field_position`, `field_summary`, `field_cite`, `field_table`, `field_form`, `field_width`, `field_aspect`, `field_autoplay`, `field_textColor`, `field_backgroundColor`, `field_grid`, `field_padding`, `field_tag`, `field_transition`, `field_keywords`, `field_confirm`, `field_code`, `field_quote`, `field_button`, `field_location`, `field_phone`, `field_paginate`, `field_altTitle`, `field_email`, `field_fax`) VALUES ('14', '14', '2', NULL, '2019-12-16 20:42:51', '2019-12-17 01:09:13', '4187191b-4a6a-4542-a43d-2f05d9adb385', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '{\"id\":null,\"ownerId\":\"14\",\"ownerSiteId\":\"2\",\"fieldId\":\"26\",\"zoom\":15,\"distance\":null,\"lat\":null,\"lng\":null,\"address\":\"\",\"parts\":{\"number\":\"\",\"address\":\"\",\"city\":\"\",\"postcode\":\"\",\"county\":\"\",\"state\":\"\",\"country\":\"\",\"planet\":\"Earth\",\"system\":\"the Solar System\",\"arm\":\"Orion Arm\",\"galaxy\":\"Milky Way\",\"group\":\"the Local Group\",\"cluster\":\"Virgo Cluster\",\"supercluster\":\"Laniakea Supercluster\"}}', NULL, NULL, NULL, NULL, NULL);
INSERT INTO `content` (`id`, `elementId`, `siteId`, `title`, `dateCreated`, `dateUpdated`, `uid`, `field_altText`, `field_caption`, `field_heading`, `field_richText`, `field_alignment`, `field_textSize`, `field_position`, `field_summary`, `field_cite`, `field_table`, `field_form`, `field_width`, `field_aspect`, `field_autoplay`, `field_textColor`, `field_backgroundColor`, `field_grid`, `field_padding`, `field_tag`, `field_transition`, `field_keywords`, `field_confirm`, `field_code`, `field_quote`, `field_button`, `field_location`, `field_phone`, `field_paginate`, `field_altTitle`, `field_email`, `field_fax`) VALUES ('15', '15', '2', NULL, '2019-12-16 21:01:51', '2019-12-17 00:55:20', 'e1b33540-7339-4e98-8fd7-fdb498550a52', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO `content` (`id`, `elementId`, `siteId`, `title`, `dateCreated`, `dateUpdated`, `uid`, `field_altText`, `field_caption`, `field_heading`, `field_richText`, `field_alignment`, `field_textSize`, `field_position`, `field_summary`, `field_cite`, `field_table`, `field_form`, `field_width`, `field_aspect`, `field_autoplay`, `field_textColor`, `field_backgroundColor`, `field_grid`, `field_padding`, `field_tag`, `field_transition`, `field_keywords`, `field_confirm`, `field_code`, `field_quote`, `field_button`, `field_location`, `field_phone`, `field_paginate`, `field_altTitle`, `field_email`, `field_fax`) VALUES ('16', '16', '2', 'Homepage', '2019-12-16 21:21:33', '2019-12-24 17:47:06', '5d688e52-043b-420d-9274-decd4650e5d3', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO `content` (`id`, `elementId`, `siteId`, `title`, `dateCreated`, `dateUpdated`, `uid`, `field_altText`, `field_caption`, `field_heading`, `field_richText`, `field_alignment`, `field_textSize`, `field_position`, `field_summary`, `field_cite`, `field_table`, `field_form`, `field_width`, `field_aspect`, `field_autoplay`, `field_textColor`, `field_backgroundColor`, `field_grid`, `field_padding`, `field_tag`, `field_transition`, `field_keywords`, `field_confirm`, `field_code`, `field_quote`, `field_button`, `field_location`, `field_phone`, `field_paginate`, `field_altTitle`, `field_email`, `field_fax`) VALUES ('17', '17', '2', 'Homepage', '2019-12-16 21:21:33', '2019-12-16 21:21:33', 'acbcaaa4-024a-4dae-a99a-9b54d1b10133', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO `content` (`id`, `elementId`, `siteId`, `title`, `dateCreated`, `dateUpdated`, `uid`, `field_altText`, `field_caption`, `field_heading`, `field_richText`, `field_alignment`, `field_textSize`, `field_position`, `field_summary`, `field_cite`, `field_table`, `field_form`, `field_width`, `field_aspect`, `field_autoplay`, `field_textColor`, `field_backgroundColor`, `field_grid`, `field_padding`, `field_tag`, `field_transition`, `field_keywords`, `field_confirm`, `field_code`, `field_quote`, `field_button`, `field_location`, `field_phone`, `field_paginate`, `field_altTitle`, `field_email`, `field_fax`) VALUES ('18', '18', '2', 'Homepage', '2019-12-16 21:22:54', '2019-12-16 21:22:54', '31df2622-60ca-4040-8981-dee9e4467c73', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO `content` (`id`, `elementId`, `siteId`, `title`, `dateCreated`, `dateUpdated`, `uid`, `field_altText`, `field_caption`, `field_heading`, `field_richText`, `field_alignment`, `field_textSize`, `field_position`, `field_summary`, `field_cite`, `field_table`, `field_form`, `field_width`, `field_aspect`, `field_autoplay`, `field_textColor`, `field_backgroundColor`, `field_grid`, `field_padding`, `field_tag`, `field_transition`, `field_keywords`, `field_confirm`, `field_code`, `field_quote`, `field_button`, `field_location`, `field_phone`, `field_paginate`, `field_altTitle`, `field_email`, `field_fax`) VALUES ('19', '19', '2', 'Page Not Found', '2019-12-16 21:26:21', '2019-12-16 21:28:08', '566c0332-cf20-4b26-a8b5-c9bc3b0575e8', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO `content` (`id`, `elementId`, `siteId`, `title`, `dateCreated`, `dateUpdated`, `uid`, `field_altText`, `field_caption`, `field_heading`, `field_richText`, `field_alignment`, `field_textSize`, `field_position`, `field_summary`, `field_cite`, `field_table`, `field_form`, `field_width`, `field_aspect`, `field_autoplay`, `field_textColor`, `field_backgroundColor`, `field_grid`, `field_padding`, `field_tag`, `field_transition`, `field_keywords`, `field_confirm`, `field_code`, `field_quote`, `field_button`, `field_location`, `field_phone`, `field_paginate`, `field_altTitle`, `field_email`, `field_fax`) VALUES ('20', '20', '2', 'Page Not Found', '2019-12-16 21:26:21', '2019-12-16 21:26:21', 'fa5d5099-344c-42a2-9db0-25296b00bfb5', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO `content` (`id`, `elementId`, `siteId`, `title`, `dateCreated`, `dateUpdated`, `uid`, `field_altText`, `field_caption`, `field_heading`, `field_richText`, `field_alignment`, `field_textSize`, `field_position`, `field_summary`, `field_cite`, `field_table`, `field_form`, `field_width`, `field_aspect`, `field_autoplay`, `field_textColor`, `field_backgroundColor`, `field_grid`, `field_padding`, `field_tag`, `field_transition`, `field_keywords`, `field_confirm`, `field_code`, `field_quote`, `field_button`, `field_location`, `field_phone`, `field_paginate`, `field_altTitle`, `field_email`, `field_fax`) VALUES ('21', '21', '2', 'Page Not Found', '2019-12-16 21:26:22', '2019-12-16 21:26:22', 'cc024651-9f98-4ff9-ac17-861dfb47a677', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO `content` (`id`, `elementId`, `siteId`, `title`, `dateCreated`, `dateUpdated`, `uid`, `field_altText`, `field_caption`, `field_heading`, `field_richText`, `field_alignment`, `field_textSize`, `field_position`, `field_summary`, `field_cite`, `field_table`, `field_form`, `field_width`, `field_aspect`, `field_autoplay`, `field_textColor`, `field_backgroundColor`, `field_grid`, `field_padding`, `field_tag`, `field_transition`, `field_keywords`, `field_confirm`, `field_code`, `field_quote`, `field_button`, `field_location`, `field_phone`, `field_paginate`, `field_altTitle`, `field_email`, `field_fax`) VALUES ('22', '22', '2', 'Page Not Found', '2019-12-16 21:28:07', '2019-12-16 21:28:07', 'bc51f604-da59-4fdc-bd0f-ed6f35e6247d', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO `content` (`id`, `elementId`, `siteId`, `title`, `dateCreated`, `dateUpdated`, `uid`, `field_altText`, `field_caption`, `field_heading`, `field_richText`, `field_alignment`, `field_textSize`, `field_position`, `field_summary`, `field_cite`, `field_table`, `field_form`, `field_width`, `field_aspect`, `field_autoplay`, `field_textColor`, `field_backgroundColor`, `field_grid`, `field_padding`, `field_tag`, `field_transition`, `field_keywords`, `field_confirm`, `field_code`, `field_quote`, `field_button`, `field_location`, `field_phone`, `field_paginate`, `field_altTitle`, `field_email`, `field_fax`) VALUES ('23', '23', '2', 'Page Not Found', '2019-12-16 21:28:08', '2019-12-16 21:28:08', '7f6f82bf-914b-4a34-a5ab-f2e92aad85dd', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO `content` (`id`, `elementId`, `siteId`, `title`, `dateCreated`, `dateUpdated`, `uid`, `field_altText`, `field_caption`, `field_heading`, `field_richText`, `field_alignment`, `field_textSize`, `field_position`, `field_summary`, `field_cite`, `field_table`, `field_form`, `field_width`, `field_aspect`, `field_autoplay`, `field_textColor`, `field_backgroundColor`, `field_grid`, `field_padding`, `field_tag`, `field_transition`, `field_keywords`, `field_confirm`, `field_code`, `field_quote`, `field_button`, `field_location`, `field_phone`, `field_paginate`, `field_altTitle`, `field_email`, `field_fax`) VALUES ('24', '24', '2', NULL, '2019-12-24 17:47:06', '2019-12-24 17:47:06', '8bb51347-885b-4099-bab8-01bf4bd972b3', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'medium', NULL, NULL, NULL, 'blue', NULL, 'large', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO `content` (`id`, `elementId`, `siteId`, `title`, `dateCreated`, `dateUpdated`, `uid`, `field_altText`, `field_caption`, `field_heading`, `field_richText`, `field_alignment`, `field_textSize`, `field_position`, `field_summary`, `field_cite`, `field_table`, `field_form`, `field_width`, `field_aspect`, `field_autoplay`, `field_textColor`, `field_backgroundColor`, `field_grid`, `field_padding`, `field_tag`, `field_transition`, `field_keywords`, `field_confirm`, `field_code`, `field_quote`, `field_button`, `field_location`, `field_phone`, `field_paginate`, `field_altTitle`, `field_email`, `field_fax`) VALUES ('25', '25', '2', NULL, '2019-12-24 17:47:06', '2019-12-24 17:47:06', 'c9b209d8-ae1a-4de3-aa75-29e1f493dbd9', NULL, NULL, 'My Header Text', NULL, 'left', 'huge', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'white', NULL, NULL, NULL, 'h1', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO `content` (`id`, `elementId`, `siteId`, `title`, `dateCreated`, `dateUpdated`, `uid`, `field_altText`, `field_caption`, `field_heading`, `field_richText`, `field_alignment`, `field_textSize`, `field_position`, `field_summary`, `field_cite`, `field_table`, `field_form`, `field_width`, `field_aspect`, `field_autoplay`, `field_textColor`, `field_backgroundColor`, `field_grid`, `field_padding`, `field_tag`, `field_transition`, `field_keywords`, `field_confirm`, `field_code`, `field_quote`, `field_button`, `field_location`, `field_phone`, `field_paginate`, `field_altTitle`, `field_email`, `field_fax`) VALUES ('26', '26', '2', NULL, '2019-12-24 17:47:06', '2019-12-24 17:47:06', 'ebfe7d1c-ef11-4389-bfbb-6462d5ff4d6a', NULL, NULL, NULL, '<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Vestibulum vestibulum tincidunt libero, eu ornare eros mattis et.</p>', 'left', 'medium', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'white', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO `content` (`id`, `elementId`, `siteId`, `title`, `dateCreated`, `dateUpdated`, `uid`, `field_altText`, `field_caption`, `field_heading`, `field_richText`, `field_alignment`, `field_textSize`, `field_position`, `field_summary`, `field_cite`, `field_table`, `field_form`, `field_width`, `field_aspect`, `field_autoplay`, `field_textColor`, `field_backgroundColor`, `field_grid`, `field_padding`, `field_tag`, `field_transition`, `field_keywords`, `field_confirm`, `field_code`, `field_quote`, `field_button`, `field_location`, `field_phone`, `field_paginate`, `field_altTitle`, `field_email`, `field_fax`) VALUES ('27', '27', '2', NULL, '2019-12-24 17:47:06', '2019-12-24 17:47:06', '23ff57d7-24a6-42e7-ab10-35bc31047334', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'medium', NULL, NULL, NULL, 'white', NULL, 'medium', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO `content` (`id`, `elementId`, `siteId`, `title`, `dateCreated`, `dateUpdated`, `uid`, `field_altText`, `field_caption`, `field_heading`, `field_richText`, `field_alignment`, `field_textSize`, `field_position`, `field_summary`, `field_cite`, `field_table`, `field_form`, `field_width`, `field_aspect`, `field_autoplay`, `field_textColor`, `field_backgroundColor`, `field_grid`, `field_padding`, `field_tag`, `field_transition`, `field_keywords`, `field_confirm`, `field_code`, `field_quote`, `field_button`, `field_location`, `field_phone`, `field_paginate`, `field_altTitle`, `field_email`, `field_fax`) VALUES ('28', '28', '2', NULL, '2019-12-24 17:47:06', '2019-12-24 17:47:06', 'd7346a9e-1a4b-439e-8a07-3bd8ac84939d', NULL, NULL, 'Heading Here', NULL, 'left', 'medium', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'black', NULL, NULL, NULL, 'h2', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO `content` (`id`, `elementId`, `siteId`, `title`, `dateCreated`, `dateUpdated`, `uid`, `field_altText`, `field_caption`, `field_heading`, `field_richText`, `field_alignment`, `field_textSize`, `field_position`, `field_summary`, `field_cite`, `field_table`, `field_form`, `field_width`, `field_aspect`, `field_autoplay`, `field_textColor`, `field_backgroundColor`, `field_grid`, `field_padding`, `field_tag`, `field_transition`, `field_keywords`, `field_confirm`, `field_code`, `field_quote`, `field_button`, `field_location`, `field_phone`, `field_paginate`, `field_altTitle`, `field_email`, `field_fax`) VALUES ('29', '29', '2', NULL, '2019-12-24 17:47:06', '2019-12-24 17:47:06', '92943a4d-3af9-4570-9d4f-3b2e3b6f6fa4', NULL, NULL, NULL, '<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Vestibulum vestibulum tincidunt libero, eu ornare eros mattis et. In pellentesque volutpat libero, tempor congue enim venenatis quis. Aenean cursus convallis lacus sit amet sodales. Suspendisse potenti. Donec pellentesque neque non feugiat interdum. Etiam eget fermentum ipsum. Proin sapien orci, lacinia vel lectus quis, pulvinar vestibulum purus. Integer est diam, imperdiet sed lacus a, efficitur interdum eros. Duis dignissim dui nisi, nec ullamcorper enim facilisis in. Nulla mattis lobortis mauris, a interdum erat pulvinar at. Curabitur sagittis odio non enim luctus hendrerit. Nullam id venenatis odio.</p><p>Praesent purus lacus, cursus id laoreet non, aliquet sit amet nisl. Curabitur vulputate condimentum neque. Vestibulum pretium sed magna non suscipit. Aliquam varius risus nec ipsum feugiat, ac sodales risus blandit. Vivamus eu leo ac nibh venenatis fringilla. Vestibulum sed erat scelerisque, interdum mauris quis, vulputate dui. Mauris libero lectus, venenatis sit amet lectus suscipit, laoreet dignissim neque. Pellentesque felis mi, imperdiet vel maximus vitae, cursus id turpis. Maecenas lacinia metus aliquet, bibendum justo sit amet, tincidunt magna. Mauris finibus magna ex, eget accumsan ipsum consectetur at. Ut tristique massa sapien, et lacinia est facilisis non. Integer non nibh justo. Suspendisse ornare urna sit amet arcu finibus, id tristique mi sodales. Vivamus vel orci ac eros pellentesque egestas porttitor nec lacus.</p>', 'left', 'medium', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'black', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO `content` (`id`, `elementId`, `siteId`, `title`, `dateCreated`, `dateUpdated`, `uid`, `field_altText`, `field_caption`, `field_heading`, `field_richText`, `field_alignment`, `field_textSize`, `field_position`, `field_summary`, `field_cite`, `field_table`, `field_form`, `field_width`, `field_aspect`, `field_autoplay`, `field_textColor`, `field_backgroundColor`, `field_grid`, `field_padding`, `field_tag`, `field_transition`, `field_keywords`, `field_confirm`, `field_code`, `field_quote`, `field_button`, `field_location`, `field_phone`, `field_paginate`, `field_altTitle`, `field_email`, `field_fax`) VALUES ('30', '30', '2', 'Homepage', '2019-12-24 17:47:06', '2019-12-24 17:47:06', 'adb63ebe-2f83-484d-bc66-35ee58a5794d', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO `content` (`id`, `elementId`, `siteId`, `title`, `dateCreated`, `dateUpdated`, `uid`, `field_altText`, `field_caption`, `field_heading`, `field_richText`, `field_alignment`, `field_textSize`, `field_position`, `field_summary`, `field_cite`, `field_table`, `field_form`, `field_width`, `field_aspect`, `field_autoplay`, `field_textColor`, `field_backgroundColor`, `field_grid`, `field_padding`, `field_tag`, `field_transition`, `field_keywords`, `field_confirm`, `field_code`, `field_quote`, `field_button`, `field_location`, `field_phone`, `field_paginate`, `field_altTitle`, `field_email`, `field_fax`) VALUES ('31', '31', '2', NULL, '2019-12-24 17:47:06', '2019-12-24 17:47:06', '7a277406-a892-47d8-aa09-970b0132c45a', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'medium', NULL, NULL, NULL, 'blue', NULL, 'large', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO `content` (`id`, `elementId`, `siteId`, `title`, `dateCreated`, `dateUpdated`, `uid`, `field_altText`, `field_caption`, `field_heading`, `field_richText`, `field_alignment`, `field_textSize`, `field_position`, `field_summary`, `field_cite`, `field_table`, `field_form`, `field_width`, `field_aspect`, `field_autoplay`, `field_textColor`, `field_backgroundColor`, `field_grid`, `field_padding`, `field_tag`, `field_transition`, `field_keywords`, `field_confirm`, `field_code`, `field_quote`, `field_button`, `field_location`, `field_phone`, `field_paginate`, `field_altTitle`, `field_email`, `field_fax`) VALUES ('32', '32', '2', NULL, '2019-12-24 17:47:06', '2019-12-24 17:47:06', '86327018-b9a4-49d5-a89a-ada152f2be10', NULL, NULL, 'My Header Text', NULL, 'left', 'huge', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'white', NULL, NULL, NULL, 'h1', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO `content` (`id`, `elementId`, `siteId`, `title`, `dateCreated`, `dateUpdated`, `uid`, `field_altText`, `field_caption`, `field_heading`, `field_richText`, `field_alignment`, `field_textSize`, `field_position`, `field_summary`, `field_cite`, `field_table`, `field_form`, `field_width`, `field_aspect`, `field_autoplay`, `field_textColor`, `field_backgroundColor`, `field_grid`, `field_padding`, `field_tag`, `field_transition`, `field_keywords`, `field_confirm`, `field_code`, `field_quote`, `field_button`, `field_location`, `field_phone`, `field_paginate`, `field_altTitle`, `field_email`, `field_fax`) VALUES ('33', '33', '2', NULL, '2019-12-24 17:47:06', '2019-12-24 17:47:06', '2585e336-8f9e-4435-8e19-0d054ad40f24', NULL, NULL, NULL, '<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Vestibulum vestibulum tincidunt libero, eu ornare eros mattis et.</p>', 'left', 'medium', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'white', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO `content` (`id`, `elementId`, `siteId`, `title`, `dateCreated`, `dateUpdated`, `uid`, `field_altText`, `field_caption`, `field_heading`, `field_richText`, `field_alignment`, `field_textSize`, `field_position`, `field_summary`, `field_cite`, `field_table`, `field_form`, `field_width`, `field_aspect`, `field_autoplay`, `field_textColor`, `field_backgroundColor`, `field_grid`, `field_padding`, `field_tag`, `field_transition`, `field_keywords`, `field_confirm`, `field_code`, `field_quote`, `field_button`, `field_location`, `field_phone`, `field_paginate`, `field_altTitle`, `field_email`, `field_fax`) VALUES ('34', '34', '2', NULL, '2019-12-24 17:47:06', '2019-12-24 17:47:06', 'fb49a593-d9c3-4146-97b7-dfbf4f7d93f2', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'medium', NULL, NULL, NULL, 'white', NULL, 'medium', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO `content` (`id`, `elementId`, `siteId`, `title`, `dateCreated`, `dateUpdated`, `uid`, `field_altText`, `field_caption`, `field_heading`, `field_richText`, `field_alignment`, `field_textSize`, `field_position`, `field_summary`, `field_cite`, `field_table`, `field_form`, `field_width`, `field_aspect`, `field_autoplay`, `field_textColor`, `field_backgroundColor`, `field_grid`, `field_padding`, `field_tag`, `field_transition`, `field_keywords`, `field_confirm`, `field_code`, `field_quote`, `field_button`, `field_location`, `field_phone`, `field_paginate`, `field_altTitle`, `field_email`, `field_fax`) VALUES ('35', '35', '2', NULL, '2019-12-24 17:47:06', '2019-12-24 17:47:06', 'be6a1510-4e40-4228-b3a5-6b5c92de0a20', NULL, NULL, 'Heading Here', NULL, 'left', 'medium', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'black', NULL, NULL, NULL, 'h2', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO `content` (`id`, `elementId`, `siteId`, `title`, `dateCreated`, `dateUpdated`, `uid`, `field_altText`, `field_caption`, `field_heading`, `field_richText`, `field_alignment`, `field_textSize`, `field_position`, `field_summary`, `field_cite`, `field_table`, `field_form`, `field_width`, `field_aspect`, `field_autoplay`, `field_textColor`, `field_backgroundColor`, `field_grid`, `field_padding`, `field_tag`, `field_transition`, `field_keywords`, `field_confirm`, `field_code`, `field_quote`, `field_button`, `field_location`, `field_phone`, `field_paginate`, `field_altTitle`, `field_email`, `field_fax`) VALUES ('36', '36', '2', NULL, '2019-12-24 17:47:06', '2019-12-24 17:47:06', '3738b0d5-6151-4c8e-a194-d779e290e1ed', NULL, NULL, NULL, '<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Vestibulum vestibulum tincidunt libero, eu ornare eros mattis et. In pellentesque volutpat libero, tempor congue enim venenatis quis. Aenean cursus convallis lacus sit amet sodales. Suspendisse potenti. Donec pellentesque neque non feugiat interdum. Etiam eget fermentum ipsum. Proin sapien orci, lacinia vel lectus quis, pulvinar vestibulum purus. Integer est diam, imperdiet sed lacus a, efficitur interdum eros. Duis dignissim dui nisi, nec ullamcorper enim facilisis in. Nulla mattis lobortis mauris, a interdum erat pulvinar at. Curabitur sagittis odio non enim luctus hendrerit. Nullam id venenatis odio.</p><p>Praesent purus lacus, cursus id laoreet non, aliquet sit amet nisl. Curabitur vulputate condimentum neque. Vestibulum pretium sed magna non suscipit. Aliquam varius risus nec ipsum feugiat, ac sodales risus blandit. Vivamus eu leo ac nibh venenatis fringilla. Vestibulum sed erat scelerisque, interdum mauris quis, vulputate dui. Mauris libero lectus, venenatis sit amet lectus suscipit, laoreet dignissim neque. Pellentesque felis mi, imperdiet vel maximus vitae, cursus id turpis. Maecenas lacinia metus aliquet, bibendum justo sit amet, tincidunt magna. Mauris finibus magna ex, eget accumsan ipsum consectetur at. Ut tristique massa sapien, et lacinia est facilisis non. Integer non nibh justo. Suspendisse ornare urna sit amet arcu finibus, id tristique mi sodales. Vivamus vel orci ac eros pellentesque egestas porttitor nec lacus.</p>', 'left', 'medium', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'black', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL);

INSERT INTO `elementindexsettings` (`id`, `type`, `settings`, `dateCreated`, `dateUpdated`, `uid`) VALUES ('1', 'craft\\elements\\Entry', '{\"sources\":{\"section:2e7aaa5a-bc25-4e9a-8efd-dd29ee0fcec2\":{\"tableAttributes\":{\"1\":\"type\",\"2\":\"link\"}}}}', '2019-12-16 10:00:30', '2019-12-16 10:00:30', '5043a3f6-3788-4e57-9567-1f8840783ed7');

INSERT INTO `elements` (`id`, `draftId`, `revisionId`, `fieldLayoutId`, `type`, `enabled`, `archived`, `dateCreated`, `dateUpdated`, `dateDeleted`, `uid`) VALUES ('1', NULL, NULL, NULL, 'craft\\elements\\User', '1', '0', '2019-12-12 12:18:01', '2019-12-12 12:21:26', NULL, '82e194ad-74d8-4315-adf9-dc9e4b80f4ed');
INSERT INTO `elements` (`id`, `draftId`, `revisionId`, `fieldLayoutId`, `type`, `enabled`, `archived`, `dateCreated`, `dateUpdated`, `dateDeleted`, `uid`) VALUES ('3', NULL, NULL, '35', 'craft\\elements\\Entry', '1', '0', '2019-12-16 09:59:38', '2019-12-16 09:59:38', NULL, 'efe77985-8915-42e6-a028-10019f351587');
INSERT INTO `elements` (`id`, `draftId`, `revisionId`, `fieldLayoutId`, `type`, `enabled`, `archived`, `dateCreated`, `dateUpdated`, `dateDeleted`, `uid`) VALUES ('4', NULL, '1', NULL, 'craft\\elements\\Entry', '1', '0', '2019-12-16 09:59:38', '2019-12-16 09:59:38', NULL, 'b2f30ba4-af60-4bcb-9eb4-8d0ccc2c8c1b');
INSERT INTO `elements` (`id`, `draftId`, `revisionId`, `fieldLayoutId`, `type`, `enabled`, `archived`, `dateCreated`, `dateUpdated`, `dateDeleted`, `uid`) VALUES ('6', NULL, NULL, '36', 'craft\\elements\\Entry', '1', '0', '2019-12-16 09:59:57', '2019-12-16 09:59:57', NULL, 'e4cc687e-e11f-4032-a1a6-1a44b826278b');
INSERT INTO `elements` (`id`, `draftId`, `revisionId`, `fieldLayoutId`, `type`, `enabled`, `archived`, `dateCreated`, `dateUpdated`, `dateDeleted`, `uid`) VALUES ('7', NULL, '2', NULL, 'craft\\elements\\Entry', '1', '0', '2019-12-16 09:59:57', '2019-12-16 09:59:57', NULL, 'fb8647ed-1fa7-4e39-8770-c5137c4584e1');
INSERT INTO `elements` (`id`, `draftId`, `revisionId`, `fieldLayoutId`, `type`, `enabled`, `archived`, `dateCreated`, `dateUpdated`, `dateDeleted`, `uid`) VALUES ('9', NULL, NULL, '35', 'craft\\elements\\Entry', '1', '0', '2019-12-16 10:00:07', '2019-12-16 10:00:07', NULL, 'e7860502-7edd-400a-acab-73168100ab7c');
INSERT INTO `elements` (`id`, `draftId`, `revisionId`, `fieldLayoutId`, `type`, `enabled`, `archived`, `dateCreated`, `dateUpdated`, `dateDeleted`, `uid`) VALUES ('10', NULL, '3', NULL, 'craft\\elements\\Entry', '1', '0', '2019-12-16 10:00:07', '2019-12-16 10:00:07', NULL, '65c110f0-db70-4d4b-8c04-c9fd35f72bc8');
INSERT INTO `elements` (`id`, `draftId`, `revisionId`, `fieldLayoutId`, `type`, `enabled`, `archived`, `dateCreated`, `dateUpdated`, `dateDeleted`, `uid`) VALUES ('11', NULL, NULL, NULL, 'verbb\\navigation\\elements\\Node', '1', '0', '2019-12-16 10:06:29', '2019-12-16 20:46:07', NULL, '0da0f7c7-3ee4-4a41-a52d-529ff166e6f3');
INSERT INTO `elements` (`id`, `draftId`, `revisionId`, `fieldLayoutId`, `type`, `enabled`, `archived`, `dateCreated`, `dateUpdated`, `dateDeleted`, `uid`) VALUES ('12', NULL, NULL, NULL, 'verbb\\navigation\\elements\\Node', '1', '0', '2019-12-16 10:06:36', '2019-12-16 20:47:53', NULL, 'c011af7b-6923-46ff-a521-61b4ca947bd4');
INSERT INTO `elements` (`id`, `draftId`, `revisionId`, `fieldLayoutId`, `type`, `enabled`, `archived`, `dateCreated`, `dateUpdated`, `dateDeleted`, `uid`) VALUES ('13', NULL, NULL, NULL, 'verbb\\navigation\\elements\\Node', '1', '0', '2019-12-16 10:06:41', '2019-12-16 20:46:08', NULL, '412bbe12-7b1a-4c80-9aa1-4196bd572a30');
INSERT INTO `elements` (`id`, `draftId`, `revisionId`, `fieldLayoutId`, `type`, `enabled`, `archived`, `dateCreated`, `dateUpdated`, `dateDeleted`, `uid`) VALUES ('14', NULL, NULL, '34', 'craft\\elements\\GlobalSet', '1', '0', '2019-12-16 20:42:51', '2019-12-17 01:09:13', NULL, '02eaae2b-ff7a-47f7-af7b-69935108d5d4');
INSERT INTO `elements` (`id`, `draftId`, `revisionId`, `fieldLayoutId`, `type`, `enabled`, `archived`, `dateCreated`, `dateUpdated`, `dateDeleted`, `uid`) VALUES ('15', NULL, NULL, '37', 'craft\\elements\\GlobalSet', '1', '0', '2019-12-16 21:01:51', '2019-12-17 00:55:20', NULL, '98b897f7-b828-4bf3-857d-925e359b630c');
INSERT INTO `elements` (`id`, `draftId`, `revisionId`, `fieldLayoutId`, `type`, `enabled`, `archived`, `dateCreated`, `dateUpdated`, `dateDeleted`, `uid`) VALUES ('16', NULL, NULL, '41', 'craft\\elements\\Entry', '1', '0', '2019-12-16 21:21:33', '2019-12-24 17:47:06', NULL, '0b4e9b15-abd7-446a-8aae-bc8266dd9813');
INSERT INTO `elements` (`id`, `draftId`, `revisionId`, `fieldLayoutId`, `type`, `enabled`, `archived`, `dateCreated`, `dateUpdated`, `dateDeleted`, `uid`) VALUES ('17', NULL, '4', NULL, 'craft\\elements\\Entry', '1', '0', '2019-12-16 21:21:33', '2019-12-16 21:21:33', NULL, '219cb050-63e6-47a0-a0b6-3ed45cfffe43');
INSERT INTO `elements` (`id`, `draftId`, `revisionId`, `fieldLayoutId`, `type`, `enabled`, `archived`, `dateCreated`, `dateUpdated`, `dateDeleted`, `uid`) VALUES ('18', NULL, '5', NULL, 'craft\\elements\\Entry', '1', '0', '2019-12-16 21:22:54', '2019-12-16 21:22:54', NULL, '6ed3debd-60f5-4473-bb6c-c52282ebe2cf');
INSERT INTO `elements` (`id`, `draftId`, `revisionId`, `fieldLayoutId`, `type`, `enabled`, `archived`, `dateCreated`, `dateUpdated`, `dateDeleted`, `uid`) VALUES ('19', NULL, NULL, NULL, 'craft\\elements\\Entry', '1', '0', '2019-12-16 21:26:21', '2019-12-16 21:28:08', NULL, '949c98db-61ff-4cac-9472-5a64d5abea4c');
INSERT INTO `elements` (`id`, `draftId`, `revisionId`, `fieldLayoutId`, `type`, `enabled`, `archived`, `dateCreated`, `dateUpdated`, `dateDeleted`, `uid`) VALUES ('20', NULL, '6', NULL, 'craft\\elements\\Entry', '1', '0', '2019-12-16 21:26:21', '2019-12-16 21:26:21', NULL, '72c3622b-6469-41c2-bcc5-36f3137a8474');
INSERT INTO `elements` (`id`, `draftId`, `revisionId`, `fieldLayoutId`, `type`, `enabled`, `archived`, `dateCreated`, `dateUpdated`, `dateDeleted`, `uid`) VALUES ('21', NULL, '7', NULL, 'craft\\elements\\Entry', '1', '0', '2019-12-16 21:26:22', '2019-12-16 21:26:22', NULL, '913f26a7-838b-4ff3-bc4f-04f3d2eda3af');
INSERT INTO `elements` (`id`, `draftId`, `revisionId`, `fieldLayoutId`, `type`, `enabled`, `archived`, `dateCreated`, `dateUpdated`, `dateDeleted`, `uid`) VALUES ('22', NULL, '8', NULL, 'craft\\elements\\Entry', '1', '0', '2019-12-16 21:28:07', '2019-12-16 21:28:07', NULL, '47afb297-8cd7-4dae-88f6-c0a39ce8680e');
INSERT INTO `elements` (`id`, `draftId`, `revisionId`, `fieldLayoutId`, `type`, `enabled`, `archived`, `dateCreated`, `dateUpdated`, `dateDeleted`, `uid`) VALUES ('23', NULL, '9', NULL, 'craft\\elements\\Entry', '1', '0', '2019-12-16 21:28:08', '2019-12-16 21:28:08', NULL, '7e32f8b7-a69a-46ae-800b-eb3c38e4e58c');
INSERT INTO `elements` (`id`, `draftId`, `revisionId`, `fieldLayoutId`, `type`, `enabled`, `archived`, `dateCreated`, `dateUpdated`, `dateDeleted`, `uid`) VALUES ('24', NULL, NULL, '18', 'benf\\neo\\elements\\Block', '1', '0', '2019-12-24 17:47:06', '2019-12-24 17:47:06', NULL, 'e1317997-e837-4dcd-b3b9-4a5e0ec76bcc');
INSERT INTO `elements` (`id`, `draftId`, `revisionId`, `fieldLayoutId`, `type`, `enabled`, `archived`, `dateCreated`, `dateUpdated`, `dateDeleted`, `uid`) VALUES ('25', NULL, NULL, '3', 'benf\\neo\\elements\\Block', '1', '0', '2019-12-24 17:47:06', '2019-12-24 17:47:06', NULL, 'da13ddfd-7865-4def-a67d-704a1d37ee54');
INSERT INTO `elements` (`id`, `draftId`, `revisionId`, `fieldLayoutId`, `type`, `enabled`, `archived`, `dateCreated`, `dateUpdated`, `dateDeleted`, `uid`) VALUES ('26', NULL, NULL, '4', 'benf\\neo\\elements\\Block', '1', '0', '2019-12-24 17:47:06', '2019-12-24 17:47:06', NULL, '00764b1a-f27d-415e-b1b6-66adcbc971b1');
INSERT INTO `elements` (`id`, `draftId`, `revisionId`, `fieldLayoutId`, `type`, `enabled`, `archived`, `dateCreated`, `dateUpdated`, `dateDeleted`, `uid`) VALUES ('27', NULL, NULL, '18', 'benf\\neo\\elements\\Block', '1', '0', '2019-12-24 17:47:06', '2019-12-24 17:47:06', NULL, 'ebd836cc-8a53-43c7-a0fb-adcaf7a280a8');
INSERT INTO `elements` (`id`, `draftId`, `revisionId`, `fieldLayoutId`, `type`, `enabled`, `archived`, `dateCreated`, `dateUpdated`, `dateDeleted`, `uid`) VALUES ('28', NULL, NULL, '3', 'benf\\neo\\elements\\Block', '1', '0', '2019-12-24 17:47:06', '2019-12-24 17:47:06', NULL, 'da260696-c70b-4d1b-a518-981bd7aea6c2');
INSERT INTO `elements` (`id`, `draftId`, `revisionId`, `fieldLayoutId`, `type`, `enabled`, `archived`, `dateCreated`, `dateUpdated`, `dateDeleted`, `uid`) VALUES ('29', NULL, NULL, '4', 'benf\\neo\\elements\\Block', '1', '0', '2019-12-24 17:47:06', '2019-12-24 17:47:06', NULL, 'c75f9ac5-e895-4f3b-b14f-6914533a5a61');
INSERT INTO `elements` (`id`, `draftId`, `revisionId`, `fieldLayoutId`, `type`, `enabled`, `archived`, `dateCreated`, `dateUpdated`, `dateDeleted`, `uid`) VALUES ('30', NULL, '10', '41', 'craft\\elements\\Entry', '1', '0', '2019-12-24 17:47:06', '2019-12-24 17:47:06', NULL, '1ad13e3b-0ea8-4cea-97b5-7f4bf52a6e82');
INSERT INTO `elements` (`id`, `draftId`, `revisionId`, `fieldLayoutId`, `type`, `enabled`, `archived`, `dateCreated`, `dateUpdated`, `dateDeleted`, `uid`) VALUES ('31', NULL, NULL, '18', 'benf\\neo\\elements\\Block', '1', '0', '2019-12-24 17:47:06', '2019-12-24 17:47:06', NULL, '78d7eb29-288b-4894-bd8e-709663ef4b32');
INSERT INTO `elements` (`id`, `draftId`, `revisionId`, `fieldLayoutId`, `type`, `enabled`, `archived`, `dateCreated`, `dateUpdated`, `dateDeleted`, `uid`) VALUES ('32', NULL, NULL, '3', 'benf\\neo\\elements\\Block', '1', '0', '2019-12-24 17:47:06', '2019-12-24 17:47:06', NULL, '905b759f-e0c4-485e-87b7-0d826bd9794f');
INSERT INTO `elements` (`id`, `draftId`, `revisionId`, `fieldLayoutId`, `type`, `enabled`, `archived`, `dateCreated`, `dateUpdated`, `dateDeleted`, `uid`) VALUES ('33', NULL, NULL, '4', 'benf\\neo\\elements\\Block', '1', '0', '2019-12-24 17:47:06', '2019-12-24 17:47:06', NULL, '7fbe9afd-d5ac-49ab-b688-dc30273d2466');
INSERT INTO `elements` (`id`, `draftId`, `revisionId`, `fieldLayoutId`, `type`, `enabled`, `archived`, `dateCreated`, `dateUpdated`, `dateDeleted`, `uid`) VALUES ('34', NULL, NULL, '18', 'benf\\neo\\elements\\Block', '1', '0', '2019-12-24 17:47:06', '2019-12-24 17:47:06', NULL, '98ff6abc-0c5c-4b4c-99ca-00ba61d93ee8');
INSERT INTO `elements` (`id`, `draftId`, `revisionId`, `fieldLayoutId`, `type`, `enabled`, `archived`, `dateCreated`, `dateUpdated`, `dateDeleted`, `uid`) VALUES ('35', NULL, NULL, '3', 'benf\\neo\\elements\\Block', '1', '0', '2019-12-24 17:47:06', '2019-12-24 17:47:06', NULL, 'dd323e9d-9bea-4f03-8090-e78515d9f3aa');
INSERT INTO `elements` (`id`, `draftId`, `revisionId`, `fieldLayoutId`, `type`, `enabled`, `archived`, `dateCreated`, `dateUpdated`, `dateDeleted`, `uid`) VALUES ('36', NULL, NULL, '4', 'benf\\neo\\elements\\Block', '1', '0', '2019-12-24 17:47:06', '2019-12-24 17:47:06', NULL, '108df03e-7316-4c80-a78a-f9590d6590d3');

INSERT INTO `elements_sites` (`id`, `elementId`, `siteId`, `slug`, `uri`, `enabled`, `dateCreated`, `dateUpdated`, `uid`) VALUES ('1', '1', '2', NULL, NULL, '1', '2019-12-12 12:18:01', '2019-12-12 12:18:01', 'e7325435-2723-45fc-a93f-4bc756bf336c');
INSERT INTO `elements_sites` (`id`, `elementId`, `siteId`, `slug`, `uri`, `enabled`, `dateCreated`, `dateUpdated`, `uid`) VALUES ('3', '3', '2', 'about-us', 'about-us', '1', '2019-12-16 09:59:38', '2019-12-16 09:59:39', '68dd159f-c7d6-4ce3-8436-75fcf0a47409');
INSERT INTO `elements_sites` (`id`, `elementId`, `siteId`, `slug`, `uri`, `enabled`, `dateCreated`, `dateUpdated`, `uid`) VALUES ('4', '4', '2', 'about-us', 'about-us', '1', '2019-12-16 09:59:38', '2019-12-16 09:59:38', '82f0027c-0e36-4c09-9782-240f81fd7f6a');
INSERT INTO `elements_sites` (`id`, `elementId`, `siteId`, `slug`, `uri`, `enabled`, `dateCreated`, `dateUpdated`, `uid`) VALUES ('6', '6', '2', 'news', 'news', '1', '2019-12-16 09:59:57', '2019-12-16 09:59:58', 'e61262eb-7813-47b7-8957-0fc42f4d09eb');
INSERT INTO `elements_sites` (`id`, `elementId`, `siteId`, `slug`, `uri`, `enabled`, `dateCreated`, `dateUpdated`, `uid`) VALUES ('7', '7', '2', 'news', 'news', '1', '2019-12-16 09:59:57', '2019-12-16 09:59:57', '40da8688-ea8c-45b7-9176-61ce8fd35206');
INSERT INTO `elements_sites` (`id`, `elementId`, `siteId`, `slug`, `uri`, `enabled`, `dateCreated`, `dateUpdated`, `uid`) VALUES ('9', '9', '2', 'contact', 'contact', '1', '2019-12-16 10:00:07', '2019-12-16 10:00:08', '47a46951-8a71-4053-9d20-6d911cae6208');
INSERT INTO `elements_sites` (`id`, `elementId`, `siteId`, `slug`, `uri`, `enabled`, `dateCreated`, `dateUpdated`, `uid`) VALUES ('10', '10', '2', 'contact', 'contact', '1', '2019-12-16 10:00:07', '2019-12-16 10:00:07', '197fae3f-4bc4-4b50-b39b-35315534b11c');
INSERT INTO `elements_sites` (`id`, `elementId`, `siteId`, `slug`, `uri`, `enabled`, `dateCreated`, `dateUpdated`, `uid`) VALUES ('11', '11', '2', '2', NULL, '1', '2019-12-16 10:06:29', '2019-12-16 10:06:29', '7d417e5b-855a-4958-9a8c-9dc39100d2d0');
INSERT INTO `elements_sites` (`id`, `elementId`, `siteId`, `slug`, `uri`, `enabled`, `dateCreated`, `dateUpdated`, `uid`) VALUES ('12', '12', '2', '2', NULL, '1', '2019-12-16 10:06:36', '2019-12-16 10:06:36', 'd22287c5-5d06-4933-80ef-6375b42ba1ac');
INSERT INTO `elements_sites` (`id`, `elementId`, `siteId`, `slug`, `uri`, `enabled`, `dateCreated`, `dateUpdated`, `uid`) VALUES ('13', '13', '2', '2', NULL, '1', '2019-12-16 10:06:41', '2019-12-16 10:06:41', 'd76cad35-8596-4593-ae2a-b491890ae732');
INSERT INTO `elements_sites` (`id`, `elementId`, `siteId`, `slug`, `uri`, `enabled`, `dateCreated`, `dateUpdated`, `uid`) VALUES ('14', '14', '2', NULL, NULL, '1', '2019-12-16 20:42:51', '2019-12-16 20:42:51', 'cac12336-72eb-44a7-b63f-5393c4638bfe');
INSERT INTO `elements_sites` (`id`, `elementId`, `siteId`, `slug`, `uri`, `enabled`, `dateCreated`, `dateUpdated`, `uid`) VALUES ('15', '15', '2', NULL, NULL, '1', '2019-12-16 21:01:51', '2019-12-16 21:01:51', 'b47a5002-ae0b-4d2c-b1ad-4c2c8cc3bf3f');
INSERT INTO `elements_sites` (`id`, `elementId`, `siteId`, `slug`, `uri`, `enabled`, `dateCreated`, `dateUpdated`, `uid`) VALUES ('16', '16', '2', 'homepage', '__home__', '1', '2019-12-16 21:21:33', '2019-12-16 21:21:33', '89ca7f6e-caee-432e-b394-76bc68910016');
INSERT INTO `elements_sites` (`id`, `elementId`, `siteId`, `slug`, `uri`, `enabled`, `dateCreated`, `dateUpdated`, `uid`) VALUES ('17', '17', '2', 'homepage', '__home__', '1', '2019-12-16 21:21:33', '2019-12-16 21:21:33', '50a201d8-8fd6-4bb5-a596-3e4444506aab');
INSERT INTO `elements_sites` (`id`, `elementId`, `siteId`, `slug`, `uri`, `enabled`, `dateCreated`, `dateUpdated`, `uid`) VALUES ('18', '18', '2', 'homepage', '__home__', '1', '2019-12-16 21:22:54', '2019-12-16 21:22:54', '348323c3-a59d-4638-bec5-715793b21a76');
INSERT INTO `elements_sites` (`id`, `elementId`, `siteId`, `slug`, `uri`, `enabled`, `dateCreated`, `dateUpdated`, `uid`) VALUES ('19', '19', '2', 'page-not-found', 'page-not-found', '1', '2019-12-16 21:26:21', '2019-12-16 21:26:21', 'e6f43b69-d405-4710-8097-9f8c188a84b1');
INSERT INTO `elements_sites` (`id`, `elementId`, `siteId`, `slug`, `uri`, `enabled`, `dateCreated`, `dateUpdated`, `uid`) VALUES ('20', '20', '2', 'page-not-found', 'page-not-found', '1', '2019-12-16 21:26:21', '2019-12-16 21:26:21', '0b7b4028-7960-4777-9fc9-b9928cfca48e');
INSERT INTO `elements_sites` (`id`, `elementId`, `siteId`, `slug`, `uri`, `enabled`, `dateCreated`, `dateUpdated`, `uid`) VALUES ('21', '21', '2', 'page-not-found', 'page-not-found', '1', '2019-12-16 21:26:22', '2019-12-16 21:26:22', 'e1398448-e62d-4eea-90d2-b6edf5cff2e2');
INSERT INTO `elements_sites` (`id`, `elementId`, `siteId`, `slug`, `uri`, `enabled`, `dateCreated`, `dateUpdated`, `uid`) VALUES ('22', '22', '2', 'page-not-found', 'page-not-found', '1', '2019-12-16 21:28:07', '2019-12-16 21:28:07', 'c1a76101-0a0c-4689-ab53-925844bd1927');
INSERT INTO `elements_sites` (`id`, `elementId`, `siteId`, `slug`, `uri`, `enabled`, `dateCreated`, `dateUpdated`, `uid`) VALUES ('23', '23', '2', 'page-not-found', 'page-not-found', '1', '2019-12-16 21:28:08', '2019-12-16 21:28:08', 'cabb7a17-c5e8-4619-a457-f4df5e727d86');
INSERT INTO `elements_sites` (`id`, `elementId`, `siteId`, `slug`, `uri`, `enabled`, `dateCreated`, `dateUpdated`, `uid`) VALUES ('24', '24', '2', NULL, NULL, '1', '2019-12-24 17:47:06', '2019-12-24 17:47:06', '73014ccb-baf4-42dc-a81a-be08217b60ae');
INSERT INTO `elements_sites` (`id`, `elementId`, `siteId`, `slug`, `uri`, `enabled`, `dateCreated`, `dateUpdated`, `uid`) VALUES ('25', '25', '2', NULL, NULL, '1', '2019-12-24 17:47:06', '2019-12-24 17:47:06', '2a0cb7f3-00a8-4e10-b384-b4c5e7a1805f');
INSERT INTO `elements_sites` (`id`, `elementId`, `siteId`, `slug`, `uri`, `enabled`, `dateCreated`, `dateUpdated`, `uid`) VALUES ('26', '26', '2', NULL, NULL, '1', '2019-12-24 17:47:06', '2019-12-24 17:47:06', '70762d1e-1aee-44c2-bb37-3db32bbe823c');
INSERT INTO `elements_sites` (`id`, `elementId`, `siteId`, `slug`, `uri`, `enabled`, `dateCreated`, `dateUpdated`, `uid`) VALUES ('27', '27', '2', NULL, NULL, '1', '2019-12-24 17:47:06', '2019-12-24 17:47:06', '72c6a301-3e80-4ef8-84d7-28402b3bf45c');
INSERT INTO `elements_sites` (`id`, `elementId`, `siteId`, `slug`, `uri`, `enabled`, `dateCreated`, `dateUpdated`, `uid`) VALUES ('28', '28', '2', NULL, NULL, '1', '2019-12-24 17:47:06', '2019-12-24 17:47:06', 'b2f01711-ac83-466d-a50f-c96b4553257f');
INSERT INTO `elements_sites` (`id`, `elementId`, `siteId`, `slug`, `uri`, `enabled`, `dateCreated`, `dateUpdated`, `uid`) VALUES ('29', '29', '2', NULL, NULL, '1', '2019-12-24 17:47:06', '2019-12-24 17:47:06', '53578e2e-c8a5-454f-838e-663226c4503b');
INSERT INTO `elements_sites` (`id`, `elementId`, `siteId`, `slug`, `uri`, `enabled`, `dateCreated`, `dateUpdated`, `uid`) VALUES ('30', '30', '2', 'homepage', '__home__', '1', '2019-12-24 17:47:06', '2019-12-24 17:47:06', 'b664d233-edb3-4f9b-ab54-ba2e73cd70fe');
INSERT INTO `elements_sites` (`id`, `elementId`, `siteId`, `slug`, `uri`, `enabled`, `dateCreated`, `dateUpdated`, `uid`) VALUES ('31', '31', '2', NULL, NULL, '1', '2019-12-24 17:47:06', '2019-12-24 17:47:06', 'd8d85dd8-2cc9-4ac5-8018-8ef96ef23fe1');
INSERT INTO `elements_sites` (`id`, `elementId`, `siteId`, `slug`, `uri`, `enabled`, `dateCreated`, `dateUpdated`, `uid`) VALUES ('32', '32', '2', NULL, NULL, '1', '2019-12-24 17:47:06', '2019-12-24 17:47:06', 'd875d95d-ae7a-4d1c-811a-a2317cd7f83e');
INSERT INTO `elements_sites` (`id`, `elementId`, `siteId`, `slug`, `uri`, `enabled`, `dateCreated`, `dateUpdated`, `uid`) VALUES ('33', '33', '2', NULL, NULL, '1', '2019-12-24 17:47:06', '2019-12-24 17:47:06', '0f5f83e6-c6b0-4603-bb8e-0c5905b5f983');
INSERT INTO `elements_sites` (`id`, `elementId`, `siteId`, `slug`, `uri`, `enabled`, `dateCreated`, `dateUpdated`, `uid`) VALUES ('34', '34', '2', NULL, NULL, '1', '2019-12-24 17:47:06', '2019-12-24 17:47:06', '74a94e5c-6e06-4938-a0ea-68d6cb14b13a');
INSERT INTO `elements_sites` (`id`, `elementId`, `siteId`, `slug`, `uri`, `enabled`, `dateCreated`, `dateUpdated`, `uid`) VALUES ('35', '35', '2', NULL, NULL, '1', '2019-12-24 17:47:06', '2019-12-24 17:47:06', '1115a371-b63a-498a-9c42-2ebbf84507a3');
INSERT INTO `elements_sites` (`id`, `elementId`, `siteId`, `slug`, `uri`, `enabled`, `dateCreated`, `dateUpdated`, `uid`) VALUES ('36', '36', '2', NULL, NULL, '1', '2019-12-24 17:47:06', '2019-12-24 17:47:06', '70ac6d8b-097a-4cf5-9275-23bc042603b5');

INSERT INTO `entries` (`id`, `sectionId`, `parentId`, `typeId`, `authorId`, `postDate`, `expiryDate`, `deletedWithEntryType`, `dateCreated`, `dateUpdated`, `uid`) VALUES ('3', '1', NULL, '1', '1', '2019-12-16 09:59:00', NULL, NULL, '2019-12-16 09:59:38', '2019-12-16 09:59:38', '1c34a725-5515-43fa-8a70-d539047f4335');
INSERT INTO `entries` (`id`, `sectionId`, `parentId`, `typeId`, `authorId`, `postDate`, `expiryDate`, `deletedWithEntryType`, `dateCreated`, `dateUpdated`, `uid`) VALUES ('4', '1', NULL, '1', '1', '2019-12-16 09:59:00', NULL, NULL, '2019-12-16 09:59:38', '2019-12-16 09:59:38', '4f48efcf-100c-49ac-9a7e-7c5e79d1c4b6');
INSERT INTO `entries` (`id`, `sectionId`, `parentId`, `typeId`, `authorId`, `postDate`, `expiryDate`, `deletedWithEntryType`, `dateCreated`, `dateUpdated`, `uid`) VALUES ('6', '1', NULL, '2', '1', '2019-12-16 09:59:00', NULL, NULL, '2019-12-16 09:59:57', '2019-12-16 09:59:57', '9ee402b2-d06f-4d2a-9cff-bcc08a964cae');
INSERT INTO `entries` (`id`, `sectionId`, `parentId`, `typeId`, `authorId`, `postDate`, `expiryDate`, `deletedWithEntryType`, `dateCreated`, `dateUpdated`, `uid`) VALUES ('7', '1', NULL, '2', '1', '2019-12-16 09:59:00', NULL, NULL, '2019-12-16 09:59:57', '2019-12-16 09:59:57', '5ac2f1a7-7992-4466-9308-728796c8910f');
INSERT INTO `entries` (`id`, `sectionId`, `parentId`, `typeId`, `authorId`, `postDate`, `expiryDate`, `deletedWithEntryType`, `dateCreated`, `dateUpdated`, `uid`) VALUES ('9', '1', NULL, '1', '1', '2019-12-16 10:00:00', NULL, NULL, '2019-12-16 10:00:07', '2019-12-16 10:00:07', '618b8667-dce1-4b56-8d0f-c7f6a5662bcd');
INSERT INTO `entries` (`id`, `sectionId`, `parentId`, `typeId`, `authorId`, `postDate`, `expiryDate`, `deletedWithEntryType`, `dateCreated`, `dateUpdated`, `uid`) VALUES ('10', '1', NULL, '1', '1', '2019-12-16 10:00:00', NULL, NULL, '2019-12-16 10:00:07', '2019-12-16 10:00:07', 'a78c09a6-d8df-46b2-97d4-07b1edfd928a');
INSERT INTO `entries` (`id`, `sectionId`, `parentId`, `typeId`, `authorId`, `postDate`, `expiryDate`, `deletedWithEntryType`, `dateCreated`, `dateUpdated`, `uid`) VALUES ('16', '3', NULL, '4', NULL, '2019-12-16 21:21:00', NULL, NULL, '2019-12-16 21:21:33', '2019-12-16 21:21:33', '59c2f57e-040b-4b0a-8200-78d32ce26f23');
INSERT INTO `entries` (`id`, `sectionId`, `parentId`, `typeId`, `authorId`, `postDate`, `expiryDate`, `deletedWithEntryType`, `dateCreated`, `dateUpdated`, `uid`) VALUES ('17', '3', NULL, '4', NULL, '2019-12-16 21:21:00', NULL, NULL, '2019-12-16 21:21:33', '2019-12-16 21:21:33', 'ced36f06-d212-403f-a3a4-9985b57f684e');
INSERT INTO `entries` (`id`, `sectionId`, `parentId`, `typeId`, `authorId`, `postDate`, `expiryDate`, `deletedWithEntryType`, `dateCreated`, `dateUpdated`, `uid`) VALUES ('18', '3', NULL, '4', NULL, '2019-12-16 21:21:00', NULL, NULL, '2019-12-16 21:22:54', '2019-12-16 21:22:54', '10565cf4-33b1-4fda-b885-15a370ff3288');
INSERT INTO `entries` (`id`, `sectionId`, `parentId`, `typeId`, `authorId`, `postDate`, `expiryDate`, `deletedWithEntryType`, `dateCreated`, `dateUpdated`, `uid`) VALUES ('19', '4', NULL, '5', NULL, '2019-12-16 21:26:00', NULL, NULL, '2019-12-16 21:26:21', '2019-12-16 21:26:21', '9040ad9c-5d98-44f4-8268-d78b56aae34e');
INSERT INTO `entries` (`id`, `sectionId`, `parentId`, `typeId`, `authorId`, `postDate`, `expiryDate`, `deletedWithEntryType`, `dateCreated`, `dateUpdated`, `uid`) VALUES ('20', '4', NULL, '5', NULL, '2019-12-16 21:26:00', NULL, NULL, '2019-12-16 21:26:21', '2019-12-16 21:26:21', '33e66916-26ec-4d79-98e6-35d06c7e7aef');
INSERT INTO `entries` (`id`, `sectionId`, `parentId`, `typeId`, `authorId`, `postDate`, `expiryDate`, `deletedWithEntryType`, `dateCreated`, `dateUpdated`, `uid`) VALUES ('21', '4', NULL, '5', NULL, '2019-12-16 21:26:00', NULL, NULL, '2019-12-16 21:26:22', '2019-12-16 21:26:22', '45a55e05-d125-4e68-a02a-55e766279a03');
INSERT INTO `entries` (`id`, `sectionId`, `parentId`, `typeId`, `authorId`, `postDate`, `expiryDate`, `deletedWithEntryType`, `dateCreated`, `dateUpdated`, `uid`) VALUES ('22', '4', NULL, '5', NULL, '2019-12-16 21:26:00', NULL, NULL, '2019-12-16 21:28:07', '2019-12-16 21:28:07', '749fda71-07bb-4653-a9db-8e0c1fadd83d');
INSERT INTO `entries` (`id`, `sectionId`, `parentId`, `typeId`, `authorId`, `postDate`, `expiryDate`, `deletedWithEntryType`, `dateCreated`, `dateUpdated`, `uid`) VALUES ('23', '4', NULL, '5', NULL, '2019-12-16 21:26:00', NULL, NULL, '2019-12-16 21:28:08', '2019-12-16 21:28:08', '705c9dbe-b1d0-462f-8b38-6a96ce2a411f');
INSERT INTO `entries` (`id`, `sectionId`, `parentId`, `typeId`, `authorId`, `postDate`, `expiryDate`, `deletedWithEntryType`, `dateCreated`, `dateUpdated`, `uid`) VALUES ('30', '3', NULL, '4', NULL, '2019-12-16 21:21:00', NULL, NULL, '2019-12-24 17:47:06', '2019-12-24 17:47:06', '206058cc-2369-46b3-87fd-cff61b788812');

INSERT INTO `entrytypes` (`id`, `sectionId`, `fieldLayoutId`, `name`, `handle`, `hasTitleField`, `titleLabel`, `titleFormat`, `sortOrder`, `dateCreated`, `dateUpdated`, `dateDeleted`, `uid`) VALUES ('1', '1', '35', 'General Page', 'general', '1', 'Title', '', '1', '2019-12-16 09:53:47', '2019-12-16 21:17:45', NULL, '9fc96015-4f93-4429-89ec-faefb125c13c');
INSERT INTO `entrytypes` (`id`, `sectionId`, `fieldLayoutId`, `name`, `handle`, `hasTitleField`, `titleLabel`, `titleFormat`, `sortOrder`, `dateCreated`, `dateUpdated`, `dateDeleted`, `uid`) VALUES ('2', '1', '36', 'News Page', 'news', '1', 'Title', '', '2', '2019-12-16 09:59:07', '2019-12-17 00:45:52', NULL, '8ad5b5c9-bc0d-403b-b82d-1727493c2733');
INSERT INTO `entrytypes` (`id`, `sectionId`, `fieldLayoutId`, `name`, `handle`, `hasTitleField`, `titleLabel`, `titleFormat`, `sortOrder`, `dateCreated`, `dateUpdated`, `dateDeleted`, `uid`) VALUES ('3', '2', '38', 'Article', 'article', '1', 'Article Title', '', '1', '2019-12-16 21:04:59', '2019-12-16 21:20:36', NULL, '4a347537-3003-4554-9cca-b513286e6a4b');
INSERT INTO `entrytypes` (`id`, `sectionId`, `fieldLayoutId`, `name`, `handle`, `hasTitleField`, `titleLabel`, `titleFormat`, `sortOrder`, `dateCreated`, `dateUpdated`, `dateDeleted`, `uid`) VALUES ('4', '3', '41', 'Homepage', 'homepage', '0', '', '{section.name|raw}', '1', '2019-12-16 21:21:33', '2019-12-16 21:22:54', NULL, '5b2354fd-20ab-4d94-aa20-a1795f4f8f52');
INSERT INTO `entrytypes` (`id`, `sectionId`, `fieldLayoutId`, `name`, `handle`, `hasTitleField`, `titleLabel`, `titleFormat`, `sortOrder`, `dateCreated`, `dateUpdated`, `dateDeleted`, `uid`) VALUES ('5', '4', '42', 'Page Not Found', 'pageNotFound', '0', '', '{section.name|raw}', '1', '2019-12-16 21:26:21', '2019-12-16 21:28:08', NULL, 'f2b12058-6b52-41b2-bc86-afdb464182a7');

INSERT INTO `fieldgroups` (`id`, `name`, `dateCreated`, `dateUpdated`, `uid`) VALUES ('3', 'Text', '2019-12-16 10:34:17', '2019-12-16 10:34:17', '59376394-99bc-4a56-848d-d7f1bb119194');
INSERT INTO `fieldgroups` (`id`, `name`, `dateCreated`, `dateUpdated`, `uid`) VALUES ('4', 'Options', '2019-12-16 10:34:25', '2019-12-16 10:34:25', 'e0066e90-e858-47a6-9353-554b8abee96e');
INSERT INTO `fieldgroups` (`id`, `name`, `dateCreated`, `dateUpdated`, `uid`) VALUES ('5', 'Style', '2019-12-16 10:34:30', '2019-12-16 10:34:30', '3c9f6df0-5abd-4877-a460-4152aec05e33');
INSERT INTO `fieldgroups` (`id`, `name`, `dateCreated`, `dateUpdated`, `uid`) VALUES ('6', 'Assets', '2019-12-16 10:34:35', '2019-12-16 10:34:35', '24f4c2bc-c279-4faf-94b4-ed1d70b683a2');
INSERT INTO `fieldgroups` (`id`, `name`, `dateCreated`, `dateUpdated`, `uid`) VALUES ('7', 'Compound', '2019-12-16 10:34:40', '2019-12-16 10:34:40', 'fbd00a3e-7235-4a6d-8b32-345e745b6912');
INSERT INTO `fieldgroups` (`id`, `name`, `dateCreated`, `dateUpdated`, `uid`) VALUES ('8', 'Content Builders', '2019-12-16 10:34:51', '2019-12-16 10:34:51', '5e61df28-d93d-4339-82b6-07a8f44b142c');
INSERT INTO `fieldgroups` (`id`, `name`, `dateCreated`, `dateUpdated`, `uid`) VALUES ('9', 'Plugin', '2019-12-16 10:46:13', '2019-12-16 10:46:13', '721537c2-5b3e-44c1-96a4-5afe4d0e049f');
INSERT INTO `fieldgroups` (`id`, `name`, `dateCreated`, `dateUpdated`, `uid`) VALUES ('10', 'Relations', '2019-12-16 11:08:26', '2019-12-16 11:08:26', '8c1e1966-fc9d-48fd-9621-ff86acfa29ef');

INSERT INTO `fieldlabels` (`id`, `fieldId`, `fieldLayoutId`, `name`, `instructions`, `hideName`, `hideInstructions`, `dateCreated`, `dateUpdated`, `uid`) VALUES ('14', '27', '35', 'Preview Image', NULL, '0', '0', '2019-12-16 20:46:06', '2019-12-16 21:17:45', '27cc3f43-1460-4a0f-9a8f-9e3429fe6133');
INSERT INTO `fieldlabels` (`id`, `fieldId`, `fieldLayoutId`, `name`, `instructions`, `hideName`, `hideInstructions`, `dateCreated`, `dateUpdated`, `uid`) VALUES ('15', '8', '35', 'Preview Summary', NULL, '0', '0', '2019-12-16 20:46:06', '2019-12-16 21:17:45', 'd4aad52c-bc14-43c6-b51a-dc79a41c1d0e');
INSERT INTO `fieldlabels` (`id`, `fieldId`, `fieldLayoutId`, `name`, `instructions`, `hideName`, `hideInstructions`, `dateCreated`, `dateUpdated`, `uid`) VALUES ('16', '27', '36', 'Preview Image', NULL, '0', '0', '2019-12-16 20:47:52', '2019-12-17 00:45:52', '14484882-8c18-460a-a80a-ef33044364b9');
INSERT INTO `fieldlabels` (`id`, `fieldId`, `fieldLayoutId`, `name`, `instructions`, `hideName`, `hideInstructions`, `dateCreated`, `dateUpdated`, `uid`) VALUES ('17', '8', '36', 'Preview Summary', NULL, '0', '0', '2019-12-16 20:47:52', '2019-12-17 00:45:52', '00965c4d-fcbf-4867-bb54-3ee41ae64241');
INSERT INTO `fieldlabels` (`id`, `fieldId`, `fieldLayoutId`, `name`, `instructions`, `hideName`, `hideInstructions`, `dateCreated`, `dateUpdated`, `uid`) VALUES ('18', '27', '38', 'Preview Image', NULL, '0', '0', '2019-12-16 21:06:51', '2019-12-16 21:20:36', '980236a8-008b-4c2c-9eb4-65680023726c');
INSERT INTO `fieldlabels` (`id`, `fieldId`, `fieldLayoutId`, `name`, `instructions`, `hideName`, `hideInstructions`, `dateCreated`, `dateUpdated`, `uid`) VALUES ('19', '8', '38', 'Preview Summary', NULL, '0', '0', '2019-12-16 21:06:51', '2019-12-16 21:20:36', '4e729115-883e-4cd8-9388-e35d926baaba');
INSERT INTO `fieldlabels` (`id`, `fieldId`, `fieldLayoutId`, `name`, `instructions`, `hideName`, `hideInstructions`, `dateCreated`, `dateUpdated`, `uid`) VALUES ('20', '33', '36', NULL, 'Select the category of news articles to display on the page. Leave blank to display all articles.', '0', '0', '2019-12-16 21:08:01', '2019-12-17 00:45:52', '79636c09-58bb-4566-84d5-35b85c7f24a6');
INSERT INTO `fieldlabels` (`id`, `fieldId`, `fieldLayoutId`, `name`, `instructions`, `hideName`, `hideInstructions`, `dateCreated`, `dateUpdated`, `uid`) VALUES ('21', '33', '38', NULL, 'Select the categories for this article.', '0', '0', '2019-12-16 21:08:43', '2019-12-16 21:20:36', 'fe34c62a-2236-4fae-8c1c-de822d65bc45');
INSERT INTO `fieldlabels` (`id`, `fieldId`, `fieldLayoutId`, `name`, `instructions`, `hideName`, `hideInstructions`, `dateCreated`, `dateUpdated`, `uid`) VALUES ('30', '36', '35', NULL, 'Include an alternate title for this page. Leave blank to use the page title.', '0', '0', '2019-12-16 21:17:44', '2019-12-16 21:17:44', '67a42122-d27b-446d-b3c5-54f8946e9709');
INSERT INTO `fieldlabels` (`id`, `fieldId`, `fieldLayoutId`, `name`, `instructions`, `hideName`, `hideInstructions`, `dateCreated`, `dateUpdated`, `uid`) VALUES ('31', '36', '36', NULL, 'Include an alternate title for this page. Leave blank to use the page title.', '0', '0', '2019-12-16 21:19:09', '2019-12-17 00:45:52', '6f748cee-7649-486b-9e31-2c5c4dfde3ea');
INSERT INTO `fieldlabels` (`id`, `fieldId`, `fieldLayoutId`, `name`, `instructions`, `hideName`, `hideInstructions`, `dateCreated`, `dateUpdated`, `uid`) VALUES ('32', '36', '38', NULL, 'Include an alternate title for this article. Leave blank to use the article title.', '0', '0', '2019-12-16 21:20:36', '2019-12-16 21:20:36', '33e0438e-ac04-4545-827e-dba40dd8373f');
INSERT INTO `fieldlabels` (`id`, `fieldId`, `fieldLayoutId`, `name`, `instructions`, `hideName`, `hideInstructions`, `dateCreated`, `dateUpdated`, `uid`) VALUES ('33', '31', '38', 'Article Content', 'Include blocks of content to build out the article', '0', '0', '2019-12-16 21:20:36', '2019-12-16 21:20:36', '298ee8f2-65d1-4329-97e9-feb88de73704');
INSERT INTO `fieldlabels` (`id`, `fieldId`, `fieldLayoutId`, `name`, `instructions`, `hideName`, `hideInstructions`, `dateCreated`, `dateUpdated`, `uid`) VALUES ('34', '27', '41', 'Preview Image', NULL, '0', '0', '2019-12-16 21:22:54', '2019-12-16 21:22:54', '2541f75b-4171-4336-9aa5-95c41d7a4d97');
INSERT INTO `fieldlabels` (`id`, `fieldId`, `fieldLayoutId`, `name`, `instructions`, `hideName`, `hideInstructions`, `dateCreated`, `dateUpdated`, `uid`) VALUES ('35', '8', '41', 'Preview Summary', NULL, '0', '0', '2019-12-16 21:22:54', '2019-12-16 21:22:54', '76528ccf-891d-4da3-b269-05bda077a25f');
INSERT INTO `fieldlabels` (`id`, `fieldId`, `fieldLayoutId`, `name`, `instructions`, `hideName`, `hideInstructions`, `dateCreated`, `dateUpdated`, `uid`) VALUES ('36', '27', '37', 'Default Page Header Image', 'Include a default image for page headers that will be used if no preview image for the page is selected.', '0', '0', '2019-12-16 21:24:49', '2019-12-17 00:55:20', '5f97e9d4-ebdb-4e2e-b7f7-918596aa3673');
INSERT INTO `fieldlabels` (`id`, `fieldId`, `fieldLayoutId`, `name`, `instructions`, `hideName`, `hideInstructions`, `dateCreated`, `dateUpdated`, `uid`) VALUES ('37', '27', '42', 'Preview Image', NULL, '0', '0', '2019-12-16 21:28:08', '2019-12-16 21:28:08', '61eb5681-7dc8-4039-a429-2f56fe76f751');
INSERT INTO `fieldlabels` (`id`, `fieldId`, `fieldLayoutId`, `name`, `instructions`, `hideName`, `hideInstructions`, `dateCreated`, `dateUpdated`, `uid`) VALUES ('38', '8', '42', 'Preview Summary', NULL, '0', '0', '2019-12-16 21:28:08', '2019-12-16 21:28:08', '3559cf6d-fc2b-47c2-a837-aaf4e9b61ed4');
INSERT INTO `fieldlabels` (`id`, `fieldId`, `fieldLayoutId`, `name`, `instructions`, `hideName`, `hideInstructions`, `dateCreated`, `dateUpdated`, `uid`) VALUES ('39', '27', '43', 'Preview Image', NULL, '0', '0', '2019-12-16 21:35:05', '2019-12-16 21:35:05', '6d833a0d-6246-4586-907b-5b31c9727bdc');
INSERT INTO `fieldlabels` (`id`, `fieldId`, `fieldLayoutId`, `name`, `instructions`, `hideName`, `hideInstructions`, `dateCreated`, `dateUpdated`, `uid`) VALUES ('40', '8', '43', 'Preview Summary', NULL, '0', '0', '2019-12-16 21:35:05', '2019-12-16 21:35:05', 'd32294d1-1946-4841-b16b-b395a92f06db');
INSERT INTO `fieldlabels` (`id`, `fieldId`, `fieldLayoutId`, `name`, `instructions`, `hideName`, `hideInstructions`, `dateCreated`, `dateUpdated`, `uid`) VALUES ('41', '27', '2', 'Poster Image', 'The image that appears before the video plays.', '0', '0', '2019-12-16 21:40:04', '2019-12-16 21:40:04', 'f31e66f1-27d1-4f03-8b55-bb6252812528');
INSERT INTO `fieldlabels` (`id`, `fieldId`, `fieldLayoutId`, `name`, `instructions`, `hideName`, `hideInstructions`, `dateCreated`, `dateUpdated`, `uid`) VALUES ('42', '26', '34', 'Address', 'Your business address', '0', '0', '2019-12-17 00:02:28', '2019-12-17 01:09:13', 'c11baa06-b38b-42d8-99c7-cf1058818fc4');
INSERT INTO `fieldlabels` (`id`, `fieldId`, `fieldLayoutId`, `name`, `instructions`, `hideName`, `hideInstructions`, `dateCreated`, `dateUpdated`, `uid`) VALUES ('48', '38', '36', 'Featured Articles', 'Select the articles to feature on this page. Leave blank to display the latest published articles.', '0', '0', '2019-12-17 00:45:52', '2019-12-17 00:45:52', 'e825f055-53f8-4ef8-a89a-4c5d66291914');
INSERT INTO `fieldlabels` (`id`, `fieldId`, `fieldLayoutId`, `name`, `instructions`, `hideName`, `hideInstructions`, `dateCreated`, `dateUpdated`, `uid`) VALUES ('60', '39', '34', NULL, 'Your business address. This is the default email address where all form submission notifications will be sent if a recipient is not specified in the page content form. If left blank, notifications will be sent to the recipient address assigned in the form under \"Freeform\" > \"Forms\"', '0', '0', '2019-12-17 00:54:13', '2019-12-17 01:09:13', '8d4505ab-e3cd-4c47-b1ea-6000f0190be7');
INSERT INTO `fieldlabels` (`id`, `fieldId`, `fieldLayoutId`, `name`, `instructions`, `hideName`, `hideInstructions`, `dateCreated`, `dateUpdated`, `uid`) VALUES ('61', '32', '34', NULL, 'Your business phone number', '0', '0', '2019-12-17 00:54:13', '2019-12-17 01:09:13', 'ac0fab81-a82e-405c-a51e-ba686d42227d');
INSERT INTO `fieldlabels` (`id`, `fieldId`, `fieldLayoutId`, `name`, `instructions`, `hideName`, `hideInstructions`, `dateCreated`, `dateUpdated`, `uid`) VALUES ('67', '40', '34', NULL, 'Your business Fax', '0', '0', '2019-12-17 00:58:30', '2019-12-17 01:09:13', 'cf6f24df-b2ff-4aab-96c3-a000bb9acc67');
INSERT INTO `fieldlabels` (`id`, `fieldId`, `fieldLayoutId`, `name`, `instructions`, `hideName`, `hideInstructions`, `dateCreated`, `dateUpdated`, `uid`) VALUES ('68', '15', '22', 'Table Color', NULL, '0', '0', '2019-12-17 01:04:29', '2019-12-17 01:04:29', 'f301d903-be4a-42ba-8ab1-23e7154995c3');
INSERT INTO `fieldlabels` (`id`, `fieldId`, `fieldLayoutId`, `name`, `instructions`, `hideName`, `hideInstructions`, `dateCreated`, `dateUpdated`, `uid`) VALUES ('69', '6', '23', 'Button Size', NULL, '0', '0', '2019-12-17 01:04:29', '2019-12-17 01:04:29', 'e60c5f66-c8fe-41de-acd0-e501e74b4bdb');
INSERT INTO `fieldlabels` (`id`, `fieldId`, `fieldLayoutId`, `name`, `instructions`, `hideName`, `hideInstructions`, `dateCreated`, `dateUpdated`, `uid`) VALUES ('70', '15', '23', 'Button Color', NULL, '0', '0', '2019-12-17 01:04:29', '2019-12-17 01:04:29', '4d65607a-3aa7-4d62-a7af-5e157bcea397');
INSERT INTO `fieldlabels` (`id`, `fieldId`, `fieldLayoutId`, `name`, `instructions`, `hideName`, `hideInstructions`, `dateCreated`, `dateUpdated`, `uid`) VALUES ('71', '13', '26', 'Thumbnail Aspect Ratio', NULL, '0', '0', '2019-12-17 01:04:30', '2019-12-17 01:04:30', '7f4f3fd6-f500-45c7-b570-0785a090d565');
INSERT INTO `fieldlabels` (`id`, `fieldId`, `fieldLayoutId`, `name`, `instructions`, `hideName`, `hideInstructions`, `dateCreated`, `dateUpdated`, `uid`) VALUES ('72', '37', '31', NULL, 'If you would like the user to be redirected to another page upon successfully submitting the form, select it here.', '0', '0', '2019-12-17 01:04:30', '2019-12-17 01:04:30', '3d8bf18a-b682-4cea-8d56-8986020e538c');
INSERT INTO `fieldlabels` (`id`, `fieldId`, `fieldLayoutId`, `name`, `instructions`, `hideName`, `hideInstructions`, `dateCreated`, `dateUpdated`, `uid`) VALUES ('73', '39', '31', 'Recipient Email Address', 'Email address of who should receive notifications when a user submits this form. Leave blank to forward notifications to your business email address defined in \"Globals\" > \"General\"', '0', '0', '2019-12-17 01:04:30', '2019-12-17 01:04:30', '78f7bf5c-0a3d-46ef-877d-e5bc2ca0c2f8');
INSERT INTO `fieldlabels` (`id`, `fieldId`, `fieldLayoutId`, `name`, `instructions`, `hideName`, `hideInstructions`, `dateCreated`, `dateUpdated`, `uid`) VALUES ('74', '27', '18', 'Background Image', NULL, '0', '0', '2019-12-17 01:05:13', '2019-12-17 01:05:13', '3257468b-931d-4658-8ff1-327f55923542');
INSERT INTO `fieldlabels` (`id`, `fieldId`, `fieldLayoutId`, `name`, `instructions`, `hideName`, `hideInstructions`, `dateCreated`, `dateUpdated`, `uid`) VALUES ('75', '15', '6', 'Table Color', NULL, '0', '0', '2019-12-17 01:05:13', '2019-12-17 01:05:13', '98d9769d-86a3-4eca-bfe6-ed419f9b948e');
INSERT INTO `fieldlabels` (`id`, `fieldId`, `fieldLayoutId`, `name`, `instructions`, `hideName`, `hideInstructions`, `dateCreated`, `dateUpdated`, `uid`) VALUES ('76', '6', '7', 'Button Size', NULL, '0', '0', '2019-12-17 01:05:13', '2019-12-17 01:05:13', '2b1335e6-5b47-49ef-bfde-bfa8c491ac0e');
INSERT INTO `fieldlabels` (`id`, `fieldId`, `fieldLayoutId`, `name`, `instructions`, `hideName`, `hideInstructions`, `dateCreated`, `dateUpdated`, `uid`) VALUES ('77', '15', '7', 'Button Color', NULL, '0', '0', '2019-12-17 01:05:13', '2019-12-17 01:05:13', 'e7fd382f-0cce-4294-acf8-150076569d20');
INSERT INTO `fieldlabels` (`id`, `fieldId`, `fieldLayoutId`, `name`, `instructions`, `hideName`, `hideInstructions`, `dateCreated`, `dateUpdated`, `uid`) VALUES ('78', '13', '10', 'Thumbnail Aspect Ratio', NULL, '0', '0', '2019-12-17 01:05:13', '2019-12-17 01:05:13', '01fd4b03-a734-4748-ba98-7fa0e38b7efd');
INSERT INTO `fieldlabels` (`id`, `fieldId`, `fieldLayoutId`, `name`, `instructions`, `hideName`, `hideInstructions`, `dateCreated`, `dateUpdated`, `uid`) VALUES ('79', '37', '16', NULL, 'If you would like the user to be redirected to another page upon successfully submitting the form, select it here.', '0', '0', '2019-12-17 01:05:13', '2019-12-17 01:05:13', 'b40538c5-0c41-41e0-9870-d96cd269224f');
INSERT INTO `fieldlabels` (`id`, `fieldId`, `fieldLayoutId`, `name`, `instructions`, `hideName`, `hideInstructions`, `dateCreated`, `dateUpdated`, `uid`) VALUES ('80', '39', '16', 'Recipient Email Address', 'Email address of who should receive notifications when a user submits this form. Leave blank to forward notifications to your business email address defined in \"Globals\" > \"General\"', '0', '0', '2019-12-17 01:05:13', '2019-12-17 01:05:13', '6b34b961-3add-429c-9947-b1db0caef17c');

INSERT INTO `fieldlayoutfields` (`id`, `layoutId`, `tabId`, `fieldId`, `required`, `sortOrder`, `dateCreated`, `dateUpdated`, `uid`) VALUES ('2', '1', '2', '1', '0', '1', '2019-12-16 11:23:49', '2019-12-16 11:23:49', 'a7ea0651-a113-411b-9ec2-9b6a1e95cdf0');
INSERT INTO `fieldlayoutfields` (`id`, `layoutId`, `tabId`, `fieldId`, `required`, `sortOrder`, `dateCreated`, `dateUpdated`, `uid`) VALUES ('279', '35', '179', '30', '1', '2', '2019-12-16 21:17:44', '2019-12-16 21:17:44', '603babe0-7b11-4ebd-8916-5a4c7119510d');
INSERT INTO `fieldlayoutfields` (`id`, `layoutId`, `tabId`, `fieldId`, `required`, `sortOrder`, `dateCreated`, `dateUpdated`, `uid`) VALUES ('280', '35', '179', '36', '0', '1', '2019-12-16 21:17:44', '2019-12-16 21:17:44', 'b9e76742-cb75-4c87-9d76-e0359d6dc5bf');
INSERT INTO `fieldlayoutfields` (`id`, `layoutId`, `tabId`, `fieldId`, `required`, `sortOrder`, `dateCreated`, `dateUpdated`, `uid`) VALUES ('281', '35', '180', '21', '0', '3', '2019-12-16 21:17:44', '2019-12-16 21:17:44', 'e0ca7d49-d6d1-4960-98ec-ab3e29a59875');
INSERT INTO `fieldlayoutfields` (`id`, `layoutId`, `tabId`, `fieldId`, `required`, `sortOrder`, `dateCreated`, `dateUpdated`, `uid`) VALUES ('282', '35', '180', '8', '0', '2', '2019-12-16 21:17:44', '2019-12-16 21:17:44', '97fd6989-674c-454f-b526-14bb77f4210e');
INSERT INTO `fieldlayoutfields` (`id`, `layoutId`, `tabId`, `fieldId`, `required`, `sortOrder`, `dateCreated`, `dateUpdated`, `uid`) VALUES ('283', '35', '180', '27', '0', '1', '2019-12-16 21:17:44', '2019-12-16 21:17:44', 'e6c670b1-5d02-4465-8922-497a21246adb');
INSERT INTO `fieldlayoutfields` (`id`, `layoutId`, `tabId`, `fieldId`, `required`, `sortOrder`, `dateCreated`, `dateUpdated`, `uid`) VALUES ('290', '38', '183', '31', '1', '2', '2019-12-16 21:20:36', '2019-12-16 21:20:36', '432c3e93-7cd5-489d-af6f-f5fee24c3d7a');
INSERT INTO `fieldlayoutfields` (`id`, `layoutId`, `tabId`, `fieldId`, `required`, `sortOrder`, `dateCreated`, `dateUpdated`, `uid`) VALUES ('291', '38', '183', '33', '0', '3', '2019-12-16 21:20:36', '2019-12-16 21:20:36', '40be2573-197e-4dcb-930e-cb8227e7ed18');
INSERT INTO `fieldlayoutfields` (`id`, `layoutId`, `tabId`, `fieldId`, `required`, `sortOrder`, `dateCreated`, `dateUpdated`, `uid`) VALUES ('292', '38', '183', '36', '0', '1', '2019-12-16 21:20:36', '2019-12-16 21:20:36', '123d6bb0-4f20-486e-a2e0-929458a4380b');
INSERT INTO `fieldlayoutfields` (`id`, `layoutId`, `tabId`, `fieldId`, `required`, `sortOrder`, `dateCreated`, `dateUpdated`, `uid`) VALUES ('293', '38', '184', '21', '0', '3', '2019-12-16 21:20:36', '2019-12-16 21:20:36', 'd8de6367-c537-46b7-8a47-f54683f9e68e');
INSERT INTO `fieldlayoutfields` (`id`, `layoutId`, `tabId`, `fieldId`, `required`, `sortOrder`, `dateCreated`, `dateUpdated`, `uid`) VALUES ('294', '38', '184', '8', '0', '2', '2019-12-16 21:20:36', '2019-12-16 21:20:36', '435727c4-ab29-4807-b097-51785b21dc05');
INSERT INTO `fieldlayoutfields` (`id`, `layoutId`, `tabId`, `fieldId`, `required`, `sortOrder`, `dateCreated`, `dateUpdated`, `uid`) VALUES ('295', '38', '184', '27', '0', '1', '2019-12-16 21:20:36', '2019-12-16 21:20:36', '6d17ba03-3c60-475b-b8bc-bc9a5c758b1d');
INSERT INTO `fieldlayoutfields` (`id`, `layoutId`, `tabId`, `fieldId`, `required`, `sortOrder`, `dateCreated`, `dateUpdated`, `uid`) VALUES ('296', '41', '185', '30', '1', '1', '2019-12-16 21:22:54', '2019-12-16 21:22:54', 'f3f4f2d2-f8f1-4a1c-8d8b-0f69e59ca3f1');
INSERT INTO `fieldlayoutfields` (`id`, `layoutId`, `tabId`, `fieldId`, `required`, `sortOrder`, `dateCreated`, `dateUpdated`, `uid`) VALUES ('297', '41', '186', '21', '0', '3', '2019-12-16 21:22:54', '2019-12-16 21:22:54', 'c8e5809b-9721-4c47-aa46-53393b0a6fb0');
INSERT INTO `fieldlayoutfields` (`id`, `layoutId`, `tabId`, `fieldId`, `required`, `sortOrder`, `dateCreated`, `dateUpdated`, `uid`) VALUES ('298', '41', '186', '8', '0', '2', '2019-12-16 21:22:54', '2019-12-16 21:22:54', '88120f5b-c16d-48b9-b0cc-2fd38fb856e8');
INSERT INTO `fieldlayoutfields` (`id`, `layoutId`, `tabId`, `fieldId`, `required`, `sortOrder`, `dateCreated`, `dateUpdated`, `uid`) VALUES ('299', '41', '186', '27', '0', '1', '2019-12-16 21:22:54', '2019-12-16 21:22:54', 'bdff0a6a-7fd7-44fd-91b6-80b28f4117ef');
INSERT INTO `fieldlayoutfields` (`id`, `layoutId`, `tabId`, `fieldId`, `required`, `sortOrder`, `dateCreated`, `dateUpdated`, `uid`) VALUES ('302', '42', '189', '30', '1', '1', '2019-12-16 21:28:08', '2019-12-16 21:28:08', '787b11a4-4f67-4464-a6c1-1e9683780e78');
INSERT INTO `fieldlayoutfields` (`id`, `layoutId`, `tabId`, `fieldId`, `required`, `sortOrder`, `dateCreated`, `dateUpdated`, `uid`) VALUES ('303', '42', '190', '21', '0', '3', '2019-12-16 21:28:08', '2019-12-16 21:28:08', '2af1d33d-93fe-4393-b4da-d738cf515c60');
INSERT INTO `fieldlayoutfields` (`id`, `layoutId`, `tabId`, `fieldId`, `required`, `sortOrder`, `dateCreated`, `dateUpdated`, `uid`) VALUES ('304', '42', '190', '8', '0', '2', '2019-12-16 21:28:08', '2019-12-16 21:28:08', '522aae12-9bec-497c-9213-c74fb29fea57');
INSERT INTO `fieldlayoutfields` (`id`, `layoutId`, `tabId`, `fieldId`, `required`, `sortOrder`, `dateCreated`, `dateUpdated`, `uid`) VALUES ('305', '42', '190', '27', '0', '1', '2019-12-16 21:28:08', '2019-12-16 21:28:08', '96d56d5a-55e7-43c4-ad31-e82558221487');
INSERT INTO `fieldlayoutfields` (`id`, `layoutId`, `tabId`, `fieldId`, `required`, `sortOrder`, `dateCreated`, `dateUpdated`, `uid`) VALUES ('306', '43', '191', '21', '0', '3', '2019-12-16 21:35:05', '2019-12-16 21:35:05', '6756f530-f5a2-4811-affb-dfa239e48c59');
INSERT INTO `fieldlayoutfields` (`id`, `layoutId`, `tabId`, `fieldId`, `required`, `sortOrder`, `dateCreated`, `dateUpdated`, `uid`) VALUES ('307', '43', '191', '8', '0', '2', '2019-12-16 21:35:05', '2019-12-16 21:35:05', '346a53c3-3135-4c18-821a-cb3656411c02');
INSERT INTO `fieldlayoutfields` (`id`, `layoutId`, `tabId`, `fieldId`, `required`, `sortOrder`, `dateCreated`, `dateUpdated`, `uid`) VALUES ('308', '43', '191', '27', '0', '1', '2019-12-16 21:35:05', '2019-12-16 21:35:05', '22ad159d-b2c9-42eb-a8b7-cfc4a6b440fc');
INSERT INTO `fieldlayoutfields` (`id`, `layoutId`, `tabId`, `fieldId`, `required`, `sortOrder`, `dateCreated`, `dateUpdated`, `uid`) VALUES ('309', '2', '192', '1', '0', '1', '2019-12-16 21:40:04', '2019-12-16 21:40:04', 'b1d279d6-a112-48b5-b2ea-94b3fe809ec2');
INSERT INTO `fieldlayoutfields` (`id`, `layoutId`, `tabId`, `fieldId`, `required`, `sortOrder`, `dateCreated`, `dateUpdated`, `uid`) VALUES ('310', '2', '192', '27', '0', '2', '2019-12-16 21:40:04', '2019-12-16 21:40:04', 'd686b132-7835-49c6-9a68-88774aa44744');
INSERT INTO `fieldlayoutfields` (`id`, `layoutId`, `tabId`, `fieldId`, `required`, `sortOrder`, `dateCreated`, `dateUpdated`, `uid`) VALUES ('357', '36', '222', '34', '0', '4', '2019-12-17 00:45:52', '2019-12-17 00:45:52', '4200046b-e08e-4581-b5e1-b682d97503bd');
INSERT INTO `fieldlayoutfields` (`id`, `layoutId`, `tabId`, `fieldId`, `required`, `sortOrder`, `dateCreated`, `dateUpdated`, `uid`) VALUES ('358', '36', '222', '38', '0', '2', '2019-12-17 00:45:52', '2019-12-17 00:45:52', 'b84f0112-c7b0-4c89-9b6c-1919fed8c569');
INSERT INTO `fieldlayoutfields` (`id`, `layoutId`, `tabId`, `fieldId`, `required`, `sortOrder`, `dateCreated`, `dateUpdated`, `uid`) VALUES ('359', '36', '222', '33', '0', '3', '2019-12-17 00:45:52', '2019-12-17 00:45:52', '79482019-25c8-4b5a-a778-39a94f2601de');
INSERT INTO `fieldlayoutfields` (`id`, `layoutId`, `tabId`, `fieldId`, `required`, `sortOrder`, `dateCreated`, `dateUpdated`, `uid`) VALUES ('360', '36', '222', '36', '0', '1', '2019-12-17 00:45:52', '2019-12-17 00:45:52', '0420c8d4-c4c7-4a2f-8696-151360f7ba68');
INSERT INTO `fieldlayoutfields` (`id`, `layoutId`, `tabId`, `fieldId`, `required`, `sortOrder`, `dateCreated`, `dateUpdated`, `uid`) VALUES ('361', '36', '223', '21', '0', '3', '2019-12-17 00:45:52', '2019-12-17 00:45:52', '8cc0ebb0-db77-4535-92c3-6b29d7b7b05e');
INSERT INTO `fieldlayoutfields` (`id`, `layoutId`, `tabId`, `fieldId`, `required`, `sortOrder`, `dateCreated`, `dateUpdated`, `uid`) VALUES ('362', '36', '223', '8', '0', '2', '2019-12-17 00:45:52', '2019-12-17 00:45:52', '84f9dddb-1182-43ea-8de9-6a43d7d307a6');
INSERT INTO `fieldlayoutfields` (`id`, `layoutId`, `tabId`, `fieldId`, `required`, `sortOrder`, `dateCreated`, `dateUpdated`, `uid`) VALUES ('363', '36', '223', '27', '0', '1', '2019-12-17 00:45:52', '2019-12-17 00:45:52', '6a9b72d4-6852-46cd-bde4-da857f3e6280');
INSERT INTO `fieldlayoutfields` (`id`, `layoutId`, `tabId`, `fieldId`, `required`, `sortOrder`, `dateCreated`, `dateUpdated`, `uid`) VALUES ('453', '37', '279', '27', '0', '1', '2019-12-17 00:55:20', '2019-12-17 00:55:20', 'c31d3c25-0e86-43c8-80a6-72dc3b5b8ddd');
INSERT INTO `fieldlayoutfields` (`id`, `layoutId`, `tabId`, `fieldId`, `required`, `sortOrder`, `dateCreated`, `dateUpdated`, `uid`) VALUES ('454', '37', '280', '35', '0', '1', '2019-12-17 00:55:20', '2019-12-17 00:55:20', '6dea5c7f-2d89-4a7c-8934-6e64cbf8890b');
INSERT INTO `fieldlayoutfields` (`id`, `layoutId`, `tabId`, `fieldId`, `required`, `sortOrder`, `dateCreated`, `dateUpdated`, `uid`) VALUES ('500', '19', '308', '3', '1', '1', '2019-12-17 01:04:29', '2019-12-17 01:04:29', 'ff791562-5df3-490e-9ff6-b537c12c0826');
INSERT INTO `fieldlayoutfields` (`id`, `layoutId`, `tabId`, `fieldId`, `required`, `sortOrder`, `dateCreated`, `dateUpdated`, `uid`) VALUES ('501', '19', '309', '5', '0', '3', '2019-12-17 01:04:29', '2019-12-17 01:04:29', 'a7ecf257-e732-4dd1-88e5-cc9d57aa2609');
INSERT INTO `fieldlayoutfields` (`id`, `layoutId`, `tabId`, `fieldId`, `required`, `sortOrder`, `dateCreated`, `dateUpdated`, `uid`) VALUES ('502', '19', '309', '15', '0', '4', '2019-12-17 01:04:29', '2019-12-17 01:04:29', 'fa6c4106-45f5-43f5-aa22-c75e5d1d3688');
INSERT INTO `fieldlayoutfields` (`id`, `layoutId`, `tabId`, `fieldId`, `required`, `sortOrder`, `dateCreated`, `dateUpdated`, `uid`) VALUES ('503', '19', '309', '6', '0', '2', '2019-12-17 01:04:29', '2019-12-17 01:04:29', '150f198f-0839-4a71-a9b4-b65d39298a17');
INSERT INTO `fieldlayoutfields` (`id`, `layoutId`, `tabId`, `fieldId`, `required`, `sortOrder`, `dateCreated`, `dateUpdated`, `uid`) VALUES ('504', '19', '309', '19', '0', '1', '2019-12-17 01:04:29', '2019-12-17 01:04:29', '82dedf32-ea4d-4500-88e1-348b78f62901');
INSERT INTO `fieldlayoutfields` (`id`, `layoutId`, `tabId`, `fieldId`, `required`, `sortOrder`, `dateCreated`, `dateUpdated`, `uid`) VALUES ('505', '20', '310', '4', '1', '1', '2019-12-17 01:04:29', '2019-12-17 01:04:29', 'f3bc2102-a6fb-46f4-baa4-25b6605bdf1c');
INSERT INTO `fieldlayoutfields` (`id`, `layoutId`, `tabId`, `fieldId`, `required`, `sortOrder`, `dateCreated`, `dateUpdated`, `uid`) VALUES ('506', '20', '311', '5', '0', '1', '2019-12-17 01:04:29', '2019-12-17 01:04:29', 'cce2f852-996f-4101-bcb7-22a42b439fe6');
INSERT INTO `fieldlayoutfields` (`id`, `layoutId`, `tabId`, `fieldId`, `required`, `sortOrder`, `dateCreated`, `dateUpdated`, `uid`) VALUES ('507', '20', '311', '15', '0', '3', '2019-12-17 01:04:29', '2019-12-17 01:04:29', '646fbe6d-b540-481c-85fd-bd2dcd8448bb');
INSERT INTO `fieldlayoutfields` (`id`, `layoutId`, `tabId`, `fieldId`, `required`, `sortOrder`, `dateCreated`, `dateUpdated`, `uid`) VALUES ('508', '20', '311', '6', '0', '2', '2019-12-17 01:04:29', '2019-12-17 01:04:29', 'a724067b-8898-401e-b817-cdd75fd83814');
INSERT INTO `fieldlayoutfields` (`id`, `layoutId`, `tabId`, `fieldId`, `required`, `sortOrder`, `dateCreated`, `dateUpdated`, `uid`) VALUES ('509', '21', '312', '9', '0', '2', '2019-12-17 01:04:29', '2019-12-17 01:04:29', '0767b7ae-93c4-445b-96cb-a9c1771fd089');
INSERT INTO `fieldlayoutfields` (`id`, `layoutId`, `tabId`, `fieldId`, `required`, `sortOrder`, `dateCreated`, `dateUpdated`, `uid`) VALUES ('510', '21', '312', '24', '1', '1', '2019-12-17 01:04:29', '2019-12-17 01:04:29', 'bcb998c3-fab5-4a62-b6df-b9531a1d2d56');
INSERT INTO `fieldlayoutfields` (`id`, `layoutId`, `tabId`, `fieldId`, `required`, `sortOrder`, `dateCreated`, `dateUpdated`, `uid`) VALUES ('511', '21', '313', '7', '0', '3', '2019-12-17 01:04:29', '2019-12-17 01:04:29', '4ac4a93a-1d35-48ec-800a-adc96c9f9ce7');
INSERT INTO `fieldlayoutfields` (`id`, `layoutId`, `tabId`, `fieldId`, `required`, `sortOrder`, `dateCreated`, `dateUpdated`, `uid`) VALUES ('512', '21', '313', '5', '0', '1', '2019-12-17 01:04:29', '2019-12-17 01:04:29', 'd614daaf-370c-4549-bc8d-a4c3722cb66b');
INSERT INTO `fieldlayoutfields` (`id`, `layoutId`, `tabId`, `fieldId`, `required`, `sortOrder`, `dateCreated`, `dateUpdated`, `uid`) VALUES ('513', '21', '313', '15', '0', '2', '2019-12-17 01:04:29', '2019-12-17 01:04:29', '21e3bac2-9ea5-4e0f-b5bd-22bc66c6651b');
INSERT INTO `fieldlayoutfields` (`id`, `layoutId`, `tabId`, `fieldId`, `required`, `sortOrder`, `dateCreated`, `dateUpdated`, `uid`) VALUES ('514', '22', '314', '10', '1', '1', '2019-12-17 01:04:29', '2019-12-17 01:04:29', 'ad37d5b3-e08a-4dbf-b278-e7ff0709d612');
INSERT INTO `fieldlayoutfields` (`id`, `layoutId`, `tabId`, `fieldId`, `required`, `sortOrder`, `dateCreated`, `dateUpdated`, `uid`) VALUES ('515', '22', '315', '15', '0', '1', '2019-12-17 01:04:29', '2019-12-17 01:04:29', '2f33cfbd-1b5c-463a-9c01-8725419435e5');
INSERT INTO `fieldlayoutfields` (`id`, `layoutId`, `tabId`, `fieldId`, `required`, `sortOrder`, `dateCreated`, `dateUpdated`, `uid`) VALUES ('516', '23', '316', '25', '1', '1', '2019-12-17 01:04:29', '2019-12-17 01:04:29', 'a93035dc-92e1-4174-a939-306cbecdc22f');
INSERT INTO `fieldlayoutfields` (`id`, `layoutId`, `tabId`, `fieldId`, `required`, `sortOrder`, `dateCreated`, `dateUpdated`, `uid`) VALUES ('517', '23', '317', '15', '0', '2', '2019-12-17 01:04:29', '2019-12-17 01:04:29', '5dce99d8-bb4d-4d65-a432-bd7cf98885eb');
INSERT INTO `fieldlayoutfields` (`id`, `layoutId`, `tabId`, `fieldId`, `required`, `sortOrder`, `dateCreated`, `dateUpdated`, `uid`) VALUES ('518', '23', '317', '6', '0', '1', '2019-12-17 01:04:29', '2019-12-17 01:04:29', '6e63668f-8819-410b-ac75-d8725542fd72');
INSERT INTO `fieldlayoutfields` (`id`, `layoutId`, `tabId`, `fieldId`, `required`, `sortOrder`, `dateCreated`, `dateUpdated`, `uid`) VALUES ('519', '24', '318', '2', '0', '2', '2019-12-17 01:04:29', '2019-12-17 01:04:29', 'df0ebe3e-a9a6-475f-a11e-f3e4110dabd9');
INSERT INTO `fieldlayoutfields` (`id`, `layoutId`, `tabId`, `fieldId`, `required`, `sortOrder`, `dateCreated`, `dateUpdated`, `uid`) VALUES ('520', '24', '318', '27', '1', '1', '2019-12-17 01:04:29', '2019-12-17 01:04:29', 'caed03b8-2203-4dd7-abc6-2fa3c448be80');
INSERT INTO `fieldlayoutfields` (`id`, `layoutId`, `tabId`, `fieldId`, `required`, `sortOrder`, `dateCreated`, `dateUpdated`, `uid`) VALUES ('521', '24', '319', '7', '0', '1', '2019-12-17 01:04:29', '2019-12-17 01:04:29', '3f8cff74-8224-4db1-899d-469542fe1b90');
INSERT INTO `fieldlayoutfields` (`id`, `layoutId`, `tabId`, `fieldId`, `required`, `sortOrder`, `dateCreated`, `dateUpdated`, `uid`) VALUES ('522', '24', '319', '13', '0', '2', '2019-12-17 01:04:29', '2019-12-17 01:04:29', '00491057-fe4a-4ce1-9e35-117d9a9363aa');
INSERT INTO `fieldlayoutfields` (`id`, `layoutId`, `tabId`, `fieldId`, `required`, `sortOrder`, `dateCreated`, `dateUpdated`, `uid`) VALUES ('523', '25', '320', '29', '1', '1', '2019-12-17 01:04:29', '2019-12-17 01:04:29', '06b3fa05-98d5-478a-b4f0-1b5bc9f0c598');
INSERT INTO `fieldlayoutfields` (`id`, `layoutId`, `tabId`, `fieldId`, `required`, `sortOrder`, `dateCreated`, `dateUpdated`, `uid`) VALUES ('524', '25', '320', '2', '0', '2', '2019-12-17 01:04:29', '2019-12-17 01:04:29', '752ff4e0-8bfc-443d-9f28-1736cf49d32b');
INSERT INTO `fieldlayoutfields` (`id`, `layoutId`, `tabId`, `fieldId`, `required`, `sortOrder`, `dateCreated`, `dateUpdated`, `uid`) VALUES ('525', '25', '321', '7', '0', '1', '2019-12-17 01:04:29', '2019-12-17 01:04:29', '7aeb5c93-ba70-4ccf-b369-b70c1e44ec46');
INSERT INTO `fieldlayoutfields` (`id`, `layoutId`, `tabId`, `fieldId`, `required`, `sortOrder`, `dateCreated`, `dateUpdated`, `uid`) VALUES ('526', '26', '322', '28', '1', '1', '2019-12-17 01:04:30', '2019-12-17 01:04:30', '18f101cc-284f-4da4-a948-893347267d80');
INSERT INTO `fieldlayoutfields` (`id`, `layoutId`, `tabId`, `fieldId`, `required`, `sortOrder`, `dateCreated`, `dateUpdated`, `uid`) VALUES ('527', '26', '323', '13', '0', '2', '2019-12-17 01:04:30', '2019-12-17 01:04:30', '2dc38bee-b9cf-4aaa-8898-d3c2fcee349d');
INSERT INTO `fieldlayoutfields` (`id`, `layoutId`, `tabId`, `fieldId`, `required`, `sortOrder`, `dateCreated`, `dateUpdated`, `uid`) VALUES ('528', '26', '323', '17', '0', '1', '2019-12-17 01:04:30', '2019-12-17 01:04:30', 'bb15cab2-c4af-41fa-ab84-ab9d0b404f86');
INSERT INTO `fieldlayoutfields` (`id`, `layoutId`, `tabId`, `fieldId`, `required`, `sortOrder`, `dateCreated`, `dateUpdated`, `uid`) VALUES ('529', '28', '325', '14', '0', '2', '2019-12-17 01:04:30', '2019-12-17 01:04:30', 'f517ed05-8eba-4a7a-b51b-8aa6dfde5396');
INSERT INTO `fieldlayoutfields` (`id`, `layoutId`, `tabId`, `fieldId`, `required`, `sortOrder`, `dateCreated`, `dateUpdated`, `uid`) VALUES ('530', '28', '325', '20', '0', '1', '2019-12-17 01:04:30', '2019-12-17 01:04:30', '177799c3-afe0-402e-82cc-cec86b1d8dde');
INSERT INTO `fieldlayoutfields` (`id`, `layoutId`, `tabId`, `fieldId`, `required`, `sortOrder`, `dateCreated`, `dateUpdated`, `uid`) VALUES ('531', '40', '326', '26', '1', '1', '2019-12-17 01:04:30', '2019-12-17 01:04:30', 'f8a35265-9611-4602-a69a-5bf614ee226a');
INSERT INTO `fieldlayoutfields` (`id`, `layoutId`, `tabId`, `fieldId`, `required`, `sortOrder`, `dateCreated`, `dateUpdated`, `uid`) VALUES ('532', '40', '326', '2', '0', '2', '2019-12-17 01:04:30', '2019-12-17 01:04:30', '7dc10a89-1774-468c-b251-daeb42e268ea');
INSERT INTO `fieldlayoutfields` (`id`, `layoutId`, `tabId`, `fieldId`, `required`, `sortOrder`, `dateCreated`, `dateUpdated`, `uid`) VALUES ('533', '40', '327', '7', '0', '1', '2019-12-17 01:04:30', '2019-12-17 01:04:30', 'b96f3958-02ca-4e9c-a373-e3b73745d5ff');
INSERT INTO `fieldlayoutfields` (`id`, `layoutId`, `tabId`, `fieldId`, `required`, `sortOrder`, `dateCreated`, `dateUpdated`, `uid`) VALUES ('534', '40', '327', '13', '0', '2', '2019-12-17 01:04:30', '2019-12-17 01:04:30', '7567f694-1bce-4367-9f65-dd76b1d522cb');
INSERT INTO `fieldlayoutfields` (`id`, `layoutId`, `tabId`, `fieldId`, `required`, `sortOrder`, `dateCreated`, `dateUpdated`, `uid`) VALUES ('535', '31', '330', '37', '0', '3', '2019-12-17 01:04:30', '2019-12-17 01:04:30', 'c0233bda-d54e-4b22-8c8f-511ebe38b863');
INSERT INTO `fieldlayoutfields` (`id`, `layoutId`, `tabId`, `fieldId`, `required`, `sortOrder`, `dateCreated`, `dateUpdated`, `uid`) VALUES ('536', '31', '330', '11', '1', '1', '2019-12-17 01:04:30', '2019-12-17 01:04:30', 'ee5e7e02-9385-4cbb-a1e1-b5ba5c766919');
INSERT INTO `fieldlayoutfields` (`id`, `layoutId`, `tabId`, `fieldId`, `required`, `sortOrder`, `dateCreated`, `dateUpdated`, `uid`) VALUES ('537', '31', '330', '22', '0', '2', '2019-12-17 01:04:30', '2019-12-17 01:04:30', 'e3f1928f-b9c5-4807-98e1-e2bef1aeaec8');
INSERT INTO `fieldlayoutfields` (`id`, `layoutId`, `tabId`, `fieldId`, `required`, `sortOrder`, `dateCreated`, `dateUpdated`, `uid`) VALUES ('538', '31', '330', '39', '0', '4', '2019-12-17 01:04:30', '2019-12-17 01:04:30', '5a398fe8-9926-4304-96a0-3cf01b9e2845');
INSERT INTO `fieldlayoutfields` (`id`, `layoutId`, `tabId`, `fieldId`, `required`, `sortOrder`, `dateCreated`, `dateUpdated`, `uid`) VALUES ('539', '32', '331', '23', '1', '1', '2019-12-17 01:04:30', '2019-12-17 01:04:30', 'aa6fea4a-bfaa-4fd2-b14b-cfabf0f34b9c');
INSERT INTO `fieldlayoutfields` (`id`, `layoutId`, `tabId`, `fieldId`, `required`, `sortOrder`, `dateCreated`, `dateUpdated`, `uid`) VALUES ('540', '27', '332', '27', '1', '1', '2019-12-17 01:04:30', '2019-12-17 01:04:30', '4b584982-dda6-43f3-91f5-5be412a8aff4');
INSERT INTO `fieldlayoutfields` (`id`, `layoutId`, `tabId`, `fieldId`, `required`, `sortOrder`, `dateCreated`, `dateUpdated`, `uid`) VALUES ('541', '33', '333', '3', '1', '1', '2019-12-17 01:04:30', '2019-12-17 01:04:30', '0cc68ed3-da68-4716-9635-edf29a989cbb');
INSERT INTO `fieldlayoutfields` (`id`, `layoutId`, `tabId`, `fieldId`, `required`, `sortOrder`, `dateCreated`, `dateUpdated`, `uid`) VALUES ('542', '18', '335', '18', '0', '2', '2019-12-17 01:05:13', '2019-12-17 01:05:13', '08e08e27-9135-4367-bd7f-983af6bc6f86');
INSERT INTO `fieldlayoutfields` (`id`, `layoutId`, `tabId`, `fieldId`, `required`, `sortOrder`, `dateCreated`, `dateUpdated`, `uid`) VALUES ('543', '18', '335', '16', '0', '3', '2019-12-17 01:05:13', '2019-12-17 01:05:13', '6e67016a-be72-4365-95c3-bfa8498765c2');
INSERT INTO `fieldlayoutfields` (`id`, `layoutId`, `tabId`, `fieldId`, `required`, `sortOrder`, `dateCreated`, `dateUpdated`, `uid`) VALUES ('544', '18', '335', '12', '0', '1', '2019-12-17 01:05:13', '2019-12-17 01:05:13', '40aa7153-961e-4c56-bd83-614a84e56b0b');
INSERT INTO `fieldlayoutfields` (`id`, `layoutId`, `tabId`, `fieldId`, `required`, `sortOrder`, `dateCreated`, `dateUpdated`, `uid`) VALUES ('545', '18', '335', '27', '0', '4', '2019-12-17 01:05:13', '2019-12-17 01:05:13', 'a2c1883f-3842-4e49-b0d1-b42fefb3826e');
INSERT INTO `fieldlayoutfields` (`id`, `layoutId`, `tabId`, `fieldId`, `required`, `sortOrder`, `dateCreated`, `dateUpdated`, `uid`) VALUES ('546', '3', '336', '3', '1', '1', '2019-12-17 01:05:13', '2019-12-17 01:05:13', '371074f4-25c0-4f5d-ba83-fdd50aeb184b');
INSERT INTO `fieldlayoutfields` (`id`, `layoutId`, `tabId`, `fieldId`, `required`, `sortOrder`, `dateCreated`, `dateUpdated`, `uid`) VALUES ('547', '3', '337', '5', '0', '1', '2019-12-17 01:05:13', '2019-12-17 01:05:13', 'e77d729c-a042-4812-925e-325c6bda01d9');
INSERT INTO `fieldlayoutfields` (`id`, `layoutId`, `tabId`, `fieldId`, `required`, `sortOrder`, `dateCreated`, `dateUpdated`, `uid`) VALUES ('548', '3', '337', '15', '0', '3', '2019-12-17 01:05:13', '2019-12-17 01:05:13', 'd207b044-c397-4456-b9dd-25670e2745b9');
INSERT INTO `fieldlayoutfields` (`id`, `layoutId`, `tabId`, `fieldId`, `required`, `sortOrder`, `dateCreated`, `dateUpdated`, `uid`) VALUES ('549', '3', '337', '6', '0', '2', '2019-12-17 01:05:13', '2019-12-17 01:05:13', '83c1e4c3-a22b-4cd2-ab12-96ea03ac2527');
INSERT INTO `fieldlayoutfields` (`id`, `layoutId`, `tabId`, `fieldId`, `required`, `sortOrder`, `dateCreated`, `dateUpdated`, `uid`) VALUES ('550', '3', '337', '19', '0', '4', '2019-12-17 01:05:13', '2019-12-17 01:05:13', '511b24a1-e627-4981-9ddd-1483724dae49');
INSERT INTO `fieldlayoutfields` (`id`, `layoutId`, `tabId`, `fieldId`, `required`, `sortOrder`, `dateCreated`, `dateUpdated`, `uid`) VALUES ('551', '4', '338', '4', '1', '1', '2019-12-17 01:05:13', '2019-12-17 01:05:13', '8bac4a8f-2b70-4ddd-b159-0af394ab9eb3');
INSERT INTO `fieldlayoutfields` (`id`, `layoutId`, `tabId`, `fieldId`, `required`, `sortOrder`, `dateCreated`, `dateUpdated`, `uid`) VALUES ('552', '4', '339', '5', '0', '1', '2019-12-17 01:05:13', '2019-12-17 01:05:13', 'c1e96641-169b-4040-ac7d-924614d51dce');
INSERT INTO `fieldlayoutfields` (`id`, `layoutId`, `tabId`, `fieldId`, `required`, `sortOrder`, `dateCreated`, `dateUpdated`, `uid`) VALUES ('553', '4', '339', '15', '0', '3', '2019-12-17 01:05:13', '2019-12-17 01:05:13', '410dfd48-df1d-41cf-b52a-5b0942ac8756');
INSERT INTO `fieldlayoutfields` (`id`, `layoutId`, `tabId`, `fieldId`, `required`, `sortOrder`, `dateCreated`, `dateUpdated`, `uid`) VALUES ('554', '4', '339', '6', '0', '2', '2019-12-17 01:05:13', '2019-12-17 01:05:13', '7a8addd1-a651-4eb2-a6e9-d44e2865a197');
INSERT INTO `fieldlayoutfields` (`id`, `layoutId`, `tabId`, `fieldId`, `required`, `sortOrder`, `dateCreated`, `dateUpdated`, `uid`) VALUES ('555', '5', '340', '9', '0', '2', '2019-12-17 01:05:13', '2019-12-17 01:05:13', 'a1028789-0298-40e1-9d1e-e81183fa46ea');
INSERT INTO `fieldlayoutfields` (`id`, `layoutId`, `tabId`, `fieldId`, `required`, `sortOrder`, `dateCreated`, `dateUpdated`, `uid`) VALUES ('556', '5', '340', '24', '1', '1', '2019-12-17 01:05:13', '2019-12-17 01:05:13', 'eff9ed5e-e633-45e2-ab44-c725efad37e9');
INSERT INTO `fieldlayoutfields` (`id`, `layoutId`, `tabId`, `fieldId`, `required`, `sortOrder`, `dateCreated`, `dateUpdated`, `uid`) VALUES ('557', '5', '341', '7', '0', '3', '2019-12-17 01:05:13', '2019-12-17 01:05:13', '3c3b4b56-a153-4c3c-9000-2bed4437ebe3');
INSERT INTO `fieldlayoutfields` (`id`, `layoutId`, `tabId`, `fieldId`, `required`, `sortOrder`, `dateCreated`, `dateUpdated`, `uid`) VALUES ('558', '5', '341', '5', '0', '1', '2019-12-17 01:05:13', '2019-12-17 01:05:13', '1f0b6e6c-4118-4972-8faa-f33e7e06d835');
INSERT INTO `fieldlayoutfields` (`id`, `layoutId`, `tabId`, `fieldId`, `required`, `sortOrder`, `dateCreated`, `dateUpdated`, `uid`) VALUES ('559', '5', '341', '15', '0', '2', '2019-12-17 01:05:13', '2019-12-17 01:05:13', '010439a8-b8ce-4b86-920f-75c1e57436bf');
INSERT INTO `fieldlayoutfields` (`id`, `layoutId`, `tabId`, `fieldId`, `required`, `sortOrder`, `dateCreated`, `dateUpdated`, `uid`) VALUES ('560', '6', '342', '10', '1', '1', '2019-12-17 01:05:13', '2019-12-17 01:05:13', 'c522003c-22d9-4dad-8651-942354d741cc');
INSERT INTO `fieldlayoutfields` (`id`, `layoutId`, `tabId`, `fieldId`, `required`, `sortOrder`, `dateCreated`, `dateUpdated`, `uid`) VALUES ('561', '6', '343', '15', '0', '1', '2019-12-17 01:05:13', '2019-12-17 01:05:13', 'f3e811c4-7781-4264-91f9-7a3080cd2369');
INSERT INTO `fieldlayoutfields` (`id`, `layoutId`, `tabId`, `fieldId`, `required`, `sortOrder`, `dateCreated`, `dateUpdated`, `uid`) VALUES ('562', '7', '344', '25', '1', '1', '2019-12-17 01:05:13', '2019-12-17 01:05:13', '7317fe6e-9fe0-41b2-ad01-fcef0eb305ad');
INSERT INTO `fieldlayoutfields` (`id`, `layoutId`, `tabId`, `fieldId`, `required`, `sortOrder`, `dateCreated`, `dateUpdated`, `uid`) VALUES ('563', '7', '345', '15', '0', '2', '2019-12-17 01:05:13', '2019-12-17 01:05:13', 'fe8575c2-9e76-474a-bbbe-00b1ee76f42e');
INSERT INTO `fieldlayoutfields` (`id`, `layoutId`, `tabId`, `fieldId`, `required`, `sortOrder`, `dateCreated`, `dateUpdated`, `uid`) VALUES ('564', '7', '345', '6', '0', '1', '2019-12-17 01:05:13', '2019-12-17 01:05:13', '33d795f7-1d0a-4dc7-807c-9df1b3d43de0');
INSERT INTO `fieldlayoutfields` (`id`, `layoutId`, `tabId`, `fieldId`, `required`, `sortOrder`, `dateCreated`, `dateUpdated`, `uid`) VALUES ('565', '8', '346', '2', '0', '2', '2019-12-17 01:05:13', '2019-12-17 01:05:13', '4545a31e-21ac-4ecc-b10d-a7da89cf0559');
INSERT INTO `fieldlayoutfields` (`id`, `layoutId`, `tabId`, `fieldId`, `required`, `sortOrder`, `dateCreated`, `dateUpdated`, `uid`) VALUES ('566', '8', '346', '27', '1', '1', '2019-12-17 01:05:13', '2019-12-17 01:05:13', '3dfb624a-1bea-4851-b88e-d7f11e0f209f');
INSERT INTO `fieldlayoutfields` (`id`, `layoutId`, `tabId`, `fieldId`, `required`, `sortOrder`, `dateCreated`, `dateUpdated`, `uid`) VALUES ('567', '8', '347', '7', '0', '1', '2019-12-17 01:05:13', '2019-12-17 01:05:13', '94f7a88e-40f2-4b79-81bb-10463edab57f');
INSERT INTO `fieldlayoutfields` (`id`, `layoutId`, `tabId`, `fieldId`, `required`, `sortOrder`, `dateCreated`, `dateUpdated`, `uid`) VALUES ('568', '8', '347', '13', '0', '2', '2019-12-17 01:05:13', '2019-12-17 01:05:13', '513ae7b0-1694-4175-a55b-515ef12ea24d');
INSERT INTO `fieldlayoutfields` (`id`, `layoutId`, `tabId`, `fieldId`, `required`, `sortOrder`, `dateCreated`, `dateUpdated`, `uid`) VALUES ('569', '9', '348', '29', '1', '1', '2019-12-17 01:05:13', '2019-12-17 01:05:13', '60020007-5fe8-41c7-88c9-b3b884fd1e9a');
INSERT INTO `fieldlayoutfields` (`id`, `layoutId`, `tabId`, `fieldId`, `required`, `sortOrder`, `dateCreated`, `dateUpdated`, `uid`) VALUES ('570', '9', '348', '2', '0', '2', '2019-12-17 01:05:13', '2019-12-17 01:05:13', '1dbe812c-bcbd-49e7-9925-e2216f3cc960');
INSERT INTO `fieldlayoutfields` (`id`, `layoutId`, `tabId`, `fieldId`, `required`, `sortOrder`, `dateCreated`, `dateUpdated`, `uid`) VALUES ('571', '9', '349', '7', '0', '1', '2019-12-17 01:05:13', '2019-12-17 01:05:13', '90a21979-3f75-44f9-ab97-c0250ef57faa');
INSERT INTO `fieldlayoutfields` (`id`, `layoutId`, `tabId`, `fieldId`, `required`, `sortOrder`, `dateCreated`, `dateUpdated`, `uid`) VALUES ('572', '10', '350', '28', '1', '1', '2019-12-17 01:05:13', '2019-12-17 01:05:13', 'c895f3a5-caff-468a-a91f-4fc37d332704');
INSERT INTO `fieldlayoutfields` (`id`, `layoutId`, `tabId`, `fieldId`, `required`, `sortOrder`, `dateCreated`, `dateUpdated`, `uid`) VALUES ('573', '10', '351', '13', '0', '2', '2019-12-17 01:05:13', '2019-12-17 01:05:13', '53548aac-ab4a-447d-a059-333720f5fa7d');
INSERT INTO `fieldlayoutfields` (`id`, `layoutId`, `tabId`, `fieldId`, `required`, `sortOrder`, `dateCreated`, `dateUpdated`, `uid`) VALUES ('574', '10', '351', '17', '0', '1', '2019-12-17 01:05:13', '2019-12-17 01:05:13', 'd99b3509-aee9-4bbc-ac42-8acba482b556');
INSERT INTO `fieldlayoutfields` (`id`, `layoutId`, `tabId`, `fieldId`, `required`, `sortOrder`, `dateCreated`, `dateUpdated`, `uid`) VALUES ('575', '12', '353', '14', '0', '2', '2019-12-17 01:05:13', '2019-12-17 01:05:13', '0ab94fa2-bb88-406d-81a7-d8a844eb893a');
INSERT INTO `fieldlayoutfields` (`id`, `layoutId`, `tabId`, `fieldId`, `required`, `sortOrder`, `dateCreated`, `dateUpdated`, `uid`) VALUES ('576', '12', '353', '20', '0', '1', '2019-12-17 01:05:13', '2019-12-17 01:05:13', '00c9dc19-453d-4948-8b94-d78045ecee50');
INSERT INTO `fieldlayoutfields` (`id`, `layoutId`, `tabId`, `fieldId`, `required`, `sortOrder`, `dateCreated`, `dateUpdated`, `uid`) VALUES ('577', '39', '354', '26', '1', '1', '2019-12-17 01:05:13', '2019-12-17 01:05:13', '4629b74b-cc39-4748-bf36-e599536e39e0');
INSERT INTO `fieldlayoutfields` (`id`, `layoutId`, `tabId`, `fieldId`, `required`, `sortOrder`, `dateCreated`, `dateUpdated`, `uid`) VALUES ('578', '39', '354', '2', '0', '2', '2019-12-17 01:05:13', '2019-12-17 01:05:13', 'ca7237f5-79fd-4c31-8d6a-5a8163b18c27');
INSERT INTO `fieldlayoutfields` (`id`, `layoutId`, `tabId`, `fieldId`, `required`, `sortOrder`, `dateCreated`, `dateUpdated`, `uid`) VALUES ('579', '39', '355', '7', '0', '1', '2019-12-17 01:05:13', '2019-12-17 01:05:13', 'ace3d1ce-386f-4291-bc09-d74a42d31e55');
INSERT INTO `fieldlayoutfields` (`id`, `layoutId`, `tabId`, `fieldId`, `required`, `sortOrder`, `dateCreated`, `dateUpdated`, `uid`) VALUES ('580', '39', '355', '13', '0', '2', '2019-12-17 01:05:13', '2019-12-17 01:05:13', '4d7f7dfa-5264-433a-aa53-c456654f7753');
INSERT INTO `fieldlayoutfields` (`id`, `layoutId`, `tabId`, `fieldId`, `required`, `sortOrder`, `dateCreated`, `dateUpdated`, `uid`) VALUES ('581', '16', '358', '37', '0', '3', '2019-12-17 01:05:13', '2019-12-17 01:05:13', 'd17d3dca-3cb1-4b70-8e3c-d2a77cf5a21f');
INSERT INTO `fieldlayoutfields` (`id`, `layoutId`, `tabId`, `fieldId`, `required`, `sortOrder`, `dateCreated`, `dateUpdated`, `uid`) VALUES ('582', '16', '358', '11', '1', '1', '2019-12-17 01:05:13', '2019-12-17 01:05:13', '86ed268f-e4d7-4c02-8d3e-a54f14588212');
INSERT INTO `fieldlayoutfields` (`id`, `layoutId`, `tabId`, `fieldId`, `required`, `sortOrder`, `dateCreated`, `dateUpdated`, `uid`) VALUES ('583', '16', '358', '22', '0', '2', '2019-12-17 01:05:13', '2019-12-17 01:05:13', '981e6314-055a-4e34-abac-a4ac9877ed4f');
INSERT INTO `fieldlayoutfields` (`id`, `layoutId`, `tabId`, `fieldId`, `required`, `sortOrder`, `dateCreated`, `dateUpdated`, `uid`) VALUES ('584', '16', '358', '39', '0', '4', '2019-12-17 01:05:13', '2019-12-17 01:05:13', '466f2ceb-ec8f-4610-ad27-40320854a147');
INSERT INTO `fieldlayoutfields` (`id`, `layoutId`, `tabId`, `fieldId`, `required`, `sortOrder`, `dateCreated`, `dateUpdated`, `uid`) VALUES ('585', '17', '359', '23', '1', '1', '2019-12-17 01:05:13', '2019-12-17 01:05:13', 'b24ea45f-a0af-4742-8d45-84b8f2143c37');
INSERT INTO `fieldlayoutfields` (`id`, `layoutId`, `tabId`, `fieldId`, `required`, `sortOrder`, `dateCreated`, `dateUpdated`, `uid`) VALUES ('586', '11', '360', '27', '1', '1', '2019-12-17 01:05:13', '2019-12-17 01:05:13', '50cc49db-d2b3-4ad0-841a-f5e099e205e5');
INSERT INTO `fieldlayoutfields` (`id`, `layoutId`, `tabId`, `fieldId`, `required`, `sortOrder`, `dateCreated`, `dateUpdated`, `uid`) VALUES ('587', '13', '361', '3', '1', '1', '2019-12-17 01:05:13', '2019-12-17 01:05:13', '7abe1978-b985-4659-af07-db8048694745');
INSERT INTO `fieldlayoutfields` (`id`, `layoutId`, `tabId`, `fieldId`, `required`, `sortOrder`, `dateCreated`, `dateUpdated`, `uid`) VALUES ('588', '34', '362', '32', '0', '2', '2019-12-17 01:09:13', '2019-12-17 01:09:13', '870850c4-bba3-4175-9f2e-b1b9fe564831');
INSERT INTO `fieldlayoutfields` (`id`, `layoutId`, `tabId`, `fieldId`, `required`, `sortOrder`, `dateCreated`, `dateUpdated`, `uid`) VALUES ('589', '34', '362', '26', '0', '4', '2019-12-17 01:09:13', '2019-12-17 01:09:13', '3b9673f1-7885-461c-84a3-cc32be64b262');
INSERT INTO `fieldlayoutfields` (`id`, `layoutId`, `tabId`, `fieldId`, `required`, `sortOrder`, `dateCreated`, `dateUpdated`, `uid`) VALUES ('590', '34', '362', '39', '0', '1', '2019-12-17 01:09:13', '2019-12-17 01:09:13', 'a8e7e955-fe15-4f25-85ff-be2d6de08fbf');
INSERT INTO `fieldlayoutfields` (`id`, `layoutId`, `tabId`, `fieldId`, `required`, `sortOrder`, `dateCreated`, `dateUpdated`, `uid`) VALUES ('591', '34', '362', '40', '0', '3', '2019-12-17 01:09:13', '2019-12-17 01:09:13', '0c202e60-917f-483a-b5c9-0fb9debcfc83');

INSERT INTO `fieldlayouts` (`id`, `type`, `dateCreated`, `dateUpdated`, `dateDeleted`, `uid`) VALUES ('1', 'craft\\elements\\Asset', '2019-12-16 11:23:29', '2019-12-16 11:23:29', NULL, '35c91d56-3fdb-42e0-8cc9-b00e1fa6bb70');
INSERT INTO `fieldlayouts` (`id`, `type`, `dateCreated`, `dateUpdated`, `dateDeleted`, `uid`) VALUES ('2', 'craft\\elements\\Asset', '2019-12-16 11:24:50', '2019-12-16 11:24:50', NULL, 'c6dbf030-8a39-4c50-8a65-6e9fa1e46a2e');
INSERT INTO `fieldlayouts` (`id`, `type`, `dateCreated`, `dateUpdated`, `dateDeleted`, `uid`) VALUES ('3', 'benf\\neo\\elements\\Block', '2019-12-16 11:57:50', '2019-12-17 01:05:13', NULL, '9860e55a-4ad2-43df-baeb-2766b911051b');
INSERT INTO `fieldlayouts` (`id`, `type`, `dateCreated`, `dateUpdated`, `dateDeleted`, `uid`) VALUES ('4', 'benf\\neo\\elements\\Block', '2019-12-16 11:57:50', '2019-12-17 01:05:13', NULL, '0fed8306-9bb0-4eee-ab4d-dd06627187c0');
INSERT INTO `fieldlayouts` (`id`, `type`, `dateCreated`, `dateUpdated`, `dateDeleted`, `uid`) VALUES ('5', 'benf\\neo\\elements\\Block', '2019-12-16 11:57:50', '2019-12-17 01:05:13', NULL, 'bec33071-96ef-4a3e-873b-27092aa4cc76');
INSERT INTO `fieldlayouts` (`id`, `type`, `dateCreated`, `dateUpdated`, `dateDeleted`, `uid`) VALUES ('6', 'benf\\neo\\elements\\Block', '2019-12-16 11:57:50', '2019-12-17 01:05:13', NULL, '1d566ede-cbd1-4597-812c-6c4a7ccc6265');
INSERT INTO `fieldlayouts` (`id`, `type`, `dateCreated`, `dateUpdated`, `dateDeleted`, `uid`) VALUES ('7', 'benf\\neo\\elements\\Block', '2019-12-16 11:57:50', '2019-12-17 01:05:13', NULL, 'a2749570-8f8d-4f97-a418-50bda0f93a3e');
INSERT INTO `fieldlayouts` (`id`, `type`, `dateCreated`, `dateUpdated`, `dateDeleted`, `uid`) VALUES ('8', 'benf\\neo\\elements\\Block', '2019-12-16 11:57:50', '2019-12-17 01:05:13', NULL, '43423637-8002-4f69-a541-0989d36574a5');
INSERT INTO `fieldlayouts` (`id`, `type`, `dateCreated`, `dateUpdated`, `dateDeleted`, `uid`) VALUES ('9', 'benf\\neo\\elements\\Block', '2019-12-16 11:57:50', '2019-12-17 01:05:13', NULL, 'dbc05a7f-85cb-4091-90a8-394e9de4035e');
INSERT INTO `fieldlayouts` (`id`, `type`, `dateCreated`, `dateUpdated`, `dateDeleted`, `uid`) VALUES ('10', 'benf\\neo\\elements\\Block', '2019-12-16 11:57:50', '2019-12-17 01:05:13', NULL, 'ef4c47d1-7dc7-49e8-9eae-eec68da8e8fd');
INSERT INTO `fieldlayouts` (`id`, `type`, `dateCreated`, `dateUpdated`, `dateDeleted`, `uid`) VALUES ('11', 'benf\\neo\\elements\\Block', '2019-12-16 11:57:50', '2019-12-17 01:05:13', NULL, 'a95e5b43-5bbe-48be-86d3-0b898cffe674');
INSERT INTO `fieldlayouts` (`id`, `type`, `dateCreated`, `dateUpdated`, `dateDeleted`, `uid`) VALUES ('12', 'benf\\neo\\elements\\Block', '2019-12-16 11:57:50', '2019-12-17 01:05:13', NULL, 'b1ab227c-a66c-4f43-a95e-95cecc1fe7b9');
INSERT INTO `fieldlayouts` (`id`, `type`, `dateCreated`, `dateUpdated`, `dateDeleted`, `uid`) VALUES ('13', 'benf\\neo\\elements\\Block', '2019-12-16 11:57:50', '2019-12-17 01:05:13', NULL, '36861469-36fc-4375-88cc-36d2ead6d3bf');
INSERT INTO `fieldlayouts` (`id`, `type`, `dateCreated`, `dateUpdated`, `dateDeleted`, `uid`) VALUES ('14', 'benf\\neo\\elements\\Block', '2019-12-16 11:57:50', '2019-12-17 01:05:13', NULL, 'd6da7468-737b-4a4f-8b8c-291ff48d7565');
INSERT INTO `fieldlayouts` (`id`, `type`, `dateCreated`, `dateUpdated`, `dateDeleted`, `uid`) VALUES ('15', 'benf\\neo\\elements\\Block', '2019-12-16 11:57:50', '2019-12-17 01:05:13', NULL, 'ec49bda0-19d8-402b-a4da-457d363e5a37');
INSERT INTO `fieldlayouts` (`id`, `type`, `dateCreated`, `dateUpdated`, `dateDeleted`, `uid`) VALUES ('16', 'benf\\neo\\elements\\Block', '2019-12-16 11:57:50', '2019-12-17 01:05:13', NULL, 'c96dbb5c-2f37-4af1-b4af-8b91aaf5ab09');
INSERT INTO `fieldlayouts` (`id`, `type`, `dateCreated`, `dateUpdated`, `dateDeleted`, `uid`) VALUES ('17', 'benf\\neo\\elements\\Block', '2019-12-16 11:57:50', '2019-12-17 01:05:13', NULL, 'f4acd46a-dc4d-472d-8eda-b2f936344cb7');
INSERT INTO `fieldlayouts` (`id`, `type`, `dateCreated`, `dateUpdated`, `dateDeleted`, `uid`) VALUES ('18', 'benf\\neo\\elements\\Block', '2019-12-16 11:57:50', '2019-12-17 01:05:13', NULL, '95a8afe5-3088-4221-a5a2-72244c99eb2c');
INSERT INTO `fieldlayouts` (`id`, `type`, `dateCreated`, `dateUpdated`, `dateDeleted`, `uid`) VALUES ('19', 'benf\\neo\\elements\\Block', '2019-12-16 20:40:27', '2019-12-17 01:04:29', NULL, '87396e49-befe-4584-aab3-f8f4f0a04cb9');
INSERT INTO `fieldlayouts` (`id`, `type`, `dateCreated`, `dateUpdated`, `dateDeleted`, `uid`) VALUES ('20', 'benf\\neo\\elements\\Block', '2019-12-16 20:40:27', '2019-12-17 01:04:29', NULL, '2f04aa36-b292-4d42-acf1-3de3985f0038');
INSERT INTO `fieldlayouts` (`id`, `type`, `dateCreated`, `dateUpdated`, `dateDeleted`, `uid`) VALUES ('21', 'benf\\neo\\elements\\Block', '2019-12-16 20:40:27', '2019-12-17 01:04:29', NULL, 'b9496a75-f916-45b5-8433-9c967e426fb4');
INSERT INTO `fieldlayouts` (`id`, `type`, `dateCreated`, `dateUpdated`, `dateDeleted`, `uid`) VALUES ('22', 'benf\\neo\\elements\\Block', '2019-12-16 20:40:27', '2019-12-17 01:04:29', NULL, '3792ad99-c503-4d19-8155-78ea4064ad06');
INSERT INTO `fieldlayouts` (`id`, `type`, `dateCreated`, `dateUpdated`, `dateDeleted`, `uid`) VALUES ('23', 'benf\\neo\\elements\\Block', '2019-12-16 20:40:28', '2019-12-17 01:04:29', NULL, '1310cde0-91f6-4f3e-8a17-b1184ec78fb1');
INSERT INTO `fieldlayouts` (`id`, `type`, `dateCreated`, `dateUpdated`, `dateDeleted`, `uid`) VALUES ('24', 'benf\\neo\\elements\\Block', '2019-12-16 20:40:28', '2019-12-17 01:04:29', NULL, '733d5f58-395a-4ab4-8995-243c997e88df');
INSERT INTO `fieldlayouts` (`id`, `type`, `dateCreated`, `dateUpdated`, `dateDeleted`, `uid`) VALUES ('25', 'benf\\neo\\elements\\Block', '2019-12-16 20:40:28', '2019-12-17 01:04:29', NULL, 'e2150a61-f963-432b-9fb5-55ba449195a8');
INSERT INTO `fieldlayouts` (`id`, `type`, `dateCreated`, `dateUpdated`, `dateDeleted`, `uid`) VALUES ('26', 'benf\\neo\\elements\\Block', '2019-12-16 20:40:28', '2019-12-17 01:04:30', NULL, '2cb29f15-5074-43f3-b5e4-7ab90aa0b927');
INSERT INTO `fieldlayouts` (`id`, `type`, `dateCreated`, `dateUpdated`, `dateDeleted`, `uid`) VALUES ('27', 'benf\\neo\\elements\\Block', '2019-12-16 20:40:28', '2019-12-17 01:04:30', NULL, '695826e1-9905-45b1-93c0-4297531d3ee4');
INSERT INTO `fieldlayouts` (`id`, `type`, `dateCreated`, `dateUpdated`, `dateDeleted`, `uid`) VALUES ('28', 'benf\\neo\\elements\\Block', '2019-12-16 20:40:28', '2019-12-17 01:04:30', NULL, 'c7ad669c-d87b-4f13-bf55-b5a462172582');
INSERT INTO `fieldlayouts` (`id`, `type`, `dateCreated`, `dateUpdated`, `dateDeleted`, `uid`) VALUES ('29', 'benf\\neo\\elements\\Block', '2019-12-16 20:40:28', '2019-12-17 01:04:30', NULL, '378d4adc-7624-43ad-a9fe-8eb642ceed9b');
INSERT INTO `fieldlayouts` (`id`, `type`, `dateCreated`, `dateUpdated`, `dateDeleted`, `uid`) VALUES ('30', 'benf\\neo\\elements\\Block', '2019-12-16 20:40:28', '2019-12-17 01:04:30', NULL, '50206415-30d5-48e6-9214-066d7088f14e');
INSERT INTO `fieldlayouts` (`id`, `type`, `dateCreated`, `dateUpdated`, `dateDeleted`, `uid`) VALUES ('31', 'benf\\neo\\elements\\Block', '2019-12-16 20:40:28', '2019-12-17 01:04:30', NULL, 'b5ca9ee2-cf4d-47d2-b9eb-4e8f24388705');
INSERT INTO `fieldlayouts` (`id`, `type`, `dateCreated`, `dateUpdated`, `dateDeleted`, `uid`) VALUES ('32', 'benf\\neo\\elements\\Block', '2019-12-16 20:40:28', '2019-12-17 01:04:30', NULL, 'd084d117-eb5c-472c-a3cb-e3011678cde4');
INSERT INTO `fieldlayouts` (`id`, `type`, `dateCreated`, `dateUpdated`, `dateDeleted`, `uid`) VALUES ('33', 'benf\\neo\\elements\\Block', '2019-12-16 20:40:28', '2019-12-17 01:04:30', NULL, '799bde03-acc3-4963-aafd-180a037e5ccd');
INSERT INTO `fieldlayouts` (`id`, `type`, `dateCreated`, `dateUpdated`, `dateDeleted`, `uid`) VALUES ('34', 'craft\\elements\\GlobalSet', '2019-12-16 20:42:51', '2019-12-16 20:42:51', NULL, 'b42ad105-7d14-4f21-83f5-b37a659ac819');
INSERT INTO `fieldlayouts` (`id`, `type`, `dateCreated`, `dateUpdated`, `dateDeleted`, `uid`) VALUES ('35', 'craft\\elements\\Entry', '2019-12-16 20:46:06', '2019-12-16 20:46:06', NULL, '317b3dab-bb54-475d-8ae5-c739377cdc64');
INSERT INTO `fieldlayouts` (`id`, `type`, `dateCreated`, `dateUpdated`, `dateDeleted`, `uid`) VALUES ('36', 'craft\\elements\\Entry', '2019-12-16 20:47:52', '2019-12-16 20:47:52', NULL, 'd70439e2-45b1-499f-86ad-3b14bab04dce');
INSERT INTO `fieldlayouts` (`id`, `type`, `dateCreated`, `dateUpdated`, `dateDeleted`, `uid`) VALUES ('37', 'craft\\elements\\GlobalSet', '2019-12-16 21:01:51', '2019-12-16 21:01:51', NULL, '4705535e-ca45-45a5-a79e-6684a8626a4d');
INSERT INTO `fieldlayouts` (`id`, `type`, `dateCreated`, `dateUpdated`, `dateDeleted`, `uid`) VALUES ('38', 'craft\\elements\\Entry', '2019-12-16 21:06:51', '2019-12-16 21:06:51', NULL, 'b870c8ec-ef37-4abe-9b54-8a4f703b57b5');
INSERT INTO `fieldlayouts` (`id`, `type`, `dateCreated`, `dateUpdated`, `dateDeleted`, `uid`) VALUES ('39', 'benf\\neo\\elements\\Block', '2019-12-16 21:12:39', '2019-12-17 01:05:13', NULL, '3cb4d0c2-55cb-42ab-872a-6a554afaf976');
INSERT INTO `fieldlayouts` (`id`, `type`, `dateCreated`, `dateUpdated`, `dateDeleted`, `uid`) VALUES ('40', 'benf\\neo\\elements\\Block', '2019-12-16 21:14:59', '2019-12-17 01:04:30', NULL, '5e72834c-8d84-40e9-add6-809f5cd48232');
INSERT INTO `fieldlayouts` (`id`, `type`, `dateCreated`, `dateUpdated`, `dateDeleted`, `uid`) VALUES ('41', 'craft\\elements\\Entry', '2019-12-16 21:22:54', '2019-12-16 21:22:54', NULL, '1b8a3b09-15ab-4668-b7e7-a63fe6e15581');
INSERT INTO `fieldlayouts` (`id`, `type`, `dateCreated`, `dateUpdated`, `dateDeleted`, `uid`) VALUES ('42', 'craft\\elements\\Entry', '2019-12-16 21:28:08', '2019-12-16 21:28:08', NULL, '72bb2cd1-054d-4567-9375-f6b699409645');
INSERT INTO `fieldlayouts` (`id`, `type`, `dateCreated`, `dateUpdated`, `dateDeleted`, `uid`) VALUES ('43', 'craft\\elements\\Category', '2019-12-16 21:35:05', '2019-12-16 21:35:05', NULL, 'ab232e4c-6d38-4c72-90aa-1d195ea96651');

INSERT INTO `fieldlayouttabs` (`id`, `layoutId`, `name`, `sortOrder`, `dateCreated`, `dateUpdated`, `uid`) VALUES ('2', '1', 'Content', '1', '2019-12-16 11:23:49', '2019-12-16 11:23:49', '1de1840b-fdd0-4195-8913-4af1951c42b0');
INSERT INTO `fieldlayouttabs` (`id`, `layoutId`, `name`, `sortOrder`, `dateCreated`, `dateUpdated`, `uid`) VALUES ('179', '35', 'Content', '1', '2019-12-16 21:17:44', '2019-12-16 21:17:44', '8c06d709-0dc3-4cf5-bab5-ceabea55d385');
INSERT INTO `fieldlayouttabs` (`id`, `layoutId`, `name`, `sortOrder`, `dateCreated`, `dateUpdated`, `uid`) VALUES ('180', '35', 'SEO / Meta', '2', '2019-12-16 21:17:44', '2019-12-16 21:17:44', '98c94838-77cc-42b6-afbb-75b81bd6c358');
INSERT INTO `fieldlayouttabs` (`id`, `layoutId`, `name`, `sortOrder`, `dateCreated`, `dateUpdated`, `uid`) VALUES ('183', '38', 'Content', '1', '2019-12-16 21:20:36', '2019-12-16 21:20:36', '1749049b-81cf-4cda-9215-4449ed7dca8a');
INSERT INTO `fieldlayouttabs` (`id`, `layoutId`, `name`, `sortOrder`, `dateCreated`, `dateUpdated`, `uid`) VALUES ('184', '38', 'SEO / Meta', '2', '2019-12-16 21:20:36', '2019-12-16 21:20:36', '24b25161-3364-4983-905a-5733a08f1666');
INSERT INTO `fieldlayouttabs` (`id`, `layoutId`, `name`, `sortOrder`, `dateCreated`, `dateUpdated`, `uid`) VALUES ('185', '41', 'Content', '1', '2019-12-16 21:22:54', '2019-12-16 21:22:54', 'f28608f1-bc29-42a2-9278-0e86c1836765');
INSERT INTO `fieldlayouttabs` (`id`, `layoutId`, `name`, `sortOrder`, `dateCreated`, `dateUpdated`, `uid`) VALUES ('186', '41', 'SEO / Meta', '2', '2019-12-16 21:22:54', '2019-12-16 21:22:54', '018c8e2f-11d1-4cd6-84a3-5dc1ba168108');
INSERT INTO `fieldlayouttabs` (`id`, `layoutId`, `name`, `sortOrder`, `dateCreated`, `dateUpdated`, `uid`) VALUES ('189', '42', 'Content', '1', '2019-12-16 21:28:08', '2019-12-16 21:28:08', '0148712d-32d2-461f-86fa-bbe7beec8f1d');
INSERT INTO `fieldlayouttabs` (`id`, `layoutId`, `name`, `sortOrder`, `dateCreated`, `dateUpdated`, `uid`) VALUES ('190', '42', 'SEO / Meta', '2', '2019-12-16 21:28:08', '2019-12-16 21:28:08', '9d747b97-86ee-4634-b06f-6315fb75e07a');
INSERT INTO `fieldlayouttabs` (`id`, `layoutId`, `name`, `sortOrder`, `dateCreated`, `dateUpdated`, `uid`) VALUES ('191', '43', 'SEO / Meta', '1', '2019-12-16 21:35:05', '2019-12-16 21:35:05', 'f67d67b0-a419-4575-9a75-85cc994befce');
INSERT INTO `fieldlayouttabs` (`id`, `layoutId`, `name`, `sortOrder`, `dateCreated`, `dateUpdated`, `uid`) VALUES ('192', '2', 'Content', '1', '2019-12-16 21:40:04', '2019-12-16 21:40:04', '38c633d5-7eb1-4123-b2a1-75f0229683b4');
INSERT INTO `fieldlayouttabs` (`id`, `layoutId`, `name`, `sortOrder`, `dateCreated`, `dateUpdated`, `uid`) VALUES ('222', '36', 'Content', '1', '2019-12-17 00:45:52', '2019-12-17 00:45:52', '4ce162c0-c0f2-4562-ae47-20f01b2b1a34');
INSERT INTO `fieldlayouttabs` (`id`, `layoutId`, `name`, `sortOrder`, `dateCreated`, `dateUpdated`, `uid`) VALUES ('223', '36', 'SEO / Meta', '2', '2019-12-17 00:45:52', '2019-12-17 00:45:52', 'b1e4bbfa-35c6-4f62-b093-f3637a39a893');
INSERT INTO `fieldlayouttabs` (`id`, `layoutId`, `name`, `sortOrder`, `dateCreated`, `dateUpdated`, `uid`) VALUES ('279', '37', 'Pages', '1', '2019-12-17 00:55:20', '2019-12-17 00:55:20', '73d17932-9de2-4006-be9d-682cbf0bd743');
INSERT INTO `fieldlayouttabs` (`id`, `layoutId`, `name`, `sortOrder`, `dateCreated`, `dateUpdated`, `uid`) VALUES ('280', '37', 'News', '2', '2019-12-17 00:55:20', '2019-12-17 00:55:20', '288fe565-960e-45d7-b190-8cbdc756f43d');
INSERT INTO `fieldlayouttabs` (`id`, `layoutId`, `name`, `sortOrder`, `dateCreated`, `dateUpdated`, `uid`) VALUES ('308', '19', 'Content', '1', '2019-12-17 01:04:29', '2019-12-17 01:04:29', 'efc9bd40-3952-422b-839f-e98678d0482c');
INSERT INTO `fieldlayouttabs` (`id`, `layoutId`, `name`, `sortOrder`, `dateCreated`, `dateUpdated`, `uid`) VALUES ('309', '19', 'Settings', '2', '2019-12-17 01:04:29', '2019-12-17 01:04:29', '50363d73-c8dd-4d96-b833-115caf0b03d0');
INSERT INTO `fieldlayouttabs` (`id`, `layoutId`, `name`, `sortOrder`, `dateCreated`, `dateUpdated`, `uid`) VALUES ('310', '20', 'Content', '1', '2019-12-17 01:04:29', '2019-12-17 01:04:29', '759e747d-d6e0-4d5e-b2c3-7fbf3691cce8');
INSERT INTO `fieldlayouttabs` (`id`, `layoutId`, `name`, `sortOrder`, `dateCreated`, `dateUpdated`, `uid`) VALUES ('311', '20', 'Settings', '2', '2019-12-17 01:04:29', '2019-12-17 01:04:29', '158dda50-9ab1-46ea-ae26-4e0939404aeb');
INSERT INTO `fieldlayouttabs` (`id`, `layoutId`, `name`, `sortOrder`, `dateCreated`, `dateUpdated`, `uid`) VALUES ('312', '21', 'Content', '1', '2019-12-17 01:04:29', '2019-12-17 01:04:29', '1971cf37-bad5-48cf-b7d0-b53e40efe985');
INSERT INTO `fieldlayouttabs` (`id`, `layoutId`, `name`, `sortOrder`, `dateCreated`, `dateUpdated`, `uid`) VALUES ('313', '21', 'Settings', '2', '2019-12-17 01:04:29', '2019-12-17 01:04:29', '61632002-0a0c-4ee3-9a6e-58096adf8267');
INSERT INTO `fieldlayouttabs` (`id`, `layoutId`, `name`, `sortOrder`, `dateCreated`, `dateUpdated`, `uid`) VALUES ('314', '22', 'Content', '1', '2019-12-17 01:04:29', '2019-12-17 01:04:29', 'b13412cd-36c4-42eb-8b28-12eb84cc1687');
INSERT INTO `fieldlayouttabs` (`id`, `layoutId`, `name`, `sortOrder`, `dateCreated`, `dateUpdated`, `uid`) VALUES ('315', '22', 'Settings', '2', '2019-12-17 01:04:29', '2019-12-17 01:04:29', '11f20078-72fa-4c94-908f-b0cb8fd473eb');
INSERT INTO `fieldlayouttabs` (`id`, `layoutId`, `name`, `sortOrder`, `dateCreated`, `dateUpdated`, `uid`) VALUES ('316', '23', 'Content', '1', '2019-12-17 01:04:29', '2019-12-17 01:04:29', '7553c16a-e07f-4fc8-8efb-811f91df4ff4');
INSERT INTO `fieldlayouttabs` (`id`, `layoutId`, `name`, `sortOrder`, `dateCreated`, `dateUpdated`, `uid`) VALUES ('317', '23', 'Settings', '2', '2019-12-17 01:04:29', '2019-12-17 01:04:29', '1672f935-b8ca-4b51-b030-5b3b509e94c2');
INSERT INTO `fieldlayouttabs` (`id`, `layoutId`, `name`, `sortOrder`, `dateCreated`, `dateUpdated`, `uid`) VALUES ('318', '24', 'Content', '1', '2019-12-17 01:04:29', '2019-12-17 01:04:29', 'c3ded2b5-d12b-4eae-8421-7aa17407a981');
INSERT INTO `fieldlayouttabs` (`id`, `layoutId`, `name`, `sortOrder`, `dateCreated`, `dateUpdated`, `uid`) VALUES ('319', '24', 'Settings', '2', '2019-12-17 01:04:29', '2019-12-17 01:04:29', '0b1df707-9c6f-49d5-a651-6c6cad10c790');
INSERT INTO `fieldlayouttabs` (`id`, `layoutId`, `name`, `sortOrder`, `dateCreated`, `dateUpdated`, `uid`) VALUES ('320', '25', 'Content', '1', '2019-12-17 01:04:29', '2019-12-17 01:04:29', 'e032cd36-3517-4aec-bae9-75d39ce45713');
INSERT INTO `fieldlayouttabs` (`id`, `layoutId`, `name`, `sortOrder`, `dateCreated`, `dateUpdated`, `uid`) VALUES ('321', '25', 'Settings', '2', '2019-12-17 01:04:29', '2019-12-17 01:04:29', 'efab9d7d-ae20-47cb-a59d-9a8a83b7ce20');
INSERT INTO `fieldlayouttabs` (`id`, `layoutId`, `name`, `sortOrder`, `dateCreated`, `dateUpdated`, `uid`) VALUES ('322', '26', 'Content', '1', '2019-12-17 01:04:30', '2019-12-17 01:04:30', '5a74a1b2-cdad-4861-a10b-33353871be06');
INSERT INTO `fieldlayouttabs` (`id`, `layoutId`, `name`, `sortOrder`, `dateCreated`, `dateUpdated`, `uid`) VALUES ('323', '26', 'Settings', '2', '2019-12-17 01:04:30', '2019-12-17 01:04:30', 'ce9a30d8-a149-409d-9031-0c334a06d6e1');
INSERT INTO `fieldlayouttabs` (`id`, `layoutId`, `name`, `sortOrder`, `dateCreated`, `dateUpdated`, `uid`) VALUES ('324', '28', 'Content', '1', '2019-12-17 01:04:30', '2019-12-17 01:04:30', 'a243647a-7145-4e34-a4b9-1bb899424fd1');
INSERT INTO `fieldlayouttabs` (`id`, `layoutId`, `name`, `sortOrder`, `dateCreated`, `dateUpdated`, `uid`) VALUES ('325', '28', 'Settings', '2', '2019-12-17 01:04:30', '2019-12-17 01:04:30', '3bb6a390-4e58-4f85-be58-f4e7d524fa12');
INSERT INTO `fieldlayouttabs` (`id`, `layoutId`, `name`, `sortOrder`, `dateCreated`, `dateUpdated`, `uid`) VALUES ('326', '40', 'Content', '1', '2019-12-17 01:04:30', '2019-12-17 01:04:30', '1ecda6f4-29ad-461b-b90f-169aedc8e4f4');
INSERT INTO `fieldlayouttabs` (`id`, `layoutId`, `name`, `sortOrder`, `dateCreated`, `dateUpdated`, `uid`) VALUES ('327', '40', 'Settings', '2', '2019-12-17 01:04:30', '2019-12-17 01:04:30', 'ffa9ab2a-c3f5-4a87-a0cf-910688148402');
INSERT INTO `fieldlayouttabs` (`id`, `layoutId`, `name`, `sortOrder`, `dateCreated`, `dateUpdated`, `uid`) VALUES ('328', '29', 'Content', '1', '2019-12-17 01:04:30', '2019-12-17 01:04:30', 'dc104716-aa42-438d-a3d1-b524a9eb42eb');
INSERT INTO `fieldlayouttabs` (`id`, `layoutId`, `name`, `sortOrder`, `dateCreated`, `dateUpdated`, `uid`) VALUES ('329', '30', 'Content', '1', '2019-12-17 01:04:30', '2019-12-17 01:04:30', 'c49da29c-45e9-4173-8f11-bfca22a7f470');
INSERT INTO `fieldlayouttabs` (`id`, `layoutId`, `name`, `sortOrder`, `dateCreated`, `dateUpdated`, `uid`) VALUES ('330', '31', 'Content', '1', '2019-12-17 01:04:30', '2019-12-17 01:04:30', '0e06a561-22be-4dd6-8a54-8fffec305e49');
INSERT INTO `fieldlayouttabs` (`id`, `layoutId`, `name`, `sortOrder`, `dateCreated`, `dateUpdated`, `uid`) VALUES ('331', '32', 'Content', '1', '2019-12-17 01:04:30', '2019-12-17 01:04:30', '0f355769-8d3b-4897-85b2-f13ab181214d');
INSERT INTO `fieldlayouttabs` (`id`, `layoutId`, `name`, `sortOrder`, `dateCreated`, `dateUpdated`, `uid`) VALUES ('332', '27', 'Content', '1', '2019-12-17 01:04:30', '2019-12-17 01:04:30', 'a36855e6-1521-428f-ad3b-668689f9d908');
INSERT INTO `fieldlayouttabs` (`id`, `layoutId`, `name`, `sortOrder`, `dateCreated`, `dateUpdated`, `uid`) VALUES ('333', '33', 'Content', '1', '2019-12-17 01:04:30', '2019-12-17 01:04:30', '4b39c56a-ece5-42dc-81f5-ac1a320d9ca3');
INSERT INTO `fieldlayouttabs` (`id`, `layoutId`, `name`, `sortOrder`, `dateCreated`, `dateUpdated`, `uid`) VALUES ('334', '18', 'Content', '1', '2019-12-17 01:05:13', '2019-12-17 01:05:13', '00450a21-8459-44dc-9c19-624855f042a8');
INSERT INTO `fieldlayouttabs` (`id`, `layoutId`, `name`, `sortOrder`, `dateCreated`, `dateUpdated`, `uid`) VALUES ('335', '18', 'Settings', '2', '2019-12-17 01:05:13', '2019-12-17 01:05:13', '61795da4-0c4e-4cb6-b92b-009224d94954');
INSERT INTO `fieldlayouttabs` (`id`, `layoutId`, `name`, `sortOrder`, `dateCreated`, `dateUpdated`, `uid`) VALUES ('336', '3', 'Content', '1', '2019-12-17 01:05:13', '2019-12-17 01:05:13', 'cd68a525-0557-4021-b333-f70ce4f740c3');
INSERT INTO `fieldlayouttabs` (`id`, `layoutId`, `name`, `sortOrder`, `dateCreated`, `dateUpdated`, `uid`) VALUES ('337', '3', 'Settings', '2', '2019-12-17 01:05:13', '2019-12-17 01:05:13', 'c186c080-9c43-4b9d-ab2c-992933d3c90e');
INSERT INTO `fieldlayouttabs` (`id`, `layoutId`, `name`, `sortOrder`, `dateCreated`, `dateUpdated`, `uid`) VALUES ('338', '4', 'Content', '1', '2019-12-17 01:05:13', '2019-12-17 01:05:13', '184aaccf-5856-4002-9a2a-8af2d339df9c');
INSERT INTO `fieldlayouttabs` (`id`, `layoutId`, `name`, `sortOrder`, `dateCreated`, `dateUpdated`, `uid`) VALUES ('339', '4', 'Settings', '2', '2019-12-17 01:05:13', '2019-12-17 01:05:13', '6ffee24c-c636-4bea-85a8-a554dc27a6d9');
INSERT INTO `fieldlayouttabs` (`id`, `layoutId`, `name`, `sortOrder`, `dateCreated`, `dateUpdated`, `uid`) VALUES ('340', '5', 'Content', '1', '2019-12-17 01:05:13', '2019-12-17 01:05:13', '766b2a6f-3bc7-40e8-a15a-8a7ccfc20fa4');
INSERT INTO `fieldlayouttabs` (`id`, `layoutId`, `name`, `sortOrder`, `dateCreated`, `dateUpdated`, `uid`) VALUES ('341', '5', 'Settings', '2', '2019-12-17 01:05:13', '2019-12-17 01:05:13', '1c03b165-a168-48c4-8189-a585c61f70c2');
INSERT INTO `fieldlayouttabs` (`id`, `layoutId`, `name`, `sortOrder`, `dateCreated`, `dateUpdated`, `uid`) VALUES ('342', '6', 'Content', '1', '2019-12-17 01:05:13', '2019-12-17 01:05:13', '5fa0b4b2-6058-4870-9453-63d197a0e65e');
INSERT INTO `fieldlayouttabs` (`id`, `layoutId`, `name`, `sortOrder`, `dateCreated`, `dateUpdated`, `uid`) VALUES ('343', '6', 'Settings', '2', '2019-12-17 01:05:13', '2019-12-17 01:05:13', '71376318-e660-4e4a-a757-9ce939a2f813');
INSERT INTO `fieldlayouttabs` (`id`, `layoutId`, `name`, `sortOrder`, `dateCreated`, `dateUpdated`, `uid`) VALUES ('344', '7', 'Content', '1', '2019-12-17 01:05:13', '2019-12-17 01:05:13', '394bc0cc-77b3-47a2-b2b6-79f41484979e');
INSERT INTO `fieldlayouttabs` (`id`, `layoutId`, `name`, `sortOrder`, `dateCreated`, `dateUpdated`, `uid`) VALUES ('345', '7', 'Settings', '2', '2019-12-17 01:05:13', '2019-12-17 01:05:13', '1a3bf088-0d7f-47a1-af60-db8efa38d081');
INSERT INTO `fieldlayouttabs` (`id`, `layoutId`, `name`, `sortOrder`, `dateCreated`, `dateUpdated`, `uid`) VALUES ('346', '8', 'Content', '1', '2019-12-17 01:05:13', '2019-12-17 01:05:13', 'dadb0041-8d0e-49d9-bea2-456efd6fdfb3');
INSERT INTO `fieldlayouttabs` (`id`, `layoutId`, `name`, `sortOrder`, `dateCreated`, `dateUpdated`, `uid`) VALUES ('347', '8', 'Settings', '2', '2019-12-17 01:05:13', '2019-12-17 01:05:13', 'dea6cec7-3722-4f64-93ae-4c5cbf3bee74');
INSERT INTO `fieldlayouttabs` (`id`, `layoutId`, `name`, `sortOrder`, `dateCreated`, `dateUpdated`, `uid`) VALUES ('348', '9', 'Content', '1', '2019-12-17 01:05:13', '2019-12-17 01:05:13', 'ac37bc0d-5a2e-49b2-a30a-88c89d246c17');
INSERT INTO `fieldlayouttabs` (`id`, `layoutId`, `name`, `sortOrder`, `dateCreated`, `dateUpdated`, `uid`) VALUES ('349', '9', 'Settings', '2', '2019-12-17 01:05:13', '2019-12-17 01:05:13', '5b1e8155-ec8e-419c-9147-403da03f834e');
INSERT INTO `fieldlayouttabs` (`id`, `layoutId`, `name`, `sortOrder`, `dateCreated`, `dateUpdated`, `uid`) VALUES ('350', '10', 'Content', '1', '2019-12-17 01:05:13', '2019-12-17 01:05:13', '2d34fbcd-0549-4691-8f48-501884ded67a');
INSERT INTO `fieldlayouttabs` (`id`, `layoutId`, `name`, `sortOrder`, `dateCreated`, `dateUpdated`, `uid`) VALUES ('351', '10', 'Settings', '2', '2019-12-17 01:05:13', '2019-12-17 01:05:13', '5d973252-72d6-49f6-bc55-428f988a009a');
INSERT INTO `fieldlayouttabs` (`id`, `layoutId`, `name`, `sortOrder`, `dateCreated`, `dateUpdated`, `uid`) VALUES ('352', '12', 'Content', '1', '2019-12-17 01:05:13', '2019-12-17 01:05:13', '4d6c20ff-dff6-417c-88b1-7e8d804bd0c4');
INSERT INTO `fieldlayouttabs` (`id`, `layoutId`, `name`, `sortOrder`, `dateCreated`, `dateUpdated`, `uid`) VALUES ('353', '12', 'Settings', '2', '2019-12-17 01:05:13', '2019-12-17 01:05:13', '5e4b6eed-516e-45de-a4b0-3233ef974620');
INSERT INTO `fieldlayouttabs` (`id`, `layoutId`, `name`, `sortOrder`, `dateCreated`, `dateUpdated`, `uid`) VALUES ('354', '39', 'Content', '1', '2019-12-17 01:05:13', '2019-12-17 01:05:13', '5728f455-fc45-40d2-97d5-dc2e95720e4f');
INSERT INTO `fieldlayouttabs` (`id`, `layoutId`, `name`, `sortOrder`, `dateCreated`, `dateUpdated`, `uid`) VALUES ('355', '39', 'Settings', '2', '2019-12-17 01:05:13', '2019-12-17 01:05:13', 'd939217b-dfb1-47f7-ab2f-b4c8d4cdbd48');
INSERT INTO `fieldlayouttabs` (`id`, `layoutId`, `name`, `sortOrder`, `dateCreated`, `dateUpdated`, `uid`) VALUES ('356', '14', 'Content', '1', '2019-12-17 01:05:13', '2019-12-17 01:05:13', 'fe4e3dae-0256-4bf7-89e5-c02f749e7d00');
INSERT INTO `fieldlayouttabs` (`id`, `layoutId`, `name`, `sortOrder`, `dateCreated`, `dateUpdated`, `uid`) VALUES ('357', '15', 'Content', '1', '2019-12-17 01:05:13', '2019-12-17 01:05:13', '5284afdd-eeea-4e66-bc2f-d3c32de065a7');
INSERT INTO `fieldlayouttabs` (`id`, `layoutId`, `name`, `sortOrder`, `dateCreated`, `dateUpdated`, `uid`) VALUES ('358', '16', 'Content', '1', '2019-12-17 01:05:13', '2019-12-17 01:05:13', '68e4af64-d6df-4de0-b905-813fb9d8f336');
INSERT INTO `fieldlayouttabs` (`id`, `layoutId`, `name`, `sortOrder`, `dateCreated`, `dateUpdated`, `uid`) VALUES ('359', '17', 'Content', '1', '2019-12-17 01:05:13', '2019-12-17 01:05:13', 'bd7e9008-e645-4059-8964-5669df53e759');
INSERT INTO `fieldlayouttabs` (`id`, `layoutId`, `name`, `sortOrder`, `dateCreated`, `dateUpdated`, `uid`) VALUES ('360', '11', 'Content', '1', '2019-12-17 01:05:13', '2019-12-17 01:05:13', '656fc9d0-ff00-47d6-b64b-2d6d585478ac');
INSERT INTO `fieldlayouttabs` (`id`, `layoutId`, `name`, `sortOrder`, `dateCreated`, `dateUpdated`, `uid`) VALUES ('361', '13', 'Content', '1', '2019-12-17 01:05:13', '2019-12-17 01:05:13', 'e608626d-aaff-4dee-8bc3-f7b626aae5d7');
INSERT INTO `fieldlayouttabs` (`id`, `layoutId`, `name`, `sortOrder`, `dateCreated`, `dateUpdated`, `uid`) VALUES ('362', '34', 'Contact', '1', '2019-12-17 01:09:13', '2019-12-17 01:09:13', '8991e0a5-e9b4-450f-9b1f-180ba81c3391');

INSERT INTO `fields` (`id`, `groupId`, `name`, `handle`, `context`, `instructions`, `searchable`, `translationMethod`, `translationKeyFormat`, `type`, `settings`, `dateCreated`, `dateUpdated`, `uid`) VALUES ('1', '3', 'Alternate Text', 'altText', 'global', 'Include descriptive text of the image for visually impaired users.', '1', 'none', NULL, 'craft\\fields\\PlainText', '{\"placeholder\":\"\",\"code\":\"\",\"multiline\":\"\",\"initialRows\":\"4\",\"charLimit\":\"\",\"columnType\":\"text\"}', '2019-12-16 10:35:47', '2019-12-16 11:05:13', 'c2609bfd-fefa-4ef4-9677-4644e30ed7b2');
INSERT INTO `fields` (`id`, `groupId`, `name`, `handle`, `context`, `instructions`, `searchable`, `translationMethod`, `translationKeyFormat`, `type`, `settings`, `dateCreated`, `dateUpdated`, `uid`) VALUES ('2', '3', 'Caption', 'caption', 'global', '', '1', 'none', NULL, 'craft\\fields\\PlainText', '{\"placeholder\":\"\",\"code\":\"\",\"multiline\":\"\",\"initialRows\":\"4\",\"charLimit\":\"\",\"columnType\":\"text\"}', '2019-12-16 10:36:24', '2019-12-16 10:36:24', 'cf28ac9c-b373-4de1-8afb-0baa227165d1');
INSERT INTO `fields` (`id`, `groupId`, `name`, `handle`, `context`, `instructions`, `searchable`, `translationMethod`, `translationKeyFormat`, `type`, `settings`, `dateCreated`, `dateUpdated`, `uid`) VALUES ('3', '3', 'Heading', 'heading', 'global', '', '1', 'none', NULL, 'craft\\fields\\PlainText', '{\"placeholder\":\"\",\"code\":\"\",\"multiline\":\"\",\"initialRows\":\"4\",\"charLimit\":\"\",\"columnType\":\"text\"}', '2019-12-16 10:36:34', '2019-12-16 10:36:34', '332bf96d-e927-4c21-bfbd-d8dd96087850');
INSERT INTO `fields` (`id`, `groupId`, `name`, `handle`, `context`, `instructions`, `searchable`, `translationMethod`, `translationKeyFormat`, `type`, `settings`, `dateCreated`, `dateUpdated`, `uid`) VALUES ('4', '3', 'Rich Text', 'richText', 'global', '', '1', 'none', NULL, 'craft\\redactor\\Field', '{\"redactorConfig\":\"Standard.json\",\"purifierConfig\":\"\",\"cleanupHtml\":true,\"removeInlineStyles\":\"1\",\"removeEmptyTags\":\"1\",\"removeNbsp\":\"1\",\"purifyHtml\":\"1\",\"columnType\":\"text\",\"availableVolumes\":[\"b4623a75-4ffd-4637-bd4d-36ffbe88a935\"],\"availableTransforms\":\"*\"}', '2019-12-16 10:38:12', '2019-12-17 00:39:12', '7ce9ced9-3e8f-4bf2-9cd6-065b16567e6e');
INSERT INTO `fields` (`id`, `groupId`, `name`, `handle`, `context`, `instructions`, `searchable`, `translationMethod`, `translationKeyFormat`, `type`, `settings`, `dateCreated`, `dateUpdated`, `uid`) VALUES ('5', '5', 'Alignment', 'alignment', 'global', '', '0', 'none', NULL, 'craft\\fields\\Dropdown', '{\"optgroups\":true,\"options\":[{\"label\":\"Left\",\"value\":\"left\",\"default\":\"1\"},{\"label\":\"Center\",\"value\":\"center\",\"default\":\"\"},{\"label\":\"Right\",\"value\":\"right\",\"default\":\"\"}]}', '2019-12-16 10:40:33', '2019-12-16 10:40:33', '3aad9545-9f94-41c9-b9f5-f11ef3d223fd');
INSERT INTO `fields` (`id`, `groupId`, `name`, `handle`, `context`, `instructions`, `searchable`, `translationMethod`, `translationKeyFormat`, `type`, `settings`, `dateCreated`, `dateUpdated`, `uid`) VALUES ('6', '5', 'Text Size', 'textSize', 'global', '', '0', 'none', NULL, 'craft\\fields\\Dropdown', '{\"optgroups\":true,\"options\":[{\"label\":\"Huge\",\"value\":\"huge\",\"default\":\"\"},{\"label\":\"Large\",\"value\":\"large\",\"default\":\"\"},{\"label\":\"Medium\",\"value\":\"medium\",\"default\":\"1\"},{\"label\":\"Small\",\"value\":\"small\",\"default\":\"\"}]}', '2019-12-16 10:41:25', '2019-12-16 11:01:06', '9995c1a8-7fe7-4dc4-bac6-7a5a2547e5e2');
INSERT INTO `fields` (`id`, `groupId`, `name`, `handle`, `context`, `instructions`, `searchable`, `translationMethod`, `translationKeyFormat`, `type`, `settings`, `dateCreated`, `dateUpdated`, `uid`) VALUES ('7', '5', 'Position', 'position', 'global', '', '0', 'none', NULL, 'craft\\fields\\Dropdown', '{\"optgroups\":true,\"options\":[{\"label\":\"Auto\",\"value\":\"auto\",\"default\":\"1\"},{\"label\":\"Left\",\"value\":\"left\",\"default\":\"\"},{\"label\":\"Center\",\"value\":\"center\",\"default\":\"\"},{\"label\":\"Right\",\"value\":\"right\",\"default\":\"\"},{\"label\":\"Full\",\"value\":\"full\",\"default\":\"\"}]}', '2019-12-16 10:42:52', '2019-12-16 10:53:53', '05beaa1f-418d-42f6-8972-ffcf1d3421e6');
INSERT INTO `fields` (`id`, `groupId`, `name`, `handle`, `context`, `instructions`, `searchable`, `translationMethod`, `translationKeyFormat`, `type`, `settings`, `dateCreated`, `dateUpdated`, `uid`) VALUES ('8', '3', 'Summary', 'summary', 'global', '', '1', 'none', NULL, 'craft\\redactor\\Field', '{\"redactorConfig\":\"Simple.json\",\"purifierConfig\":\"\",\"cleanupHtml\":true,\"removeInlineStyles\":\"1\",\"removeEmptyTags\":\"1\",\"removeNbsp\":\"1\",\"purifyHtml\":\"1\",\"columnType\":\"text\",\"availableVolumes\":\"*\",\"availableTransforms\":\"*\"}', '2019-12-16 10:45:20', '2019-12-16 10:45:20', 'e3bfa017-1474-4fed-a176-88a42ff2e8c2');
INSERT INTO `fields` (`id`, `groupId`, `name`, `handle`, `context`, `instructions`, `searchable`, `translationMethod`, `translationKeyFormat`, `type`, `settings`, `dateCreated`, `dateUpdated`, `uid`) VALUES ('9', '3', 'Source / Citation', 'cite', 'global', '', '1', 'none', NULL, 'craft\\fields\\PlainText', '{\"placeholder\":\"\",\"code\":\"\",\"multiline\":\"\",\"initialRows\":\"4\",\"charLimit\":\"\",\"columnType\":\"text\"}', '2019-12-16 10:45:55', '2019-12-16 11:08:11', '2378559f-b7e8-4d0d-83a9-c90809389dc4');
INSERT INTO `fields` (`id`, `groupId`, `name`, `handle`, `context`, `instructions`, `searchable`, `translationMethod`, `translationKeyFormat`, `type`, `settings`, `dateCreated`, `dateUpdated`, `uid`) VALUES ('10', '9', 'Table', 'table', 'global', '', '1', 'none', NULL, 'supercool\\tablemaker\\fields\\TableMakerField', '{\"columnsLabel\":\"\",\"columnsInstructions\":\"\",\"columnsAddRowLabel\":\"\",\"rowsLabel\":\"\",\"rowsInstructions\":\"\",\"rowsAddRowLabel\":\"\"}', '2019-12-16 10:46:32', '2019-12-16 10:46:32', '3481333e-977a-4adb-90d5-fae5926ad8bb');
INSERT INTO `fields` (`id`, `groupId`, `name`, `handle`, `context`, `instructions`, `searchable`, `translationMethod`, `translationKeyFormat`, `type`, `settings`, `dateCreated`, `dateUpdated`, `uid`) VALUES ('11', '9', 'Form', 'form', 'global', '', '0', 'none', NULL, 'Solspace\\Freeform\\FieldTypes\\FormFieldType', NULL, '2019-12-16 10:46:47', '2019-12-16 10:46:47', '734d68d3-e878-4e03-8aa9-9feb0dd82fb1');
INSERT INTO `fields` (`id`, `groupId`, `name`, `handle`, `context`, `instructions`, `searchable`, `translationMethod`, `translationKeyFormat`, `type`, `settings`, `dateCreated`, `dateUpdated`, `uid`) VALUES ('12', '5', 'Width', 'width', 'global', '', '0', 'none', NULL, 'craft\\fields\\Dropdown', '{\"optgroups\":true,\"options\":[{\"label\":\"Full\",\"value\":\"full\",\"default\":\"\"},{\"label\":\"Wide\",\"value\":\"wide\",\"default\":\"\"},{\"label\":\"Medium\",\"value\":\"medium\",\"default\":\"1\"},{\"label\":\"Thin\",\"value\":\"thin\",\"default\":\"\"}]}', '2019-12-16 10:50:10', '2019-12-16 10:53:39', 'adfefe4f-d6ca-4d4e-82ef-22326f737fd6');
INSERT INTO `fields` (`id`, `groupId`, `name`, `handle`, `context`, `instructions`, `searchable`, `translationMethod`, `translationKeyFormat`, `type`, `settings`, `dateCreated`, `dateUpdated`, `uid`) VALUES ('13', '5', 'Aspect Ratio', 'aspect', 'global', '', '0', 'none', NULL, 'craft\\fields\\Dropdown', '{\"optgroups\":true,\"options\":[{\"label\":\"Auto\",\"value\":\"auto\",\"default\":\"1\"},{\"label\":\"Square (1:1)\",\"value\":\"square\",\"default\":\"\"},{\"label\":\"Horizontal (3:2)\",\"value\":\"horizontal\",\"default\":\"\"},{\"label\":\"Vertical (2:3)\",\"value\":\"vertical\",\"default\":\"\"},{\"label\":\"Wide (16:9)\",\"value\":\"wide\",\"default\":\"\"}]}', '2019-12-16 10:52:38', '2019-12-16 10:54:05', '87a3aca4-9b17-41ab-a703-bba76a315981');
INSERT INTO `fields` (`id`, `groupId`, `name`, `handle`, `context`, `instructions`, `searchable`, `translationMethod`, `translationKeyFormat`, `type`, `settings`, `dateCreated`, `dateUpdated`, `uid`) VALUES ('14', '5', 'Autoplay', 'autoplay', 'global', '', '0', 'none', NULL, 'craft\\fields\\Lightswitch', '{\"default\":\"\"}', '2019-12-16 10:53:30', '2019-12-16 10:53:30', '16b8848e-d06a-4c6b-b716-ee84349642d3');
INSERT INTO `fields` (`id`, `groupId`, `name`, `handle`, `context`, `instructions`, `searchable`, `translationMethod`, `translationKeyFormat`, `type`, `settings`, `dateCreated`, `dateUpdated`, `uid`) VALUES ('15', '5', 'Text Color', 'textColor', 'global', '', '0', 'none', NULL, 'craft\\fields\\Dropdown', '{\"optgroups\":true,\"options\":[{\"label\":\"Black\",\"value\":\"black\",\"default\":\"1\"},{\"label\":\"Blue\",\"value\":\"blue\",\"default\":\"\"},{\"label\":\"Orange\",\"value\":\"orange\",\"default\":\"\"},{\"label\":\"White\",\"value\":\"white\",\"default\":\"\"}]}', '2019-12-16 10:56:25', '2019-12-16 10:56:25', '57f2498a-803a-4083-9433-9b937db415bc');
INSERT INTO `fields` (`id`, `groupId`, `name`, `handle`, `context`, `instructions`, `searchable`, `translationMethod`, `translationKeyFormat`, `type`, `settings`, `dateCreated`, `dateUpdated`, `uid`) VALUES ('16', '5', 'Background Color', 'backgroundColor', 'global', '', '0', 'none', NULL, 'craft\\fields\\Dropdown', '{\"optgroups\":true,\"options\":[{\"label\":\"White\",\"value\":\"white\",\"default\":\"1\"},{\"label\":\"Blue\",\"value\":\"blue\",\"default\":\"\"},{\"label\":\"Orange\",\"value\":\"orange\",\"default\":\"\"},{\"label\":\"Black\",\"value\":\"black\",\"default\":\"\"}]}', '2019-12-16 10:57:16', '2019-12-16 10:57:16', '8ed3608e-41ca-474f-bf29-b77c0b80931c');
INSERT INTO `fields` (`id`, `groupId`, `name`, `handle`, `context`, `instructions`, `searchable`, `translationMethod`, `translationKeyFormat`, `type`, `settings`, `dateCreated`, `dateUpdated`, `uid`) VALUES ('17', '5', 'Grid Layout', 'grid', 'global', '', '0', 'none', NULL, 'craft\\fields\\Dropdown', '{\"optgroups\":true,\"options\":[{\"label\":\"None\",\"value\":\"one\",\"default\":\"\"},{\"label\":\"Two Up\",\"value\":\"two\",\"default\":\"\"},{\"label\":\"Three Up\",\"value\":\"three\",\"default\":\"1\"},{\"label\":\"Four Up\",\"value\":\"four\",\"default\":\"\"},{\"label\":\"Five Up\",\"value\":\"five\",\"default\":\"\"}]}', '2019-12-16 10:59:15', '2019-12-16 10:59:15', 'fea94669-6b2d-4306-850a-4fb9d696fcac');
INSERT INTO `fields` (`id`, `groupId`, `name`, `handle`, `context`, `instructions`, `searchable`, `translationMethod`, `translationKeyFormat`, `type`, `settings`, `dateCreated`, `dateUpdated`, `uid`) VALUES ('18', '5', 'Padding', 'padding', 'global', '', '0', 'none', NULL, 'craft\\fields\\Dropdown', '{\"optgroups\":true,\"options\":[{\"label\":\"Large\",\"value\":\"large\",\"default\":\"\"},{\"label\":\"Medium\",\"value\":\"medium\",\"default\":\"1\"},{\"label\":\"Small\",\"value\":\"small\",\"default\":\"\"},{\"label\":\"None\",\"value\":\"none\",\"default\":\"\"}]}', '2019-12-16 11:00:28', '2019-12-16 11:00:28', '1a09a8f2-8bc2-42f9-afe4-ab7d17bc6bfc');
INSERT INTO `fields` (`id`, `groupId`, `name`, `handle`, `context`, `instructions`, `searchable`, `translationMethod`, `translationKeyFormat`, `type`, `settings`, `dateCreated`, `dateUpdated`, `uid`) VALUES ('19', '5', 'Tag', 'tag', 'global', '', '0', 'none', NULL, 'craft\\fields\\Dropdown', '{\"optgroups\":true,\"options\":[{\"label\":\"H1\",\"value\":\"h1\",\"default\":\"\"},{\"label\":\"H2\",\"value\":\"h2\",\"default\":\"1\"},{\"label\":\"H3\",\"value\":\"h3\",\"default\":\"\"},{\"label\":\"H4\",\"value\":\"h4\",\"default\":\"\"},{\"label\":\"H5\",\"value\":\"h5\",\"default\":\"\"}]}', '2019-12-16 11:02:50', '2019-12-16 11:02:50', 'bae81998-dbb4-433d-845e-416fc4ac4e18');
INSERT INTO `fields` (`id`, `groupId`, `name`, `handle`, `context`, `instructions`, `searchable`, `translationMethod`, `translationKeyFormat`, `type`, `settings`, `dateCreated`, `dateUpdated`, `uid`) VALUES ('20', '5', 'Transition Type', 'transition', 'global', '', '0', 'none', NULL, 'craft\\fields\\Dropdown', '{\"optgroups\":true,\"options\":[{\"label\":\"Slide\",\"value\":\"slide\",\"default\":\"1\"},{\"label\":\"Fade\",\"value\":\"fade\",\"default\":\"\"}]}', '2019-12-16 11:03:41', '2019-12-16 11:03:41', '9c5a65fa-d228-42d3-9975-bf2ff8e37155');
INSERT INTO `fields` (`id`, `groupId`, `name`, `handle`, `context`, `instructions`, `searchable`, `translationMethod`, `translationKeyFormat`, `type`, `settings`, `dateCreated`, `dateUpdated`, `uid`) VALUES ('21', '3', 'Additional Keywords', 'keywords', 'global', 'Use this field to include additional keywords to assist in site searches.', '1', 'none', NULL, 'craft\\fields\\PlainText', '{\"placeholder\":\"\",\"code\":\"\",\"multiline\":\"\",\"initialRows\":\"4\",\"charLimit\":\"\",\"columnType\":\"text\"}', '2019-12-16 11:04:39', '2019-12-16 11:04:39', '8eb75ebb-5efd-460a-b661-78a2e5c1929b');
INSERT INTO `fields` (`id`, `groupId`, `name`, `handle`, `context`, `instructions`, `searchable`, `translationMethod`, `translationKeyFormat`, `type`, `settings`, `dateCreated`, `dateUpdated`, `uid`) VALUES ('22', '3', 'Confirmation Message', 'confirm', 'global', 'The text that will be displayed when a user successfully submits the form.', '1', 'none', NULL, 'craft\\redactor\\Field', '{\"redactorConfig\":\"Simple.json\",\"purifierConfig\":\"\",\"cleanupHtml\":true,\"removeInlineStyles\":\"1\",\"removeEmptyTags\":\"1\",\"removeNbsp\":\"1\",\"purifyHtml\":\"1\",\"columnType\":\"text\",\"availableVolumes\":\"*\",\"availableTransforms\":\"*\"}', '2019-12-16 11:06:18', '2019-12-16 11:06:18', '9c399ba4-8fdb-47a1-9f2c-883a0c08c56f');
INSERT INTO `fields` (`id`, `groupId`, `name`, `handle`, `context`, `instructions`, `searchable`, `translationMethod`, `translationKeyFormat`, `type`, `settings`, `dateCreated`, `dateUpdated`, `uid`) VALUES ('23', '3', 'Custom Code', 'code', 'global', '', '1', 'none', NULL, 'craft\\fields\\PlainText', '{\"placeholder\":\"\",\"code\":\"1\",\"multiline\":\"1\",\"initialRows\":\"6\",\"charLimit\":\"\",\"columnType\":\"text\"}', '2019-12-16 11:07:18', '2019-12-16 11:07:18', '11d456e9-f112-4213-9e12-5bbf5fc576a3');
INSERT INTO `fields` (`id`, `groupId`, `name`, `handle`, `context`, `instructions`, `searchable`, `translationMethod`, `translationKeyFormat`, `type`, `settings`, `dateCreated`, `dateUpdated`, `uid`) VALUES ('24', '3', 'Quote', 'quote', 'global', '', '1', 'none', NULL, 'craft\\redactor\\Field', '{\"redactorConfig\":\"Simple.json\",\"purifierConfig\":\"\",\"cleanupHtml\":true,\"removeInlineStyles\":\"1\",\"removeEmptyTags\":\"1\",\"removeNbsp\":\"1\",\"purifyHtml\":\"1\",\"columnType\":\"text\",\"availableVolumes\":\"*\",\"availableTransforms\":\"*\"}', '2019-12-16 11:07:55', '2019-12-16 11:07:55', 'cdb2e12c-0fba-43fe-bfcc-643a14754ab9');
INSERT INTO `fields` (`id`, `groupId`, `name`, `handle`, `context`, `instructions`, `searchable`, `translationMethod`, `translationKeyFormat`, `type`, `settings`, `dateCreated`, `dateUpdated`, `uid`) VALUES ('25', '9', 'Link', 'button', 'global', '', '1', 'none', NULL, 'fruitstudios\\linkit\\fields\\LinkitField', '{\"selectLinkText\":\"\",\"types\":{\"fruitstudios\\\\linkit\\\\models\\\\Email\":{\"enabled\":\"1\",\"customLabel\":\"\",\"customPlaceholder\":\"\"},\"fruitstudios\\\\linkit\\\\models\\\\Phone\":{\"enabled\":\"1\",\"customLabel\":\"\",\"customPlaceholder\":\"\"},\"fruitstudios\\\\linkit\\\\models\\\\Url\":{\"enabled\":\"1\",\"customLabel\":\"\",\"customPlaceholder\":\"\",\"allowAlias\":\"1\",\"allowMailto\":\"1\",\"allowHash\":\"1\",\"allowPaths\":\"1\"},\"fruitstudios\\\\linkit\\\\models\\\\Twitter\":{\"enabled\":\"1\",\"customLabel\":\"\",\"customPlaceholder\":\"\"},\"fruitstudios\\\\linkit\\\\models\\\\Facebook\":{\"enabled\":\"1\",\"customLabel\":\"\",\"customPlaceholder\":\"\"},\"fruitstudios\\\\linkit\\\\models\\\\Instagram\":{\"enabled\":\"1\",\"customLabel\":\"\",\"customPlaceholder\":\"\"},\"fruitstudios\\\\linkit\\\\models\\\\LinkedIn\":{\"enabled\":\"1\",\"customLabel\":\"\",\"customPlaceholder\":\"\"},\"fruitstudios\\\\linkit\\\\models\\\\Entry\":{\"enabled\":\"1\",\"customLabel\":\"\",\"sources\":\"*\",\"customSelectionLabel\":\"\"},\"fruitstudios\\\\linkit\\\\models\\\\Category\":{\"enabled\":\"1\",\"customLabel\":\"\",\"sources\":\"*\",\"customSelectionLabel\":\"\"},\"fruitstudios\\\\linkit\\\\models\\\\Asset\":{\"enabled\":\"1\",\"customLabel\":\"\",\"sources\":[\"folder:69c7ff12-d018-4af6-9653-fe7836160abf\"],\"customSelectionLabel\":\"\"},\"fruitstudios\\\\linkit\\\\models\\\\User\":{\"enabled\":\"\",\"customLabel\":\"\",\"sources\":\"*\",\"customSelectionLabel\":\"\",\"userPath\":\"\"}},\"allowCustomText\":\"1\",\"defaultText\":\"\",\"allowTarget\":\"1\"}', '2019-12-16 11:12:42', '2019-12-17 00:40:21', 'b7d09be9-9704-4d76-bf5a-6022ec9927c9');
INSERT INTO `fields` (`id`, `groupId`, `name`, `handle`, `context`, `instructions`, `searchable`, `translationMethod`, `translationKeyFormat`, `type`, `settings`, `dateCreated`, `dateUpdated`, `uid`) VALUES ('26', '9', 'Location', 'location', 'global', '', '1', 'none', NULL, 'ether\\simplemap\\fields\\MapField', '{\"lat\":51.272154,\"lng\":0.514951,\"zoom\":15,\"minZoom\":\"3\",\"maxZoom\":\"18\",\"country\":\"US\",\"hideSearch\":\"\",\"hideMap\":\"\",\"hideAddress\":\"\",\"showLatLng\":\"\",\"showCurrentLocation\":\"\",\"size\":\"normal\",\"hideLatLng\":null,\"height\":null,\"countryRestriction\":null,\"typeRestriction\":null,\"boundaryRestrictionNELat\":null,\"boundaryRestrictionNELng\":null,\"boundaryRestrictionSWLat\":null,\"boundaryRestrictionSWLng\":null,\"boundary\":\"\\\"\\\"\"}', '2019-12-16 11:20:43', '2019-12-16 11:20:43', '89aeb5c6-2010-4b63-8418-bb1cbc073dbe');
INSERT INTO `fields` (`id`, `groupId`, `name`, `handle`, `context`, `instructions`, `searchable`, `translationMethod`, `translationKeyFormat`, `type`, `settings`, `dateCreated`, `dateUpdated`, `uid`) VALUES ('27', '6', 'Image', 'image', 'global', '', '1', 'site', NULL, 'craft\\fields\\Assets', '{\"useSingleFolder\":\"\",\"defaultUploadLocationSource\":\"volume:31bc6e28-f82b-4d59-8e21-a33325447c9d\",\"defaultUploadLocationSubpath\":\"\",\"singleUploadLocationSource\":\"volume:31bc6e28-f82b-4d59-8e21-a33325447c9d\",\"singleUploadLocationSubpath\":\"\",\"restrictFiles\":\"1\",\"allowedKinds\":[\"image\"],\"sources\":[\"volume:31bc6e28-f82b-4d59-8e21-a33325447c9d\"],\"source\":null,\"targetSiteId\":null,\"viewMode\":\"large\",\"limit\":\"1\",\"selectionLabel\":\"Add an image\",\"localizeRelations\":false,\"validateRelatedElements\":\"\"}', '2019-12-16 11:28:59', '2019-12-16 11:28:59', 'f6eb14cb-2129-492c-b471-b6ea4179d905');
INSERT INTO `fields` (`id`, `groupId`, `name`, `handle`, `context`, `instructions`, `searchable`, `translationMethod`, `translationKeyFormat`, `type`, `settings`, `dateCreated`, `dateUpdated`, `uid`) VALUES ('28', '6', 'Images', 'images', 'global', '', '1', 'site', NULL, 'craft\\fields\\Assets', '{\"useSingleFolder\":\"\",\"defaultUploadLocationSource\":\"volume:31bc6e28-f82b-4d59-8e21-a33325447c9d\",\"defaultUploadLocationSubpath\":\"\",\"singleUploadLocationSource\":\"volume:31bc6e28-f82b-4d59-8e21-a33325447c9d\",\"singleUploadLocationSubpath\":\"\",\"restrictFiles\":\"1\",\"allowedKinds\":[\"image\"],\"sources\":[\"volume:31bc6e28-f82b-4d59-8e21-a33325447c9d\"],\"source\":null,\"targetSiteId\":null,\"viewMode\":\"large\",\"limit\":\"\",\"selectionLabel\":\"Add an image\",\"localizeRelations\":false,\"validateRelatedElements\":\"\"}', '2019-12-16 11:29:33', '2019-12-16 11:29:33', '2b68a629-7e92-49f4-bc66-ed66591dadd3');
INSERT INTO `fields` (`id`, `groupId`, `name`, `handle`, `context`, `instructions`, `searchable`, `translationMethod`, `translationKeyFormat`, `type`, `settings`, `dateCreated`, `dateUpdated`, `uid`) VALUES ('29', '6', 'Video', 'video', 'global', '', '1', 'site', NULL, 'craft\\fields\\Assets', '{\"useSingleFolder\":\"\",\"defaultUploadLocationSource\":\"volume:e1c0dfb7-b877-4184-8f8d-c8121e74c039\",\"defaultUploadLocationSubpath\":\"\",\"singleUploadLocationSource\":\"volume:31bc6e28-f82b-4d59-8e21-a33325447c9d\",\"singleUploadLocationSubpath\":\"\",\"restrictFiles\":\"1\",\"allowedKinds\":[\"json\",\"video\"],\"sources\":[\"volume:e1c0dfb7-b877-4184-8f8d-c8121e74c039\"],\"source\":null,\"targetSiteId\":null,\"viewMode\":\"large\",\"limit\":\"1\",\"selectionLabel\":\"Add a video\",\"localizeRelations\":false,\"validateRelatedElements\":\"\"}', '2019-12-16 11:30:21', '2019-12-16 11:30:21', '39d33505-2395-4f4a-9798-27430aa67b22');
INSERT INTO `fields` (`id`, `groupId`, `name`, `handle`, `context`, `instructions`, `searchable`, `translationMethod`, `translationKeyFormat`, `type`, `settings`, `dateCreated`, `dateUpdated`, `uid`) VALUES ('30', '8', 'Page Content', 'pageContent', 'global', 'Include rows of content to build out the page', '1', 'site', NULL, 'benf\\neo\\Field', '{\"minBlocks\":\"\",\"maxBlocks\":\"\",\"maxTopBlocks\":\"\",\"propagationMethod\":\"all\"}', '2019-12-16 11:57:50', '2019-12-17 01:05:13', 'b8826224-f4da-4eca-95e1-b4e3acd1b2c3');
INSERT INTO `fields` (`id`, `groupId`, `name`, `handle`, `context`, `instructions`, `searchable`, `translationMethod`, `translationKeyFormat`, `type`, `settings`, `dateCreated`, `dateUpdated`, `uid`) VALUES ('31', '8', 'Entry Content', 'entryContent', 'global', 'Include blocks of content to build out the entry', '1', 'site', NULL, 'benf\\neo\\Field', '{\"minBlocks\":\"\",\"maxBlocks\":\"\",\"maxTopBlocks\":\"\",\"propagationMethod\":\"all\"}', '2019-12-16 20:40:27', '2019-12-17 01:04:29', '90d4a327-9400-48d7-8bb4-18e710636c38');
INSERT INTO `fields` (`id`, `groupId`, `name`, `handle`, `context`, `instructions`, `searchable`, `translationMethod`, `translationKeyFormat`, `type`, `settings`, `dateCreated`, `dateUpdated`, `uid`) VALUES ('32', '3', 'Phone', 'phone', 'global', '', '1', 'none', NULL, 'craft\\fields\\PlainText', '{\"placeholder\":\"\",\"code\":\"\",\"multiline\":\"\",\"initialRows\":\"4\",\"charLimit\":\"\",\"columnType\":\"text\"}', '2019-12-16 20:41:40', '2019-12-16 20:41:40', '331f18ab-885e-434c-9e0a-c0c51fdd435d');
INSERT INTO `fields` (`id`, `groupId`, `name`, `handle`, `context`, `instructions`, `searchable`, `translationMethod`, `translationKeyFormat`, `type`, `settings`, `dateCreated`, `dateUpdated`, `uid`) VALUES ('33', '10', 'Article Categories', 'newsCategories', 'global', '', '1', 'site', NULL, 'craft\\fields\\Categories', '{\"allowLimit\":false,\"allowMultipleSources\":false,\"branchLimit\":\"\",\"sources\":\"*\",\"source\":\"group:18fafec6-ea29-45d3-b653-efadf9123eb9\",\"targetSiteId\":null,\"viewMode\":null,\"limit\":null,\"selectionLabel\":\"\",\"localizeRelations\":false,\"validateRelatedElements\":\"\"}', '2019-12-16 20:53:14', '2019-12-16 21:09:07', 'd7ccc6b6-5363-4117-92f8-aa87787aaaec');
INSERT INTO `fields` (`id`, `groupId`, `name`, `handle`, `context`, `instructions`, `searchable`, `translationMethod`, `translationKeyFormat`, `type`, `settings`, `dateCreated`, `dateUpdated`, `uid`) VALUES ('34', '4', 'Entries per page', 'paginate', 'global', '', '1', 'none', NULL, 'craft\\fields\\Dropdown', '{\"optgroups\":true,\"options\":[{\"label\":\"All\",\"value\":\"0\",\"default\":\"1\"},{\"label\":\"10\",\"value\":\"10\",\"default\":\"\"},{\"label\":\"20\",\"value\":\"20\",\"default\":\"\"},{\"label\":\"30\",\"value\":\"30\",\"default\":\"\"},{\"label\":\"40\",\"value\":\"40\",\"default\":\"\"},{\"label\":\"50\",\"value\":\"50\",\"default\":\"\"}]}', '2019-12-16 20:55:58', '2019-12-16 20:55:58', '03b750b8-b69a-4bec-a1d1-cecf95c4b46d');
INSERT INTO `fields` (`id`, `groupId`, `name`, `handle`, `context`, `instructions`, `searchable`, `translationMethod`, `translationKeyFormat`, `type`, `settings`, `dateCreated`, `dateUpdated`, `uid`) VALUES ('35', '10', 'Default News Page', 'defaultNews', 'global', 'Select the default News page for the site. If none is selected, the first one in the Pages section will be used.', '1', 'site', NULL, 'nfourtythree\\entriessubset\\fields\\EntriesSubsetField', '{\"entryTypes\":[\"8ad5b5c9-bc0d-403b-b82d-1727493c2733\"],\"userGroups\":null,\"users\":null,\"sources\":[\"section:2e7aaa5a-bc25-4e9a-8efd-dd29ee0fcec2\"],\"source\":null,\"targetSiteId\":null,\"viewMode\":null,\"limit\":\"1\",\"selectionLabel\":\"\",\"localizeRelations\":false,\"validateRelatedElements\":\"\"}', '2019-12-16 21:00:57', '2019-12-16 21:03:10', '1d8e8c49-ce5a-499e-91d5-e14174a42325');
INSERT INTO `fields` (`id`, `groupId`, `name`, `handle`, `context`, `instructions`, `searchable`, `translationMethod`, `translationKeyFormat`, `type`, `settings`, `dateCreated`, `dateUpdated`, `uid`) VALUES ('36', '3', 'Alternate Title', 'altTitle', 'global', '', '1', 'none', NULL, 'craft\\fields\\PlainText', '{\"placeholder\":\"\",\"code\":\"\",\"multiline\":\"\",\"initialRows\":\"4\",\"charLimit\":\"\",\"columnType\":\"text\"}', '2019-12-16 21:16:45', '2019-12-16 21:16:45', 'e02a1f1e-a3b6-4425-aa2b-04168abc924c');
INSERT INTO `fields` (`id`, `groupId`, `name`, `handle`, `context`, `instructions`, `searchable`, `translationMethod`, `translationKeyFormat`, `type`, `settings`, `dateCreated`, `dateUpdated`, `uid`) VALUES ('37', '10', 'Redirect Page', 'redirectPage', 'global', '', '1', 'site', NULL, 'craft\\fields\\Entries', '{\"sources\":\"*\",\"source\":null,\"targetSiteId\":null,\"viewMode\":null,\"limit\":\"1\",\"selectionLabel\":\"\",\"localizeRelations\":false,\"validateRelatedElements\":\"\"}', '2019-12-17 00:41:57', '2019-12-17 00:41:57', '6286013d-8215-4661-87ba-5f4531648a0d');
INSERT INTO `fields` (`id`, `groupId`, `name`, `handle`, `context`, `instructions`, `searchable`, `translationMethod`, `translationKeyFormat`, `type`, `settings`, `dateCreated`, `dateUpdated`, `uid`) VALUES ('38', '10', 'Articles', 'newsEntries', 'global', '', '1', 'site', NULL, 'craft\\fields\\Entries', '{\"sources\":[\"section:eef60044-7c15-4709-90ea-0c8035e7b0cd\"],\"source\":null,\"targetSiteId\":null,\"viewMode\":null,\"limit\":\"\",\"selectionLabel\":\"\",\"localizeRelations\":false,\"validateRelatedElements\":\"\"}', '2019-12-17 00:43:53', '2019-12-17 00:43:53', '80be1cb0-8f7d-4b68-907f-80dd8ed9d007');
INSERT INTO `fields` (`id`, `groupId`, `name`, `handle`, `context`, `instructions`, `searchable`, `translationMethod`, `translationKeyFormat`, `type`, `settings`, `dateCreated`, `dateUpdated`, `uid`) VALUES ('39', '3', 'Email Address', 'email', 'global', '', '1', 'none', NULL, 'craft\\fields\\Email', '{\"placeholder\":\"\"}', '2019-12-17 00:51:35', '2019-12-17 00:51:35', 'c3651f55-968d-46a6-bde1-c32e6c4f635d');
INSERT INTO `fields` (`id`, `groupId`, `name`, `handle`, `context`, `instructions`, `searchable`, `translationMethod`, `translationKeyFormat`, `type`, `settings`, `dateCreated`, `dateUpdated`, `uid`) VALUES ('40', '3', 'Fax', 'fax', 'global', '', '1', 'none', NULL, 'craft\\fields\\PlainText', '{\"placeholder\":\"\",\"code\":\"\",\"multiline\":\"\",\"initialRows\":\"4\",\"charLimit\":\"\",\"columnType\":\"text\"}', '2019-12-17 00:52:00', '2019-12-17 00:52:00', 'da6505e8-c202-4902-8d31-2617deeebc1e');

INSERT INTO `freeform_fields` (`id`, `type`, `handle`, `label`, `required`, `instructions`, `metaProperties`, `dateCreated`, `dateUpdated`, `uid`) VALUES ('1', 'text', 'firstName', 'First Name', '0', NULL, NULL, '2019-12-16 10:22:46', '2019-12-16 10:22:46', '61279aae-8842-48c4-9f1f-5979a506177c');
INSERT INTO `freeform_fields` (`id`, `type`, `handle`, `label`, `required`, `instructions`, `metaProperties`, `dateCreated`, `dateUpdated`, `uid`) VALUES ('2', 'text', 'lastName', 'Last Name', '0', NULL, NULL, '2019-12-16 10:22:46', '2019-12-16 10:22:46', '34c243c7-ccb3-429d-8abb-299fafdcb445');
INSERT INTO `freeform_fields` (`id`, `type`, `handle`, `label`, `required`, `instructions`, `metaProperties`, `dateCreated`, `dateUpdated`, `uid`) VALUES ('3', 'email', 'email', 'Email', '0', NULL, NULL, '2019-12-16 10:22:46', '2019-12-16 10:22:46', '538cf756-306f-4f4d-8179-ebd639b9de30');
INSERT INTO `freeform_fields` (`id`, `type`, `handle`, `label`, `required`, `instructions`, `metaProperties`, `dateCreated`, `dateUpdated`, `uid`) VALUES ('4', 'text', 'website', 'Website', '0', NULL, NULL, '2019-12-16 10:22:46', '2019-12-16 10:22:46', 'bb7ad4b9-b90e-4672-90eb-d7826bf0c2a7');
INSERT INTO `freeform_fields` (`id`, `type`, `handle`, `label`, `required`, `instructions`, `metaProperties`, `dateCreated`, `dateUpdated`, `uid`) VALUES ('5', 'text', 'cellPhone', 'Cell Phone', '0', NULL, NULL, '2019-12-16 10:22:46', '2019-12-16 10:22:46', 'ca5d1029-4e49-4388-941d-3a7eb151a353');
INSERT INTO `freeform_fields` (`id`, `type`, `handle`, `label`, `required`, `instructions`, `metaProperties`, `dateCreated`, `dateUpdated`, `uid`) VALUES ('6', 'text', 'homePhone', 'Home Phone', '0', NULL, NULL, '2019-12-16 10:22:46', '2019-12-16 10:22:46', 'bde57cdf-f832-4d7d-aea8-0a03c12f4f21');
INSERT INTO `freeform_fields` (`id`, `type`, `handle`, `label`, `required`, `instructions`, `metaProperties`, `dateCreated`, `dateUpdated`, `uid`) VALUES ('7', 'text', 'companyName', 'Company Name', '0', NULL, NULL, '2019-12-16 10:22:46', '2019-12-16 10:22:46', '2cad2ad3-8d6a-468e-a7dc-849f5ac22f4d');
INSERT INTO `freeform_fields` (`id`, `type`, `handle`, `label`, `required`, `instructions`, `metaProperties`, `dateCreated`, `dateUpdated`, `uid`) VALUES ('8', 'textarea', 'address', 'Address', '0', NULL, '{\"rows\":2}', '2019-12-16 10:22:46', '2019-12-16 10:22:46', 'b19e4d32-3d2b-48e1-bd74-a7da12b79b2f');
INSERT INTO `freeform_fields` (`id`, `type`, `handle`, `label`, `required`, `instructions`, `metaProperties`, `dateCreated`, `dateUpdated`, `uid`) VALUES ('9', 'text', 'city', 'City', '0', NULL, NULL, '2019-12-16 10:22:47', '2019-12-16 10:22:47', '6a18d3c3-c04d-4828-9f6f-6b3c26823ce6');
INSERT INTO `freeform_fields` (`id`, `type`, `handle`, `label`, `required`, `instructions`, `metaProperties`, `dateCreated`, `dateUpdated`, `uid`) VALUES ('10', 'select', 'state', 'State', '0', NULL, '{\"options\":[{\"value\":\"\",\"label\":\"Select a State\"},{\"value\":\"AL\",\"label\":\"Alabama\"},{\"value\":\"AK\",\"label\":\"Alaska\"},{\"value\":\"AZ\",\"label\":\"Arizona\"},{\"value\":\"AR\",\"label\":\"Arkansas\"},{\"value\":\"CA\",\"label\":\"California\"},{\"value\":\"CO\",\"label\":\"Colorado\"},{\"value\":\"CT\",\"label\":\"Connecticut\"},{\"value\":\"DE\",\"label\":\"Delaware\"},{\"value\":\"DC\",\"label\":\"District of Columbia\"},{\"value\":\"FL\",\"label\":\"Florida\"},{\"value\":\"GA\",\"label\":\"Georgia\"},{\"value\":\"HI\",\"label\":\"Hawaii\"},{\"value\":\"ID\",\"label\":\"Idaho\"},{\"value\":\"IL\",\"label\":\"Illinois\"},{\"value\":\"IN\",\"label\":\"Indiana\"},{\"value\":\"IA\",\"label\":\"Iowa\"},{\"value\":\"KS\",\"label\":\"Kansas\"},{\"value\":\"KY\",\"label\":\"Kentucky\"},{\"value\":\"LA\",\"label\":\"Louisiana\"},{\"value\":\"ME\",\"label\":\"Maine\"},{\"value\":\"MD\",\"label\":\"Maryland\"},{\"value\":\"MA\",\"label\":\"Massachusetts\"},{\"value\":\"MI\",\"label\":\"Michigan\"},{\"value\":\"MN\",\"label\":\"Minnesota\"},{\"value\":\"MS\",\"label\":\"Mississippi\"},{\"value\":\"MO\",\"label\":\"Missouri\"},{\"value\":\"MT\",\"label\":\"Montana\"},{\"value\":\"NE\",\"label\":\"Nebraska\"},{\"value\":\"NV\",\"label\":\"Nevada\"},{\"value\":\"NH\",\"label\":\"New Hampshire\"},{\"value\":\"NJ\",\"label\":\"New Jersey\"},{\"value\":\"NM\",\"label\":\"New Mexico\"},{\"value\":\"NY\",\"label\":\"New York\"},{\"value\":\"NC\",\"label\":\"North Carolina\"},{\"value\":\"ND\",\"label\":\"North Dakota\"},{\"value\":\"OH\",\"label\":\"Ohio\"},{\"value\":\"OK\",\"label\":\"Oklahoma\"},{\"value\":\"OR\",\"label\":\"Oregon\"},{\"value\":\"PA\",\"label\":\"Pennsylvania\"},{\"value\":\"RI\",\"label\":\"Rhode Island\"},{\"value\":\"SC\",\"label\":\"South Carolina\"},{\"value\":\"SD\",\"label\":\"South Dakota\"},{\"value\":\"TN\",\"label\":\"Tennessee\"},{\"value\":\"TX\",\"label\":\"Texas\"},{\"value\":\"UT\",\"label\":\"Utah\"},{\"value\":\"VT\",\"label\":\"Vermont\"},{\"value\":\"VA\",\"label\":\"Virginia\"},{\"value\":\"WA\",\"label\":\"Washington\"},{\"value\":\"WV\",\"label\":\"West Virginia\"},{\"value\":\"WI\",\"label\":\"Wisconsin\"},{\"value\":\"WY\",\"label\":\"Wyoming\"}]}', '2019-12-16 10:22:47', '2019-12-16 10:22:47', '2a54d7df-e363-4498-ab7b-e405233e5431');
INSERT INTO `freeform_fields` (`id`, `type`, `handle`, `label`, `required`, `instructions`, `metaProperties`, `dateCreated`, `dateUpdated`, `uid`) VALUES ('11', 'text', 'zipCode', 'Zip Code', '0', NULL, NULL, '2019-12-16 10:22:47', '2019-12-16 10:22:47', '4ce54ae0-4e03-4d14-a2d0-d739dcc02b7c');
INSERT INTO `freeform_fields` (`id`, `type`, `handle`, `label`, `required`, `instructions`, `metaProperties`, `dateCreated`, `dateUpdated`, `uid`) VALUES ('12', 'textarea', 'message', 'Message', '0', NULL, '{\"rows\":5}', '2019-12-16 10:22:47', '2019-12-16 10:22:47', 'edf2e337-db56-4a56-80a7-029c03be85ed');
INSERT INTO `freeform_fields` (`id`, `type`, `handle`, `label`, `required`, `instructions`, `metaProperties`, `dateCreated`, `dateUpdated`, `uid`) VALUES ('13', 'number', 'number', 'Number', '0', NULL, NULL, '2019-12-16 10:22:47', '2019-12-16 10:22:47', 'ef0e5e56-e96f-4c1e-aa2b-e7f432b607b7');
INSERT INTO `freeform_fields` (`id`, `type`, `handle`, `label`, `required`, `instructions`, `metaProperties`, `dateCreated`, `dateUpdated`, `uid`) VALUES ('14', 'cc_details', 'payment', '', '0', NULL, NULL, '2019-12-16 10:22:47', '2019-12-16 10:22:47', 'a3912ae9-b959-403e-9c82-a982704c2717');

INSERT INTO `freeform_statuses` (`id`, `name`, `handle`, `color`, `isDefault`, `sortOrder`, `dateCreated`, `dateUpdated`, `uid`) VALUES ('1', 'Pending', 'pending', 'light', NULL, '1', '2019-12-16 10:22:47', '2019-12-16 10:22:47', 'ca1a91f2-946d-404d-8a58-56d2f8f72e59');
INSERT INTO `freeform_statuses` (`id`, `name`, `handle`, `color`, `isDefault`, `sortOrder`, `dateCreated`, `dateUpdated`, `uid`) VALUES ('2', 'Open', 'open', 'green', '1', '2', '2019-12-16 10:22:47', '2019-12-16 10:22:47', 'fd5bc9d3-47e0-4967-a7f7-128058d8987b');
INSERT INTO `freeform_statuses` (`id`, `name`, `handle`, `color`, `isDefault`, `sortOrder`, `dateCreated`, `dateUpdated`, `uid`) VALUES ('3', 'Closed', 'closed', 'grey', NULL, '3', '2019-12-16 10:22:47', '2019-12-16 10:22:47', '6a005464-7efe-4edd-a593-631723603421');

INSERT INTO `globalsets` (`id`, `name`, `handle`, `fieldLayoutId`, `dateCreated`, `dateUpdated`, `uid`) VALUES ('14', 'General', 'general', '34', '2019-12-16 20:42:51', '2019-12-17 01:09:13', '02eaae2b-ff7a-47f7-af7b-69935108d5d4');
INSERT INTO `globalsets` (`id`, `name`, `handle`, `fieldLayoutId`, `dateCreated`, `dateUpdated`, `uid`) VALUES ('15', 'Sections', 'sections', '37', '2019-12-16 21:01:51', '2019-12-17 00:55:20', '98b897f7-b828-4bf3-857d-925e359b630c');

INSERT INTO `gqlschemas` (`id`, `name`, `accessToken`, `enabled`, `expiryDate`, `lastUsed`, `scope`, `dateCreated`, `dateUpdated`, `uid`) VALUES ('1', 'Public Schema', '__PUBLIC__', '1', NULL, NULL, '[]', '2019-12-16 10:24:23', '2019-12-16 10:24:23', '242af376-ab42-41bd-a2d4-9bb343315bb3');

INSERT INTO `info` (`id`, `version`, `schemaVersion`, `maintenance`, `config`, `configMap`, `fieldVersion`, `dateCreated`, `dateUpdated`, `uid`) VALUES ('1', '3.3.18.4', '3.3.3', '0', '{\"categoryGroups\":{\"18fafec6-ea29-45d3-b653-efadf9123eb9\":{\"name\":\"News Categories\",\"handle\":\"newsCategories\",\"structure\":{\"uid\":\"e9e93210-f319-4d40-aec7-d642796aad61\",\"maxLevels\":null},\"siteSettings\":{\"ab67a472-afac-4525-a8c9-08a909f0d281\":{\"hasUrls\":true,\"uriFormat\":\"news/category/{slug}\",\"template\":\"news/category\"}},\"fieldLayouts\":{\"ab232e4c-6d38-4c72-90aa-1d195ea96651\":{\"tabs\":[{\"name\":\"SEO / Meta\",\"sortOrder\":1,\"fields\":{\"8eb75ebb-5efd-460a-b661-78a2e5c1929b\":{\"required\":false,\"sortOrder\":3},\"e3bfa017-1474-4fed-a176-88a42ff2e8c2\":{\"required\":false,\"sortOrder\":2},\"f6eb14cb-2129-492c-b471-b6ea4179d905\":{\"required\":false,\"sortOrder\":1}}}]}}}},\"dateModified\":1577211027,\"email\":{\"fromEmail\":\"support@fostercommerce.com\",\"fromName\":\"Craft Vue Tailwind\",\"transportType\":\"craft\\\\mail\\\\transportadapters\\\\Sendmail\"},\"fieldGroups\":{\"24f4c2bc-c279-4faf-94b4-ed1d70b683a2\":{\"name\":\"Assets\"},\"3c9f6df0-5abd-4877-a460-4152aec05e33\":{\"name\":\"Style\"},\"59376394-99bc-4a56-848d-d7f1bb119194\":{\"name\":\"Text\"},\"5e61df28-d93d-4339-82b6-07a8f44b142c\":{\"name\":\"Content Builders\"},\"721537c2-5b3e-44c1-96a4-5afe4d0e049f\":{\"name\":\"Plugin\"},\"8c1e1966-fc9d-48fd-9621-ff86acfa29ef\":{\"name\":\"Relations\"},\"e0066e90-e858-47a6-9353-554b8abee96e\":{\"name\":\"Options\"},\"fbd00a3e-7235-4a6d-8b32-345e745b6912\":{\"name\":\"Compound\"}},\"fieldlabels\":{\"00965c4d-fcbf-4867-bb54-3ee41ae64241\":{\"field\":\"e3bfa017-1474-4fed-a176-88a42ff2e8c2\",\"fieldLayout\":\"d70439e2-45b1-499f-86ad-3b14bab04dce\",\"name\":\"Preview Summary\",\"instructions\":null,\"hideName\":false,\"hideInstructions\":false},\"01fd4b03-a734-4748-ba98-7fa0e38b7efd\":{\"field\":\"87a3aca4-9b17-41ab-a703-bba76a315981\",\"fieldLayout\":\"ef4c47d1-7dc7-49e8-9eae-eec68da8e8fd\",\"name\":\"Thumbnail Aspect Ratio\",\"instructions\":null,\"hideName\":false,\"hideInstructions\":false},\"14484882-8c18-460a-a80a-ef33044364b9\":{\"field\":\"f6eb14cb-2129-492c-b471-b6ea4179d905\",\"fieldLayout\":\"d70439e2-45b1-499f-86ad-3b14bab04dce\",\"name\":\"Preview Image\",\"instructions\":null,\"hideName\":false,\"hideInstructions\":false},\"2541f75b-4171-4336-9aa5-95c41d7a4d97\":{\"field\":\"f6eb14cb-2129-492c-b471-b6ea4179d905\",\"fieldLayout\":\"1b8a3b09-15ab-4668-b7e7-a63fe6e15581\",\"name\":\"Preview Image\",\"instructions\":null,\"hideName\":false,\"hideInstructions\":false},\"27cc3f43-1460-4a0f-9a8f-9e3429fe6133\":{\"field\":\"f6eb14cb-2129-492c-b471-b6ea4179d905\",\"fieldLayout\":\"317b3dab-bb54-475d-8ae5-c739377cdc64\",\"name\":\"Preview Image\",\"instructions\":null,\"hideName\":false,\"hideInstructions\":false},\"298ee8f2-65d1-4329-97e9-feb88de73704\":{\"field\":\"90d4a327-9400-48d7-8bb4-18e710636c38\",\"fieldLayout\":\"b870c8ec-ef37-4abe-9b54-8a4f703b57b5\",\"name\":\"Article Content\",\"instructions\":\"Include blocks of content to build out the article\",\"hideName\":false,\"hideInstructions\":false},\"2b1335e6-5b47-49ef-bfde-bfa8c491ac0e\":{\"field\":\"9995c1a8-7fe7-4dc4-bac6-7a5a2547e5e2\",\"fieldLayout\":\"a2749570-8f8d-4f97-a418-50bda0f93a3e\",\"name\":\"Button Size\",\"instructions\":null,\"hideName\":false,\"hideInstructions\":false},\"3257468b-931d-4658-8ff1-327f55923542\":{\"field\":\"f6eb14cb-2129-492c-b471-b6ea4179d905\",\"fieldLayout\":\"95a8afe5-3088-4221-a5a2-72244c99eb2c\",\"name\":\"Background Image\",\"instructions\":null,\"hideName\":false,\"hideInstructions\":false},\"33e0438e-ac04-4545-827e-dba40dd8373f\":{\"field\":\"e02a1f1e-a3b6-4425-aa2b-04168abc924c\",\"fieldLayout\":\"b870c8ec-ef37-4abe-9b54-8a4f703b57b5\",\"name\":null,\"instructions\":\"Include an alternate title for this article. Leave blank to use the article title.\",\"hideName\":false,\"hideInstructions\":false},\"3559cf6d-fc2b-47c2-a837-aaf4e9b61ed4\":{\"field\":\"e3bfa017-1474-4fed-a176-88a42ff2e8c2\",\"fieldLayout\":\"72bb2cd1-054d-4567-9375-f6b699409645\",\"name\":\"Preview Summary\",\"instructions\":null,\"hideName\":false,\"hideInstructions\":false},\"3d8bf18a-b682-4cea-8d56-8986020e538c\":{\"field\":\"6286013d-8215-4661-87ba-5f4531648a0d\",\"fieldLayout\":\"b5ca9ee2-cf4d-47d2-b9eb-4e8f24388705\",\"name\":null,\"instructions\":\"If you would like the user to be redirected to another page upon successfully submitting the form, select it here.\",\"hideName\":false,\"hideInstructions\":false},\"4d65607a-3aa7-4d62-a7af-5e157bcea397\":{\"field\":\"57f2498a-803a-4083-9433-9b937db415bc\",\"fieldLayout\":\"1310cde0-91f6-4f3e-8a17-b1184ec78fb1\",\"name\":\"Button Color\",\"instructions\":null,\"hideName\":false,\"hideInstructions\":false},\"4e729115-883e-4cd8-9388-e35d926baaba\":{\"field\":\"e3bfa017-1474-4fed-a176-88a42ff2e8c2\",\"fieldLayout\":\"b870c8ec-ef37-4abe-9b54-8a4f703b57b5\",\"name\":\"Preview Summary\",\"instructions\":null,\"hideName\":false,\"hideInstructions\":false},\"5f97e9d4-ebdb-4e2e-b7f7-918596aa3673\":{\"field\":\"f6eb14cb-2129-492c-b471-b6ea4179d905\",\"fieldLayout\":\"4705535e-ca45-45a5-a79e-6684a8626a4d\",\"name\":\"Default Page Header Image\",\"instructions\":\"Include a default image for page headers that will be used if no preview image for the page is selected.\",\"hideName\":false,\"hideInstructions\":false},\"61eb5681-7dc8-4039-a429-2f56fe76f751\":{\"field\":\"f6eb14cb-2129-492c-b471-b6ea4179d905\",\"fieldLayout\":\"72bb2cd1-054d-4567-9375-f6b699409645\",\"name\":\"Preview Image\",\"instructions\":null,\"hideName\":false,\"hideInstructions\":false},\"67a42122-d27b-446d-b3c5-54f8946e9709\":{\"field\":\"e02a1f1e-a3b6-4425-aa2b-04168abc924c\",\"fieldLayout\":\"317b3dab-bb54-475d-8ae5-c739377cdc64\",\"name\":null,\"instructions\":\"Include an alternate title for this page. Leave blank to use the page title.\",\"hideName\":false,\"hideInstructions\":false},\"6b34b961-3add-429c-9947-b1db0caef17c\":{\"field\":\"c3651f55-968d-46a6-bde1-c32e6c4f635d\",\"fieldLayout\":\"c96dbb5c-2f37-4af1-b4af-8b91aaf5ab09\",\"name\":\"Recipient Email Address\",\"instructions\":\"Email address of who should receive notifications when a user submits this form. Leave blank to forward notifications to your business email address defined in \\\"Globals\\\" > \\\"General\\\"\",\"hideName\":false,\"hideInstructions\":false},\"6d833a0d-6246-4586-907b-5b31c9727bdc\":{\"field\":\"f6eb14cb-2129-492c-b471-b6ea4179d905\",\"fieldLayout\":\"ab232e4c-6d38-4c72-90aa-1d195ea96651\",\"name\":\"Preview Image\",\"instructions\":null,\"hideName\":false,\"hideInstructions\":false},\"6f748cee-7649-486b-9e31-2c5c4dfde3ea\":{\"field\":\"e02a1f1e-a3b6-4425-aa2b-04168abc924c\",\"fieldLayout\":\"d70439e2-45b1-499f-86ad-3b14bab04dce\",\"name\":null,\"instructions\":\"Include an alternate title for this page. Leave blank to use the page title.\",\"hideName\":false,\"hideInstructions\":false},\"76528ccf-891d-4da3-b269-05bda077a25f\":{\"field\":\"e3bfa017-1474-4fed-a176-88a42ff2e8c2\",\"fieldLayout\":\"1b8a3b09-15ab-4668-b7e7-a63fe6e15581\",\"name\":\"Preview Summary\",\"instructions\":null,\"hideName\":false,\"hideInstructions\":false},\"78f7bf5c-0a3d-46ef-877d-e5bc2ca0c2f8\":{\"field\":\"c3651f55-968d-46a6-bde1-c32e6c4f635d\",\"fieldLayout\":\"b5ca9ee2-cf4d-47d2-b9eb-4e8f24388705\",\"name\":\"Recipient Email Address\",\"instructions\":\"Email address of who should receive notifications when a user submits this form. Leave blank to forward notifications to your business email address defined in \\\"Globals\\\" > \\\"General\\\"\",\"hideName\":false,\"hideInstructions\":false},\"79636c09-58bb-4566-84d5-35b85c7f24a6\":{\"field\":\"d7ccc6b6-5363-4117-92f8-aa87787aaaec\",\"fieldLayout\":\"d70439e2-45b1-499f-86ad-3b14bab04dce\",\"name\":null,\"instructions\":\"Select the category of news articles to display on the page. Leave blank to display all articles.\",\"hideName\":false,\"hideInstructions\":false},\"7f4f3fd6-f500-45c7-b570-0785a090d565\":{\"field\":\"87a3aca4-9b17-41ab-a703-bba76a315981\",\"fieldLayout\":\"2cb29f15-5074-43f3-b5e4-7ab90aa0b927\",\"name\":\"Thumbnail Aspect Ratio\",\"instructions\":null,\"hideName\":false,\"hideInstructions\":false},\"8d4505ab-e3cd-4c47-b1ea-6000f0190be7\":{\"field\":\"c3651f55-968d-46a6-bde1-c32e6c4f635d\",\"fieldLayout\":\"b42ad105-7d14-4f21-83f5-b37a659ac819\",\"name\":null,\"instructions\":\"Your business address. This is the default email address where all form submission notifications will be sent if a recipient is not specified in the page content form. If left blank, notifications will be sent to the recipient address assigned in the form under \\\"Freeform\\\" > \\\"Forms\\\"\",\"hideName\":false,\"hideInstructions\":false},\"980236a8-008b-4c2c-9eb4-65680023726c\":{\"field\":\"f6eb14cb-2129-492c-b471-b6ea4179d905\",\"fieldLayout\":\"b870c8ec-ef37-4abe-9b54-8a4f703b57b5\",\"name\":\"Preview Image\",\"instructions\":null,\"hideName\":false,\"hideInstructions\":false},\"98d9769d-86a3-4eca-bfe6-ed419f9b948e\":{\"field\":\"57f2498a-803a-4083-9433-9b937db415bc\",\"fieldLayout\":\"1d566ede-cbd1-4597-812c-6c4a7ccc6265\",\"name\":\"Table Color\",\"instructions\":null,\"hideName\":false,\"hideInstructions\":false},\"ac0fab81-a82e-405c-a51e-ba686d42227d\":{\"field\":\"331f18ab-885e-434c-9e0a-c0c51fdd435d\",\"fieldLayout\":\"b42ad105-7d14-4f21-83f5-b37a659ac819\",\"name\":null,\"instructions\":\"Your business phone number\",\"hideName\":false,\"hideInstructions\":false},\"b40538c5-0c41-41e0-9870-d96cd269224f\":{\"field\":\"6286013d-8215-4661-87ba-5f4531648a0d\",\"fieldLayout\":\"c96dbb5c-2f37-4af1-b4af-8b91aaf5ab09\",\"name\":null,\"instructions\":\"If you would like the user to be redirected to another page upon successfully submitting the form, select it here.\",\"hideName\":false,\"hideInstructions\":false},\"c11baa06-b38b-42d8-99c7-cf1058818fc4\":{\"field\":\"89aeb5c6-2010-4b63-8418-bb1cbc073dbe\",\"fieldLayout\":\"b42ad105-7d14-4f21-83f5-b37a659ac819\",\"name\":\"Address\",\"instructions\":\"Your business address\",\"hideName\":false,\"hideInstructions\":false},\"cf6f24df-b2ff-4aab-96c3-a000bb9acc67\":{\"field\":\"da6505e8-c202-4902-8d31-2617deeebc1e\",\"fieldLayout\":\"b42ad105-7d14-4f21-83f5-b37a659ac819\",\"name\":null,\"instructions\":\"Your business Fax\",\"hideName\":false,\"hideInstructions\":false},\"d32294d1-1946-4841-b16b-b395a92f06db\":{\"field\":\"e3bfa017-1474-4fed-a176-88a42ff2e8c2\",\"fieldLayout\":\"ab232e4c-6d38-4c72-90aa-1d195ea96651\",\"name\":\"Preview Summary\",\"instructions\":null,\"hideName\":false,\"hideInstructions\":false},\"d4aad52c-bc14-43c6-b51a-dc79a41c1d0e\":{\"field\":\"e3bfa017-1474-4fed-a176-88a42ff2e8c2\",\"fieldLayout\":\"317b3dab-bb54-475d-8ae5-c739377cdc64\",\"name\":\"Preview Summary\",\"instructions\":null,\"hideName\":false,\"hideInstructions\":false},\"e60c5f66-c8fe-41de-acd0-e501e74b4bdb\":{\"field\":\"9995c1a8-7fe7-4dc4-bac6-7a5a2547e5e2\",\"fieldLayout\":\"1310cde0-91f6-4f3e-8a17-b1184ec78fb1\",\"name\":\"Button Size\",\"instructions\":null,\"hideName\":false,\"hideInstructions\":false},\"e7fd382f-0cce-4294-acf8-150076569d20\":{\"field\":\"57f2498a-803a-4083-9433-9b937db415bc\",\"fieldLayout\":\"a2749570-8f8d-4f97-a418-50bda0f93a3e\",\"name\":\"Button Color\",\"instructions\":null,\"hideName\":false,\"hideInstructions\":false},\"e825f055-53f8-4ef8-a89a-4c5d66291914\":{\"field\":\"80be1cb0-8f7d-4b68-907f-80dd8ed9d007\",\"fieldLayout\":\"d70439e2-45b1-499f-86ad-3b14bab04dce\",\"name\":\"Featured Articles\",\"instructions\":\"Select the articles to feature on this page. Leave blank to display the latest published articles.\",\"hideName\":false,\"hideInstructions\":false},\"f301d903-be4a-42ba-8ab1-23e7154995c3\":{\"field\":\"57f2498a-803a-4083-9433-9b937db415bc\",\"fieldLayout\":\"3792ad99-c503-4d19-8155-78ea4064ad06\",\"name\":\"Table Color\",\"instructions\":null,\"hideName\":false,\"hideInstructions\":false},\"f31e66f1-27d1-4f03-8b55-bb6252812528\":{\"field\":\"f6eb14cb-2129-492c-b471-b6ea4179d905\",\"fieldLayout\":\"c6dbf030-8a39-4c50-8a65-6e9fa1e46a2e\",\"name\":\"Poster Image\",\"instructions\":\"The image that appears before the video plays.\",\"hideName\":false,\"hideInstructions\":false},\"fe34c62a-2236-4fae-8c1c-de822d65bc45\":{\"field\":\"d7ccc6b6-5363-4117-92f8-aa87787aaaec\",\"fieldLayout\":\"b870c8ec-ef37-4abe-9b54-8a4f703b57b5\",\"name\":null,\"instructions\":\"Select the categories for this article.\",\"hideName\":false,\"hideInstructions\":false}},\"fields\":{\"03b750b8-b69a-4bec-a1d1-cecf95c4b46d\":{\"name\":\"Entries per page\",\"handle\":\"paginate\",\"instructions\":\"\",\"searchable\":true,\"translationMethod\":\"none\",\"translationKeyFormat\":null,\"type\":\"craft\\\\fields\\\\Dropdown\",\"settings\":{\"optgroups\":true,\"options\":[{\"label\":\"All\",\"value\":\"0\",\"default\":\"1\"},{\"label\":\"10\",\"value\":\"10\",\"default\":\"\"},{\"label\":\"20\",\"value\":\"20\",\"default\":\"\"},{\"label\":\"30\",\"value\":\"30\",\"default\":\"\"},{\"label\":\"40\",\"value\":\"40\",\"default\":\"\"},{\"label\":\"50\",\"value\":\"50\",\"default\":\"\"}]},\"contentColumnType\":\"string\",\"fieldGroup\":\"e0066e90-e858-47a6-9353-554b8abee96e\"},\"05beaa1f-418d-42f6-8972-ffcf1d3421e6\":{\"name\":\"Position\",\"handle\":\"position\",\"instructions\":\"\",\"searchable\":false,\"translationMethod\":\"none\",\"translationKeyFormat\":null,\"type\":\"craft\\\\fields\\\\Dropdown\",\"settings\":{\"optgroups\":true,\"options\":[{\"label\":\"Auto\",\"value\":\"auto\",\"default\":\"1\"},{\"label\":\"Left\",\"value\":\"left\",\"default\":\"\"},{\"label\":\"Center\",\"value\":\"center\",\"default\":\"\"},{\"label\":\"Right\",\"value\":\"right\",\"default\":\"\"},{\"label\":\"Full\",\"value\":\"full\",\"default\":\"\"}]},\"contentColumnType\":\"string\",\"fieldGroup\":\"3c9f6df0-5abd-4877-a460-4152aec05e33\"},\"11d456e9-f112-4213-9e12-5bbf5fc576a3\":{\"name\":\"Custom Code\",\"handle\":\"code\",\"instructions\":\"\",\"searchable\":true,\"translationMethod\":\"none\",\"translationKeyFormat\":null,\"type\":\"craft\\\\fields\\\\PlainText\",\"settings\":{\"placeholder\":\"\",\"code\":\"1\",\"multiline\":\"1\",\"initialRows\":\"6\",\"charLimit\":\"\",\"columnType\":\"text\"},\"contentColumnType\":\"text\",\"fieldGroup\":\"59376394-99bc-4a56-848d-d7f1bb119194\"},\"16b8848e-d06a-4c6b-b716-ee84349642d3\":{\"name\":\"Autoplay\",\"handle\":\"autoplay\",\"instructions\":\"\",\"searchable\":false,\"translationMethod\":\"none\",\"translationKeyFormat\":null,\"type\":\"craft\\\\fields\\\\Lightswitch\",\"settings\":{\"default\":\"\"},\"contentColumnType\":\"boolean\",\"fieldGroup\":\"3c9f6df0-5abd-4877-a460-4152aec05e33\"},\"1a09a8f2-8bc2-42f9-afe4-ab7d17bc6bfc\":{\"name\":\"Padding\",\"handle\":\"padding\",\"instructions\":\"\",\"searchable\":false,\"translationMethod\":\"none\",\"translationKeyFormat\":null,\"type\":\"craft\\\\fields\\\\Dropdown\",\"settings\":{\"optgroups\":true,\"options\":[{\"label\":\"Large\",\"value\":\"large\",\"default\":\"\"},{\"label\":\"Medium\",\"value\":\"medium\",\"default\":\"1\"},{\"label\":\"Small\",\"value\":\"small\",\"default\":\"\"},{\"label\":\"None\",\"value\":\"none\",\"default\":\"\"}]},\"contentColumnType\":\"string\",\"fieldGroup\":\"3c9f6df0-5abd-4877-a460-4152aec05e33\"},\"1d8e8c49-ce5a-499e-91d5-e14174a42325\":{\"name\":\"Default News Page\",\"handle\":\"defaultNews\",\"instructions\":\"Select the default News page for the site. If none is selected, the first one in the Pages section will be used.\",\"searchable\":true,\"translationMethod\":\"site\",\"translationKeyFormat\":null,\"type\":\"nfourtythree\\\\entriessubset\\\\fields\\\\EntriesSubsetField\",\"settings\":{\"entryTypes\":[\"8ad5b5c9-bc0d-403b-b82d-1727493c2733\"],\"userGroups\":null,\"users\":null,\"sources\":[\"section:2e7aaa5a-bc25-4e9a-8efd-dd29ee0fcec2\"],\"source\":null,\"targetSiteId\":null,\"viewMode\":null,\"limit\":\"1\",\"selectionLabel\":\"\",\"localizeRelations\":false,\"validateRelatedElements\":\"\"},\"contentColumnType\":\"string\",\"fieldGroup\":\"8c1e1966-fc9d-48fd-9621-ff86acfa29ef\"},\"2378559f-b7e8-4d0d-83a9-c90809389dc4\":{\"name\":\"Source / Citation\",\"handle\":\"cite\",\"instructions\":\"\",\"searchable\":true,\"translationMethod\":\"none\",\"translationKeyFormat\":null,\"type\":\"craft\\\\fields\\\\PlainText\",\"settings\":{\"placeholder\":\"\",\"code\":\"\",\"multiline\":\"\",\"initialRows\":\"4\",\"charLimit\":\"\",\"columnType\":\"text\"},\"contentColumnType\":\"text\",\"fieldGroup\":\"59376394-99bc-4a56-848d-d7f1bb119194\"},\"2b68a629-7e92-49f4-bc66-ed66591dadd3\":{\"name\":\"Images\",\"handle\":\"images\",\"instructions\":\"\",\"searchable\":true,\"translationMethod\":\"site\",\"translationKeyFormat\":null,\"type\":\"craft\\\\fields\\\\Assets\",\"settings\":{\"useSingleFolder\":\"\",\"defaultUploadLocationSource\":\"volume:31bc6e28-f82b-4d59-8e21-a33325447c9d\",\"defaultUploadLocationSubpath\":\"\",\"singleUploadLocationSource\":\"volume:31bc6e28-f82b-4d59-8e21-a33325447c9d\",\"singleUploadLocationSubpath\":\"\",\"restrictFiles\":\"1\",\"allowedKinds\":[\"image\"],\"sources\":[\"volume:31bc6e28-f82b-4d59-8e21-a33325447c9d\"],\"source\":null,\"targetSiteId\":null,\"viewMode\":\"large\",\"limit\":\"\",\"selectionLabel\":\"Add an image\",\"localizeRelations\":false,\"validateRelatedElements\":\"\"},\"contentColumnType\":\"string\",\"fieldGroup\":\"24f4c2bc-c279-4faf-94b4-ed1d70b683a2\"},\"331f18ab-885e-434c-9e0a-c0c51fdd435d\":{\"name\":\"Phone\",\"handle\":\"phone\",\"instructions\":\"\",\"searchable\":true,\"translationMethod\":\"none\",\"translationKeyFormat\":null,\"type\":\"craft\\\\fields\\\\PlainText\",\"settings\":{\"placeholder\":\"\",\"code\":\"\",\"multiline\":\"\",\"initialRows\":\"4\",\"charLimit\":\"\",\"columnType\":\"text\"},\"contentColumnType\":\"text\",\"fieldGroup\":\"59376394-99bc-4a56-848d-d7f1bb119194\"},\"332bf96d-e927-4c21-bfbd-d8dd96087850\":{\"name\":\"Heading\",\"handle\":\"heading\",\"instructions\":\"\",\"searchable\":true,\"translationMethod\":\"none\",\"translationKeyFormat\":null,\"type\":\"craft\\\\fields\\\\PlainText\",\"settings\":{\"placeholder\":\"\",\"code\":\"\",\"multiline\":\"\",\"initialRows\":\"4\",\"charLimit\":\"\",\"columnType\":\"text\"},\"contentColumnType\":\"text\",\"fieldGroup\":\"59376394-99bc-4a56-848d-d7f1bb119194\"},\"3481333e-977a-4adb-90d5-fae5926ad8bb\":{\"name\":\"Table\",\"handle\":\"table\",\"instructions\":\"\",\"searchable\":true,\"translationMethod\":\"none\",\"translationKeyFormat\":null,\"type\":\"supercool\\\\tablemaker\\\\fields\\\\TableMakerField\",\"settings\":{\"columnsLabel\":\"\",\"columnsInstructions\":\"\",\"columnsAddRowLabel\":\"\",\"rowsLabel\":\"\",\"rowsInstructions\":\"\",\"rowsAddRowLabel\":\"\"},\"contentColumnType\":\"text\",\"fieldGroup\":\"721537c2-5b3e-44c1-96a4-5afe4d0e049f\"},\"39d33505-2395-4f4a-9798-27430aa67b22\":{\"name\":\"Video\",\"handle\":\"video\",\"instructions\":\"\",\"searchable\":true,\"translationMethod\":\"site\",\"translationKeyFormat\":null,\"type\":\"craft\\\\fields\\\\Assets\",\"settings\":{\"useSingleFolder\":\"\",\"defaultUploadLocationSource\":\"volume:e1c0dfb7-b877-4184-8f8d-c8121e74c039\",\"defaultUploadLocationSubpath\":\"\",\"singleUploadLocationSource\":\"volume:31bc6e28-f82b-4d59-8e21-a33325447c9d\",\"singleUploadLocationSubpath\":\"\",\"restrictFiles\":\"1\",\"allowedKinds\":[\"json\",\"video\"],\"sources\":[\"volume:e1c0dfb7-b877-4184-8f8d-c8121e74c039\"],\"source\":null,\"targetSiteId\":null,\"viewMode\":\"large\",\"limit\":\"1\",\"selectionLabel\":\"Add a video\",\"localizeRelations\":false,\"validateRelatedElements\":\"\"},\"contentColumnType\":\"string\",\"fieldGroup\":\"24f4c2bc-c279-4faf-94b4-ed1d70b683a2\"},\"3aad9545-9f94-41c9-b9f5-f11ef3d223fd\":{\"name\":\"Alignment\",\"handle\":\"alignment\",\"instructions\":\"\",\"searchable\":false,\"translationMethod\":\"none\",\"translationKeyFormat\":null,\"type\":\"craft\\\\fields\\\\Dropdown\",\"settings\":{\"optgroups\":true,\"options\":[{\"label\":\"Left\",\"value\":\"left\",\"default\":\"1\"},{\"label\":\"Center\",\"value\":\"center\",\"default\":\"\"},{\"label\":\"Right\",\"value\":\"right\",\"default\":\"\"}]},\"contentColumnType\":\"string\",\"fieldGroup\":\"3c9f6df0-5abd-4877-a460-4152aec05e33\"},\"57f2498a-803a-4083-9433-9b937db415bc\":{\"name\":\"Text Color\",\"handle\":\"textColor\",\"instructions\":\"\",\"searchable\":false,\"translationMethod\":\"none\",\"translationKeyFormat\":null,\"type\":\"craft\\\\fields\\\\Dropdown\",\"settings\":{\"optgroups\":true,\"options\":[{\"label\":\"Black\",\"value\":\"black\",\"default\":\"1\"},{\"label\":\"Blue\",\"value\":\"blue\",\"default\":\"\"},{\"label\":\"Orange\",\"value\":\"orange\",\"default\":\"\"},{\"label\":\"White\",\"value\":\"white\",\"default\":\"\"}]},\"contentColumnType\":\"string\",\"fieldGroup\":\"3c9f6df0-5abd-4877-a460-4152aec05e33\"},\"6286013d-8215-4661-87ba-5f4531648a0d\":{\"name\":\"Redirect Page\",\"handle\":\"redirectPage\",\"instructions\":\"\",\"searchable\":true,\"translationMethod\":\"site\",\"translationKeyFormat\":null,\"type\":\"craft\\\\fields\\\\Entries\",\"settings\":{\"sources\":\"*\",\"source\":null,\"targetSiteId\":null,\"viewMode\":null,\"limit\":\"1\",\"selectionLabel\":\"\",\"localizeRelations\":false,\"validateRelatedElements\":\"\"},\"contentColumnType\":\"string\",\"fieldGroup\":\"8c1e1966-fc9d-48fd-9621-ff86acfa29ef\"},\"734d68d3-e878-4e03-8aa9-9feb0dd82fb1\":{\"name\":\"Form\",\"handle\":\"form\",\"instructions\":\"\",\"searchable\":false,\"translationMethod\":\"none\",\"translationKeyFormat\":null,\"type\":\"Solspace\\\\Freeform\\\\FieldTypes\\\\FormFieldType\",\"contentColumnType\":\"integer\",\"fieldGroup\":\"721537c2-5b3e-44c1-96a4-5afe4d0e049f\"},\"7ce9ced9-3e8f-4bf2-9cd6-065b16567e6e\":{\"name\":\"Rich Text\",\"handle\":\"richText\",\"instructions\":\"\",\"searchable\":true,\"translationMethod\":\"none\",\"translationKeyFormat\":null,\"type\":\"craft\\\\redactor\\\\Field\",\"settings\":{\"redactorConfig\":\"Standard.json\",\"purifierConfig\":\"\",\"cleanupHtml\":true,\"removeInlineStyles\":\"1\",\"removeEmptyTags\":\"1\",\"removeNbsp\":\"1\",\"purifyHtml\":\"1\",\"columnType\":\"text\",\"availableVolumes\":[\"b4623a75-4ffd-4637-bd4d-36ffbe88a935\"],\"availableTransforms\":\"*\"},\"contentColumnType\":\"text\",\"fieldGroup\":\"59376394-99bc-4a56-848d-d7f1bb119194\"},\"80be1cb0-8f7d-4b68-907f-80dd8ed9d007\":{\"name\":\"Articles\",\"handle\":\"newsEntries\",\"instructions\":\"\",\"searchable\":true,\"translationMethod\":\"site\",\"translationKeyFormat\":null,\"type\":\"craft\\\\fields\\\\Entries\",\"settings\":{\"sources\":[\"section:eef60044-7c15-4709-90ea-0c8035e7b0cd\"],\"source\":null,\"targetSiteId\":null,\"viewMode\":null,\"limit\":\"\",\"selectionLabel\":\"\",\"localizeRelations\":false,\"validateRelatedElements\":\"\"},\"contentColumnType\":\"string\",\"fieldGroup\":\"8c1e1966-fc9d-48fd-9621-ff86acfa29ef\"},\"87a3aca4-9b17-41ab-a703-bba76a315981\":{\"name\":\"Aspect Ratio\",\"handle\":\"aspect\",\"instructions\":\"\",\"searchable\":false,\"translationMethod\":\"none\",\"translationKeyFormat\":null,\"type\":\"craft\\\\fields\\\\Dropdown\",\"settings\":{\"optgroups\":true,\"options\":[{\"label\":\"Auto\",\"value\":\"auto\",\"default\":\"1\"},{\"label\":\"Square (1:1)\",\"value\":\"square\",\"default\":\"\"},{\"label\":\"Horizontal (3:2)\",\"value\":\"horizontal\",\"default\":\"\"},{\"label\":\"Vertical (2:3)\",\"value\":\"vertical\",\"default\":\"\"},{\"label\":\"Wide (16:9)\",\"value\":\"wide\",\"default\":\"\"}]},\"contentColumnType\":\"string\",\"fieldGroup\":\"3c9f6df0-5abd-4877-a460-4152aec05e33\"},\"89aeb5c6-2010-4b63-8418-bb1cbc073dbe\":{\"name\":\"Location\",\"handle\":\"location\",\"instructions\":\"\",\"searchable\":true,\"translationMethod\":\"none\",\"translationKeyFormat\":null,\"type\":\"ether\\\\simplemap\\\\fields\\\\MapField\",\"settings\":{\"lat\":51.272154000000000451109372079372406005859375,\"lng\":0.51495100000000004758504701385390944778919219970703125,\"zoom\":15,\"minZoom\":\"3\",\"maxZoom\":\"18\",\"country\":\"US\",\"hideSearch\":\"\",\"hideMap\":\"\",\"hideAddress\":\"\",\"showLatLng\":\"\",\"showCurrentLocation\":\"\",\"size\":\"normal\",\"hideLatLng\":null,\"height\":null,\"countryRestriction\":null,\"typeRestriction\":null,\"boundaryRestrictionNELat\":null,\"boundaryRestrictionNELng\":null,\"boundaryRestrictionSWLat\":null,\"boundaryRestrictionSWLng\":null,\"boundary\":\"\\\"\\\"\"},\"contentColumnType\":\"text\",\"fieldGroup\":\"721537c2-5b3e-44c1-96a4-5afe4d0e049f\"},\"8eb75ebb-5efd-460a-b661-78a2e5c1929b\":{\"name\":\"Additional Keywords\",\"handle\":\"keywords\",\"instructions\":\"Use this field to include additional keywords to assist in site searches.\",\"searchable\":true,\"translationMethod\":\"none\",\"translationKeyFormat\":null,\"type\":\"craft\\\\fields\\\\PlainText\",\"settings\":{\"placeholder\":\"\",\"code\":\"\",\"multiline\":\"\",\"initialRows\":\"4\",\"charLimit\":\"\",\"columnType\":\"text\"},\"contentColumnType\":\"text\",\"fieldGroup\":\"59376394-99bc-4a56-848d-d7f1bb119194\"},\"8ed3608e-41ca-474f-bf29-b77c0b80931c\":{\"name\":\"Background Color\",\"handle\":\"backgroundColor\",\"instructions\":\"\",\"searchable\":false,\"translationMethod\":\"none\",\"translationKeyFormat\":null,\"type\":\"craft\\\\fields\\\\Dropdown\",\"settings\":{\"optgroups\":true,\"options\":[{\"label\":\"White\",\"value\":\"white\",\"default\":\"1\"},{\"label\":\"Blue\",\"value\":\"blue\",\"default\":\"\"},{\"label\":\"Orange\",\"value\":\"orange\",\"default\":\"\"},{\"label\":\"Black\",\"value\":\"black\",\"default\":\"\"}]},\"contentColumnType\":\"string\",\"fieldGroup\":\"3c9f6df0-5abd-4877-a460-4152aec05e33\"},\"90d4a327-9400-48d7-8bb4-18e710636c38\":{\"name\":\"Entry Content\",\"handle\":\"entryContent\",\"instructions\":\"Include blocks of content to build out the entry\",\"searchable\":true,\"translationMethod\":\"site\",\"translationKeyFormat\":null,\"type\":\"benf\\\\neo\\\\Field\",\"settings\":{\"minBlocks\":\"\",\"maxBlocks\":\"\",\"maxTopBlocks\":\"\",\"propagationMethod\":\"all\"},\"contentColumnType\":\"string\",\"fieldGroup\":\"5e61df28-d93d-4339-82b6-07a8f44b142c\"},\"9995c1a8-7fe7-4dc4-bac6-7a5a2547e5e2\":{\"name\":\"Text Size\",\"handle\":\"textSize\",\"instructions\":\"\",\"searchable\":false,\"translationMethod\":\"none\",\"translationKeyFormat\":null,\"type\":\"craft\\\\fields\\\\Dropdown\",\"settings\":{\"optgroups\":true,\"options\":[{\"label\":\"Huge\",\"value\":\"huge\",\"default\":\"\"},{\"label\":\"Large\",\"value\":\"large\",\"default\":\"\"},{\"label\":\"Medium\",\"value\":\"medium\",\"default\":\"1\"},{\"label\":\"Small\",\"value\":\"small\",\"default\":\"\"}]},\"contentColumnType\":\"string\",\"fieldGroup\":\"3c9f6df0-5abd-4877-a460-4152aec05e33\"},\"9c399ba4-8fdb-47a1-9f2c-883a0c08c56f\":{\"name\":\"Confirmation Message\",\"handle\":\"confirm\",\"instructions\":\"The text that will be displayed when a user successfully submits the form.\",\"searchable\":true,\"translationMethod\":\"none\",\"translationKeyFormat\":null,\"type\":\"craft\\\\redactor\\\\Field\",\"settings\":{\"redactorConfig\":\"Simple.json\",\"purifierConfig\":\"\",\"cleanupHtml\":true,\"removeInlineStyles\":\"1\",\"removeEmptyTags\":\"1\",\"removeNbsp\":\"1\",\"purifyHtml\":\"1\",\"columnType\":\"text\",\"availableVolumes\":\"*\",\"availableTransforms\":\"*\"},\"contentColumnType\":\"text\",\"fieldGroup\":\"59376394-99bc-4a56-848d-d7f1bb119194\"},\"9c5a65fa-d228-42d3-9975-bf2ff8e37155\":{\"name\":\"Transition Type\",\"handle\":\"transition\",\"instructions\":\"\",\"searchable\":false,\"translationMethod\":\"none\",\"translationKeyFormat\":null,\"type\":\"craft\\\\fields\\\\Dropdown\",\"settings\":{\"optgroups\":true,\"options\":[{\"label\":\"Slide\",\"value\":\"slide\",\"default\":\"1\"},{\"label\":\"Fade\",\"value\":\"fade\",\"default\":\"\"}]},\"contentColumnType\":\"string\",\"fieldGroup\":\"3c9f6df0-5abd-4877-a460-4152aec05e33\"},\"adfefe4f-d6ca-4d4e-82ef-22326f737fd6\":{\"name\":\"Width\",\"handle\":\"width\",\"instructions\":\"\",\"searchable\":false,\"translationMethod\":\"none\",\"translationKeyFormat\":null,\"type\":\"craft\\\\fields\\\\Dropdown\",\"settings\":{\"optgroups\":true,\"options\":[{\"label\":\"Full\",\"value\":\"full\",\"default\":\"\"},{\"label\":\"Wide\",\"value\":\"wide\",\"default\":\"\"},{\"label\":\"Medium\",\"value\":\"medium\",\"default\":\"1\"},{\"label\":\"Thin\",\"value\":\"thin\",\"default\":\"\"}]},\"contentColumnType\":\"string\",\"fieldGroup\":\"3c9f6df0-5abd-4877-a460-4152aec05e33\"},\"b7d09be9-9704-4d76-bf5a-6022ec9927c9\":{\"name\":\"Link\",\"handle\":\"button\",\"instructions\":\"\",\"searchable\":true,\"translationMethod\":\"none\",\"translationKeyFormat\":null,\"type\":\"fruitstudios\\\\linkit\\\\fields\\\\LinkitField\",\"settings\":{\"selectLinkText\":\"\",\"types\":{\"fruitstudios\\\\linkit\\\\models\\\\Email\":{\"enabled\":\"1\",\"customLabel\":\"\",\"customPlaceholder\":\"\"},\"fruitstudios\\\\linkit\\\\models\\\\Phone\":{\"enabled\":\"1\",\"customLabel\":\"\",\"customPlaceholder\":\"\"},\"fruitstudios\\\\linkit\\\\models\\\\Url\":{\"enabled\":\"1\",\"customLabel\":\"\",\"customPlaceholder\":\"\",\"allowAlias\":\"1\",\"allowMailto\":\"1\",\"allowHash\":\"1\",\"allowPaths\":\"1\"},\"fruitstudios\\\\linkit\\\\models\\\\Twitter\":{\"enabled\":\"1\",\"customLabel\":\"\",\"customPlaceholder\":\"\"},\"fruitstudios\\\\linkit\\\\models\\\\Facebook\":{\"enabled\":\"1\",\"customLabel\":\"\",\"customPlaceholder\":\"\"},\"fruitstudios\\\\linkit\\\\models\\\\Instagram\":{\"enabled\":\"1\",\"customLabel\":\"\",\"customPlaceholder\":\"\"},\"fruitstudios\\\\linkit\\\\models\\\\LinkedIn\":{\"enabled\":\"1\",\"customLabel\":\"\",\"customPlaceholder\":\"\"},\"fruitstudios\\\\linkit\\\\models\\\\Entry\":{\"enabled\":\"1\",\"customLabel\":\"\",\"sources\":\"*\",\"customSelectionLabel\":\"\"},\"fruitstudios\\\\linkit\\\\models\\\\Category\":{\"enabled\":\"1\",\"customLabel\":\"\",\"sources\":\"*\",\"customSelectionLabel\":\"\"},\"fruitstudios\\\\linkit\\\\models\\\\Asset\":{\"enabled\":\"1\",\"customLabel\":\"\",\"sources\":[\"folder:69c7ff12-d018-4af6-9653-fe7836160abf\"],\"customSelectionLabel\":\"\"},\"fruitstudios\\\\linkit\\\\models\\\\User\":{\"enabled\":\"\",\"customLabel\":\"\",\"sources\":\"*\",\"customSelectionLabel\":\"\",\"userPath\":\"\"}},\"allowCustomText\":\"1\",\"defaultText\":\"\",\"allowTarget\":\"1\"},\"contentColumnType\":\"text\",\"fieldGroup\":\"721537c2-5b3e-44c1-96a4-5afe4d0e049f\"},\"b8826224-f4da-4eca-95e1-b4e3acd1b2c3\":{\"name\":\"Page Content\",\"handle\":\"pageContent\",\"instructions\":\"Include rows of content to build out the page\",\"searchable\":true,\"translationMethod\":\"site\",\"translationKeyFormat\":null,\"type\":\"benf\\\\neo\\\\Field\",\"settings\":{\"minBlocks\":\"\",\"maxBlocks\":\"\",\"maxTopBlocks\":\"\",\"propagationMethod\":\"all\"},\"contentColumnType\":\"string\",\"fieldGroup\":\"5e61df28-d93d-4339-82b6-07a8f44b142c\"},\"bae81998-dbb4-433d-845e-416fc4ac4e18\":{\"name\":\"Tag\",\"handle\":\"tag\",\"instructions\":\"\",\"searchable\":false,\"translationMethod\":\"none\",\"translationKeyFormat\":null,\"type\":\"craft\\\\fields\\\\Dropdown\",\"settings\":{\"optgroups\":true,\"options\":[{\"label\":\"H1\",\"value\":\"h1\",\"default\":\"\"},{\"label\":\"H2\",\"value\":\"h2\",\"default\":\"1\"},{\"label\":\"H3\",\"value\":\"h3\",\"default\":\"\"},{\"label\":\"H4\",\"value\":\"h4\",\"default\":\"\"},{\"label\":\"H5\",\"value\":\"h5\",\"default\":\"\"}]},\"contentColumnType\":\"string\",\"fieldGroup\":\"3c9f6df0-5abd-4877-a460-4152aec05e33\"},\"c2609bfd-fefa-4ef4-9677-4644e30ed7b2\":{\"name\":\"Alternate Text\",\"handle\":\"altText\",\"instructions\":\"Include descriptive text of the image for visually impaired users.\",\"searchable\":true,\"translationMethod\":\"none\",\"translationKeyFormat\":null,\"type\":\"craft\\\\fields\\\\PlainText\",\"settings\":{\"placeholder\":\"\",\"code\":\"\",\"multiline\":\"\",\"initialRows\":\"4\",\"charLimit\":\"\",\"columnType\":\"text\"},\"contentColumnType\":\"text\",\"fieldGroup\":\"59376394-99bc-4a56-848d-d7f1bb119194\"},\"c3651f55-968d-46a6-bde1-c32e6c4f635d\":{\"name\":\"Email Address\",\"handle\":\"email\",\"instructions\":\"\",\"searchable\":true,\"translationMethod\":\"none\",\"translationKeyFormat\":null,\"type\":\"craft\\\\fields\\\\Email\",\"settings\":{\"placeholder\":\"\"},\"contentColumnType\":\"string\",\"fieldGroup\":\"59376394-99bc-4a56-848d-d7f1bb119194\"},\"cdb2e12c-0fba-43fe-bfcc-643a14754ab9\":{\"name\":\"Quote\",\"handle\":\"quote\",\"instructions\":\"\",\"searchable\":true,\"translationMethod\":\"none\",\"translationKeyFormat\":null,\"type\":\"craft\\\\redactor\\\\Field\",\"settings\":{\"redactorConfig\":\"Simple.json\",\"purifierConfig\":\"\",\"cleanupHtml\":true,\"removeInlineStyles\":\"1\",\"removeEmptyTags\":\"1\",\"removeNbsp\":\"1\",\"purifyHtml\":\"1\",\"columnType\":\"text\",\"availableVolumes\":\"*\",\"availableTransforms\":\"*\"},\"contentColumnType\":\"text\",\"fieldGroup\":\"59376394-99bc-4a56-848d-d7f1bb119194\"},\"cf28ac9c-b373-4de1-8afb-0baa227165d1\":{\"name\":\"Caption\",\"handle\":\"caption\",\"instructions\":\"\",\"searchable\":true,\"translationMethod\":\"none\",\"translationKeyFormat\":null,\"type\":\"craft\\\\fields\\\\PlainText\",\"settings\":{\"placeholder\":\"\",\"code\":\"\",\"multiline\":\"\",\"initialRows\":\"4\",\"charLimit\":\"\",\"columnType\":\"text\"},\"contentColumnType\":\"text\",\"fieldGroup\":\"59376394-99bc-4a56-848d-d7f1bb119194\"},\"d7ccc6b6-5363-4117-92f8-aa87787aaaec\":{\"name\":\"Article Categories\",\"handle\":\"newsCategories\",\"instructions\":\"\",\"searchable\":true,\"translationMethod\":\"site\",\"translationKeyFormat\":null,\"type\":\"craft\\\\fields\\\\Categories\",\"settings\":{\"allowLimit\":false,\"allowMultipleSources\":false,\"branchLimit\":\"\",\"sources\":\"*\",\"source\":\"group:18fafec6-ea29-45d3-b653-efadf9123eb9\",\"targetSiteId\":null,\"viewMode\":null,\"limit\":null,\"selectionLabel\":\"\",\"localizeRelations\":false,\"validateRelatedElements\":\"\"},\"contentColumnType\":\"string\",\"fieldGroup\":\"8c1e1966-fc9d-48fd-9621-ff86acfa29ef\"},\"da6505e8-c202-4902-8d31-2617deeebc1e\":{\"name\":\"Fax\",\"handle\":\"fax\",\"instructions\":\"\",\"searchable\":true,\"translationMethod\":\"none\",\"translationKeyFormat\":null,\"type\":\"craft\\\\fields\\\\PlainText\",\"settings\":{\"placeholder\":\"\",\"code\":\"\",\"multiline\":\"\",\"initialRows\":\"4\",\"charLimit\":\"\",\"columnType\":\"text\"},\"contentColumnType\":\"text\",\"fieldGroup\":\"59376394-99bc-4a56-848d-d7f1bb119194\"},\"e02a1f1e-a3b6-4425-aa2b-04168abc924c\":{\"name\":\"Alternate Title\",\"handle\":\"altTitle\",\"instructions\":\"\",\"searchable\":true,\"translationMethod\":\"none\",\"translationKeyFormat\":null,\"type\":\"craft\\\\fields\\\\PlainText\",\"settings\":{\"placeholder\":\"\",\"code\":\"\",\"multiline\":\"\",\"initialRows\":\"4\",\"charLimit\":\"\",\"columnType\":\"text\"},\"contentColumnType\":\"text\",\"fieldGroup\":\"59376394-99bc-4a56-848d-d7f1bb119194\"},\"e3bfa017-1474-4fed-a176-88a42ff2e8c2\":{\"name\":\"Summary\",\"handle\":\"summary\",\"instructions\":\"\",\"searchable\":true,\"translationMethod\":\"none\",\"translationKeyFormat\":null,\"type\":\"craft\\\\redactor\\\\Field\",\"settings\":{\"redactorConfig\":\"Simple.json\",\"purifierConfig\":\"\",\"cleanupHtml\":true,\"removeInlineStyles\":\"1\",\"removeEmptyTags\":\"1\",\"removeNbsp\":\"1\",\"purifyHtml\":\"1\",\"columnType\":\"text\",\"availableVolumes\":\"*\",\"availableTransforms\":\"*\"},\"contentColumnType\":\"text\",\"fieldGroup\":\"59376394-99bc-4a56-848d-d7f1bb119194\"},\"f6eb14cb-2129-492c-b471-b6ea4179d905\":{\"name\":\"Image\",\"handle\":\"image\",\"instructions\":\"\",\"searchable\":true,\"translationMethod\":\"site\",\"translationKeyFormat\":null,\"type\":\"craft\\\\fields\\\\Assets\",\"settings\":{\"useSingleFolder\":\"\",\"defaultUploadLocationSource\":\"volume:31bc6e28-f82b-4d59-8e21-a33325447c9d\",\"defaultUploadLocationSubpath\":\"\",\"singleUploadLocationSource\":\"volume:31bc6e28-f82b-4d59-8e21-a33325447c9d\",\"singleUploadLocationSubpath\":\"\",\"restrictFiles\":\"1\",\"allowedKinds\":[\"image\"],\"sources\":[\"volume:31bc6e28-f82b-4d59-8e21-a33325447c9d\"],\"source\":null,\"targetSiteId\":null,\"viewMode\":\"large\",\"limit\":\"1\",\"selectionLabel\":\"Add an image\",\"localizeRelations\":false,\"validateRelatedElements\":\"\"},\"contentColumnType\":\"string\",\"fieldGroup\":\"24f4c2bc-c279-4faf-94b4-ed1d70b683a2\"},\"fea94669-6b2d-4306-850a-4fb9d696fcac\":{\"name\":\"Grid Layout\",\"handle\":\"grid\",\"instructions\":\"\",\"searchable\":false,\"translationMethod\":\"none\",\"translationKeyFormat\":null,\"type\":\"craft\\\\fields\\\\Dropdown\",\"settings\":{\"optgroups\":true,\"options\":[{\"label\":\"None\",\"value\":\"one\",\"default\":\"\"},{\"label\":\"Two Up\",\"value\":\"two\",\"default\":\"\"},{\"label\":\"Three Up\",\"value\":\"three\",\"default\":\"1\"},{\"label\":\"Four Up\",\"value\":\"four\",\"default\":\"\"},{\"label\":\"Five Up\",\"value\":\"five\",\"default\":\"\"}]},\"contentColumnType\":\"string\",\"fieldGroup\":\"3c9f6df0-5abd-4877-a460-4152aec05e33\"}},\"globalSets\":{\"02eaae2b-ff7a-47f7-af7b-69935108d5d4\":{\"name\":\"General\",\"handle\":\"general\",\"fieldLayouts\":{\"b42ad105-7d14-4f21-83f5-b37a659ac819\":{\"tabs\":[{\"name\":\"Contact\",\"sortOrder\":1,\"fields\":{\"331f18ab-885e-434c-9e0a-c0c51fdd435d\":{\"required\":false,\"sortOrder\":2},\"89aeb5c6-2010-4b63-8418-bb1cbc073dbe\":{\"required\":false,\"sortOrder\":4},\"c3651f55-968d-46a6-bde1-c32e6c4f635d\":{\"required\":false,\"sortOrder\":1},\"da6505e8-c202-4902-8d31-2617deeebc1e\":{\"required\":false,\"sortOrder\":3}}}]}}},\"98b897f7-b828-4bf3-857d-925e359b630c\":{\"name\":\"Sections\",\"handle\":\"sections\",\"fieldLayouts\":{\"4705535e-ca45-45a5-a79e-6684a8626a4d\":{\"tabs\":[{\"name\":\"Pages\",\"sortOrder\":1,\"fields\":{\"f6eb14cb-2129-492c-b471-b6ea4179d905\":{\"required\":false,\"sortOrder\":1}}},{\"name\":\"News\",\"sortOrder\":2,\"fields\":{\"1d8e8c49-ce5a-499e-91d5-e14174a42325\":{\"required\":false,\"sortOrder\":1}}}]}}}},\"navigation\":{\"navs\":{\"7d098513-b442-4de8-898e-3463aba0cfb3\":{\"name\":\"Primary Navigation\",\"handle\":\"primary\",\"structure\":{\"uid\":\"3f9f861e-2ea7-4b48-a3d6-0281910f3a61\",\"maxLevels\":null},\"instructions\":\"\",\"propagateNodes\":false,\"sortOrder\":null}}},\"neoBlockTypeGroups\":{\"2083052d-b712-4ab1-a611-7a96f4e19c69\":{\"field\":\"b8826224-f4da-4eca-95e1-b4e3acd1b2c3\",\"name\":\"Media\",\"sortOrder\":9},\"72809716-7d0b-4784-b87f-c2bb0f8a9b28\":{\"field\":\"90d4a327-9400-48d7-8bb4-18e710636c38\",\"name\":\"Modules\",\"sortOrder\":13},\"88a88db3-b10a-4908-b313-85c7025ddf3f\":{\"field\":\"b8826224-f4da-4eca-95e1-b4e3acd1b2c3\",\"name\":\"Text\",\"sortOrder\":3},\"94d69d08-46bf-4038-81c9-4feb3a90a3ca\":{\"field\":\"b8826224-f4da-4eca-95e1-b4e3acd1b2c3\",\"name\":\"Containers\",\"sortOrder\":1},\"9b3584b0-08f9-4db4-9be7-bc77649ceb97\":{\"field\":\"90d4a327-9400-48d7-8bb4-18e710636c38\",\"name\":\"Media\",\"sortOrder\":7},\"9e5e0a64-8462-4df5-8db4-f4501609956d\":{\"field\":\"b8826224-f4da-4eca-95e1-b4e3acd1b2c3\",\"name\":\"Modules\",\"sortOrder\":15},\"b88351cc-7b87-4b71-a595-77d345d4aa18\":{\"field\":\"90d4a327-9400-48d7-8bb4-18e710636c38\",\"name\":\"Components\",\"sortOrder\":18},\"bb4204b0-9d80-450b-aafc-3c45b162ba95\":{\"field\":\"b8826224-f4da-4eca-95e1-b4e3acd1b2c3\",\"name\":\"Components\",\"sortOrder\":20},\"ff918988-53de-46fa-b6d4-efb70daa9213\":{\"field\":\"90d4a327-9400-48d7-8bb4-18e710636c38\",\"name\":\"Text\",\"sortOrder\":1}},\"neoBlockTypes\":{\"02ec681f-f570-4233-b3df-70226ab61b32\":{\"field\":\"90d4a327-9400-48d7-8bb4-18e710636c38\",\"name\":\"Heading\",\"handle\":\"heading\",\"sortOrder\":2,\"maxBlocks\":0,\"maxChildBlocks\":0,\"childBlocks\":\"\",\"topLevel\":true,\"fieldLayouts\":{\"87396e49-befe-4584-aab3-f8f4f0a04cb9\":{\"tabs\":[{\"name\":\"Content\",\"sortOrder\":1,\"fields\":{\"332bf96d-e927-4c21-bfbd-d8dd96087850\":{\"required\":true,\"sortOrder\":1}}},{\"name\":\"Settings\",\"sortOrder\":2,\"fields\":{\"3aad9545-9f94-41c9-b9f5-f11ef3d223fd\":{\"required\":false,\"sortOrder\":3},\"57f2498a-803a-4083-9433-9b937db415bc\":{\"required\":false,\"sortOrder\":4},\"9995c1a8-7fe7-4dc4-bac6-7a5a2547e5e2\":{\"required\":false,\"sortOrder\":2},\"bae81998-dbb4-433d-845e-416fc4ac4e18\":{\"required\":false,\"sortOrder\":1}}}]}}},\"061db8fb-26a7-4faa-aa0b-cdfcb21a0681\":{\"field\":\"b8826224-f4da-4eca-95e1-b4e3acd1b2c3\",\"name\":\"Pane\",\"handle\":\"pane\",\"sortOrder\":22,\"maxBlocks\":0,\"maxChildBlocks\":0,\"childBlocks\":[\"heading\",\"richText\",\"quote\",\"table\",\"button\",\"image\",\"video\",\"gallery\",\"slider\",\"map\",\"form\",\"code\"],\"topLevel\":false,\"fieldLayouts\":{\"36861469-36fc-4375-88cc-36d2ead6d3bf\":{\"tabs\":[{\"name\":\"Content\",\"sortOrder\":1,\"fields\":{\"332bf96d-e927-4c21-bfbd-d8dd96087850\":{\"required\":true,\"sortOrder\":1}}}]}}},\"1aa769c1-0804-4c0a-8b49-6251543a63f3\":{\"field\":\"90d4a327-9400-48d7-8bb4-18e710636c38\",\"name\":\"Gallery\",\"handle\":\"gallery\",\"sortOrder\":10,\"maxBlocks\":0,\"maxChildBlocks\":0,\"childBlocks\":\"\",\"topLevel\":true,\"fieldLayouts\":{\"2cb29f15-5074-43f3-b5e4-7ab90aa0b927\":{\"tabs\":[{\"name\":\"Content\",\"sortOrder\":1,\"fields\":{\"2b68a629-7e92-49f4-bc66-ed66591dadd3\":{\"required\":true,\"sortOrder\":1}}},{\"name\":\"Settings\",\"sortOrder\":2,\"fields\":{\"87a3aca4-9b17-41ab-a703-bba76a315981\":{\"required\":false,\"sortOrder\":2},\"fea94669-6b2d-4306-850a-4fb9d696fcac\":{\"required\":false,\"sortOrder\":1}}}]}}},\"1f1a70a2-dfc5-476e-9a09-46461229a679\":{\"field\":\"90d4a327-9400-48d7-8bb4-18e710636c38\",\"name\":\"Pane\",\"handle\":\"pane\",\"sortOrder\":20,\"maxBlocks\":0,\"maxChildBlocks\":0,\"childBlocks\":[\"heading\",\"richText\",\"quote\",\"table\",\"button\",\"image\",\"video\",\"gallery\",\"slider\",\"map\",\"form\",\"code\"],\"topLevel\":false,\"fieldLayouts\":{\"799bde03-acc3-4963-aafd-180a037e5ccd\":{\"tabs\":[{\"name\":\"Content\",\"sortOrder\":1,\"fields\":{\"332bf96d-e927-4c21-bfbd-d8dd96087850\":{\"required\":true,\"sortOrder\":1}}}]}}},\"207b818c-1e66-482c-8d36-5594d9792957\":{\"field\":\"b8826224-f4da-4eca-95e1-b4e3acd1b2c3\",\"name\":\"Rich Text\",\"handle\":\"richText\",\"sortOrder\":5,\"maxBlocks\":0,\"maxChildBlocks\":0,\"childBlocks\":\"\",\"topLevel\":false,\"fieldLayouts\":{\"0fed8306-9bb0-4eee-ab4d-dd06627187c0\":{\"tabs\":[{\"name\":\"Content\",\"sortOrder\":1,\"fields\":{\"7ce9ced9-3e8f-4bf2-9cd6-065b16567e6e\":{\"required\":true,\"sortOrder\":1}}},{\"name\":\"Settings\",\"sortOrder\":2,\"fields\":{\"3aad9545-9f94-41c9-b9f5-f11ef3d223fd\":{\"required\":false,\"sortOrder\":1},\"57f2498a-803a-4083-9433-9b937db415bc\":{\"required\":false,\"sortOrder\":3},\"9995c1a8-7fe7-4dc4-bac6-7a5a2547e5e2\":{\"required\":false,\"sortOrder\":2}}}]}}},\"223008a6-72c3-4da3-88ea-dbff940d585f\":{\"field\":\"90d4a327-9400-48d7-8bb4-18e710636c38\",\"name\":\"Form\",\"handle\":\"form\",\"sortOrder\":16,\"maxBlocks\":0,\"maxChildBlocks\":0,\"childBlocks\":\"\",\"topLevel\":true,\"fieldLayouts\":{\"b5ca9ee2-cf4d-47d2-b9eb-4e8f24388705\":{\"tabs\":[{\"name\":\"Content\",\"sortOrder\":1,\"fields\":{\"6286013d-8215-4661-87ba-5f4531648a0d\":{\"required\":false,\"sortOrder\":3},\"734d68d3-e878-4e03-8aa9-9feb0dd82fb1\":{\"required\":true,\"sortOrder\":1},\"9c399ba4-8fdb-47a1-9f2c-883a0c08c56f\":{\"required\":false,\"sortOrder\":2},\"c3651f55-968d-46a6-bde1-c32e6c4f635d\":{\"required\":false,\"sortOrder\":4}}}]}}},\"275f5285-cf76-4b51-9628-42ad3cfaac3a\":{\"field\":\"b8826224-f4da-4eca-95e1-b4e3acd1b2c3\",\"name\":\"Image\",\"handle\":\"image\",\"sortOrder\":10,\"maxBlocks\":0,\"maxChildBlocks\":0,\"childBlocks\":\"\",\"topLevel\":false,\"fieldLayouts\":{\"43423637-8002-4f69-a541-0989d36574a5\":{\"tabs\":[{\"name\":\"Content\",\"sortOrder\":1,\"fields\":{\"cf28ac9c-b373-4de1-8afb-0baa227165d1\":{\"required\":false,\"sortOrder\":2},\"f6eb14cb-2129-492c-b471-b6ea4179d905\":{\"required\":true,\"sortOrder\":1}}},{\"name\":\"Settings\",\"sortOrder\":2,\"fields\":{\"05beaa1f-418d-42f6-8972-ffcf1d3421e6\":{\"required\":false,\"sortOrder\":1},\"87a3aca4-9b17-41ab-a703-bba76a315981\":{\"required\":false,\"sortOrder\":2}}}]}}},\"297a303e-0622-4f04-a6eb-99a446d55741\":{\"field\":\"90d4a327-9400-48d7-8bb4-18e710636c38\",\"name\":\"Accordion\",\"handle\":\"accordion\",\"sortOrder\":14,\"maxBlocks\":0,\"maxChildBlocks\":0,\"childBlocks\":[\"pane\"],\"topLevel\":true,\"fieldLayouts\":{\"378d4adc-7624-43ad-a9fe-8eb642ceed9b\":{\"tabs\":[{\"name\":\"Content\",\"sortOrder\":1}]}}},\"2ae41271-4716-4de6-aedd-0b628627e3d5\":{\"field\":\"90d4a327-9400-48d7-8bb4-18e710636c38\",\"name\":\"Table\",\"handle\":\"table\",\"sortOrder\":5,\"maxBlocks\":0,\"maxChildBlocks\":0,\"childBlocks\":\"\",\"topLevel\":true,\"fieldLayouts\":{\"3792ad99-c503-4d19-8155-78ea4064ad06\":{\"tabs\":[{\"name\":\"Content\",\"sortOrder\":1,\"fields\":{\"3481333e-977a-4adb-90d5-fae5926ad8bb\":{\"required\":true,\"sortOrder\":1}}},{\"name\":\"Settings\",\"sortOrder\":2,\"fields\":{\"57f2498a-803a-4083-9433-9b937db415bc\":{\"required\":false,\"sortOrder\":1}}}]}}},\"2e04d107-0116-469f-9869-94e8041d98ab\":{\"field\":\"b8826224-f4da-4eca-95e1-b4e3acd1b2c3\",\"name\":\"Gallery\",\"handle\":\"gallery\",\"sortOrder\":12,\"maxBlocks\":0,\"maxChildBlocks\":0,\"childBlocks\":\"\",\"topLevel\":false,\"fieldLayouts\":{\"ef4c47d1-7dc7-49e8-9eae-eec68da8e8fd\":{\"tabs\":[{\"name\":\"Content\",\"sortOrder\":1,\"fields\":{\"2b68a629-7e92-49f4-bc66-ed66591dadd3\":{\"required\":true,\"sortOrder\":1}}},{\"name\":\"Settings\",\"sortOrder\":2,\"fields\":{\"87a3aca4-9b17-41ab-a703-bba76a315981\":{\"required\":false,\"sortOrder\":2},\"fea94669-6b2d-4306-850a-4fb9d696fcac\":{\"required\":false,\"sortOrder\":1}}}]}}},\"3f56f58d-e655-4368-9e90-0c4eeb3953cf\":{\"field\":\"b8826224-f4da-4eca-95e1-b4e3acd1b2c3\",\"name\":\"Button\",\"handle\":\"button\",\"sortOrder\":8,\"maxBlocks\":0,\"maxChildBlocks\":0,\"childBlocks\":\"\",\"topLevel\":false,\"fieldLayouts\":{\"a2749570-8f8d-4f97-a418-50bda0f93a3e\":{\"tabs\":[{\"name\":\"Content\",\"sortOrder\":1,\"fields\":{\"b7d09be9-9704-4d76-bf5a-6022ec9927c9\":{\"required\":true,\"sortOrder\":1}}},{\"name\":\"Settings\",\"sortOrder\":2,\"fields\":{\"57f2498a-803a-4083-9433-9b937db415bc\":{\"required\":false,\"sortOrder\":2},\"9995c1a8-7fe7-4dc4-bac6-7a5a2547e5e2\":{\"required\":false,\"sortOrder\":1}}}]}}},\"46d4d4ec-35e8-4ebe-9add-cb5b8bf8ef5a\":{\"field\":\"90d4a327-9400-48d7-8bb4-18e710636c38\",\"name\":\"Slide\",\"handle\":\"slide\",\"sortOrder\":19,\"maxBlocks\":0,\"maxChildBlocks\":0,\"childBlocks\":[\"heading\",\"richText\",\"button\"],\"topLevel\":false,\"fieldLayouts\":{\"695826e1-9905-45b1-93c0-4297531d3ee4\":{\"tabs\":[{\"name\":\"Content\",\"sortOrder\":1,\"fields\":{\"f6eb14cb-2129-492c-b471-b6ea4179d905\":{\"required\":true,\"sortOrder\":1}}}]}}},\"591fffc3-76a1-4991-8b96-7a97498e2f25\":{\"field\":\"b8826224-f4da-4eca-95e1-b4e3acd1b2c3\",\"name\":\"Tabs\",\"handle\":\"tabs\",\"sortOrder\":17,\"maxBlocks\":0,\"maxChildBlocks\":0,\"childBlocks\":[\"pane\"],\"topLevel\":false,\"fieldLayouts\":{\"ec49bda0-19d8-402b-a4da-457d363e5a37\":{\"tabs\":[{\"name\":\"Content\",\"sortOrder\":1}]}}},\"5b831b37-1f90-4657-bbbe-03a862990229\":{\"field\":\"90d4a327-9400-48d7-8bb4-18e710636c38\",\"name\":\"Map\",\"handle\":\"map\",\"sortOrder\":12,\"maxBlocks\":0,\"maxChildBlocks\":0,\"childBlocks\":\"\",\"topLevel\":true,\"fieldLayouts\":{\"5e72834c-8d84-40e9-add6-809f5cd48232\":{\"tabs\":[{\"name\":\"Content\",\"sortOrder\":1,\"fields\":{\"89aeb5c6-2010-4b63-8418-bb1cbc073dbe\":{\"required\":true,\"sortOrder\":1},\"cf28ac9c-b373-4de1-8afb-0baa227165d1\":{\"required\":false,\"sortOrder\":2}}},{\"name\":\"Settings\",\"sortOrder\":2,\"fields\":{\"05beaa1f-418d-42f6-8972-ffcf1d3421e6\":{\"required\":false,\"sortOrder\":1},\"87a3aca4-9b17-41ab-a703-bba76a315981\":{\"required\":false,\"sortOrder\":2}}}]}}},\"61448e4d-02c6-4118-86cf-3616ce629700\":{\"field\":\"b8826224-f4da-4eca-95e1-b4e3acd1b2c3\",\"name\":\"Quote\",\"handle\":\"quote\",\"sortOrder\":6,\"maxBlocks\":0,\"maxChildBlocks\":0,\"childBlocks\":\"\",\"topLevel\":false,\"fieldLayouts\":{\"bec33071-96ef-4a3e-873b-27092aa4cc76\":{\"tabs\":[{\"name\":\"Content\",\"sortOrder\":1,\"fields\":{\"2378559f-b7e8-4d0d-83a9-c90809389dc4\":{\"required\":false,\"sortOrder\":2},\"cdb2e12c-0fba-43fe-bfcc-643a14754ab9\":{\"required\":true,\"sortOrder\":1}}},{\"name\":\"Settings\",\"sortOrder\":2,\"fields\":{\"05beaa1f-418d-42f6-8972-ffcf1d3421e6\":{\"required\":false,\"sortOrder\":3},\"3aad9545-9f94-41c9-b9f5-f11ef3d223fd\":{\"required\":false,\"sortOrder\":1},\"57f2498a-803a-4083-9433-9b937db415bc\":{\"required\":false,\"sortOrder\":2}}}]}}},\"635ed81e-4066-48c5-8b30-e49cc19bba99\":{\"field\":\"b8826224-f4da-4eca-95e1-b4e3acd1b2c3\",\"name\":\"Slide\",\"handle\":\"slide\",\"sortOrder\":21,\"maxBlocks\":0,\"maxChildBlocks\":0,\"childBlocks\":[\"heading\",\"richText\",\"button\"],\"topLevel\":false,\"fieldLayouts\":{\"a95e5b43-5bbe-48be-86d3-0b898cffe674\":{\"tabs\":[{\"name\":\"Content\",\"sortOrder\":1,\"fields\":{\"f6eb14cb-2129-492c-b471-b6ea4179d905\":{\"required\":true,\"sortOrder\":1}}}]}}},\"6bc9a94c-b7ab-4f39-a463-11889c347e9f\":{\"field\":\"90d4a327-9400-48d7-8bb4-18e710636c38\",\"name\":\"Image\",\"handle\":\"image\",\"sortOrder\":8,\"maxBlocks\":0,\"maxChildBlocks\":0,\"childBlocks\":\"\",\"topLevel\":true,\"fieldLayouts\":{\"733d5f58-395a-4ab4-8995-243c997e88df\":{\"tabs\":[{\"name\":\"Content\",\"sortOrder\":1,\"fields\":{\"cf28ac9c-b373-4de1-8afb-0baa227165d1\":{\"required\":false,\"sortOrder\":2},\"f6eb14cb-2129-492c-b471-b6ea4179d905\":{\"required\":true,\"sortOrder\":1}}},{\"name\":\"Settings\",\"sortOrder\":2,\"fields\":{\"05beaa1f-418d-42f6-8972-ffcf1d3421e6\":{\"required\":false,\"sortOrder\":1},\"87a3aca4-9b17-41ab-a703-bba76a315981\":{\"required\":false,\"sortOrder\":2}}}]}}},\"6c69399f-55c0-4158-8b81-c5c70a4e2070\":{\"field\":\"b8826224-f4da-4eca-95e1-b4e3acd1b2c3\",\"name\":\"Row\",\"handle\":\"row\",\"sortOrder\":2,\"maxBlocks\":0,\"maxChildBlocks\":0,\"childBlocks\":[\"heading\",\"richText\",\"quote\",\"table\",\"button\",\"image\",\"video\",\"gallery\",\"slider\",\"map\",\"accordion\",\"tabs\",\"form\",\"code\"],\"topLevel\":true,\"fieldLayouts\":{\"95a8afe5-3088-4221-a5a2-72244c99eb2c\":{\"tabs\":[{\"name\":\"Content\",\"sortOrder\":1},{\"name\":\"Settings\",\"sortOrder\":2,\"fields\":{\"1a09a8f2-8bc2-42f9-afe4-ab7d17bc6bfc\":{\"required\":false,\"sortOrder\":2},\"8ed3608e-41ca-474f-bf29-b77c0b80931c\":{\"required\":false,\"sortOrder\":3},\"adfefe4f-d6ca-4d4e-82ef-22326f737fd6\":{\"required\":false,\"sortOrder\":1},\"f6eb14cb-2129-492c-b471-b6ea4179d905\":{\"required\":false,\"sortOrder\":4}}}]}}},\"81f43402-6e5a-4fcf-9303-d6da313f9d16\":{\"field\":\"90d4a327-9400-48d7-8bb4-18e710636c38\",\"name\":\"Button\",\"handle\":\"button\",\"sortOrder\":6,\"maxBlocks\":0,\"maxChildBlocks\":0,\"childBlocks\":\"\",\"topLevel\":true,\"fieldLayouts\":{\"1310cde0-91f6-4f3e-8a17-b1184ec78fb1\":{\"tabs\":[{\"name\":\"Content\",\"sortOrder\":1,\"fields\":{\"b7d09be9-9704-4d76-bf5a-6022ec9927c9\":{\"required\":true,\"sortOrder\":1}}},{\"name\":\"Settings\",\"sortOrder\":2,\"fields\":{\"57f2498a-803a-4083-9433-9b937db415bc\":{\"required\":false,\"sortOrder\":2},\"9995c1a8-7fe7-4dc4-bac6-7a5a2547e5e2\":{\"required\":false,\"sortOrder\":1}}}]}}},\"858e2949-7b9b-4237-be8d-a92986382819\":{\"field\":\"b8826224-f4da-4eca-95e1-b4e3acd1b2c3\",\"name\":\"Slideshow\",\"handle\":\"slider\",\"sortOrder\":13,\"maxBlocks\":0,\"maxChildBlocks\":0,\"childBlocks\":[\"slide\"],\"topLevel\":false,\"fieldLayouts\":{\"b1ab227c-a66c-4f43-a95e-95cecc1fe7b9\":{\"tabs\":[{\"name\":\"Content\",\"sortOrder\":1},{\"name\":\"Settings\",\"sortOrder\":2,\"fields\":{\"16b8848e-d06a-4c6b-b716-ee84349642d3\":{\"required\":false,\"sortOrder\":2},\"9c5a65fa-d228-42d3-9975-bf2ff8e37155\":{\"required\":false,\"sortOrder\":1}}}]}}},\"920d10dd-214c-47da-86c5-b9add6a3f156\":{\"field\":\"90d4a327-9400-48d7-8bb4-18e710636c38\",\"name\":\"Quote\",\"handle\":\"quote\",\"sortOrder\":4,\"maxBlocks\":0,\"maxChildBlocks\":0,\"childBlocks\":\"\",\"topLevel\":true,\"fieldLayouts\":{\"b9496a75-f916-45b5-8433-9c967e426fb4\":{\"tabs\":[{\"name\":\"Content\",\"sortOrder\":1,\"fields\":{\"2378559f-b7e8-4d0d-83a9-c90809389dc4\":{\"required\":false,\"sortOrder\":2},\"cdb2e12c-0fba-43fe-bfcc-643a14754ab9\":{\"required\":true,\"sortOrder\":1}}},{\"name\":\"Settings\",\"sortOrder\":2,\"fields\":{\"05beaa1f-418d-42f6-8972-ffcf1d3421e6\":{\"required\":false,\"sortOrder\":3},\"3aad9545-9f94-41c9-b9f5-f11ef3d223fd\":{\"required\":false,\"sortOrder\":1},\"57f2498a-803a-4083-9433-9b937db415bc\":{\"required\":false,\"sortOrder\":2}}}]}}},\"949ce8db-9505-4091-a701-45f00d0e3d7c\":{\"field\":\"b8826224-f4da-4eca-95e1-b4e3acd1b2c3\",\"name\":\"Map\",\"handle\":\"map\",\"sortOrder\":14,\"maxBlocks\":0,\"maxChildBlocks\":0,\"childBlocks\":\"\",\"topLevel\":false,\"fieldLayouts\":{\"3cb4d0c2-55cb-42ab-872a-6a554afaf976\":{\"tabs\":[{\"name\":\"Content\",\"sortOrder\":1,\"fields\":{\"89aeb5c6-2010-4b63-8418-bb1cbc073dbe\":{\"required\":true,\"sortOrder\":1},\"cf28ac9c-b373-4de1-8afb-0baa227165d1\":{\"required\":false,\"sortOrder\":2}}},{\"name\":\"Settings\",\"sortOrder\":2,\"fields\":{\"05beaa1f-418d-42f6-8972-ffcf1d3421e6\":{\"required\":false,\"sortOrder\":1},\"87a3aca4-9b17-41ab-a703-bba76a315981\":{\"required\":false,\"sortOrder\":2}}}]}}},\"a0ed8ff5-67c0-4d0f-8210-64e926259aff\":{\"field\":\"90d4a327-9400-48d7-8bb4-18e710636c38\",\"name\":\"Video\",\"handle\":\"video\",\"sortOrder\":9,\"maxBlocks\":0,\"maxChildBlocks\":0,\"childBlocks\":\"\",\"topLevel\":true,\"fieldLayouts\":{\"e2150a61-f963-432b-9fb5-55ba449195a8\":{\"tabs\":[{\"name\":\"Content\",\"sortOrder\":1,\"fields\":{\"39d33505-2395-4f4a-9798-27430aa67b22\":{\"required\":true,\"sortOrder\":1},\"cf28ac9c-b373-4de1-8afb-0baa227165d1\":{\"required\":false,\"sortOrder\":2}}},{\"name\":\"Settings\",\"sortOrder\":2,\"fields\":{\"05beaa1f-418d-42f6-8972-ffcf1d3421e6\":{\"required\":false,\"sortOrder\":1}}}]}}},\"a50191db-5cd1-430a-8b0d-6a7b8d34d179\":{\"field\":\"90d4a327-9400-48d7-8bb4-18e710636c38\",\"name\":\"Slideshow\",\"handle\":\"slider\",\"sortOrder\":11,\"maxBlocks\":0,\"maxChildBlocks\":0,\"childBlocks\":[\"slide\"],\"topLevel\":true,\"fieldLayouts\":{\"c7ad669c-d87b-4f13-bf55-b5a462172582\":{\"tabs\":[{\"name\":\"Content\",\"sortOrder\":1},{\"name\":\"Settings\",\"sortOrder\":2,\"fields\":{\"16b8848e-d06a-4c6b-b716-ee84349642d3\":{\"required\":false,\"sortOrder\":2},\"9c5a65fa-d228-42d3-9975-bf2ff8e37155\":{\"required\":false,\"sortOrder\":1}}}]}}},\"b43286a1-8bb8-4848-89af-972840193bcc\":{\"field\":\"b8826224-f4da-4eca-95e1-b4e3acd1b2c3\",\"name\":\"Heading\",\"handle\":\"heading\",\"sortOrder\":4,\"maxBlocks\":0,\"maxChildBlocks\":0,\"childBlocks\":\"\",\"topLevel\":false,\"fieldLayouts\":{\"9860e55a-4ad2-43df-baeb-2766b911051b\":{\"tabs\":[{\"name\":\"Content\",\"sortOrder\":1,\"fields\":{\"332bf96d-e927-4c21-bfbd-d8dd96087850\":{\"required\":true,\"sortOrder\":1}}},{\"name\":\"Settings\",\"sortOrder\":2,\"fields\":{\"3aad9545-9f94-41c9-b9f5-f11ef3d223fd\":{\"required\":false,\"sortOrder\":1},\"57f2498a-803a-4083-9433-9b937db415bc\":{\"required\":false,\"sortOrder\":3},\"9995c1a8-7fe7-4dc4-bac6-7a5a2547e5e2\":{\"required\":false,\"sortOrder\":2},\"bae81998-dbb4-433d-845e-416fc4ac4e18\":{\"required\":false,\"sortOrder\":4}}}]}}},\"b4f4527b-ece2-4d7f-b4ef-94a864420586\":{\"field\":\"b8826224-f4da-4eca-95e1-b4e3acd1b2c3\",\"name\":\"Table\",\"handle\":\"table\",\"sortOrder\":7,\"maxBlocks\":0,\"maxChildBlocks\":0,\"childBlocks\":\"\",\"topLevel\":false,\"fieldLayouts\":{\"1d566ede-cbd1-4597-812c-6c4a7ccc6265\":{\"tabs\":[{\"name\":\"Content\",\"sortOrder\":1,\"fields\":{\"3481333e-977a-4adb-90d5-fae5926ad8bb\":{\"required\":true,\"sortOrder\":1}}},{\"name\":\"Settings\",\"sortOrder\":2,\"fields\":{\"57f2498a-803a-4083-9433-9b937db415bc\":{\"required\":false,\"sortOrder\":1}}}]}}},\"bc849705-bd2b-40dc-9896-f59bfbf84330\":{\"field\":\"b8826224-f4da-4eca-95e1-b4e3acd1b2c3\",\"name\":\"Accordion\",\"handle\":\"accordion\",\"sortOrder\":16,\"maxBlocks\":0,\"maxChildBlocks\":0,\"childBlocks\":[\"pane\"],\"topLevel\":false,\"fieldLayouts\":{\"d6da7468-737b-4a4f-8b8c-291ff48d7565\":{\"tabs\":[{\"name\":\"Content\",\"sortOrder\":1}]}}},\"c610bfd8-be57-45e7-8a2f-b1ff62908a30\":{\"field\":\"90d4a327-9400-48d7-8bb4-18e710636c38\",\"name\":\"Rich Text\",\"handle\":\"richText\",\"sortOrder\":3,\"maxBlocks\":0,\"maxChildBlocks\":0,\"childBlocks\":\"\",\"topLevel\":true,\"fieldLayouts\":{\"2f04aa36-b292-4d42-acf1-3de3985f0038\":{\"tabs\":[{\"name\":\"Content\",\"sortOrder\":1,\"fields\":{\"7ce9ced9-3e8f-4bf2-9cd6-065b16567e6e\":{\"required\":true,\"sortOrder\":1}}},{\"name\":\"Settings\",\"sortOrder\":2,\"fields\":{\"3aad9545-9f94-41c9-b9f5-f11ef3d223fd\":{\"required\":false,\"sortOrder\":1},\"57f2498a-803a-4083-9433-9b937db415bc\":{\"required\":false,\"sortOrder\":3},\"9995c1a8-7fe7-4dc4-bac6-7a5a2547e5e2\":{\"required\":false,\"sortOrder\":2}}}]}}},\"cbf8bbd6-7f12-4e97-9a94-a0cba75b1301\":{\"field\":\"90d4a327-9400-48d7-8bb4-18e710636c38\",\"name\":\"Custom Code\",\"handle\":\"code\",\"sortOrder\":17,\"maxBlocks\":0,\"maxChildBlocks\":0,\"childBlocks\":\"\",\"topLevel\":true,\"fieldLayouts\":{\"d084d117-eb5c-472c-a3cb-e3011678cde4\":{\"tabs\":[{\"name\":\"Content\",\"sortOrder\":1,\"fields\":{\"11d456e9-f112-4213-9e12-5bbf5fc576a3\":{\"required\":true,\"sortOrder\":1}}}]}}},\"d4d369ff-cc8f-4c9b-9115-3830f1358c58\":{\"field\":\"90d4a327-9400-48d7-8bb4-18e710636c38\",\"name\":\"Tabs\",\"handle\":\"tabs\",\"sortOrder\":15,\"maxBlocks\":0,\"maxChildBlocks\":0,\"childBlocks\":[\"pane\"],\"topLevel\":true,\"fieldLayouts\":{\"50206415-30d5-48e6-9214-066d7088f14e\":{\"tabs\":[{\"name\":\"Content\",\"sortOrder\":1}]}}},\"e2a79140-d786-4a0d-9843-454c2650fe6f\":{\"field\":\"b8826224-f4da-4eca-95e1-b4e3acd1b2c3\",\"name\":\"Custom Code\",\"handle\":\"code\",\"sortOrder\":19,\"maxBlocks\":0,\"maxChildBlocks\":0,\"childBlocks\":\"\",\"topLevel\":false,\"fieldLayouts\":{\"f4acd46a-dc4d-472d-8eda-b2f936344cb7\":{\"tabs\":[{\"name\":\"Content\",\"sortOrder\":1,\"fields\":{\"11d456e9-f112-4213-9e12-5bbf5fc576a3\":{\"required\":true,\"sortOrder\":1}}}]}}},\"e399a90a-3a8a-4e9b-b7b2-3ddea6a68344\":{\"field\":\"b8826224-f4da-4eca-95e1-b4e3acd1b2c3\",\"name\":\"Form\",\"handle\":\"form\",\"sortOrder\":18,\"maxBlocks\":0,\"maxChildBlocks\":0,\"childBlocks\":\"\",\"topLevel\":false,\"fieldLayouts\":{\"c96dbb5c-2f37-4af1-b4af-8b91aaf5ab09\":{\"tabs\":[{\"name\":\"Content\",\"sortOrder\":1,\"fields\":{\"6286013d-8215-4661-87ba-5f4531648a0d\":{\"required\":false,\"sortOrder\":3},\"734d68d3-e878-4e03-8aa9-9feb0dd82fb1\":{\"required\":true,\"sortOrder\":1},\"9c399ba4-8fdb-47a1-9f2c-883a0c08c56f\":{\"required\":false,\"sortOrder\":2},\"c3651f55-968d-46a6-bde1-c32e6c4f635d\":{\"required\":false,\"sortOrder\":4}}}]}}},\"f3c4b0c9-5693-4c6e-a9c1-8f56d9a5d4bf\":{\"field\":\"b8826224-f4da-4eca-95e1-b4e3acd1b2c3\",\"name\":\"Video\",\"handle\":\"video\",\"sortOrder\":11,\"maxBlocks\":0,\"maxChildBlocks\":0,\"childBlocks\":\"\",\"topLevel\":false,\"fieldLayouts\":{\"dbc05a7f-85cb-4091-90a8-394e9de4035e\":{\"tabs\":[{\"name\":\"Content\",\"sortOrder\":1,\"fields\":{\"39d33505-2395-4f4a-9798-27430aa67b22\":{\"required\":true,\"sortOrder\":1},\"cf28ac9c-b373-4de1-8afb-0baa227165d1\":{\"required\":false,\"sortOrder\":2}}},{\"name\":\"Settings\",\"sortOrder\":2,\"fields\":{\"05beaa1f-418d-42f6-8972-ffcf1d3421e6\":{\"required\":false,\"sortOrder\":1}}}]}}}},\"plugins\":{\"twigpack\":{\"edition\":\"standard\",\"enabled\":true,\"schemaVersion\":\"1.0.0\"},\"navigation\":{\"edition\":\"standard\",\"enabled\":true,\"schemaVersion\":\"1.0.12\"},\"aws-s3\":{\"edition\":\"standard\",\"enabled\":true,\"schemaVersion\":\"1.2\"},\"embeddedassets\":{\"edition\":\"standard\",\"enabled\":true,\"schemaVersion\":\"1.0.0\"},\"fieldlabels\":{\"edition\":\"standard\",\"enabled\":true,\"schemaVersion\":\"1.1.2\"},\"freeform\":{\"edition\":\"lite\",\"enabled\":true,\"schemaVersion\":\"3.0.5\",\"settings\":{\"pluginName\":null,\"formTemplateDirectory\":null,\"emailTemplateDirectory\":null,\"emailTemplateStorage\":\"db\",\"defaultView\":\"dashboard\",\"fieldDisplayOrder\":\"name\",\"showTutorial\":\"1\",\"removeNewlines\":\"\",\"defaultTemplates\":\"1\",\"footerScripts\":false,\"scriptInsertLocation\":\"footer\",\"formSubmitDisable\":\"\",\"freeformHoneypot\":true,\"freeformHoneypotEnhancement\":false,\"customHoneypotName\":null,\"customErrorMessage\":null,\"formSubmitExpiration\":null,\"minimumSubmitTime\":null,\"spamProtectionBehaviour\":\"simulate_success\",\"submissionThrottlingCount\":null,\"submissionThrottlingTimeFrame\":null,\"blockedEmails\":null,\"blockedKeywords\":null,\"blockedKeywordsError\":\"Invalid Entry Data\",\"blockedEmailsError\":\"Invalid Email Address\",\"showErrorsForBlockedEmails\":false,\"showErrorsForBlockedKeywords\":false,\"blockedIpAddresses\":null,\"purgableSubmissionAgeInDays\":null,\"purgableSpamAgeInDays\":null,\"salesforce_client_id\":null,\"salesforce_client_secret\":null,\"salesforce_username\":null,\"salesforce_password\":null,\"spamFolderEnabled\":false,\"recaptchaEnabled\":false,\"recaptchaKey\":null,\"recaptchaSecret\":null,\"recaptchaType\":\"v2_checkbox\",\"recaptchaMinScore\":0.5,\"recaptchaBehaviour\":\"display_error\",\"renderFormHtmlInCpViews\":\"1\",\"ajaxByDefault\":\"1\",\"autoScrollToErrors\":\"1\",\"fillWithGet\":\"\",\"formattingTemplate\":\"flexbox.html\",\"hideBannerDemo\":\"1\",\"hideBannerOldFreeform\":false}},\"neo\":{\"edition\":\"standard\",\"enabled\":true,\"schemaVersion\":\"2.2.0\"},\"redactor\":{\"edition\":\"standard\",\"enabled\":true,\"schemaVersion\":\"2.3.0\"},\"seomatic\":{\"edition\":\"standard\",\"enabled\":true,\"schemaVersion\":\"3.0.8\",\"settings\":{\"pluginName\":\"SEO\",\"renderEnabled\":true,\"sitemapsEnabled\":true,\"regenerateSitemapsAutomatically\":true,\"headersEnabled\":true,\"environment\":\"live\",\"displayPreviewSidebar\":true,\"socialMediaPreviewTarget\":true,\"sidebarDisplayPreviewTypes\":[\"google\",\"twitter\",\"facebook\"],\"displayAnalysisSidebar\":true,\"devModeTitlePrefix\":\"&#x1f6a7; \",\"cpTitlePrefix\":\"⚙ \",\"devModeCpTitlePrefix\":\"&#x1f6a7;⚙ \",\"separatorChar\":\"|\",\"maxTitleLength\":70,\"maxDescriptionLength\":155,\"siteGroupsSeparate\":\"1\",\"addHrefLang\":true,\"addXDefaultHrefLang\":true,\"lowercaseCanonicalUrl\":\"1\",\"generatorEnabled\":true,\"siteUrlOverride\":\"\"}},\"supersort\":{\"edition\":\"standard\",\"enabled\":true,\"schemaVersion\":\"0.0.0.0\"},\"super-table\":{\"edition\":\"standard\",\"enabled\":true,\"schemaVersion\":\"2.2.1\"},\"tablemaker\":{\"edition\":\"standard\",\"enabled\":true,\"schemaVersion\":\"1.0.0\"},\"typogrify\":{\"edition\":\"standard\",\"enabled\":true,\"schemaVersion\":\"1.0.0\"},\"linkit\":{\"edition\":\"standard\",\"enabled\":true,\"schemaVersion\":\"1.0.8\"},\"simplemap\":{\"edition\":\"lite\",\"enabled\":true,\"schemaVersion\":\"3.4.2\"},\"video-embedder\":{\"edition\":\"standard\",\"enabled\":true,\"schemaVersion\":\"1.0.0\"},\"imager\":{\"edition\":\"standard\",\"enabled\":true,\"schemaVersion\":\"2.0.0\"},\"entriessubset\":{\"edition\":\"standard\",\"enabled\":true,\"schemaVersion\":\"1.1.1\"},\"classnames\":{\"edition\":\"standard\",\"enabled\":true,\"schemaVersion\":\"1.0.0\"}},\"sections\":{\"1e3c4cbe-0bc4-42ec-85db-1b75ad0e2492\":{\"name\":\"Homepage\",\"handle\":\"homepage\",\"type\":\"single\",\"enableVersioning\":true,\"propagationMethod\":\"all\",\"siteSettings\":{\"ab67a472-afac-4525-a8c9-08a909f0d281\":{\"enabledByDefault\":true,\"hasUrls\":true,\"uriFormat\":\"__home__\",\"template\":\"index\"}},\"entryTypes\":{\"5b2354fd-20ab-4d94-aa20-a1795f4f8f52\":{\"name\":\"Homepage\",\"handle\":\"homepage\",\"hasTitleField\":false,\"titleLabel\":\"\",\"titleFormat\":\"{section.name|raw}\",\"sortOrder\":1,\"fieldLayouts\":{\"1b8a3b09-15ab-4668-b7e7-a63fe6e15581\":{\"tabs\":[{\"name\":\"Content\",\"sortOrder\":1,\"fields\":{\"b8826224-f4da-4eca-95e1-b4e3acd1b2c3\":{\"required\":true,\"sortOrder\":1}}},{\"name\":\"SEO / Meta\",\"sortOrder\":2,\"fields\":{\"8eb75ebb-5efd-460a-b661-78a2e5c1929b\":{\"required\":false,\"sortOrder\":3},\"e3bfa017-1474-4fed-a176-88a42ff2e8c2\":{\"required\":false,\"sortOrder\":2},\"f6eb14cb-2129-492c-b471-b6ea4179d905\":{\"required\":false,\"sortOrder\":1}}}]}}}}},\"2e7aaa5a-bc25-4e9a-8efd-dd29ee0fcec2\":{\"name\":\"Pages\",\"handle\":\"pages\",\"type\":\"structure\",\"enableVersioning\":true,\"propagationMethod\":\"all\",\"siteSettings\":{\"ab67a472-afac-4525-a8c9-08a909f0d281\":{\"enabledByDefault\":true,\"hasUrls\":true,\"uriFormat\":\"{parent.uri}/{slug}\",\"template\":\"page/_type\"}},\"structure\":{\"uid\":\"a15327eb-2c4f-4f73-9be3-6c4b6e228b47\",\"maxLevels\":null},\"entryTypes\":{\"8ad5b5c9-bc0d-403b-b82d-1727493c2733\":{\"name\":\"News Page\",\"handle\":\"news\",\"hasTitleField\":true,\"titleLabel\":\"Title\",\"titleFormat\":\"\",\"sortOrder\":2,\"fieldLayouts\":{\"d70439e2-45b1-499f-86ad-3b14bab04dce\":{\"tabs\":[{\"name\":\"Content\",\"sortOrder\":1,\"fields\":{\"03b750b8-b69a-4bec-a1d1-cecf95c4b46d\":{\"required\":false,\"sortOrder\":4},\"80be1cb0-8f7d-4b68-907f-80dd8ed9d007\":{\"required\":false,\"sortOrder\":2},\"d7ccc6b6-5363-4117-92f8-aa87787aaaec\":{\"required\":false,\"sortOrder\":3},\"e02a1f1e-a3b6-4425-aa2b-04168abc924c\":{\"required\":false,\"sortOrder\":1}}},{\"name\":\"SEO / Meta\",\"sortOrder\":2,\"fields\":{\"8eb75ebb-5efd-460a-b661-78a2e5c1929b\":{\"required\":false,\"sortOrder\":3},\"e3bfa017-1474-4fed-a176-88a42ff2e8c2\":{\"required\":false,\"sortOrder\":2},\"f6eb14cb-2129-492c-b471-b6ea4179d905\":{\"required\":false,\"sortOrder\":1}}}]}}},\"9fc96015-4f93-4429-89ec-faefb125c13c\":{\"name\":\"General Page\",\"handle\":\"general\",\"hasTitleField\":true,\"titleLabel\":\"Title\",\"titleFormat\":\"\",\"sortOrder\":1,\"fieldLayouts\":{\"317b3dab-bb54-475d-8ae5-c739377cdc64\":{\"tabs\":[{\"name\":\"Content\",\"sortOrder\":1,\"fields\":{\"b8826224-f4da-4eca-95e1-b4e3acd1b2c3\":{\"required\":true,\"sortOrder\":2},\"e02a1f1e-a3b6-4425-aa2b-04168abc924c\":{\"required\":false,\"sortOrder\":1}}},{\"name\":\"SEO / Meta\",\"sortOrder\":2,\"fields\":{\"8eb75ebb-5efd-460a-b661-78a2e5c1929b\":{\"required\":false,\"sortOrder\":3},\"e3bfa017-1474-4fed-a176-88a42ff2e8c2\":{\"required\":false,\"sortOrder\":2},\"f6eb14cb-2129-492c-b471-b6ea4179d905\":{\"required\":false,\"sortOrder\":1}}}]}}}}},\"5994676d-ccf0-4430-a764-e4e059e1b605\":{\"name\":\"Page Not Found\",\"handle\":\"pageNotFound\",\"type\":\"single\",\"enableVersioning\":true,\"propagationMethod\":\"all\",\"siteSettings\":{\"ab67a472-afac-4525-a8c9-08a909f0d281\":{\"enabledByDefault\":true,\"hasUrls\":true,\"uriFormat\":\"page-not-found\",\"template\":\"404\"}},\"entryTypes\":{\"f2b12058-6b52-41b2-bc86-afdb464182a7\":{\"name\":\"Page Not Found\",\"handle\":\"pageNotFound\",\"hasTitleField\":false,\"titleLabel\":\"\",\"titleFormat\":\"{section.name|raw}\",\"sortOrder\":1,\"fieldLayouts\":{\"72bb2cd1-054d-4567-9375-f6b699409645\":{\"tabs\":[{\"name\":\"Content\",\"sortOrder\":1,\"fields\":{\"b8826224-f4da-4eca-95e1-b4e3acd1b2c3\":{\"required\":true,\"sortOrder\":1}}},{\"name\":\"SEO / Meta\",\"sortOrder\":2,\"fields\":{\"8eb75ebb-5efd-460a-b661-78a2e5c1929b\":{\"required\":false,\"sortOrder\":3},\"e3bfa017-1474-4fed-a176-88a42ff2e8c2\":{\"required\":false,\"sortOrder\":2},\"f6eb14cb-2129-492c-b471-b6ea4179d905\":{\"required\":false,\"sortOrder\":1}}}]}}}}},\"eef60044-7c15-4709-90ea-0c8035e7b0cd\":{\"name\":\"News\",\"handle\":\"news\",\"type\":\"channel\",\"enableVersioning\":true,\"propagationMethod\":\"all\",\"siteSettings\":{\"ab67a472-afac-4525-a8c9-08a909f0d281\":{\"enabledByDefault\":true,\"hasUrls\":true,\"uriFormat\":\"news/{slug}\",\"template\":\"news/_entry\"}},\"entryTypes\":{\"4a347537-3003-4554-9cca-b513286e6a4b\":{\"name\":\"Article\",\"handle\":\"article\",\"hasTitleField\":true,\"titleLabel\":\"Article Title\",\"titleFormat\":\"\",\"sortOrder\":1,\"fieldLayouts\":{\"b870c8ec-ef37-4abe-9b54-8a4f703b57b5\":{\"tabs\":[{\"name\":\"Content\",\"sortOrder\":1,\"fields\":{\"90d4a327-9400-48d7-8bb4-18e710636c38\":{\"required\":true,\"sortOrder\":2},\"d7ccc6b6-5363-4117-92f8-aa87787aaaec\":{\"required\":false,\"sortOrder\":3},\"e02a1f1e-a3b6-4425-aa2b-04168abc924c\":{\"required\":false,\"sortOrder\":1}}},{\"name\":\"SEO / Meta\",\"sortOrder\":2,\"fields\":{\"8eb75ebb-5efd-460a-b661-78a2e5c1929b\":{\"required\":false,\"sortOrder\":3},\"e3bfa017-1474-4fed-a176-88a42ff2e8c2\":{\"required\":false,\"sortOrder\":2},\"f6eb14cb-2129-492c-b471-b6ea4179d905\":{\"required\":false,\"sortOrder\":1}}}]}}}}}},\"siteGroups\":{\"88d38408-5360-4f46-b37c-026f929f9307\":{\"name\":\"Craft Vue Tailwind\"}},\"sites\":{\"ab67a472-afac-4525-a8c9-08a909f0d281\":{\"siteGroup\":\"88d38408-5360-4f46-b37c-026f929f9307\",\"name\":\"FWORK Plus\",\"handle\":\"default\",\"language\":\"en-US\",\"hasUrls\":true,\"baseUrl\":\"$DEFAULT_SITE_URL\",\"sortOrder\":1,\"primary\":true}},\"system\":{\"edition\":\"pro\",\"name\":\"FWORK Plus\",\"live\":true,\"schemaVersion\":\"3.3.3\",\"timeZone\":\"America/Los_Angeles\"},\"users\":{\"requireEmailVerification\":true,\"allowPublicRegistration\":false,\"defaultGroup\":null,\"photoVolumeUid\":null,\"photoSubpath\":\"\"},\"volumes\":{\"31bc6e28-f82b-4d59-8e21-a33325447c9d\":{\"name\":\"Local Images\",\"handle\":\"localImages\",\"type\":\"craft\\\\volumes\\\\Local\",\"hasUrls\":true,\"url\":\"@web/uploads/images\",\"settings\":{\"path\":\"@webroot/uploads/images\"},\"sortOrder\":1,\"fieldLayouts\":{\"35c91d56-3fdb-42e0-8cc9-b00e1fa6bb70\":{\"tabs\":[{\"name\":\"Content\",\"sortOrder\":1,\"fields\":{\"c2609bfd-fefa-4ef4-9677-4644e30ed7b2\":{\"required\":false,\"sortOrder\":1}}}]}}},\"b4623a75-4ffd-4637-bd4d-36ffbe88a935\":{\"name\":\"Local Files\",\"handle\":\"localFiles\",\"type\":\"craft\\\\volumes\\\\Local\",\"hasUrls\":true,\"url\":\"@web/uploads/files\",\"settings\":{\"path\":\"@webroot/uploads/files\"},\"sortOrder\":3},\"e1c0dfb7-b877-4184-8f8d-c8121e74c039\":{\"name\":\"Local Videos\",\"handle\":\"localVideos\",\"type\":\"craft\\\\volumes\\\\Local\",\"hasUrls\":true,\"url\":\"@web/uploads/videos\",\"settings\":{\"path\":\"@webroot/uploads/videos\"},\"sortOrder\":2,\"fieldLayouts\":{\"c6dbf030-8a39-4c50-8a65-6e9fa1e46a2e\":{\"tabs\":[{\"name\":\"Content\",\"sortOrder\":1,\"fields\":{\"c2609bfd-fefa-4ef4-9677-4644e30ed7b2\":{\"required\":false,\"sortOrder\":1},\"f6eb14cb-2129-492c-b471-b6ea4179d905\":{\"required\":false,\"sortOrder\":2}}}]}}}}}', '{\"dateModified\":\"@config/project.yaml\",\"email\":\"@config/project.yaml\",\"fieldGroups\":\"@config/project.yaml\",\"fieldlabels\":\"@config/project.yaml\",\"fields\":\"@config/project.yaml\",\"globalSets\":\"@config/project.yaml\",\"navigation\":\"@config/project.yaml\",\"neoBlockTypeGroups\":\"@config/project.yaml\",\"neoBlockTypes\":\"@config/project.yaml\",\"plugins\":\"@config/project.yaml\",\"sections\":\"@config/project.yaml\",\"siteGroups\":\"@config/project.yaml\",\"sites\":\"@config/project.yaml\",\"system\":\"@config/project.yaml\",\"users\":\"@config/project.yaml\",\"volumes\":\"@config/project.yaml\",\"categoryGroups\":\"@config/project.yaml\"}', 'UC3mTEj5VWTp', '2019-12-12 12:18:01', '2019-12-12 12:18:01', '8f098505-13b1-4e0f-bcad-b7fb6234e486');

INSERT INTO `maps` (`id`, `ownerId`, `ownerSiteId`, `fieldId`, `lat`, `lng`, `dateCreated`, `dateUpdated`, `uid`) VALUES ('1', '14', '2', '26', NULL, NULL, '2019-12-16 20:42:51', '2019-12-16 20:42:51', '99402ac2-bbd2-48cb-8ae4-cf458faea3ec');

INSERT INTO `migrations` (`id`, `pluginId`, `type`, `name`, `applyTime`, `dateCreated`, `dateUpdated`, `uid`) VALUES ('1', NULL, 'app', 'Install', '2019-12-12 12:18:02', '2019-12-12 12:18:02', '2019-12-12 12:18:02', 'f05661d4-11ee-4651-9723-99eddf257194');
INSERT INTO `migrations` (`id`, `pluginId`, `type`, `name`, `applyTime`, `dateCreated`, `dateUpdated`, `uid`) VALUES ('2', NULL, 'app', 'm150403_183908_migrations_table_changes', '2019-12-12 12:18:02', '2019-12-12 12:18:02', '2019-12-12 12:18:02', 'aaa6cb50-f844-497e-857a-9cf318dc964d');
INSERT INTO `migrations` (`id`, `pluginId`, `type`, `name`, `applyTime`, `dateCreated`, `dateUpdated`, `uid`) VALUES ('3', NULL, 'app', 'm150403_184247_plugins_table_changes', '2019-12-12 12:18:02', '2019-12-12 12:18:02', '2019-12-12 12:18:02', 'dd978a6f-91a7-4097-8bf6-992f4ce59802');
INSERT INTO `migrations` (`id`, `pluginId`, `type`, `name`, `applyTime`, `dateCreated`, `dateUpdated`, `uid`) VALUES ('4', NULL, 'app', 'm150403_184533_field_version', '2019-12-12 12:18:02', '2019-12-12 12:18:02', '2019-12-12 12:18:02', '3c92d22a-30b0-4f15-ab8e-076045f6c0ff');
INSERT INTO `migrations` (`id`, `pluginId`, `type`, `name`, `applyTime`, `dateCreated`, `dateUpdated`, `uid`) VALUES ('5', NULL, 'app', 'm150403_184729_type_columns', '2019-12-12 12:18:02', '2019-12-12 12:18:02', '2019-12-12 12:18:02', 'e4539442-f6b2-4e2d-b6b9-58cdfea07db7');
INSERT INTO `migrations` (`id`, `pluginId`, `type`, `name`, `applyTime`, `dateCreated`, `dateUpdated`, `uid`) VALUES ('6', NULL, 'app', 'm150403_185142_volumes', '2019-12-12 12:18:02', '2019-12-12 12:18:02', '2019-12-12 12:18:02', 'b2894ac0-eb57-4ab3-bba1-b04559ebad4b');
INSERT INTO `migrations` (`id`, `pluginId`, `type`, `name`, `applyTime`, `dateCreated`, `dateUpdated`, `uid`) VALUES ('7', NULL, 'app', 'm150428_231346_userpreferences', '2019-12-12 12:18:02', '2019-12-12 12:18:02', '2019-12-12 12:18:02', '52442035-d126-4c25-b947-d95a2a9bf7c1');
INSERT INTO `migrations` (`id`, `pluginId`, `type`, `name`, `applyTime`, `dateCreated`, `dateUpdated`, `uid`) VALUES ('8', NULL, 'app', 'm150519_150900_fieldversion_conversion', '2019-12-12 12:18:02', '2019-12-12 12:18:02', '2019-12-12 12:18:02', 'f52b6cd8-bb38-4980-b4a2-50677ef16612');
INSERT INTO `migrations` (`id`, `pluginId`, `type`, `name`, `applyTime`, `dateCreated`, `dateUpdated`, `uid`) VALUES ('9', NULL, 'app', 'm150617_213829_update_email_settings', '2019-12-12 12:18:02', '2019-12-12 12:18:02', '2019-12-12 12:18:02', '50806447-1558-4ecd-bad4-12aea8ddfce1');
INSERT INTO `migrations` (`id`, `pluginId`, `type`, `name`, `applyTime`, `dateCreated`, `dateUpdated`, `uid`) VALUES ('10', NULL, 'app', 'm150721_124739_templatecachequeries', '2019-12-12 12:18:02', '2019-12-12 12:18:02', '2019-12-12 12:18:02', '2059d2aa-3719-437e-a672-96ffefab0f2c');
INSERT INTO `migrations` (`id`, `pluginId`, `type`, `name`, `applyTime`, `dateCreated`, `dateUpdated`, `uid`) VALUES ('11', NULL, 'app', 'm150724_140822_adjust_quality_settings', '2019-12-12 12:18:02', '2019-12-12 12:18:02', '2019-12-12 12:18:02', 'e502115d-1df4-47c6-8790-e9617a1e1b50');
INSERT INTO `migrations` (`id`, `pluginId`, `type`, `name`, `applyTime`, `dateCreated`, `dateUpdated`, `uid`) VALUES ('12', NULL, 'app', 'm150815_133521_last_login_attempt_ip', '2019-12-12 12:18:02', '2019-12-12 12:18:02', '2019-12-12 12:18:02', '18f362d0-52b0-48cc-9e2d-a354c1e27d2b');
INSERT INTO `migrations` (`id`, `pluginId`, `type`, `name`, `applyTime`, `dateCreated`, `dateUpdated`, `uid`) VALUES ('13', NULL, 'app', 'm151002_095935_volume_cache_settings', '2019-12-12 12:18:02', '2019-12-12 12:18:02', '2019-12-12 12:18:02', 'c0f0aceb-61a5-4ef8-b2bf-4614a71ebdc4');
INSERT INTO `migrations` (`id`, `pluginId`, `type`, `name`, `applyTime`, `dateCreated`, `dateUpdated`, `uid`) VALUES ('14', NULL, 'app', 'm151005_142750_volume_s3_storage_settings', '2019-12-12 12:18:02', '2019-12-12 12:18:02', '2019-12-12 12:18:02', 'eb4eda9a-42e3-4b84-9b11-4b3a8c00cc33');
INSERT INTO `migrations` (`id`, `pluginId`, `type`, `name`, `applyTime`, `dateCreated`, `dateUpdated`, `uid`) VALUES ('15', NULL, 'app', 'm151016_133600_delete_asset_thumbnails', '2019-12-12 12:18:02', '2019-12-12 12:18:02', '2019-12-12 12:18:02', '4c09775b-3ad3-4526-92e6-71e0714f73b8');
INSERT INTO `migrations` (`id`, `pluginId`, `type`, `name`, `applyTime`, `dateCreated`, `dateUpdated`, `uid`) VALUES ('16', NULL, 'app', 'm151209_000000_move_logo', '2019-12-12 12:18:02', '2019-12-12 12:18:02', '2019-12-12 12:18:02', '08aad735-f84b-48f1-b26a-16dce994b27e');
INSERT INTO `migrations` (`id`, `pluginId`, `type`, `name`, `applyTime`, `dateCreated`, `dateUpdated`, `uid`) VALUES ('17', NULL, 'app', 'm151211_000000_rename_fileId_to_assetId', '2019-12-12 12:18:02', '2019-12-12 12:18:02', '2019-12-12 12:18:02', 'a0f8976e-1148-445b-8f4d-b17c3afa8e2a');
INSERT INTO `migrations` (`id`, `pluginId`, `type`, `name`, `applyTime`, `dateCreated`, `dateUpdated`, `uid`) VALUES ('18', NULL, 'app', 'm151215_000000_rename_asset_permissions', '2019-12-12 12:18:02', '2019-12-12 12:18:02', '2019-12-12 12:18:02', 'e0af9b43-6cb0-42c5-87af-7948e3ae0ceb');
INSERT INTO `migrations` (`id`, `pluginId`, `type`, `name`, `applyTime`, `dateCreated`, `dateUpdated`, `uid`) VALUES ('19', NULL, 'app', 'm160707_000001_rename_richtext_assetsource_setting', '2019-12-12 12:18:02', '2019-12-12 12:18:02', '2019-12-12 12:18:02', '0b6f6711-fcfb-40ad-833e-f4377af93629');
INSERT INTO `migrations` (`id`, `pluginId`, `type`, `name`, `applyTime`, `dateCreated`, `dateUpdated`, `uid`) VALUES ('20', NULL, 'app', 'm160708_185142_volume_hasUrls_setting', '2019-12-12 12:18:02', '2019-12-12 12:18:02', '2019-12-12 12:18:02', '210c52b5-957c-427a-ad77-9d1df0fbe9bd');
INSERT INTO `migrations` (`id`, `pluginId`, `type`, `name`, `applyTime`, `dateCreated`, `dateUpdated`, `uid`) VALUES ('21', NULL, 'app', 'm160714_000000_increase_max_asset_filesize', '2019-12-12 12:18:02', '2019-12-12 12:18:02', '2019-12-12 12:18:02', '28676fc4-5a43-408b-9d40-057a68835b98');
INSERT INTO `migrations` (`id`, `pluginId`, `type`, `name`, `applyTime`, `dateCreated`, `dateUpdated`, `uid`) VALUES ('22', NULL, 'app', 'm160727_194637_column_cleanup', '2019-12-12 12:18:02', '2019-12-12 12:18:02', '2019-12-12 12:18:02', 'c215417f-5046-4695-b583-3328c5b709a3');
INSERT INTO `migrations` (`id`, `pluginId`, `type`, `name`, `applyTime`, `dateCreated`, `dateUpdated`, `uid`) VALUES ('23', NULL, 'app', 'm160804_110002_userphotos_to_assets', '2019-12-12 12:18:02', '2019-12-12 12:18:02', '2019-12-12 12:18:02', 'ad340b71-13b6-458b-bf45-912eb82eba98');
INSERT INTO `migrations` (`id`, `pluginId`, `type`, `name`, `applyTime`, `dateCreated`, `dateUpdated`, `uid`) VALUES ('24', NULL, 'app', 'm160807_144858_sites', '2019-12-12 12:18:02', '2019-12-12 12:18:02', '2019-12-12 12:18:02', 'f18c8a15-ce3a-40c3-9903-01c34e0b18eb');
INSERT INTO `migrations` (`id`, `pluginId`, `type`, `name`, `applyTime`, `dateCreated`, `dateUpdated`, `uid`) VALUES ('25', NULL, 'app', 'm160829_000000_pending_user_content_cleanup', '2019-12-12 12:18:02', '2019-12-12 12:18:02', '2019-12-12 12:18:02', '9fa42e01-7929-49ec-aa68-43659bda1dab');
INSERT INTO `migrations` (`id`, `pluginId`, `type`, `name`, `applyTime`, `dateCreated`, `dateUpdated`, `uid`) VALUES ('26', NULL, 'app', 'm160830_000000_asset_index_uri_increase', '2019-12-12 12:18:02', '2019-12-12 12:18:02', '2019-12-12 12:18:02', 'fcca1755-2659-4f7c-b419-cfe10871b1f2');
INSERT INTO `migrations` (`id`, `pluginId`, `type`, `name`, `applyTime`, `dateCreated`, `dateUpdated`, `uid`) VALUES ('27', NULL, 'app', 'm160912_230520_require_entry_type_id', '2019-12-12 12:18:02', '2019-12-12 12:18:02', '2019-12-12 12:18:02', 'e9d056a2-9506-426b-9941-f8d98432d0bc');
INSERT INTO `migrations` (`id`, `pluginId`, `type`, `name`, `applyTime`, `dateCreated`, `dateUpdated`, `uid`) VALUES ('28', NULL, 'app', 'm160913_134730_require_matrix_block_type_id', '2019-12-12 12:18:02', '2019-12-12 12:18:02', '2019-12-12 12:18:02', 'f28b85d3-2466-4a81-bb7e-d66ef2b98b29');
INSERT INTO `migrations` (`id`, `pluginId`, `type`, `name`, `applyTime`, `dateCreated`, `dateUpdated`, `uid`) VALUES ('29', NULL, 'app', 'm160920_174553_matrixblocks_owner_site_id_nullable', '2019-12-12 12:18:02', '2019-12-12 12:18:02', '2019-12-12 12:18:02', '35a4dcbf-5b0a-44c0-ad82-bf178d52a5fb');
INSERT INTO `migrations` (`id`, `pluginId`, `type`, `name`, `applyTime`, `dateCreated`, `dateUpdated`, `uid`) VALUES ('30', NULL, 'app', 'm160920_231045_usergroup_handle_title_unique', '2019-12-12 12:18:02', '2019-12-12 12:18:02', '2019-12-12 12:18:02', 'ca51852e-08de-49d8-be6b-5d3c6289f1fa');
INSERT INTO `migrations` (`id`, `pluginId`, `type`, `name`, `applyTime`, `dateCreated`, `dateUpdated`, `uid`) VALUES ('31', NULL, 'app', 'm160925_113941_route_uri_parts', '2019-12-12 12:18:02', '2019-12-12 12:18:02', '2019-12-12 12:18:02', '9cf16598-e2c2-4b81-a8e6-d42777885cfd');
INSERT INTO `migrations` (`id`, `pluginId`, `type`, `name`, `applyTime`, `dateCreated`, `dateUpdated`, `uid`) VALUES ('32', NULL, 'app', 'm161006_205918_schemaVersion_not_null', '2019-12-12 12:18:02', '2019-12-12 12:18:02', '2019-12-12 12:18:02', '17775412-b0d7-4fa3-b62c-b4c0911e671f');
INSERT INTO `migrations` (`id`, `pluginId`, `type`, `name`, `applyTime`, `dateCreated`, `dateUpdated`, `uid`) VALUES ('33', NULL, 'app', 'm161007_130653_update_email_settings', '2019-12-12 12:18:02', '2019-12-12 12:18:02', '2019-12-12 12:18:02', 'c2df8ff9-1653-4d54-8338-20e5bc97d3dc');
INSERT INTO `migrations` (`id`, `pluginId`, `type`, `name`, `applyTime`, `dateCreated`, `dateUpdated`, `uid`) VALUES ('34', NULL, 'app', 'm161013_175052_newParentId', '2019-12-12 12:18:02', '2019-12-12 12:18:02', '2019-12-12 12:18:02', '91d26303-27e2-4791-b414-be2a2c1df17b');
INSERT INTO `migrations` (`id`, `pluginId`, `type`, `name`, `applyTime`, `dateCreated`, `dateUpdated`, `uid`) VALUES ('35', NULL, 'app', 'm161021_102916_fix_recent_entries_widgets', '2019-12-12 12:18:02', '2019-12-12 12:18:02', '2019-12-12 12:18:02', 'f01e7d0c-1c9c-468b-98a4-57981ade6483');
INSERT INTO `migrations` (`id`, `pluginId`, `type`, `name`, `applyTime`, `dateCreated`, `dateUpdated`, `uid`) VALUES ('36', NULL, 'app', 'm161021_182140_rename_get_help_widget', '2019-12-12 12:18:02', '2019-12-12 12:18:02', '2019-12-12 12:18:02', '4af756c3-87f7-4773-87b8-55e84ebdedb7');
INSERT INTO `migrations` (`id`, `pluginId`, `type`, `name`, `applyTime`, `dateCreated`, `dateUpdated`, `uid`) VALUES ('37', NULL, 'app', 'm161025_000000_fix_char_columns', '2019-12-12 12:18:02', '2019-12-12 12:18:02', '2019-12-12 12:18:02', '3f0b7efc-cf46-41ff-a2ea-aa727a4f5fc2');
INSERT INTO `migrations` (`id`, `pluginId`, `type`, `name`, `applyTime`, `dateCreated`, `dateUpdated`, `uid`) VALUES ('38', NULL, 'app', 'm161029_124145_email_message_languages', '2019-12-12 12:18:02', '2019-12-12 12:18:02', '2019-12-12 12:18:02', '9f0eeab6-1ae1-458b-9199-2e838da6f1f5');
INSERT INTO `migrations` (`id`, `pluginId`, `type`, `name`, `applyTime`, `dateCreated`, `dateUpdated`, `uid`) VALUES ('39', NULL, 'app', 'm161108_000000_new_version_format', '2019-12-12 12:18:02', '2019-12-12 12:18:02', '2019-12-12 12:18:02', '6376922b-318f-4e71-8a20-4902a7b4a45a');
INSERT INTO `migrations` (`id`, `pluginId`, `type`, `name`, `applyTime`, `dateCreated`, `dateUpdated`, `uid`) VALUES ('40', NULL, 'app', 'm161109_000000_index_shuffle', '2019-12-12 12:18:02', '2019-12-12 12:18:02', '2019-12-12 12:18:02', 'af8891ec-cd20-4881-a3c8-606e45673c38');
INSERT INTO `migrations` (`id`, `pluginId`, `type`, `name`, `applyTime`, `dateCreated`, `dateUpdated`, `uid`) VALUES ('41', NULL, 'app', 'm161122_185500_no_craft_app', '2019-12-12 12:18:02', '2019-12-12 12:18:02', '2019-12-12 12:18:02', '352d29fd-3201-4af3-8e77-c4a04848f17c');
INSERT INTO `migrations` (`id`, `pluginId`, `type`, `name`, `applyTime`, `dateCreated`, `dateUpdated`, `uid`) VALUES ('42', NULL, 'app', 'm161125_150752_clear_urlmanager_cache', '2019-12-12 12:18:02', '2019-12-12 12:18:02', '2019-12-12 12:18:02', 'a664c10b-1a9b-4651-ae7f-3b118efe467c');
INSERT INTO `migrations` (`id`, `pluginId`, `type`, `name`, `applyTime`, `dateCreated`, `dateUpdated`, `uid`) VALUES ('43', NULL, 'app', 'm161220_000000_volumes_hasurl_notnull', '2019-12-12 12:18:02', '2019-12-12 12:18:02', '2019-12-12 12:18:02', '055b20bc-d180-4893-8270-dc18329e8e92');
INSERT INTO `migrations` (`id`, `pluginId`, `type`, `name`, `applyTime`, `dateCreated`, `dateUpdated`, `uid`) VALUES ('44', NULL, 'app', 'm170114_161144_udates_permission', '2019-12-12 12:18:02', '2019-12-12 12:18:02', '2019-12-12 12:18:02', '91dbfe3d-f633-4572-bb70-996f179f7bf5');
INSERT INTO `migrations` (`id`, `pluginId`, `type`, `name`, `applyTime`, `dateCreated`, `dateUpdated`, `uid`) VALUES ('45', NULL, 'app', 'm170120_000000_schema_cleanup', '2019-12-12 12:18:02', '2019-12-12 12:18:02', '2019-12-12 12:18:02', '60fa5f7d-4835-4098-a60d-f0a508da87ec');
INSERT INTO `migrations` (`id`, `pluginId`, `type`, `name`, `applyTime`, `dateCreated`, `dateUpdated`, `uid`) VALUES ('46', NULL, 'app', 'm170126_000000_assets_focal_point', '2019-12-12 12:18:02', '2019-12-12 12:18:02', '2019-12-12 12:18:02', '186d2163-12e0-4f48-8657-9e17cde27309');
INSERT INTO `migrations` (`id`, `pluginId`, `type`, `name`, `applyTime`, `dateCreated`, `dateUpdated`, `uid`) VALUES ('47', NULL, 'app', 'm170206_142126_system_name', '2019-12-12 12:18:02', '2019-12-12 12:18:02', '2019-12-12 12:18:02', '36c7fc91-0be6-4d24-b057-9b603bcf23d2');
INSERT INTO `migrations` (`id`, `pluginId`, `type`, `name`, `applyTime`, `dateCreated`, `dateUpdated`, `uid`) VALUES ('48', NULL, 'app', 'm170217_044740_category_branch_limits', '2019-12-12 12:18:02', '2019-12-12 12:18:02', '2019-12-12 12:18:02', 'e98e9b47-6197-4d53-a2f0-673c11251ad0');
INSERT INTO `migrations` (`id`, `pluginId`, `type`, `name`, `applyTime`, `dateCreated`, `dateUpdated`, `uid`) VALUES ('49', NULL, 'app', 'm170217_120224_asset_indexing_columns', '2019-12-12 12:18:02', '2019-12-12 12:18:02', '2019-12-12 12:18:02', 'ef537e09-8b6c-4beb-b6f5-b2306471987a');
INSERT INTO `migrations` (`id`, `pluginId`, `type`, `name`, `applyTime`, `dateCreated`, `dateUpdated`, `uid`) VALUES ('50', NULL, 'app', 'm170223_224012_plain_text_settings', '2019-12-12 12:18:02', '2019-12-12 12:18:02', '2019-12-12 12:18:02', '762afc5a-228a-426d-bead-b2714251babc');
INSERT INTO `migrations` (`id`, `pluginId`, `type`, `name`, `applyTime`, `dateCreated`, `dateUpdated`, `uid`) VALUES ('51', NULL, 'app', 'm170227_120814_focal_point_percentage', '2019-12-12 12:18:02', '2019-12-12 12:18:02', '2019-12-12 12:18:02', 'ac15d79a-3c73-4238-8992-b734b5396c2d');
INSERT INTO `migrations` (`id`, `pluginId`, `type`, `name`, `applyTime`, `dateCreated`, `dateUpdated`, `uid`) VALUES ('52', NULL, 'app', 'm170228_171113_system_messages', '2019-12-12 12:18:02', '2019-12-12 12:18:02', '2019-12-12 12:18:02', '3dd29bb4-83bf-4f14-9e7c-fe173a3f5ae4');
INSERT INTO `migrations` (`id`, `pluginId`, `type`, `name`, `applyTime`, `dateCreated`, `dateUpdated`, `uid`) VALUES ('53', NULL, 'app', 'm170303_140500_asset_field_source_settings', '2019-12-12 12:18:02', '2019-12-12 12:18:02', '2019-12-12 12:18:02', '51e4ff18-f73d-4803-903c-22559442949d');
INSERT INTO `migrations` (`id`, `pluginId`, `type`, `name`, `applyTime`, `dateCreated`, `dateUpdated`, `uid`) VALUES ('54', NULL, 'app', 'm170306_150500_asset_temporary_uploads', '2019-12-12 12:18:02', '2019-12-12 12:18:02', '2019-12-12 12:18:02', '536f593a-c7ed-4ce2-a6ed-8c0be2a0f78d');
INSERT INTO `migrations` (`id`, `pluginId`, `type`, `name`, `applyTime`, `dateCreated`, `dateUpdated`, `uid`) VALUES ('55', NULL, 'app', 'm170523_190652_element_field_layout_ids', '2019-12-12 12:18:02', '2019-12-12 12:18:02', '2019-12-12 12:18:02', '4bf695e6-bd18-40d6-ae16-6c36036e71da');
INSERT INTO `migrations` (`id`, `pluginId`, `type`, `name`, `applyTime`, `dateCreated`, `dateUpdated`, `uid`) VALUES ('56', NULL, 'app', 'm170612_000000_route_index_shuffle', '2019-12-12 12:18:02', '2019-12-12 12:18:02', '2019-12-12 12:18:02', '116bd120-4398-4a9a-9822-e59978db98fc');
INSERT INTO `migrations` (`id`, `pluginId`, `type`, `name`, `applyTime`, `dateCreated`, `dateUpdated`, `uid`) VALUES ('57', NULL, 'app', 'm170621_195237_format_plugin_handles', '2019-12-12 12:18:02', '2019-12-12 12:18:02', '2019-12-12 12:18:02', 'ef8bbc56-2af5-470c-bce7-b55a4c67d533');
INSERT INTO `migrations` (`id`, `pluginId`, `type`, `name`, `applyTime`, `dateCreated`, `dateUpdated`, `uid`) VALUES ('58', NULL, 'app', 'm170630_161027_deprecation_line_nullable', '2019-12-12 12:18:02', '2019-12-12 12:18:02', '2019-12-12 12:18:02', '25dcf978-4589-4f00-8f2d-d6b153ca72a3');
INSERT INTO `migrations` (`id`, `pluginId`, `type`, `name`, `applyTime`, `dateCreated`, `dateUpdated`, `uid`) VALUES ('59', NULL, 'app', 'm170630_161028_deprecation_changes', '2019-12-12 12:18:02', '2019-12-12 12:18:02', '2019-12-12 12:18:02', '1b9cbdd5-4c48-4116-a2fd-db444b98a015');
INSERT INTO `migrations` (`id`, `pluginId`, `type`, `name`, `applyTime`, `dateCreated`, `dateUpdated`, `uid`) VALUES ('60', NULL, 'app', 'm170703_181539_plugins_table_tweaks', '2019-12-12 12:18:02', '2019-12-12 12:18:02', '2019-12-12 12:18:02', 'c4b582ab-38f9-4cbc-b6eb-226497884fcf');
INSERT INTO `migrations` (`id`, `pluginId`, `type`, `name`, `applyTime`, `dateCreated`, `dateUpdated`, `uid`) VALUES ('61', NULL, 'app', 'm170704_134916_sites_tables', '2019-12-12 12:18:02', '2019-12-12 12:18:02', '2019-12-12 12:18:02', '9e0772d1-97b0-4ef7-a9b4-5816628aaf09');
INSERT INTO `migrations` (`id`, `pluginId`, `type`, `name`, `applyTime`, `dateCreated`, `dateUpdated`, `uid`) VALUES ('62', NULL, 'app', 'm170706_183216_rename_sequences', '2019-12-12 12:18:02', '2019-12-12 12:18:02', '2019-12-12 12:18:02', '3eddf512-2974-49ba-836f-c8d8f97cc19c');
INSERT INTO `migrations` (`id`, `pluginId`, `type`, `name`, `applyTime`, `dateCreated`, `dateUpdated`, `uid`) VALUES ('63', NULL, 'app', 'm170707_094758_delete_compiled_traits', '2019-12-12 12:18:02', '2019-12-12 12:18:02', '2019-12-12 12:18:02', 'f0710297-92ce-426f-ac05-50f1bfb62e6a');
INSERT INTO `migrations` (`id`, `pluginId`, `type`, `name`, `applyTime`, `dateCreated`, `dateUpdated`, `uid`) VALUES ('64', NULL, 'app', 'm170731_190138_drop_asset_packagist', '2019-12-12 12:18:02', '2019-12-12 12:18:02', '2019-12-12 12:18:02', '48e0179f-f489-4aab-9d82-01c391e43931');
INSERT INTO `migrations` (`id`, `pluginId`, `type`, `name`, `applyTime`, `dateCreated`, `dateUpdated`, `uid`) VALUES ('65', NULL, 'app', 'm170810_201318_create_queue_table', '2019-12-12 12:18:02', '2019-12-12 12:18:02', '2019-12-12 12:18:02', '7a8ecce5-d2c9-45e6-8718-1ebd449c3500');
INSERT INTO `migrations` (`id`, `pluginId`, `type`, `name`, `applyTime`, `dateCreated`, `dateUpdated`, `uid`) VALUES ('66', NULL, 'app', 'm170816_133741_delete_compiled_behaviors', '2019-12-12 12:18:02', '2019-12-12 12:18:02', '2019-12-12 12:18:02', '7df5dde4-a455-41ed-9e41-2afd6ab467d8');
INSERT INTO `migrations` (`id`, `pluginId`, `type`, `name`, `applyTime`, `dateCreated`, `dateUpdated`, `uid`) VALUES ('67', NULL, 'app', 'm170903_192801_longblob_for_queue_jobs', '2019-12-12 12:18:02', '2019-12-12 12:18:02', '2019-12-12 12:18:02', 'ad04979f-d177-4943-87e8-aa0c28f6446a');
INSERT INTO `migrations` (`id`, `pluginId`, `type`, `name`, `applyTime`, `dateCreated`, `dateUpdated`, `uid`) VALUES ('68', NULL, 'app', 'm170914_204621_asset_cache_shuffle', '2019-12-12 12:18:02', '2019-12-12 12:18:02', '2019-12-12 12:18:02', '503f22b7-74a7-43eb-a2e4-8af4ae6c3f67');
INSERT INTO `migrations` (`id`, `pluginId`, `type`, `name`, `applyTime`, `dateCreated`, `dateUpdated`, `uid`) VALUES ('69', NULL, 'app', 'm171011_214115_site_groups', '2019-12-12 12:18:02', '2019-12-12 12:18:02', '2019-12-12 12:18:02', 'f80eae09-9058-4de7-83db-dd6ffb0c67a4');
INSERT INTO `migrations` (`id`, `pluginId`, `type`, `name`, `applyTime`, `dateCreated`, `dateUpdated`, `uid`) VALUES ('70', NULL, 'app', 'm171012_151440_primary_site', '2019-12-12 12:18:02', '2019-12-12 12:18:02', '2019-12-12 12:18:02', '596974ba-3b79-4120-8838-15882c3f4c27');
INSERT INTO `migrations` (`id`, `pluginId`, `type`, `name`, `applyTime`, `dateCreated`, `dateUpdated`, `uid`) VALUES ('71', NULL, 'app', 'm171013_142500_transform_interlace', '2019-12-12 12:18:02', '2019-12-12 12:18:02', '2019-12-12 12:18:02', '35c9178e-879c-472a-bd97-0960e2897f71');
INSERT INTO `migrations` (`id`, `pluginId`, `type`, `name`, `applyTime`, `dateCreated`, `dateUpdated`, `uid`) VALUES ('72', NULL, 'app', 'm171016_092553_drop_position_select', '2019-12-12 12:18:02', '2019-12-12 12:18:02', '2019-12-12 12:18:02', '5c78489e-11c3-4047-80fc-072bf2217fdf');
INSERT INTO `migrations` (`id`, `pluginId`, `type`, `name`, `applyTime`, `dateCreated`, `dateUpdated`, `uid`) VALUES ('73', NULL, 'app', 'm171016_221244_less_strict_translation_method', '2019-12-12 12:18:02', '2019-12-12 12:18:02', '2019-12-12 12:18:02', '4e98b675-859b-4b66-bf56-ab199ae8a24e');
INSERT INTO `migrations` (`id`, `pluginId`, `type`, `name`, `applyTime`, `dateCreated`, `dateUpdated`, `uid`) VALUES ('74', NULL, 'app', 'm171107_000000_assign_group_permissions', '2019-12-12 12:18:02', '2019-12-12 12:18:02', '2019-12-12 12:18:02', '81b7cd27-b05b-45f6-8cca-80b35346947f');
INSERT INTO `migrations` (`id`, `pluginId`, `type`, `name`, `applyTime`, `dateCreated`, `dateUpdated`, `uid`) VALUES ('75', NULL, 'app', 'm171117_000001_templatecache_index_tune', '2019-12-12 12:18:02', '2019-12-12 12:18:02', '2019-12-12 12:18:02', '0e000f59-36f9-4f08-a5ce-edd4cf647983');
INSERT INTO `migrations` (`id`, `pluginId`, `type`, `name`, `applyTime`, `dateCreated`, `dateUpdated`, `uid`) VALUES ('76', NULL, 'app', 'm171126_105927_disabled_plugins', '2019-12-12 12:18:02', '2019-12-12 12:18:02', '2019-12-12 12:18:02', '39de2e14-324e-40dd-bd1a-a649629b9444');
INSERT INTO `migrations` (`id`, `pluginId`, `type`, `name`, `applyTime`, `dateCreated`, `dateUpdated`, `uid`) VALUES ('77', NULL, 'app', 'm171130_214407_craftidtokens_table', '2019-12-12 12:18:02', '2019-12-12 12:18:02', '2019-12-12 12:18:02', '4a2107b4-f1cc-4e57-b564-5b5bb2b49d05');
INSERT INTO `migrations` (`id`, `pluginId`, `type`, `name`, `applyTime`, `dateCreated`, `dateUpdated`, `uid`) VALUES ('78', NULL, 'app', 'm171202_004225_update_email_settings', '2019-12-12 12:18:02', '2019-12-12 12:18:02', '2019-12-12 12:18:02', 'f3ee2cef-be66-4899-855f-f00117eb3d44');
INSERT INTO `migrations` (`id`, `pluginId`, `type`, `name`, `applyTime`, `dateCreated`, `dateUpdated`, `uid`) VALUES ('79', NULL, 'app', 'm171204_000001_templatecache_index_tune_deux', '2019-12-12 12:18:02', '2019-12-12 12:18:02', '2019-12-12 12:18:02', 'cd230256-7021-4735-944e-f37b6e0cae22');
INSERT INTO `migrations` (`id`, `pluginId`, `type`, `name`, `applyTime`, `dateCreated`, `dateUpdated`, `uid`) VALUES ('80', NULL, 'app', 'm171205_130908_remove_craftidtokens_refreshtoken_column', '2019-12-12 12:18:02', '2019-12-12 12:18:02', '2019-12-12 12:18:02', 'f27923cb-4c97-4ed6-96fd-c0af3cca6d1c');
INSERT INTO `migrations` (`id`, `pluginId`, `type`, `name`, `applyTime`, `dateCreated`, `dateUpdated`, `uid`) VALUES ('81', NULL, 'app', 'm171218_143135_longtext_query_column', '2019-12-12 12:18:02', '2019-12-12 12:18:02', '2019-12-12 12:18:02', 'b834055c-7d50-47c4-af8e-b5a8722c0666');
INSERT INTO `migrations` (`id`, `pluginId`, `type`, `name`, `applyTime`, `dateCreated`, `dateUpdated`, `uid`) VALUES ('82', NULL, 'app', 'm171231_055546_environment_variables_to_aliases', '2019-12-12 12:18:02', '2019-12-12 12:18:02', '2019-12-12 12:18:02', 'de011826-758c-4fc6-8ddb-49c99c990097');
INSERT INTO `migrations` (`id`, `pluginId`, `type`, `name`, `applyTime`, `dateCreated`, `dateUpdated`, `uid`) VALUES ('83', NULL, 'app', 'm180113_153740_drop_users_archived_column', '2019-12-12 12:18:02', '2019-12-12 12:18:02', '2019-12-12 12:18:02', 'f4b12f5a-fedb-4a7d-870c-356aeb40c964');
INSERT INTO `migrations` (`id`, `pluginId`, `type`, `name`, `applyTime`, `dateCreated`, `dateUpdated`, `uid`) VALUES ('84', NULL, 'app', 'm180122_213433_propagate_entries_setting', '2019-12-12 12:18:02', '2019-12-12 12:18:02', '2019-12-12 12:18:02', '31c08329-97f8-4916-9444-cb3b8c14de8e');
INSERT INTO `migrations` (`id`, `pluginId`, `type`, `name`, `applyTime`, `dateCreated`, `dateUpdated`, `uid`) VALUES ('85', NULL, 'app', 'm180124_230459_fix_propagate_entries_values', '2019-12-12 12:18:02', '2019-12-12 12:18:02', '2019-12-12 12:18:02', 'f4d59002-68ef-43b8-8f10-bcf5fe378acb');
INSERT INTO `migrations` (`id`, `pluginId`, `type`, `name`, `applyTime`, `dateCreated`, `dateUpdated`, `uid`) VALUES ('86', NULL, 'app', 'm180128_235202_set_tag_slugs', '2019-12-12 12:18:02', '2019-12-12 12:18:02', '2019-12-12 12:18:02', '1ac13f17-f973-4bbf-a2e8-73b159dfc380');
INSERT INTO `migrations` (`id`, `pluginId`, `type`, `name`, `applyTime`, `dateCreated`, `dateUpdated`, `uid`) VALUES ('87', NULL, 'app', 'm180202_185551_fix_focal_points', '2019-12-12 12:18:02', '2019-12-12 12:18:02', '2019-12-12 12:18:02', 'dbee3506-71ed-45e3-91f7-e558e09af1e9');
INSERT INTO `migrations` (`id`, `pluginId`, `type`, `name`, `applyTime`, `dateCreated`, `dateUpdated`, `uid`) VALUES ('88', NULL, 'app', 'm180217_172123_tiny_ints', '2019-12-12 12:18:02', '2019-12-12 12:18:02', '2019-12-12 12:18:02', '45222fdb-2780-4c4f-95dc-782aca68c087');
INSERT INTO `migrations` (`id`, `pluginId`, `type`, `name`, `applyTime`, `dateCreated`, `dateUpdated`, `uid`) VALUES ('89', NULL, 'app', 'm180321_233505_small_ints', '2019-12-12 12:18:02', '2019-12-12 12:18:02', '2019-12-12 12:18:02', '88cd291b-5043-47b2-9e38-d27e00160d59');
INSERT INTO `migrations` (`id`, `pluginId`, `type`, `name`, `applyTime`, `dateCreated`, `dateUpdated`, `uid`) VALUES ('90', NULL, 'app', 'm180328_115523_new_license_key_statuses', '2019-12-12 12:18:02', '2019-12-12 12:18:02', '2019-12-12 12:18:02', '778937b6-687b-44c3-8af0-95a4af6827be');
INSERT INTO `migrations` (`id`, `pluginId`, `type`, `name`, `applyTime`, `dateCreated`, `dateUpdated`, `uid`) VALUES ('91', NULL, 'app', 'm180404_182320_edition_changes', '2019-12-12 12:18:02', '2019-12-12 12:18:02', '2019-12-12 12:18:02', 'dc95b7a0-d1d0-4edd-adfb-419a1340fdf6');
INSERT INTO `migrations` (`id`, `pluginId`, `type`, `name`, `applyTime`, `dateCreated`, `dateUpdated`, `uid`) VALUES ('92', NULL, 'app', 'm180411_102218_fix_db_routes', '2019-12-12 12:18:02', '2019-12-12 12:18:02', '2019-12-12 12:18:02', '244fdb1b-eba9-4e55-b445-c3462eb4604c');
INSERT INTO `migrations` (`id`, `pluginId`, `type`, `name`, `applyTime`, `dateCreated`, `dateUpdated`, `uid`) VALUES ('93', NULL, 'app', 'm180416_205628_resourcepaths_table', '2019-12-12 12:18:02', '2019-12-12 12:18:02', '2019-12-12 12:18:02', 'c80d88a5-7113-42ab-b6f8-34f0a1ceadaf');
INSERT INTO `migrations` (`id`, `pluginId`, `type`, `name`, `applyTime`, `dateCreated`, `dateUpdated`, `uid`) VALUES ('94', NULL, 'app', 'm180418_205713_widget_cleanup', '2019-12-12 12:18:02', '2019-12-12 12:18:02', '2019-12-12 12:18:02', 'c3974373-4c67-40ec-b00a-5fa8991c8b67');
INSERT INTO `migrations` (`id`, `pluginId`, `type`, `name`, `applyTime`, `dateCreated`, `dateUpdated`, `uid`) VALUES ('95', NULL, 'app', 'm180425_203349_searchable_fields', '2019-12-12 12:18:02', '2019-12-12 12:18:02', '2019-12-12 12:18:02', '35c53b89-d12b-4bb5-a605-5b5223e62aec');
INSERT INTO `migrations` (`id`, `pluginId`, `type`, `name`, `applyTime`, `dateCreated`, `dateUpdated`, `uid`) VALUES ('96', NULL, 'app', 'm180516_153000_uids_in_field_settings', '2019-12-12 12:18:02', '2019-12-12 12:18:02', '2019-12-12 12:18:02', '422af37a-4b05-4faf-957c-4c13ff7ab008');
INSERT INTO `migrations` (`id`, `pluginId`, `type`, `name`, `applyTime`, `dateCreated`, `dateUpdated`, `uid`) VALUES ('97', NULL, 'app', 'm180517_173000_user_photo_volume_to_uid', '2019-12-12 12:18:02', '2019-12-12 12:18:02', '2019-12-12 12:18:02', '2ee0ba15-3c65-443d-bda5-1aa777874007');
INSERT INTO `migrations` (`id`, `pluginId`, `type`, `name`, `applyTime`, `dateCreated`, `dateUpdated`, `uid`) VALUES ('98', NULL, 'app', 'm180518_173000_permissions_to_uid', '2019-12-12 12:18:02', '2019-12-12 12:18:02', '2019-12-12 12:18:02', 'cc3ad249-4e75-47fa-815d-d94041838f66');
INSERT INTO `migrations` (`id`, `pluginId`, `type`, `name`, `applyTime`, `dateCreated`, `dateUpdated`, `uid`) VALUES ('99', NULL, 'app', 'm180520_173000_matrix_context_to_uids', '2019-12-12 12:18:02', '2019-12-12 12:18:02', '2019-12-12 12:18:02', 'cbfca97a-d02a-4cdd-b54a-ced2cd0b5e00');
INSERT INTO `migrations` (`id`, `pluginId`, `type`, `name`, `applyTime`, `dateCreated`, `dateUpdated`, `uid`) VALUES ('100', NULL, 'app', 'm180521_173000_initial_yml_and_snapshot', '2019-12-12 12:18:02', '2019-12-12 12:18:02', '2019-12-12 12:18:02', 'c0f96205-c7b1-41ba-9d83-fd26ff70f1d6');
INSERT INTO `migrations` (`id`, `pluginId`, `type`, `name`, `applyTime`, `dateCreated`, `dateUpdated`, `uid`) VALUES ('101', NULL, 'app', 'm180731_162030_soft_delete_sites', '2019-12-12 12:18:02', '2019-12-12 12:18:02', '2019-12-12 12:18:02', '01cde9ff-03ec-49e7-b2b2-d18faa7a26fd');
INSERT INTO `migrations` (`id`, `pluginId`, `type`, `name`, `applyTime`, `dateCreated`, `dateUpdated`, `uid`) VALUES ('102', NULL, 'app', 'm180810_214427_soft_delete_field_layouts', '2019-12-12 12:18:02', '2019-12-12 12:18:02', '2019-12-12 12:18:02', '8d86c64f-e6d8-4e5c-bbf0-2fa3c28266cd');
INSERT INTO `migrations` (`id`, `pluginId`, `type`, `name`, `applyTime`, `dateCreated`, `dateUpdated`, `uid`) VALUES ('103', NULL, 'app', 'm180810_214439_soft_delete_elements', '2019-12-12 12:18:02', '2019-12-12 12:18:02', '2019-12-12 12:18:02', 'f623b80c-05f7-4e00-ab00-75f2164b4f44');
INSERT INTO `migrations` (`id`, `pluginId`, `type`, `name`, `applyTime`, `dateCreated`, `dateUpdated`, `uid`) VALUES ('104', NULL, 'app', 'm180824_193422_case_sensitivity_fixes', '2019-12-12 12:18:02', '2019-12-12 12:18:02', '2019-12-12 12:18:02', '31376781-e436-4357-bef9-0a6a22fd573f');
INSERT INTO `migrations` (`id`, `pluginId`, `type`, `name`, `applyTime`, `dateCreated`, `dateUpdated`, `uid`) VALUES ('105', NULL, 'app', 'm180901_151639_fix_matrixcontent_tables', '2019-12-12 12:18:02', '2019-12-12 12:18:02', '2019-12-12 12:18:02', '4b6eccc5-6861-4c25-b936-280fa1af295c');
INSERT INTO `migrations` (`id`, `pluginId`, `type`, `name`, `applyTime`, `dateCreated`, `dateUpdated`, `uid`) VALUES ('106', NULL, 'app', 'm180904_112109_permission_changes', '2019-12-12 12:18:02', '2019-12-12 12:18:02', '2019-12-12 12:18:02', '6e5077eb-8741-4f98-812f-99e210f99a93');
INSERT INTO `migrations` (`id`, `pluginId`, `type`, `name`, `applyTime`, `dateCreated`, `dateUpdated`, `uid`) VALUES ('107', NULL, 'app', 'm180910_142030_soft_delete_sitegroups', '2019-12-12 12:18:02', '2019-12-12 12:18:02', '2019-12-12 12:18:02', 'eaf335fd-a014-482f-b83c-685f1f93fe69');
INSERT INTO `migrations` (`id`, `pluginId`, `type`, `name`, `applyTime`, `dateCreated`, `dateUpdated`, `uid`) VALUES ('108', NULL, 'app', 'm181011_160000_soft_delete_asset_support', '2019-12-12 12:18:02', '2019-12-12 12:18:02', '2019-12-12 12:18:02', '42b2442e-aa7f-420d-8837-8e4fcac6a040');
INSERT INTO `migrations` (`id`, `pluginId`, `type`, `name`, `applyTime`, `dateCreated`, `dateUpdated`, `uid`) VALUES ('109', NULL, 'app', 'm181016_183648_set_default_user_settings', '2019-12-12 12:18:02', '2019-12-12 12:18:02', '2019-12-12 12:18:02', '4084ce1e-fd65-4035-89f7-115f38a946d0');
INSERT INTO `migrations` (`id`, `pluginId`, `type`, `name`, `applyTime`, `dateCreated`, `dateUpdated`, `uid`) VALUES ('110', NULL, 'app', 'm181017_225222_system_config_settings', '2019-12-12 12:18:02', '2019-12-12 12:18:02', '2019-12-12 12:18:02', '92f580cb-d014-4a32-95ba-789b6680e494');
INSERT INTO `migrations` (`id`, `pluginId`, `type`, `name`, `applyTime`, `dateCreated`, `dateUpdated`, `uid`) VALUES ('111', NULL, 'app', 'm181018_222343_drop_userpermissions_from_config', '2019-12-12 12:18:02', '2019-12-12 12:18:02', '2019-12-12 12:18:02', 'c56b96fc-8fa6-4fcd-9a60-8562e6a8dd2e');
INSERT INTO `migrations` (`id`, `pluginId`, `type`, `name`, `applyTime`, `dateCreated`, `dateUpdated`, `uid`) VALUES ('112', NULL, 'app', 'm181029_130000_add_transforms_routes_to_config', '2019-12-12 12:18:02', '2019-12-12 12:18:02', '2019-12-12 12:18:02', '4ea26c15-5682-4174-bf7a-c22a7ced2114');
INSERT INTO `migrations` (`id`, `pluginId`, `type`, `name`, `applyTime`, `dateCreated`, `dateUpdated`, `uid`) VALUES ('113', NULL, 'app', 'm181112_203955_sequences_table', '2019-12-12 12:18:02', '2019-12-12 12:18:02', '2019-12-12 12:18:02', '078d106b-42b0-40a3-bc04-8684c48e61a6');
INSERT INTO `migrations` (`id`, `pluginId`, `type`, `name`, `applyTime`, `dateCreated`, `dateUpdated`, `uid`) VALUES ('114', NULL, 'app', 'm181121_001712_cleanup_field_configs', '2019-12-12 12:18:02', '2019-12-12 12:18:02', '2019-12-12 12:18:02', 'bc83243b-d22e-4694-a2de-f5f616653f3b');
INSERT INTO `migrations` (`id`, `pluginId`, `type`, `name`, `applyTime`, `dateCreated`, `dateUpdated`, `uid`) VALUES ('115', NULL, 'app', 'm181128_193942_fix_project_config', '2019-12-12 12:18:02', '2019-12-12 12:18:02', '2019-12-12 12:18:02', '6c5bbbdc-285f-4a55-99eb-57c9b6b91243');
INSERT INTO `migrations` (`id`, `pluginId`, `type`, `name`, `applyTime`, `dateCreated`, `dateUpdated`, `uid`) VALUES ('116', NULL, 'app', 'm181130_143040_fix_schema_version', '2019-12-12 12:18:02', '2019-12-12 12:18:02', '2019-12-12 12:18:02', 'e97a78a5-e526-4cae-8fdf-8da60426a49f');
INSERT INTO `migrations` (`id`, `pluginId`, `type`, `name`, `applyTime`, `dateCreated`, `dateUpdated`, `uid`) VALUES ('117', NULL, 'app', 'm181211_143040_fix_entry_type_uids', '2019-12-12 12:18:02', '2019-12-12 12:18:02', '2019-12-12 12:18:02', '05f7094a-df95-4ca9-95bf-00e78370e9ec');
INSERT INTO `migrations` (`id`, `pluginId`, `type`, `name`, `applyTime`, `dateCreated`, `dateUpdated`, `uid`) VALUES ('118', NULL, 'app', 'm181213_102500_config_map_aliases', '2019-12-12 12:18:02', '2019-12-12 12:18:02', '2019-12-12 12:18:02', '3a0d5618-8f78-4566-accb-f390a8ba2616');
INSERT INTO `migrations` (`id`, `pluginId`, `type`, `name`, `applyTime`, `dateCreated`, `dateUpdated`, `uid`) VALUES ('119', NULL, 'app', 'm181217_153000_fix_structure_uids', '2019-12-12 12:18:02', '2019-12-12 12:18:02', '2019-12-12 12:18:02', '832ac7ae-1604-48f2-afae-71f9dec484e5');
INSERT INTO `migrations` (`id`, `pluginId`, `type`, `name`, `applyTime`, `dateCreated`, `dateUpdated`, `uid`) VALUES ('120', NULL, 'app', 'm190104_152725_store_licensed_plugin_editions', '2019-12-12 12:18:02', '2019-12-12 12:18:02', '2019-12-12 12:18:02', '71284dea-5a67-4143-a44e-486f3767d1f7');
INSERT INTO `migrations` (`id`, `pluginId`, `type`, `name`, `applyTime`, `dateCreated`, `dateUpdated`, `uid`) VALUES ('121', NULL, 'app', 'm190108_110000_cleanup_project_config', '2019-12-12 12:18:02', '2019-12-12 12:18:02', '2019-12-12 12:18:02', '5caaa969-0090-4dc7-8956-e7ad5f5bc281');
INSERT INTO `migrations` (`id`, `pluginId`, `type`, `name`, `applyTime`, `dateCreated`, `dateUpdated`, `uid`) VALUES ('122', NULL, 'app', 'm190108_113000_asset_field_setting_change', '2019-12-12 12:18:02', '2019-12-12 12:18:02', '2019-12-12 12:18:02', 'c777b398-f970-4d5f-a30d-4174e62094cd');
INSERT INTO `migrations` (`id`, `pluginId`, `type`, `name`, `applyTime`, `dateCreated`, `dateUpdated`, `uid`) VALUES ('123', NULL, 'app', 'm190109_172845_fix_colspan', '2019-12-12 12:18:02', '2019-12-12 12:18:02', '2019-12-12 12:18:02', 'e8e3bfbd-593e-4f29-a589-c1afd7cf1805');
INSERT INTO `migrations` (`id`, `pluginId`, `type`, `name`, `applyTime`, `dateCreated`, `dateUpdated`, `uid`) VALUES ('124', NULL, 'app', 'm190110_150000_prune_nonexisting_sites', '2019-12-12 12:18:02', '2019-12-12 12:18:02', '2019-12-12 12:18:02', 'cf73f564-aa55-4519-b4d8-0d47ff87d821');
INSERT INTO `migrations` (`id`, `pluginId`, `type`, `name`, `applyTime`, `dateCreated`, `dateUpdated`, `uid`) VALUES ('125', NULL, 'app', 'm190110_214819_soft_delete_volumes', '2019-12-12 12:18:02', '2019-12-12 12:18:02', '2019-12-12 12:18:02', '1556a83f-8a7e-4ea5-b21d-dc3de53b1021');
INSERT INTO `migrations` (`id`, `pluginId`, `type`, `name`, `applyTime`, `dateCreated`, `dateUpdated`, `uid`) VALUES ('126', NULL, 'app', 'm190112_124737_fix_user_settings', '2019-12-12 12:18:02', '2019-12-12 12:18:02', '2019-12-12 12:18:02', '3753a2e1-e2a9-4824-91d9-6e14f470ad09');
INSERT INTO `migrations` (`id`, `pluginId`, `type`, `name`, `applyTime`, `dateCreated`, `dateUpdated`, `uid`) VALUES ('127', NULL, 'app', 'm190112_131225_fix_field_layouts', '2019-12-12 12:18:02', '2019-12-12 12:18:02', '2019-12-12 12:18:02', '7ec20a4a-0a16-4d96-84ac-e3414db3de96');
INSERT INTO `migrations` (`id`, `pluginId`, `type`, `name`, `applyTime`, `dateCreated`, `dateUpdated`, `uid`) VALUES ('128', NULL, 'app', 'm190112_201010_more_soft_deletes', '2019-12-12 12:18:02', '2019-12-12 12:18:02', '2019-12-12 12:18:02', '3656117e-5f74-4450-8551-4a359a89386d');
INSERT INTO `migrations` (`id`, `pluginId`, `type`, `name`, `applyTime`, `dateCreated`, `dateUpdated`, `uid`) VALUES ('129', NULL, 'app', 'm190114_143000_more_asset_field_setting_changes', '2019-12-12 12:18:02', '2019-12-12 12:18:02', '2019-12-12 12:18:02', '5d3b921d-8064-4255-a717-82e6b783065f');
INSERT INTO `migrations` (`id`, `pluginId`, `type`, `name`, `applyTime`, `dateCreated`, `dateUpdated`, `uid`) VALUES ('130', NULL, 'app', 'm190121_120000_rich_text_config_setting', '2019-12-12 12:18:02', '2019-12-12 12:18:02', '2019-12-12 12:18:02', 'ba626d61-14c7-4f0e-bba1-60dbe2a2823d');
INSERT INTO `migrations` (`id`, `pluginId`, `type`, `name`, `applyTime`, `dateCreated`, `dateUpdated`, `uid`) VALUES ('131', NULL, 'app', 'm190125_191628_fix_email_transport_password', '2019-12-12 12:18:02', '2019-12-12 12:18:02', '2019-12-12 12:18:02', '15bcbdd6-8b19-45c1-b1e8-b9a05e273fd3');
INSERT INTO `migrations` (`id`, `pluginId`, `type`, `name`, `applyTime`, `dateCreated`, `dateUpdated`, `uid`) VALUES ('132', NULL, 'app', 'm190128_181422_cleanup_volume_folders', '2019-12-12 12:18:02', '2019-12-12 12:18:02', '2019-12-12 12:18:02', '5026d7c5-347f-4c2c-92f0-511755df4deb');
INSERT INTO `migrations` (`id`, `pluginId`, `type`, `name`, `applyTime`, `dateCreated`, `dateUpdated`, `uid`) VALUES ('133', NULL, 'app', 'm190205_140000_fix_asset_soft_delete_index', '2019-12-12 12:18:02', '2019-12-12 12:18:02', '2019-12-12 12:18:02', 'ce3d6635-6486-4155-83a9-7778caee17a4');
INSERT INTO `migrations` (`id`, `pluginId`, `type`, `name`, `applyTime`, `dateCreated`, `dateUpdated`, `uid`) VALUES ('134', NULL, 'app', 'm190208_140000_reset_project_config_mapping', '2019-12-12 12:18:02', '2019-12-12 12:18:02', '2019-12-12 12:18:02', '6761e62d-dddc-4036-81ef-e44d17590123');
INSERT INTO `migrations` (`id`, `pluginId`, `type`, `name`, `applyTime`, `dateCreated`, `dateUpdated`, `uid`) VALUES ('135', NULL, 'app', 'm190218_143000_element_index_settings_uid', '2019-12-12 12:18:02', '2019-12-12 12:18:02', '2019-12-12 12:18:02', '82b2f494-47ff-4a25-843a-00f7e02ec236');
INSERT INTO `migrations` (`id`, `pluginId`, `type`, `name`, `applyTime`, `dateCreated`, `dateUpdated`, `uid`) VALUES ('136', NULL, 'app', 'm190312_152740_element_revisions', '2019-12-12 12:18:02', '2019-12-12 12:18:02', '2019-12-12 12:18:02', '3791e1c6-403c-481a-92a5-ed0f2b4b4279');
INSERT INTO `migrations` (`id`, `pluginId`, `type`, `name`, `applyTime`, `dateCreated`, `dateUpdated`, `uid`) VALUES ('137', NULL, 'app', 'm190327_235137_propagation_method', '2019-12-12 12:18:02', '2019-12-12 12:18:02', '2019-12-12 12:18:02', 'c66bbabd-23be-4855-b83f-78ba6ddadddd');
INSERT INTO `migrations` (`id`, `pluginId`, `type`, `name`, `applyTime`, `dateCreated`, `dateUpdated`, `uid`) VALUES ('138', NULL, 'app', 'm190401_223843_drop_old_indexes', '2019-12-12 12:18:02', '2019-12-12 12:18:02', '2019-12-12 12:18:02', '0032b9b1-da82-4b9d-9659-0d6b025f0f03');
INSERT INTO `migrations` (`id`, `pluginId`, `type`, `name`, `applyTime`, `dateCreated`, `dateUpdated`, `uid`) VALUES ('139', NULL, 'app', 'm190416_014525_drop_unique_global_indexes', '2019-12-12 12:18:02', '2019-12-12 12:18:02', '2019-12-12 12:18:02', '6ae71a69-b58b-43e8-9c56-d8cfd4763f64');
INSERT INTO `migrations` (`id`, `pluginId`, `type`, `name`, `applyTime`, `dateCreated`, `dateUpdated`, `uid`) VALUES ('140', NULL, 'app', 'm190417_085010_add_image_editor_permissions', '2019-12-12 12:18:02', '2019-12-12 12:18:02', '2019-12-12 12:18:02', '2ecd5129-e597-424a-a543-17f438b2f3d7');
INSERT INTO `migrations` (`id`, `pluginId`, `type`, `name`, `applyTime`, `dateCreated`, `dateUpdated`, `uid`) VALUES ('141', NULL, 'app', 'm190502_122019_store_default_user_group_uid', '2019-12-12 12:18:02', '2019-12-12 12:18:02', '2019-12-12 12:18:02', 'bdbfdda6-a33b-478b-8203-6a077e6ddd91');
INSERT INTO `migrations` (`id`, `pluginId`, `type`, `name`, `applyTime`, `dateCreated`, `dateUpdated`, `uid`) VALUES ('142', NULL, 'app', 'm190504_150349_preview_targets', '2019-12-12 12:18:02', '2019-12-12 12:18:02', '2019-12-12 12:18:02', '70bb8a42-e0d1-4fb7-9a6a-258b2ba3036d');
INSERT INTO `migrations` (`id`, `pluginId`, `type`, `name`, `applyTime`, `dateCreated`, `dateUpdated`, `uid`) VALUES ('143', NULL, 'app', 'm190516_184711_job_progress_label', '2019-12-12 12:18:02', '2019-12-12 12:18:02', '2019-12-12 12:18:02', '56b30ffa-c2f4-4fa2-bd35-295f376d926d');
INSERT INTO `migrations` (`id`, `pluginId`, `type`, `name`, `applyTime`, `dateCreated`, `dateUpdated`, `uid`) VALUES ('144', NULL, 'app', 'm190523_190303_optional_revision_creators', '2019-12-12 12:18:02', '2019-12-12 12:18:02', '2019-12-12 12:18:02', 'a0210065-c266-40bc-8e56-7ccc0b451e78');
INSERT INTO `migrations` (`id`, `pluginId`, `type`, `name`, `applyTime`, `dateCreated`, `dateUpdated`, `uid`) VALUES ('145', NULL, 'app', 'm190529_204501_fix_duplicate_uids', '2019-12-12 12:18:02', '2019-12-12 12:18:02', '2019-12-12 12:18:02', '60d93518-3a72-422b-99a1-d1b9c55f7027');
INSERT INTO `migrations` (`id`, `pluginId`, `type`, `name`, `applyTime`, `dateCreated`, `dateUpdated`, `uid`) VALUES ('146', NULL, 'app', 'm190605_223807_unsaved_drafts', '2019-12-12 12:18:02', '2019-12-12 12:18:02', '2019-12-12 12:18:02', '9b9c8da1-cba3-405d-83fc-b0cae0240137');
INSERT INTO `migrations` (`id`, `pluginId`, `type`, `name`, `applyTime`, `dateCreated`, `dateUpdated`, `uid`) VALUES ('147', NULL, 'app', 'm190607_230042_entry_revision_error_tables', '2019-12-12 12:18:02', '2019-12-12 12:18:02', '2019-12-12 12:18:02', '880af3c4-9f06-49d1-be96-8e4a17ccedfc');
INSERT INTO `migrations` (`id`, `pluginId`, `type`, `name`, `applyTime`, `dateCreated`, `dateUpdated`, `uid`) VALUES ('148', NULL, 'app', 'm190608_033429_drop_elements_uid_idx', '2019-12-12 12:18:02', '2019-12-12 12:18:02', '2019-12-12 12:18:02', '649deae3-fbb2-40ed-9718-3e6b10ed1f18');
INSERT INTO `migrations` (`id`, `pluginId`, `type`, `name`, `applyTime`, `dateCreated`, `dateUpdated`, `uid`) VALUES ('149', NULL, 'app', 'm190617_164400_add_gqlschemas_table', '2019-12-12 12:18:02', '2019-12-12 12:18:02', '2019-12-12 12:18:02', '298358a3-11e0-4a87-87da-ad180eba9692');
INSERT INTO `migrations` (`id`, `pluginId`, `type`, `name`, `applyTime`, `dateCreated`, `dateUpdated`, `uid`) VALUES ('150', NULL, 'app', 'm190624_234204_matrix_propagation_method', '2019-12-12 12:18:02', '2019-12-12 12:18:02', '2019-12-12 12:18:02', '8e97ae4f-d151-4c5c-81fd-3c19436269d7');
INSERT INTO `migrations` (`id`, `pluginId`, `type`, `name`, `applyTime`, `dateCreated`, `dateUpdated`, `uid`) VALUES ('151', NULL, 'app', 'm190711_153020_drop_snapshots', '2019-12-12 12:18:02', '2019-12-12 12:18:02', '2019-12-12 12:18:02', '13f99f7b-63f3-4b7c-9d40-b970525af725');
INSERT INTO `migrations` (`id`, `pluginId`, `type`, `name`, `applyTime`, `dateCreated`, `dateUpdated`, `uid`) VALUES ('152', NULL, 'app', 'm190712_195914_no_draft_revisions', '2019-12-12 12:18:02', '2019-12-12 12:18:02', '2019-12-12 12:18:02', '2644d059-c96c-46c6-9b73-b7184e67b7cb');
INSERT INTO `migrations` (`id`, `pluginId`, `type`, `name`, `applyTime`, `dateCreated`, `dateUpdated`, `uid`) VALUES ('153', NULL, 'app', 'm190723_140314_fix_preview_targets_column', '2019-12-12 12:18:02', '2019-12-12 12:18:02', '2019-12-12 12:18:02', 'e89734e2-85aa-4eef-bfab-21f3fa8b48a6');
INSERT INTO `migrations` (`id`, `pluginId`, `type`, `name`, `applyTime`, `dateCreated`, `dateUpdated`, `uid`) VALUES ('154', NULL, 'app', 'm190820_003519_flush_compiled_templates', '2019-12-12 12:18:02', '2019-12-12 12:18:02', '2019-12-12 12:18:02', 'c97ed2e5-3e7c-4f5f-a475-4a5560baef7f');
INSERT INTO `migrations` (`id`, `pluginId`, `type`, `name`, `applyTime`, `dateCreated`, `dateUpdated`, `uid`) VALUES ('155', NULL, 'app', 'm190823_020339_optional_draft_creators', '2019-12-12 12:18:02', '2019-12-12 12:18:02', '2019-12-12 12:18:02', '21e7c71b-11a1-420d-bf75-a46175ea81e4');
INSERT INTO `migrations` (`id`, `pluginId`, `type`, `name`, `applyTime`, `dateCreated`, `dateUpdated`, `uid`) VALUES ('156', '2', 'plugin', 'Install', '2019-12-16 09:53:47', '2019-12-16 09:53:47', '2019-12-16 09:53:47', 'a441c611-12b5-45cb-94a5-b8c80beef987');
INSERT INTO `migrations` (`id`, `pluginId`, `type`, `name`, `applyTime`, `dateCreated`, `dateUpdated`, `uid`) VALUES ('157', '2', 'plugin', 'm180826_000000_propagate_nav_setting', '2019-12-16 09:53:47', '2019-12-16 09:53:47', '2019-12-16 09:53:47', '443f7d16-d5e4-4e24-8682-3f2b62125af7');
INSERT INTO `migrations` (`id`, `pluginId`, `type`, `name`, `applyTime`, `dateCreated`, `dateUpdated`, `uid`) VALUES ('158', '2', 'plugin', 'm180827_000000_propagate_nav_setting_additional', '2019-12-16 09:53:47', '2019-12-16 09:53:47', '2019-12-16 09:53:47', '35abacb3-a24c-41a9-8787-1aaf2f796d4c');
INSERT INTO `migrations` (`id`, `pluginId`, `type`, `name`, `applyTime`, `dateCreated`, `dateUpdated`, `uid`) VALUES ('159', '2', 'plugin', 'm181110_000000_add_elementSiteId', '2019-12-16 09:53:47', '2019-12-16 09:53:47', '2019-12-16 09:53:47', '99a77954-6f67-4704-9976-e81b2851be6d');
INSERT INTO `migrations` (`id`, `pluginId`, `type`, `name`, `applyTime`, `dateCreated`, `dateUpdated`, `uid`) VALUES ('160', '2', 'plugin', 'm181123_000000_populate_elementSiteIds', '2019-12-16 09:53:47', '2019-12-16 09:53:47', '2019-12-16 09:53:47', '8dbd3000-99d1-44be-b02e-90eba1e13b24');
INSERT INTO `migrations` (`id`, `pluginId`, `type`, `name`, `applyTime`, `dateCreated`, `dateUpdated`, `uid`) VALUES ('161', '2', 'plugin', 'm190203_000000_add_instructions', '2019-12-16 09:53:47', '2019-12-16 09:53:47', '2019-12-16 09:53:47', '44dc7f9d-ae9e-4c42-8784-f5da243fc512');
INSERT INTO `migrations` (`id`, `pluginId`, `type`, `name`, `applyTime`, `dateCreated`, `dateUpdated`, `uid`) VALUES ('162', '2', 'plugin', 'm190209_000000_project_config', '2019-12-16 09:53:47', '2019-12-16 09:53:47', '2019-12-16 09:53:47', 'ff22e2c4-c1d9-40c5-9bbd-e4a18cb9a206');
INSERT INTO `migrations` (`id`, `pluginId`, `type`, `name`, `applyTime`, `dateCreated`, `dateUpdated`, `uid`) VALUES ('163', '2', 'plugin', 'm190223_000000_permissions', '2019-12-16 09:53:47', '2019-12-16 09:53:47', '2019-12-16 09:53:47', '01cd499a-676d-42b9-9ddd-6142dc024684');
INSERT INTO `migrations` (`id`, `pluginId`, `type`, `name`, `applyTime`, `dateCreated`, `dateUpdated`, `uid`) VALUES ('164', '2', 'plugin', 'm190307_000000_update_field_content', '2019-12-16 09:53:47', '2019-12-16 09:53:47', '2019-12-16 09:53:47', 'c91a417f-fe0a-4a23-b2b3-03bf44139f5c');
INSERT INTO `migrations` (`id`, `pluginId`, `type`, `name`, `applyTime`, `dateCreated`, `dateUpdated`, `uid`) VALUES ('165', '2', 'plugin', 'm190310_000000_migrate_elementSiteId', '2019-12-16 09:53:47', '2019-12-16 09:53:47', '2019-12-16 09:53:47', '42878635-f6a9-49c9-a5a8-f10263eb2a8f');
INSERT INTO `migrations` (`id`, `pluginId`, `type`, `name`, `applyTime`, `dateCreated`, `dateUpdated`, `uid`) VALUES ('166', '2', 'plugin', 'm190314_000000_soft_deletes', '2019-12-16 09:53:47', '2019-12-16 09:53:47', '2019-12-16 09:53:47', '757a20d4-15f3-4cdb-9185-c7c41552aaad');
INSERT INTO `migrations` (`id`, `pluginId`, `type`, `name`, `applyTime`, `dateCreated`, `dateUpdated`, `uid`) VALUES ('167', '2', 'plugin', 'm190315_000000_project_config', '2019-12-16 09:53:47', '2019-12-16 09:53:47', '2019-12-16 09:53:47', '043404d1-2a35-4bee-a5e3-8a6026222d8f');
INSERT INTO `migrations` (`id`, `pluginId`, `type`, `name`, `applyTime`, `dateCreated`, `dateUpdated`, `uid`) VALUES ('168', '2', 'plugin', 'm191127_000000_fix_nav_handle', '2019-12-16 09:53:47', '2019-12-16 09:53:47', '2019-12-16 09:53:47', 'fc0c9a62-84d5-4273-8b11-1728e1d00f7f');
INSERT INTO `migrations` (`id`, `pluginId`, `type`, `name`, `applyTime`, `dateCreated`, `dateUpdated`, `uid`) VALUES ('169', '3', 'plugin', 'Install', '2019-12-16 10:22:31', '2019-12-16 10:22:31', '2019-12-16 10:22:31', '74447cb5-c6e4-40f0-bc96-40eb67df8b9f');
INSERT INTO `migrations` (`id`, `pluginId`, `type`, `name`, `applyTime`, `dateCreated`, `dateUpdated`, `uid`) VALUES ('170', '3', 'plugin', 'm180929_165000_remove_storageclass_setting', '2019-12-16 10:22:31', '2019-12-16 10:22:31', '2019-12-16 10:22:31', 'a4660d0c-5508-48b0-9947-9f96df934b03');
INSERT INTO `migrations` (`id`, `pluginId`, `type`, `name`, `applyTime`, `dateCreated`, `dateUpdated`, `uid`) VALUES ('171', '3', 'plugin', 'm190131_214300_cleanup_config', '2019-12-16 10:22:31', '2019-12-16 10:22:31', '2019-12-16 10:22:31', '12ce2e80-61a6-4192-816c-6330bf525bf6');
INSERT INTO `migrations` (`id`, `pluginId`, `type`, `name`, `applyTime`, `dateCreated`, `dateUpdated`, `uid`) VALUES ('172', '3', 'plugin', 'm190305_133000_cleanup_expires_config', '2019-12-16 10:22:31', '2019-12-16 10:22:31', '2019-12-16 10:22:31', '314d9179-ce82-463c-8366-40ab2e2e4fa0');
INSERT INTO `migrations` (`id`, `pluginId`, `type`, `name`, `applyTime`, `dateCreated`, `dateUpdated`, `uid`) VALUES ('173', '5', 'plugin', 'Install', '2019-12-16 10:22:42', '2019-12-16 10:22:42', '2019-12-16 10:22:42', '741480c9-aa24-436b-a967-e3d3b45569f1');
INSERT INTO `migrations` (`id`, `pluginId`, `type`, `name`, `applyTime`, `dateCreated`, `dateUpdated`, `uid`) VALUES ('174', '5', 'plugin', 'm190509_031301_instructions_varchar_to_text', '2019-12-16 10:22:42', '2019-12-16 10:22:42', '2019-12-16 10:22:42', '45b06aa4-bee7-43cc-b7a5-fc78f23526ff');
INSERT INTO `migrations` (`id`, `pluginId`, `type`, `name`, `applyTime`, `dateCreated`, `dateUpdated`, `uid`) VALUES ('175', '5', 'plugin', 'm190517_093540_hide_field_headings', '2019-12-16 10:22:42', '2019-12-16 10:22:42', '2019-12-16 10:22:42', '506a7fd0-ecc8-4907-ae8c-e2e98bbc3ab5');
INSERT INTO `migrations` (`id`, `pluginId`, `type`, `name`, `applyTime`, `dateCreated`, `dateUpdated`, `uid`) VALUES ('176', '6', 'plugin', 'Install', '2019-12-16 10:22:46', '2019-12-16 10:22:46', '2019-12-16 10:22:46', '076238dd-83c4-47b4-920d-4d4fd91d61ca');
INSERT INTO `migrations` (`id`, `pluginId`, `type`, `name`, `applyTime`, `dateCreated`, `dateUpdated`, `uid`) VALUES ('177', '6', 'plugin', 'm180120_140521_CraftUpgrade', '2019-12-16 10:22:46', '2019-12-16 10:22:46', '2019-12-16 10:22:46', '37416906-8565-4d95-8901-8de0893b5aac');
INSERT INTO `migrations` (`id`, `pluginId`, `type`, `name`, `applyTime`, `dateCreated`, `dateUpdated`, `uid`) VALUES ('178', '6', 'plugin', 'm180125_124339_UpdateForeignKeyNames', '2019-12-16 10:22:46', '2019-12-16 10:22:46', '2019-12-16 10:22:46', '00e3e03f-3f13-4d9c-8941-aa8184fa9f6a');
INSERT INTO `migrations` (`id`, `pluginId`, `type`, `name`, `applyTime`, `dateCreated`, `dateUpdated`, `uid`) VALUES ('179', '6', 'plugin', 'm180214_094247_AddUniqueTokenToSubmissionsAndForms', '2019-12-16 10:22:46', '2019-12-16 10:22:46', '2019-12-16 10:22:46', 'fca53101-737b-49e2-b957-3bf8d56cef1f');
INSERT INTO `migrations` (`id`, `pluginId`, `type`, `name`, `applyTime`, `dateCreated`, `dateUpdated`, `uid`) VALUES ('180', '6', 'plugin', 'm180220_072652_ChangeFileUploadFieldColumnType', '2019-12-16 10:22:46', '2019-12-16 10:22:46', '2019-12-16 10:22:46', 'b936340a-fc3a-4002-8746-265fdc9779dc');
INSERT INTO `migrations` (`id`, `pluginId`, `type`, `name`, `applyTime`, `dateCreated`, `dateUpdated`, `uid`) VALUES ('181', '6', 'plugin', 'm180326_094124_AddIsSpamToSubmissions', '2019-12-16 10:22:46', '2019-12-16 10:22:46', '2019-12-16 10:22:46', '14f3b2ae-71fa-492f-9547-9a8cb4b5c871');
INSERT INTO `migrations` (`id`, `pluginId`, `type`, `name`, `applyTime`, `dateCreated`, `dateUpdated`, `uid`) VALUES ('182', '6', 'plugin', 'm180405_101920_AddIpAddressToSubmissions', '2019-12-16 10:22:46', '2019-12-16 10:22:46', '2019-12-16 10:22:46', 'fad4c5f5-d689-4f6b-b85c-d30976c965e4');
INSERT INTO `migrations` (`id`, `pluginId`, `type`, `name`, `applyTime`, `dateCreated`, `dateUpdated`, `uid`) VALUES ('183', '6', 'plugin', 'm180410_131206_CreateIntegrationsQueue', '2019-12-16 10:22:46', '2019-12-16 10:22:46', '2019-12-16 10:22:46', '24f640b7-75df-438b-851f-c4fe83d91948');
INSERT INTO `migrations` (`id`, `pluginId`, `type`, `name`, `applyTime`, `dateCreated`, `dateUpdated`, `uid`) VALUES ('184', '6', 'plugin', 'm180417_134527_AddMultipleSelectTypeToFields', '2019-12-16 10:22:46', '2019-12-16 10:22:46', '2019-12-16 10:22:46', 'ea8dc4d2-6cf4-4ec8-abc8-f7af1c855a4e');
INSERT INTO `migrations` (`id`, `pluginId`, `type`, `name`, `applyTime`, `dateCreated`, `dateUpdated`, `uid`) VALUES ('185', '6', 'plugin', 'm180430_151626_PaymentGateways', '2019-12-16 10:22:46', '2019-12-16 10:22:46', '2019-12-16 10:22:46', 'fe9acf37-b189-4eee-8cb7-f86754e444eb');
INSERT INTO `migrations` (`id`, `pluginId`, `type`, `name`, `applyTime`, `dateCreated`, `dateUpdated`, `uid`) VALUES ('186', '6', 'plugin', 'm180508_095131_CreatePaymentGatewayFieldsTable', '2019-12-16 10:22:46', '2019-12-16 10:22:46', '2019-12-16 10:22:46', '3a17227a-4470-4a6f-a1e5-61af6714b828');
INSERT INTO `migrations` (`id`, `pluginId`, `type`, `name`, `applyTime`, `dateCreated`, `dateUpdated`, `uid`) VALUES ('187', '6', 'plugin', 'm180606_141402_AddConnectionsToFormProperties', '2019-12-16 10:22:46', '2019-12-16 10:22:46', '2019-12-16 10:22:46', 'c38bd96b-d7b8-48b7-8357-af93b4165f5a');
INSERT INTO `migrations` (`id`, `pluginId`, `type`, `name`, `applyTime`, `dateCreated`, `dateUpdated`, `uid`) VALUES ('188', '6', 'plugin', 'm180730_171628_AddCcDetailsFieldType', '2019-12-16 10:22:46', '2019-12-16 10:22:46', '2019-12-16 10:22:46', '12b3423b-2b4c-42c3-8be8-8a5a10963cf7');
INSERT INTO `migrations` (`id`, `pluginId`, `type`, `name`, `applyTime`, `dateCreated`, `dateUpdated`, `uid`) VALUES ('189', '6', 'plugin', 'm180817_091801_AddRulesToFormProperties', '2019-12-16 10:22:46', '2019-12-16 10:22:46', '2019-12-16 10:22:46', '1222192c-cc12-48d7-9e34-fd613987fadb');
INSERT INTO `migrations` (`id`, `pluginId`, `type`, `name`, `applyTime`, `dateCreated`, `dateUpdated`, `uid`) VALUES ('190', '6', 'plugin', 'm181112_152751_ChangeTypeEnumColumnsToIndexedText', '2019-12-16 10:22:46', '2019-12-16 10:22:46', '2019-12-16 10:22:46', 'd3f7fcc5-f3fd-42ce-9c3a-9fcaf9d1c8d0');
INSERT INTO `migrations` (`id`, `pluginId`, `type`, `name`, `applyTime`, `dateCreated`, `dateUpdated`, `uid`) VALUES ('191', '6', 'plugin', 'm181129_083939_ChangeIntegrationFieldTypeColumnTypeToString', '2019-12-16 10:22:46', '2019-12-16 10:22:46', '2019-12-16 10:22:46', 'ed586c5a-c4bc-4e3a-bd15-63507bbc2663');
INSERT INTO `migrations` (`id`, `pluginId`, `type`, `name`, `applyTime`, `dateCreated`, `dateUpdated`, `uid`) VALUES ('192', '6', 'plugin', 'm190501_124050_MergingEditionsMigration', '2019-12-16 10:22:46', '2019-12-16 10:22:46', '2019-12-16 10:22:46', 'ae35df2a-5fb2-496f-87b9-b76c88e0d6b2');
INSERT INTO `migrations` (`id`, `pluginId`, `type`, `name`, `applyTime`, `dateCreated`, `dateUpdated`, `uid`) VALUES ('193', '6', 'plugin', 'm190502_155557_AddCCAndBCCToEmailNotifications', '2019-12-16 10:22:46', '2019-12-16 10:22:46', '2019-12-16 10:22:46', '6c09725c-d847-4d41-8bbc-3bd17d4f87f0');
INSERT INTO `migrations` (`id`, `pluginId`, `type`, `name`, `applyTime`, `dateCreated`, `dateUpdated`, `uid`) VALUES ('194', '6', 'plugin', 'm190516_085150_AddPresetAssetsToNotifications', '2019-12-16 10:22:46', '2019-12-16 10:22:46', '2019-12-16 10:22:46', '7f01cf57-b6a0-4607-b447-fe9b67728de9');
INSERT INTO `migrations` (`id`, `pluginId`, `type`, `name`, `applyTime`, `dateCreated`, `dateUpdated`, `uid`) VALUES ('195', '6', 'plugin', 'm190529_135307_AddWebhookTables', '2019-12-16 10:22:46', '2019-12-16 10:22:46', '2019-12-16 10:22:46', '06f36f9a-f029-4a85-a1b1-b7545c9ff66e');
INSERT INTO `migrations` (`id`, `pluginId`, `type`, `name`, `applyTime`, `dateCreated`, `dateUpdated`, `uid`) VALUES ('196', '6', 'plugin', 'm190603_160423_UpgradeFreeformHoneypotEnhancement', '2019-12-16 10:22:46', '2019-12-16 10:22:46', '2019-12-16 10:22:46', '8074fda4-5330-49f0-8be1-b8ca1f7945bc');
INSERT INTO `migrations` (`id`, `pluginId`, `type`, `name`, `applyTime`, `dateCreated`, `dateUpdated`, `uid`) VALUES ('197', '6', 'plugin', 'm190604_125112_AddFormLimitSubmissionProperty', '2019-12-16 10:22:46', '2019-12-16 10:22:46', '2019-12-16 10:22:46', '297aa0ba-8e9c-4b05-8a00-f3ace454da0b');
INSERT INTO `migrations` (`id`, `pluginId`, `type`, `name`, `applyTime`, `dateCreated`, `dateUpdated`, `uid`) VALUES ('198', '6', 'plugin', 'm190610_074840_MigrateScriptInsertLocation', '2019-12-16 10:22:46', '2019-12-16 10:22:46', '2019-12-16 10:22:46', '98a75f07-49d0-4e50-a430-60751e81450f');
INSERT INTO `migrations` (`id`, `pluginId`, `type`, `name`, `applyTime`, `dateCreated`, `dateUpdated`, `uid`) VALUES ('199', '6', 'plugin', 'm190614_103420_AddMissingMetaColumnsToProAndPaymentTables', '2019-12-16 10:22:46', '2019-12-16 10:22:46', '2019-12-16 10:22:46', '04d2e2d6-f715-4019-a0d7-75e464af9ba3');
INSERT INTO `migrations` (`id`, `pluginId`, `type`, `name`, `applyTime`, `dateCreated`, `dateUpdated`, `uid`) VALUES ('200', '6', 'plugin', 'm190617_122427_RemoveBrokenForeignKeys', '2019-12-16 10:22:46', '2019-12-16 10:22:46', '2019-12-16 10:22:46', '69361b7c-6ce5-460f-8356-bf7f24b736df');
INSERT INTO `migrations` (`id`, `pluginId`, `type`, `name`, `applyTime`, `dateCreated`, `dateUpdated`, `uid`) VALUES ('201', '6', 'plugin', 'm190618_142759_AddFixedForeignKeys', '2019-12-16 10:22:46', '2019-12-16 10:22:46', '2019-12-16 10:22:46', '63005dab-66da-481b-b623-8f148f48a919');
INSERT INTO `migrations` (`id`, `pluginId`, `type`, `name`, `applyTime`, `dateCreated`, `dateUpdated`, `uid`) VALUES ('202', '6', 'plugin', 'm190812_125059_AddNotesTable', '2019-12-16 10:22:46', '2019-12-16 10:22:46', '2019-12-16 10:22:46', '363f92b2-b063-4cb4-bc26-5a33aca69893');
INSERT INTO `migrations` (`id`, `pluginId`, `type`, `name`, `applyTime`, `dateCreated`, `dateUpdated`, `uid`) VALUES ('203', '6', 'plugin', 'm190905_113428_FixIntervalCountNotNullColumn', '2019-12-16 10:22:46', '2019-12-16 10:22:46', '2019-12-16 10:22:46', 'ad915f6b-b8b8-49fc-add2-435647401112');
INSERT INTO `migrations` (`id`, `pluginId`, `type`, `name`, `applyTime`, `dateCreated`, `dateUpdated`, `uid`) VALUES ('204', '7', 'plugin', 'Install', '2019-12-16 10:22:54', '2019-12-16 10:22:54', '2019-12-16 10:22:54', '225550f4-d390-4399-b826-1da9804e8005');
INSERT INTO `migrations` (`id`, `pluginId`, `type`, `name`, `applyTime`, `dateCreated`, `dateUpdated`, `uid`) VALUES ('205', '7', 'plugin', 'm181022_123749_craft3_upgrade', '2019-12-16 10:22:54', '2019-12-16 10:22:54', '2019-12-16 10:22:54', '3bd218ed-01e6-4a07-b817-9bbc8cfc9464');
INSERT INTO `migrations` (`id`, `pluginId`, `type`, `name`, `applyTime`, `dateCreated`, `dateUpdated`, `uid`) VALUES ('206', '7', 'plugin', 'm190127_023247_soft_delete_compatibility', '2019-12-16 10:22:54', '2019-12-16 10:22:54', '2019-12-16 10:22:54', 'f6c76d35-4440-4e2c-b788-3d32525b272d');
INSERT INTO `migrations` (`id`, `pluginId`, `type`, `name`, `applyTime`, `dateCreated`, `dateUpdated`, `uid`) VALUES ('207', '8', 'plugin', 'm180430_204710_remove_old_plugins', '2019-12-16 10:23:00', '2019-12-16 10:23:00', '2019-12-16 10:23:00', 'ba5d5cfa-b111-4ce3-b806-38f444fe1eae');
INSERT INTO `migrations` (`id`, `pluginId`, `type`, `name`, `applyTime`, `dateCreated`, `dateUpdated`, `uid`) VALUES ('208', '8', 'plugin', 'Install', '2019-12-16 10:23:00', '2019-12-16 10:23:00', '2019-12-16 10:23:00', 'f82b5007-4c70-4775-8bb4-6c86479dd34e');
INSERT INTO `migrations` (`id`, `pluginId`, `type`, `name`, `applyTime`, `dateCreated`, `dateUpdated`, `uid`) VALUES ('209', '8', 'plugin', 'm190225_003922_split_cleanup_html_settings', '2019-12-16 10:23:00', '2019-12-16 10:23:00', '2019-12-16 10:23:00', 'dd1ac899-0943-44d5-b468-95488ad5d40d');
INSERT INTO `migrations` (`id`, `pluginId`, `type`, `name`, `applyTime`, `dateCreated`, `dateUpdated`, `uid`) VALUES ('210', '9', 'plugin', 'Install', '2019-12-16 10:23:08', '2019-12-16 10:23:08', '2019-12-16 10:23:08', 'ba5ba066-d53f-4988-93d8-a8f174265421');
INSERT INTO `migrations` (`id`, `pluginId`, `type`, `name`, `applyTime`, `dateCreated`, `dateUpdated`, `uid`) VALUES ('211', '9', 'plugin', 'm180314_002755_field_type', '2019-12-16 10:23:08', '2019-12-16 10:23:08', '2019-12-16 10:23:08', '2bc25f57-eadd-469b-8ce9-4adc03f46eb0');
INSERT INTO `migrations` (`id`, `pluginId`, `type`, `name`, `applyTime`, `dateCreated`, `dateUpdated`, `uid`) VALUES ('212', '9', 'plugin', 'm180314_002756_base_install', '2019-12-16 10:23:08', '2019-12-16 10:23:08', '2019-12-16 10:23:08', '857ea4ae-54cb-4eb9-b6de-c43793f5e9ee');
INSERT INTO `migrations` (`id`, `pluginId`, `type`, `name`, `applyTime`, `dateCreated`, `dateUpdated`, `uid`) VALUES ('213', '9', 'plugin', 'm180502_202319_remove_field_metabundles', '2019-12-16 10:23:08', '2019-12-16 10:23:08', '2019-12-16 10:23:08', '1a195e9b-7907-411c-ae49-367f214be4d1');
INSERT INTO `migrations` (`id`, `pluginId`, `type`, `name`, `applyTime`, `dateCreated`, `dateUpdated`, `uid`) VALUES ('214', '9', 'plugin', 'm180711_024947_commerce_products', '2019-12-16 10:23:08', '2019-12-16 10:23:08', '2019-12-16 10:23:08', '70cbb9a7-e4e3-4cca-8d3a-22ec907e3f00');
INSERT INTO `migrations` (`id`, `pluginId`, `type`, `name`, `applyTime`, `dateCreated`, `dateUpdated`, `uid`) VALUES ('215', '9', 'plugin', 'm190401_220828_longer_handles', '2019-12-16 10:23:08', '2019-12-16 10:23:08', '2019-12-16 10:23:08', '2abf3f00-d1f7-46a8-add2-a00af8f2846f');
INSERT INTO `migrations` (`id`, `pluginId`, `type`, `name`, `applyTime`, `dateCreated`, `dateUpdated`, `uid`) VALUES ('216', '9', 'plugin', 'm190518_030221_calendar_events', '2019-12-16 10:23:08', '2019-12-16 10:23:08', '2019-12-16 10:23:08', '4ac0d785-93cd-4bcb-b157-1646b5a18a92');
INSERT INTO `migrations` (`id`, `pluginId`, `type`, `name`, `applyTime`, `dateCreated`, `dateUpdated`, `uid`) VALUES ('217', '11', 'plugin', 'Install', '2019-12-16 10:23:38', '2019-12-16 10:23:38', '2019-12-16 10:23:38', '10e2b7e0-9fd2-44a2-ab67-f2547382749c');
INSERT INTO `migrations` (`id`, `pluginId`, `type`, `name`, `applyTime`, `dateCreated`, `dateUpdated`, `uid`) VALUES ('218', '11', 'plugin', 'm180210_000000_migrate_content_tables', '2019-12-16 10:23:38', '2019-12-16 10:23:38', '2019-12-16 10:23:38', '635e41b3-d05d-49f3-a20a-0f3855777ac2');
INSERT INTO `migrations` (`id`, `pluginId`, `type`, `name`, `applyTime`, `dateCreated`, `dateUpdated`, `uid`) VALUES ('219', '11', 'plugin', 'm180211_000000_type_columns', '2019-12-16 10:23:38', '2019-12-16 10:23:38', '2019-12-16 10:23:38', '82d8168e-0bd0-48f2-b475-d25615dcb331');
INSERT INTO `migrations` (`id`, `pluginId`, `type`, `name`, `applyTime`, `dateCreated`, `dateUpdated`, `uid`) VALUES ('220', '11', 'plugin', 'm180219_000000_sites', '2019-12-16 10:23:38', '2019-12-16 10:23:38', '2019-12-16 10:23:38', '294e94ea-d47c-4e42-ac42-35facd0af3e3');
INSERT INTO `migrations` (`id`, `pluginId`, `type`, `name`, `applyTime`, `dateCreated`, `dateUpdated`, `uid`) VALUES ('221', '11', 'plugin', 'm180220_000000_fix_context', '2019-12-16 10:23:38', '2019-12-16 10:23:38', '2019-12-16 10:23:38', 'd40063a4-9da5-4f31-9cb2-b199fdb564fb');
INSERT INTO `migrations` (`id`, `pluginId`, `type`, `name`, `applyTime`, `dateCreated`, `dateUpdated`, `uid`) VALUES ('222', '11', 'plugin', 'm190117_000000_soft_deletes', '2019-12-16 10:23:38', '2019-12-16 10:23:38', '2019-12-16 10:23:38', '7132b6b3-6c8c-4ae9-83ce-65a36c9e1234');
INSERT INTO `migrations` (`id`, `pluginId`, `type`, `name`, `applyTime`, `dateCreated`, `dateUpdated`, `uid`) VALUES ('223', '11', 'plugin', 'm190117_000001_context_to_uids', '2019-12-16 10:23:38', '2019-12-16 10:23:38', '2019-12-16 10:23:38', '28e6b9d1-e603-4201-8842-0301490ad30e');
INSERT INTO `migrations` (`id`, `pluginId`, `type`, `name`, `applyTime`, `dateCreated`, `dateUpdated`, `uid`) VALUES ('224', '11', 'plugin', 'm190120_000000_fix_supertablecontent_tables', '2019-12-16 10:23:38', '2019-12-16 10:23:38', '2019-12-16 10:23:38', 'e79d8120-e11f-45a0-aa3b-008278aa7731');
INSERT INTO `migrations` (`id`, `pluginId`, `type`, `name`, `applyTime`, `dateCreated`, `dateUpdated`, `uid`) VALUES ('225', '11', 'plugin', 'm190131_000000_fix_supertable_missing_fields', '2019-12-16 10:23:38', '2019-12-16 10:23:38', '2019-12-16 10:23:38', 'e69294ec-9a43-4329-9aa8-c3fd369091fd');
INSERT INTO `migrations` (`id`, `pluginId`, `type`, `name`, `applyTime`, `dateCreated`, `dateUpdated`, `uid`) VALUES ('226', '11', 'plugin', 'm190227_100000_fix_project_config', '2019-12-16 10:23:38', '2019-12-16 10:23:38', '2019-12-16 10:23:38', '84eb7262-e8fc-4c7e-a89f-a477ef4fd1bc');
INSERT INTO `migrations` (`id`, `pluginId`, `type`, `name`, `applyTime`, `dateCreated`, `dateUpdated`, `uid`) VALUES ('227', '11', 'plugin', 'm190511_100000_fix_project_config', '2019-12-16 10:23:38', '2019-12-16 10:23:38', '2019-12-16 10:23:38', '6688d77a-f424-413c-b458-13afaf4b9d39');
INSERT INTO `migrations` (`id`, `pluginId`, `type`, `name`, `applyTime`, `dateCreated`, `dateUpdated`, `uid`) VALUES ('228', '11', 'plugin', 'm190520_000000_fix_project_config', '2019-12-16 10:23:38', '2019-12-16 10:23:38', '2019-12-16 10:23:38', '92d8dd8b-cb20-49ab-b9e2-15f44208603f');
INSERT INTO `migrations` (`id`, `pluginId`, `type`, `name`, `applyTime`, `dateCreated`, `dateUpdated`, `uid`) VALUES ('229', '11', 'plugin', 'm190714_000000_propagation_method', '2019-12-16 10:23:38', '2019-12-16 10:23:38', '2019-12-16 10:23:38', 'a52e6cd7-dfe6-494f-8cfe-142cba9ab70f');
INSERT INTO `migrations` (`id`, `pluginId`, `type`, `name`, `applyTime`, `dateCreated`, `dateUpdated`, `uid`) VALUES ('230', '11', 'plugin', 'm191127_000000_fix_width', '2019-12-16 10:23:38', '2019-12-16 10:23:38', '2019-12-16 10:23:38', 'fadab98c-0ad7-48c1-ade3-67db311e280f');
INSERT INTO `migrations` (`id`, `pluginId`, `type`, `name`, `applyTime`, `dateCreated`, `dateUpdated`, `uid`) VALUES ('231', '14', 'plugin', 'Install', '2019-12-16 11:09:47', '2019-12-16 11:09:47', '2019-12-16 11:09:47', '75864fe9-c54c-4dcb-af9d-6a8d49f19309');
INSERT INTO `migrations` (`id`, `pluginId`, `type`, `name`, `applyTime`, `dateCreated`, `dateUpdated`, `uid`) VALUES ('232', '14', 'plugin', 'm180423_175007_linkit_craft2', '2019-12-16 11:09:47', '2019-12-16 11:09:47', '2019-12-16 11:09:47', '335c7282-fe44-47e2-abaa-9e509c7591d1');
INSERT INTO `migrations` (`id`, `pluginId`, `type`, `name`, `applyTime`, `dateCreated`, `dateUpdated`, `uid`) VALUES ('233', '15', 'plugin', 'Install', '2019-12-16 11:19:09', '2019-12-16 11:19:09', '2019-12-16 11:19:09', '6a1a6d66-da07-473d-90b5-25638ef99bed');
INSERT INTO `migrations` (`id`, `pluginId`, `type`, `name`, `applyTime`, `dateCreated`, `dateUpdated`, `uid`) VALUES ('234', '15', 'plugin', 'm190226_143809_craft3_upgrade', '2019-12-16 11:19:09', '2019-12-16 11:19:09', '2019-12-16 11:19:09', 'e31f9177-80fd-4b1b-a819-83fd9fcf5176');
INSERT INTO `migrations` (`id`, `pluginId`, `type`, `name`, `applyTime`, `dateCreated`, `dateUpdated`, `uid`) VALUES ('235', '15', 'plugin', 'm190325_130533_repair_map_elements', '2019-12-16 11:19:09', '2019-12-16 11:19:09', '2019-12-16 11:19:09', 'f298fcbd-f3b0-4c07-aff4-e2aa75ae0aa0');
INSERT INTO `migrations` (`id`, `pluginId`, `type`, `name`, `applyTime`, `dateCreated`, `dateUpdated`, `uid`) VALUES ('236', '15', 'plugin', 'm190712_104805_new_data_format', '2019-12-16 11:19:09', '2019-12-16 11:19:09', '2019-12-16 11:19:09', '7d9d0441-f7d1-4a60-9791-e5f993b4036f');
INSERT INTO `migrations` (`id`, `pluginId`, `type`, `name`, `applyTime`, `dateCreated`, `dateUpdated`, `uid`) VALUES ('237', '15', 'plugin', 'm190723_105637_fix_map_field_column_type', '2019-12-16 11:19:09', '2019-12-16 11:19:09', '2019-12-16 11:19:09', 'e297db49-26c6-48b3-a710-7972a8e9a938');
INSERT INTO `migrations` (`id`, `pluginId`, `type`, `name`, `applyTime`, `dateCreated`, `dateUpdated`, `uid`) VALUES ('238', '18', 'plugin', 'm190121_220906_id', '2019-12-16 20:59:12', '2019-12-16 20:59:12', '2019-12-16 20:59:12', 'f1b6cc00-9cea-4c85-9f49-da7961cd4390');
INSERT INTO `migrations` (`id`, `pluginId`, `type`, `name`, `applyTime`, `dateCreated`, `dateUpdated`, `uid`) VALUES ('239', '18', 'plugin', 'm190906_102859_entry_type_id_to_uid', '2019-12-16 20:59:12', '2019-12-16 20:59:12', '2019-12-16 20:59:12', '7efa08b2-6c0f-4f87-b6ec-0ee4fdf697ae');
INSERT INTO `migrations` (`id`, `pluginId`, `type`, `name`, `applyTime`, `dateCreated`, `dateUpdated`, `uid`) VALUES ('240', '6', 'plugin', 'm191214_093453_AddExtraPostUrlColumnToForm', '2019-12-24 18:10:27', '2019-12-24 18:10:27', '2019-12-24 18:10:27', '6f9e65f3-c997-44ea-bcfd-88a028e13101');

INSERT INTO `navigation_navs` (`id`, `structureId`, `name`, `handle`, `instructions`, `sortOrder`, `propagateNodes`, `dateCreated`, `dateUpdated`, `dateDeleted`, `uid`) VALUES ('1', '1', 'Primary Navigation', 'primary', '', NULL, '0', '2019-12-16 09:53:47', '2019-12-16 10:01:14', NULL, '7d098513-b442-4de8-898e-3463aba0cfb3');

INSERT INTO `navigation_nodes` (`id`, `elementId`, `navId`, `parentId`, `url`, `type`, `classes`, `newWindow`, `deletedWithNav`, `dateCreated`, `dateUpdated`, `uid`) VALUES ('11', '3', '1', NULL, NULL, 'craft\\elements\\Entry', NULL, '0', NULL, '2019-12-16 10:06:29', '2019-12-16 20:46:07', '65157655-328e-4546-8c83-96e71e238f72');
INSERT INTO `navigation_nodes` (`id`, `elementId`, `navId`, `parentId`, `url`, `type`, `classes`, `newWindow`, `deletedWithNav`, `dateCreated`, `dateUpdated`, `uid`) VALUES ('12', '6', '1', NULL, NULL, 'craft\\elements\\Entry', NULL, '0', NULL, '2019-12-16 10:06:36', '2019-12-16 20:47:53', '2b7b72e2-9dfa-450c-b8e4-d4d65f0a19c7');
INSERT INTO `navigation_nodes` (`id`, `elementId`, `navId`, `parentId`, `url`, `type`, `classes`, `newWindow`, `deletedWithNav`, `dateCreated`, `dateUpdated`, `uid`) VALUES ('13', '9', '1', NULL, NULL, 'craft\\elements\\Entry', NULL, '0', NULL, '2019-12-16 10:06:41', '2019-12-16 20:46:08', 'ed9318f5-d9b8-418e-98b8-ebcdbc173850');

INSERT INTO `neoblocks` (`id`, `ownerId`, `ownerSiteId`, `fieldId`, `typeId`, `deletedWithOwner`, `dateCreated`, `dateUpdated`, `uid`) VALUES ('24', '16', NULL, '30', '16', NULL, '2019-12-24 17:47:06', '2019-12-24 17:47:06', 'd232cfa8-3be7-4c86-830f-a62d285d9ca3');
INSERT INTO `neoblocks` (`id`, `ownerId`, `ownerSiteId`, `fieldId`, `typeId`, `deletedWithOwner`, `dateCreated`, `dateUpdated`, `uid`) VALUES ('25', '16', NULL, '30', '1', NULL, '2019-12-24 17:47:06', '2019-12-24 17:47:06', '73f55746-4f57-4b57-a9c4-5aa9e9471faf');
INSERT INTO `neoblocks` (`id`, `ownerId`, `ownerSiteId`, `fieldId`, `typeId`, `deletedWithOwner`, `dateCreated`, `dateUpdated`, `uid`) VALUES ('26', '16', NULL, '30', '2', NULL, '2019-12-24 17:47:06', '2019-12-24 17:47:06', '25402ae1-66c0-41ab-b682-b665e94740c7');
INSERT INTO `neoblocks` (`id`, `ownerId`, `ownerSiteId`, `fieldId`, `typeId`, `deletedWithOwner`, `dateCreated`, `dateUpdated`, `uid`) VALUES ('27', '16', NULL, '30', '16', NULL, '2019-12-24 17:47:06', '2019-12-24 17:47:06', '8d059859-7ad9-4328-8e05-0cfb79eef948');
INSERT INTO `neoblocks` (`id`, `ownerId`, `ownerSiteId`, `fieldId`, `typeId`, `deletedWithOwner`, `dateCreated`, `dateUpdated`, `uid`) VALUES ('28', '16', NULL, '30', '1', NULL, '2019-12-24 17:47:06', '2019-12-24 17:47:06', '0c2fc399-7d35-4c93-bebc-f6aa15526441');
INSERT INTO `neoblocks` (`id`, `ownerId`, `ownerSiteId`, `fieldId`, `typeId`, `deletedWithOwner`, `dateCreated`, `dateUpdated`, `uid`) VALUES ('29', '16', NULL, '30', '2', NULL, '2019-12-24 17:47:06', '2019-12-24 17:47:06', '2a7b2034-1988-48b4-aa1f-ae2f545eb6ca');
INSERT INTO `neoblocks` (`id`, `ownerId`, `ownerSiteId`, `fieldId`, `typeId`, `deletedWithOwner`, `dateCreated`, `dateUpdated`, `uid`) VALUES ('31', '30', NULL, '30', '16', NULL, '2019-12-24 17:47:06', '2019-12-24 17:47:06', 'ee33b565-c7c2-4f1f-aee3-31a76d88bf62');
INSERT INTO `neoblocks` (`id`, `ownerId`, `ownerSiteId`, `fieldId`, `typeId`, `deletedWithOwner`, `dateCreated`, `dateUpdated`, `uid`) VALUES ('32', '30', NULL, '30', '1', NULL, '2019-12-24 17:47:06', '2019-12-24 17:47:06', 'c9d3c3c7-7e5e-4b2e-9c53-88fe2262324a');
INSERT INTO `neoblocks` (`id`, `ownerId`, `ownerSiteId`, `fieldId`, `typeId`, `deletedWithOwner`, `dateCreated`, `dateUpdated`, `uid`) VALUES ('33', '30', NULL, '30', '2', NULL, '2019-12-24 17:47:06', '2019-12-24 17:47:06', '909b1f1c-e243-4359-93e8-abedf5704159');
INSERT INTO `neoblocks` (`id`, `ownerId`, `ownerSiteId`, `fieldId`, `typeId`, `deletedWithOwner`, `dateCreated`, `dateUpdated`, `uid`) VALUES ('34', '30', NULL, '30', '16', NULL, '2019-12-24 17:47:06', '2019-12-24 17:47:06', '7f6454c8-053c-4a69-9136-55736623fe87');
INSERT INTO `neoblocks` (`id`, `ownerId`, `ownerSiteId`, `fieldId`, `typeId`, `deletedWithOwner`, `dateCreated`, `dateUpdated`, `uid`) VALUES ('35', '30', NULL, '30', '1', NULL, '2019-12-24 17:47:06', '2019-12-24 17:47:06', 'f1f06016-9d80-448e-98db-8ee60410e35f');
INSERT INTO `neoblocks` (`id`, `ownerId`, `ownerSiteId`, `fieldId`, `typeId`, `deletedWithOwner`, `dateCreated`, `dateUpdated`, `uid`) VALUES ('36', '30', NULL, '30', '2', NULL, '2019-12-24 17:47:06', '2019-12-24 17:47:06', '59c713f8-4c4b-4887-8b60-495be9274f29');

INSERT INTO `neoblockstructures` (`id`, `structureId`, `ownerId`, `ownerSiteId`, `fieldId`, `dateCreated`, `dateUpdated`, `uid`) VALUES ('1', '4', '16', '2', '30', '2019-12-24 17:47:06', '2019-12-24 17:47:06', '0b76e0b6-bf7c-4166-9846-6b6229ea9eb6');
INSERT INTO `neoblockstructures` (`id`, `structureId`, `ownerId`, `ownerSiteId`, `fieldId`, `dateCreated`, `dateUpdated`, `uid`) VALUES ('2', '5', '30', '2', '30', '2019-12-24 17:47:06', '2019-12-24 17:47:06', 'a18142d1-58fd-406d-aa7f-5dc2c112809a');

INSERT INTO `neoblocktypegroups` (`id`, `fieldId`, `name`, `sortOrder`, `dateCreated`, `dateUpdated`, `uid`) VALUES ('47', '31', 'Text', '1', '2019-12-17 01:04:30', '2019-12-17 01:04:30', 'ff918988-53de-46fa-b6d4-efb70daa9213');
INSERT INTO `neoblocktypegroups` (`id`, `fieldId`, `name`, `sortOrder`, `dateCreated`, `dateUpdated`, `uid`) VALUES ('48', '31', 'Media', '7', '2019-12-17 01:04:30', '2019-12-17 01:04:30', '9b3584b0-08f9-4db4-9be7-bc77649ceb97');
INSERT INTO `neoblocktypegroups` (`id`, `fieldId`, `name`, `sortOrder`, `dateCreated`, `dateUpdated`, `uid`) VALUES ('49', '31', 'Modules', '13', '2019-12-17 01:04:30', '2019-12-17 01:04:30', '72809716-7d0b-4784-b87f-c2bb0f8a9b28');
INSERT INTO `neoblocktypegroups` (`id`, `fieldId`, `name`, `sortOrder`, `dateCreated`, `dateUpdated`, `uid`) VALUES ('50', '31', 'Components', '18', '2019-12-17 01:04:30', '2019-12-17 01:04:30', 'b88351cc-7b87-4b71-a595-77d345d4aa18');
INSERT INTO `neoblocktypegroups` (`id`, `fieldId`, `name`, `sortOrder`, `dateCreated`, `dateUpdated`, `uid`) VALUES ('51', '30', 'Containers', '1', '2019-12-17 01:05:13', '2019-12-17 01:05:13', '94d69d08-46bf-4038-81c9-4feb3a90a3ca');
INSERT INTO `neoblocktypegroups` (`id`, `fieldId`, `name`, `sortOrder`, `dateCreated`, `dateUpdated`, `uid`) VALUES ('52', '30', 'Text', '3', '2019-12-17 01:05:13', '2019-12-17 01:05:13', '88a88db3-b10a-4908-b313-85c7025ddf3f');
INSERT INTO `neoblocktypegroups` (`id`, `fieldId`, `name`, `sortOrder`, `dateCreated`, `dateUpdated`, `uid`) VALUES ('53', '30', 'Media', '9', '2019-12-17 01:05:13', '2019-12-17 01:05:13', '2083052d-b712-4ab1-a611-7a96f4e19c69');
INSERT INTO `neoblocktypegroups` (`id`, `fieldId`, `name`, `sortOrder`, `dateCreated`, `dateUpdated`, `uid`) VALUES ('54', '30', 'Modules', '15', '2019-12-17 01:05:13', '2019-12-17 01:05:13', '9e5e0a64-8462-4df5-8db4-f4501609956d');
INSERT INTO `neoblocktypegroups` (`id`, `fieldId`, `name`, `sortOrder`, `dateCreated`, `dateUpdated`, `uid`) VALUES ('55', '30', 'Components', '20', '2019-12-17 01:05:13', '2019-12-17 01:05:13', 'bb4204b0-9d80-450b-aafc-3c45b162ba95');

INSERT INTO `neoblocktypes` (`id`, `fieldId`, `fieldLayoutId`, `name`, `handle`, `maxBlocks`, `maxChildBlocks`, `childBlocks`, `topLevel`, `sortOrder`, `dateCreated`, `dateUpdated`, `uid`) VALUES ('1', '30', '3', 'Heading', 'heading', '0', '0', '', '0', '4', '2019-12-16 11:57:50', '2019-12-17 01:05:13', 'b43286a1-8bb8-4848-89af-972840193bcc');
INSERT INTO `neoblocktypes` (`id`, `fieldId`, `fieldLayoutId`, `name`, `handle`, `maxBlocks`, `maxChildBlocks`, `childBlocks`, `topLevel`, `sortOrder`, `dateCreated`, `dateUpdated`, `uid`) VALUES ('2', '30', '4', 'Rich Text', 'richText', '0', '0', '', '0', '5', '2019-12-16 11:57:50', '2019-12-17 01:05:13', '207b818c-1e66-482c-8d36-5594d9792957');
INSERT INTO `neoblocktypes` (`id`, `fieldId`, `fieldLayoutId`, `name`, `handle`, `maxBlocks`, `maxChildBlocks`, `childBlocks`, `topLevel`, `sortOrder`, `dateCreated`, `dateUpdated`, `uid`) VALUES ('3', '30', '5', 'Quote', 'quote', '0', '0', '', '0', '6', '2019-12-16 11:57:50', '2019-12-17 01:05:13', '61448e4d-02c6-4118-86cf-3616ce629700');
INSERT INTO `neoblocktypes` (`id`, `fieldId`, `fieldLayoutId`, `name`, `handle`, `maxBlocks`, `maxChildBlocks`, `childBlocks`, `topLevel`, `sortOrder`, `dateCreated`, `dateUpdated`, `uid`) VALUES ('4', '30', '6', 'Table', 'table', '0', '0', '', '0', '7', '2019-12-16 11:57:50', '2019-12-17 01:05:13', 'b4f4527b-ece2-4d7f-b4ef-94a864420586');
INSERT INTO `neoblocktypes` (`id`, `fieldId`, `fieldLayoutId`, `name`, `handle`, `maxBlocks`, `maxChildBlocks`, `childBlocks`, `topLevel`, `sortOrder`, `dateCreated`, `dateUpdated`, `uid`) VALUES ('5', '30', '7', 'Button', 'button', '0', '0', '', '0', '8', '2019-12-16 11:57:50', '2019-12-17 01:05:13', '3f56f58d-e655-4368-9e90-0c4eeb3953cf');
INSERT INTO `neoblocktypes` (`id`, `fieldId`, `fieldLayoutId`, `name`, `handle`, `maxBlocks`, `maxChildBlocks`, `childBlocks`, `topLevel`, `sortOrder`, `dateCreated`, `dateUpdated`, `uid`) VALUES ('6', '30', '8', 'Image', 'image', '0', '0', '', '0', '10', '2019-12-16 11:57:50', '2019-12-17 01:05:13', '275f5285-cf76-4b51-9628-42ad3cfaac3a');
INSERT INTO `neoblocktypes` (`id`, `fieldId`, `fieldLayoutId`, `name`, `handle`, `maxBlocks`, `maxChildBlocks`, `childBlocks`, `topLevel`, `sortOrder`, `dateCreated`, `dateUpdated`, `uid`) VALUES ('7', '30', '9', 'Video', 'video', '0', '0', '', '0', '11', '2019-12-16 11:57:50', '2019-12-17 01:05:13', 'f3c4b0c9-5693-4c6e-a9c1-8f56d9a5d4bf');
INSERT INTO `neoblocktypes` (`id`, `fieldId`, `fieldLayoutId`, `name`, `handle`, `maxBlocks`, `maxChildBlocks`, `childBlocks`, `topLevel`, `sortOrder`, `dateCreated`, `dateUpdated`, `uid`) VALUES ('8', '30', '10', 'Gallery', 'gallery', '0', '0', '', '0', '12', '2019-12-16 11:57:50', '2019-12-17 01:05:13', '2e04d107-0116-469f-9869-94e8041d98ab');
INSERT INTO `neoblocktypes` (`id`, `fieldId`, `fieldLayoutId`, `name`, `handle`, `maxBlocks`, `maxChildBlocks`, `childBlocks`, `topLevel`, `sortOrder`, `dateCreated`, `dateUpdated`, `uid`) VALUES ('9', '30', '11', 'Slide', 'slide', '0', '0', '[\"heading\",\"richText\",\"button\"]', '0', '21', '2019-12-16 11:57:50', '2019-12-17 01:05:13', '635ed81e-4066-48c5-8b30-e49cc19bba99');
INSERT INTO `neoblocktypes` (`id`, `fieldId`, `fieldLayoutId`, `name`, `handle`, `maxBlocks`, `maxChildBlocks`, `childBlocks`, `topLevel`, `sortOrder`, `dateCreated`, `dateUpdated`, `uid`) VALUES ('10', '30', '12', 'Slideshow', 'slider', '0', '0', '[\"slide\"]', '0', '13', '2019-12-16 11:57:50', '2019-12-17 01:05:13', '858e2949-7b9b-4237-be8d-a92986382819');
INSERT INTO `neoblocktypes` (`id`, `fieldId`, `fieldLayoutId`, `name`, `handle`, `maxBlocks`, `maxChildBlocks`, `childBlocks`, `topLevel`, `sortOrder`, `dateCreated`, `dateUpdated`, `uid`) VALUES ('11', '30', '13', 'Pane', 'pane', '0', '0', '[\"heading\",\"richText\",\"quote\",\"table\",\"button\",\"image\",\"video\",\"gallery\",\"slider\",\"map\",\"form\",\"code\"]', '0', '22', '2019-12-16 11:57:50', '2019-12-17 01:05:13', '061db8fb-26a7-4faa-aa0b-cdfcb21a0681');
INSERT INTO `neoblocktypes` (`id`, `fieldId`, `fieldLayoutId`, `name`, `handle`, `maxBlocks`, `maxChildBlocks`, `childBlocks`, `topLevel`, `sortOrder`, `dateCreated`, `dateUpdated`, `uid`) VALUES ('12', '30', '14', 'Accordion', 'accordion', '0', '0', '[\"pane\"]', '0', '16', '2019-12-16 11:57:50', '2019-12-17 01:05:13', 'bc849705-bd2b-40dc-9896-f59bfbf84330');
INSERT INTO `neoblocktypes` (`id`, `fieldId`, `fieldLayoutId`, `name`, `handle`, `maxBlocks`, `maxChildBlocks`, `childBlocks`, `topLevel`, `sortOrder`, `dateCreated`, `dateUpdated`, `uid`) VALUES ('13', '30', '15', 'Tabs', 'tabs', '0', '0', '[\"pane\"]', '0', '17', '2019-12-16 11:57:50', '2019-12-17 01:05:13', '591fffc3-76a1-4991-8b96-7a97498e2f25');
INSERT INTO `neoblocktypes` (`id`, `fieldId`, `fieldLayoutId`, `name`, `handle`, `maxBlocks`, `maxChildBlocks`, `childBlocks`, `topLevel`, `sortOrder`, `dateCreated`, `dateUpdated`, `uid`) VALUES ('14', '30', '16', 'Form', 'form', '0', '0', '', '0', '18', '2019-12-16 11:57:50', '2019-12-17 01:05:13', 'e399a90a-3a8a-4e9b-b7b2-3ddea6a68344');
INSERT INTO `neoblocktypes` (`id`, `fieldId`, `fieldLayoutId`, `name`, `handle`, `maxBlocks`, `maxChildBlocks`, `childBlocks`, `topLevel`, `sortOrder`, `dateCreated`, `dateUpdated`, `uid`) VALUES ('15', '30', '17', 'Custom Code', 'code', '0', '0', '', '0', '19', '2019-12-16 11:57:50', '2019-12-17 01:05:13', 'e2a79140-d786-4a0d-9843-454c2650fe6f');
INSERT INTO `neoblocktypes` (`id`, `fieldId`, `fieldLayoutId`, `name`, `handle`, `maxBlocks`, `maxChildBlocks`, `childBlocks`, `topLevel`, `sortOrder`, `dateCreated`, `dateUpdated`, `uid`) VALUES ('16', '30', '18', 'Row', 'row', '0', '0', '[\"heading\",\"richText\",\"quote\",\"table\",\"button\",\"image\",\"video\",\"gallery\",\"slider\",\"map\",\"accordion\",\"tabs\",\"form\",\"code\"]', '1', '2', '2019-12-16 11:57:50', '2019-12-17 01:05:13', '6c69399f-55c0-4158-8b81-c5c70a4e2070');
INSERT INTO `neoblocktypes` (`id`, `fieldId`, `fieldLayoutId`, `name`, `handle`, `maxBlocks`, `maxChildBlocks`, `childBlocks`, `topLevel`, `sortOrder`, `dateCreated`, `dateUpdated`, `uid`) VALUES ('17', '31', '19', 'Heading', 'heading', '0', '0', '', '1', '2', '2019-12-16 20:40:27', '2019-12-17 01:04:29', '02ec681f-f570-4233-b3df-70226ab61b32');
INSERT INTO `neoblocktypes` (`id`, `fieldId`, `fieldLayoutId`, `name`, `handle`, `maxBlocks`, `maxChildBlocks`, `childBlocks`, `topLevel`, `sortOrder`, `dateCreated`, `dateUpdated`, `uid`) VALUES ('18', '31', '20', 'Rich Text', 'richText', '0', '0', '', '1', '3', '2019-12-16 20:40:27', '2019-12-17 01:04:29', 'c610bfd8-be57-45e7-8a2f-b1ff62908a30');
INSERT INTO `neoblocktypes` (`id`, `fieldId`, `fieldLayoutId`, `name`, `handle`, `maxBlocks`, `maxChildBlocks`, `childBlocks`, `topLevel`, `sortOrder`, `dateCreated`, `dateUpdated`, `uid`) VALUES ('19', '31', '21', 'Quote', 'quote', '0', '0', '', '1', '4', '2019-12-16 20:40:27', '2019-12-17 01:04:29', '920d10dd-214c-47da-86c5-b9add6a3f156');
INSERT INTO `neoblocktypes` (`id`, `fieldId`, `fieldLayoutId`, `name`, `handle`, `maxBlocks`, `maxChildBlocks`, `childBlocks`, `topLevel`, `sortOrder`, `dateCreated`, `dateUpdated`, `uid`) VALUES ('20', '31', '22', 'Table', 'table', '0', '0', '', '1', '5', '2019-12-16 20:40:27', '2019-12-17 01:04:29', '2ae41271-4716-4de6-aedd-0b628627e3d5');
INSERT INTO `neoblocktypes` (`id`, `fieldId`, `fieldLayoutId`, `name`, `handle`, `maxBlocks`, `maxChildBlocks`, `childBlocks`, `topLevel`, `sortOrder`, `dateCreated`, `dateUpdated`, `uid`) VALUES ('21', '31', '23', 'Button', 'button', '0', '0', '', '1', '6', '2019-12-16 20:40:28', '2019-12-17 01:04:29', '81f43402-6e5a-4fcf-9303-d6da313f9d16');
INSERT INTO `neoblocktypes` (`id`, `fieldId`, `fieldLayoutId`, `name`, `handle`, `maxBlocks`, `maxChildBlocks`, `childBlocks`, `topLevel`, `sortOrder`, `dateCreated`, `dateUpdated`, `uid`) VALUES ('22', '31', '24', 'Image', 'image', '0', '0', '', '1', '8', '2019-12-16 20:40:28', '2019-12-17 01:04:29', '6bc9a94c-b7ab-4f39-a463-11889c347e9f');
INSERT INTO `neoblocktypes` (`id`, `fieldId`, `fieldLayoutId`, `name`, `handle`, `maxBlocks`, `maxChildBlocks`, `childBlocks`, `topLevel`, `sortOrder`, `dateCreated`, `dateUpdated`, `uid`) VALUES ('23', '31', '25', 'Video', 'video', '0', '0', '', '1', '9', '2019-12-16 20:40:28', '2019-12-17 01:04:29', 'a0ed8ff5-67c0-4d0f-8210-64e926259aff');
INSERT INTO `neoblocktypes` (`id`, `fieldId`, `fieldLayoutId`, `name`, `handle`, `maxBlocks`, `maxChildBlocks`, `childBlocks`, `topLevel`, `sortOrder`, `dateCreated`, `dateUpdated`, `uid`) VALUES ('24', '31', '26', 'Gallery', 'gallery', '0', '0', '', '1', '10', '2019-12-16 20:40:28', '2019-12-17 01:04:30', '1aa769c1-0804-4c0a-8b49-6251543a63f3');
INSERT INTO `neoblocktypes` (`id`, `fieldId`, `fieldLayoutId`, `name`, `handle`, `maxBlocks`, `maxChildBlocks`, `childBlocks`, `topLevel`, `sortOrder`, `dateCreated`, `dateUpdated`, `uid`) VALUES ('25', '31', '27', 'Slide', 'slide', '0', '0', '[\"heading\",\"richText\",\"button\"]', '0', '19', '2019-12-16 20:40:28', '2019-12-17 01:04:30', '46d4d4ec-35e8-4ebe-9add-cb5b8bf8ef5a');
INSERT INTO `neoblocktypes` (`id`, `fieldId`, `fieldLayoutId`, `name`, `handle`, `maxBlocks`, `maxChildBlocks`, `childBlocks`, `topLevel`, `sortOrder`, `dateCreated`, `dateUpdated`, `uid`) VALUES ('26', '31', '28', 'Slideshow', 'slider', '0', '0', '[\"slide\"]', '1', '11', '2019-12-16 20:40:28', '2019-12-17 01:04:30', 'a50191db-5cd1-430a-8b0d-6a7b8d34d179');
INSERT INTO `neoblocktypes` (`id`, `fieldId`, `fieldLayoutId`, `name`, `handle`, `maxBlocks`, `maxChildBlocks`, `childBlocks`, `topLevel`, `sortOrder`, `dateCreated`, `dateUpdated`, `uid`) VALUES ('27', '31', '29', 'Accordion', 'accordion', '0', '0', '[\"pane\"]', '1', '14', '2019-12-16 20:40:28', '2019-12-17 01:04:30', '297a303e-0622-4f04-a6eb-99a446d55741');
INSERT INTO `neoblocktypes` (`id`, `fieldId`, `fieldLayoutId`, `name`, `handle`, `maxBlocks`, `maxChildBlocks`, `childBlocks`, `topLevel`, `sortOrder`, `dateCreated`, `dateUpdated`, `uid`) VALUES ('28', '31', '30', 'Tabs', 'tabs', '0', '0', '[\"pane\"]', '1', '15', '2019-12-16 20:40:28', '2019-12-17 01:04:30', 'd4d369ff-cc8f-4c9b-9115-3830f1358c58');
INSERT INTO `neoblocktypes` (`id`, `fieldId`, `fieldLayoutId`, `name`, `handle`, `maxBlocks`, `maxChildBlocks`, `childBlocks`, `topLevel`, `sortOrder`, `dateCreated`, `dateUpdated`, `uid`) VALUES ('29', '31', '31', 'Form', 'form', '0', '0', '', '1', '16', '2019-12-16 20:40:28', '2019-12-17 01:04:30', '223008a6-72c3-4da3-88ea-dbff940d585f');
INSERT INTO `neoblocktypes` (`id`, `fieldId`, `fieldLayoutId`, `name`, `handle`, `maxBlocks`, `maxChildBlocks`, `childBlocks`, `topLevel`, `sortOrder`, `dateCreated`, `dateUpdated`, `uid`) VALUES ('30', '31', '32', 'Custom Code', 'code', '0', '0', '', '1', '17', '2019-12-16 20:40:28', '2019-12-17 01:04:30', 'cbf8bbd6-7f12-4e97-9a94-a0cba75b1301');
INSERT INTO `neoblocktypes` (`id`, `fieldId`, `fieldLayoutId`, `name`, `handle`, `maxBlocks`, `maxChildBlocks`, `childBlocks`, `topLevel`, `sortOrder`, `dateCreated`, `dateUpdated`, `uid`) VALUES ('31', '31', '33', 'Pane', 'pane', '0', '0', '[\"heading\",\"richText\",\"quote\",\"table\",\"button\",\"image\",\"video\",\"gallery\",\"slider\",\"map\",\"form\",\"code\"]', '0', '20', '2019-12-16 20:40:28', '2019-12-17 01:04:30', '1f1a70a2-dfc5-476e-9a09-46461229a679');
INSERT INTO `neoblocktypes` (`id`, `fieldId`, `fieldLayoutId`, `name`, `handle`, `maxBlocks`, `maxChildBlocks`, `childBlocks`, `topLevel`, `sortOrder`, `dateCreated`, `dateUpdated`, `uid`) VALUES ('32', '30', '39', 'Map', 'map', '0', '0', '', '0', '14', '2019-12-16 21:12:39', '2019-12-17 01:05:13', '949ce8db-9505-4091-a701-45f00d0e3d7c');
INSERT INTO `neoblocktypes` (`id`, `fieldId`, `fieldLayoutId`, `name`, `handle`, `maxBlocks`, `maxChildBlocks`, `childBlocks`, `topLevel`, `sortOrder`, `dateCreated`, `dateUpdated`, `uid`) VALUES ('33', '31', '40', 'Map', 'map', '0', '0', '', '1', '12', '2019-12-16 21:14:59', '2019-12-17 01:04:30', '5b831b37-1f90-4657-bbbe-03a862990229');

INSERT INTO `plugins` (`id`, `handle`, `version`, `schemaVersion`, `licenseKeyStatus`, `licensedEdition`, `installDate`, `dateCreated`, `dateUpdated`, `uid`) VALUES ('1', 'twigpack', '1.1.12', '1.0.0', 'unknown', NULL, '2019-12-12 12:19:19', '2019-12-12 12:19:19', '2020-01-02 20:16:02', '508d06e9-a207-4141-8752-fa363383505a');
INSERT INTO `plugins` (`id`, `handle`, `version`, `schemaVersion`, `licenseKeyStatus`, `licensedEdition`, `installDate`, `dateCreated`, `dateUpdated`, `uid`) VALUES ('2', 'navigation', '1.1.14.1', '1.0.12', 'invalid', NULL, '2019-12-16 09:53:47', '2019-12-16 09:53:47', '2020-01-02 20:16:02', '05a4dd6b-944f-4118-b81d-fdeb7b3cdff9');
INSERT INTO `plugins` (`id`, `handle`, `version`, `schemaVersion`, `licenseKeyStatus`, `licensedEdition`, `installDate`, `dateCreated`, `dateUpdated`, `uid`) VALUES ('3', 'aws-s3', '1.2.5', '1.2', 'unknown', NULL, '2019-12-16 10:22:31', '2019-12-16 10:22:31', '2020-01-02 20:16:02', 'edaf1bae-8e07-428b-928c-3e9842ea8da5');
INSERT INTO `plugins` (`id`, `handle`, `version`, `schemaVersion`, `licenseKeyStatus`, `licensedEdition`, `installDate`, `dateCreated`, `dateUpdated`, `uid`) VALUES ('4', 'embeddedassets', '2.1.1.1', '1.0.0', 'unknown', NULL, '2019-12-16 10:22:35', '2019-12-16 10:22:35', '2020-01-02 20:16:02', '7607440e-824c-4c2e-88c1-0490519b6dbc');
INSERT INTO `plugins` (`id`, `handle`, `version`, `schemaVersion`, `licenseKeyStatus`, `licensedEdition`, `installDate`, `dateCreated`, `dateUpdated`, `uid`) VALUES ('5', 'fieldlabels', '1.1.8', '1.1.2', 'unknown', NULL, '2019-12-16 10:22:42', '2019-12-16 10:22:42', '2020-01-02 20:16:02', '33528037-4250-4394-bff6-3a85338f2cbc');
INSERT INTO `plugins` (`id`, `handle`, `version`, `schemaVersion`, `licenseKeyStatus`, `licensedEdition`, `installDate`, `dateCreated`, `dateUpdated`, `uid`) VALUES ('6', 'freeform', '3.5.8', '3.0.5', 'invalid', NULL, '2019-12-16 10:22:46', '2019-12-16 10:22:46', '2020-01-02 20:16:02', '55d5dcd8-5747-40e3-a0d9-f63f37919ae9');
INSERT INTO `plugins` (`id`, `handle`, `version`, `schemaVersion`, `licenseKeyStatus`, `licensedEdition`, `installDate`, `dateCreated`, `dateUpdated`, `uid`) VALUES ('7', 'neo', '2.5.9', '2.2.0', 'invalid', NULL, '2019-12-16 10:22:53', '2019-12-16 10:22:53', '2020-01-02 20:16:02', '6d9bbb64-ca31-43cc-a9d2-5408bd589aa7');
INSERT INTO `plugins` (`id`, `handle`, `version`, `schemaVersion`, `licenseKeyStatus`, `licensedEdition`, `installDate`, `dateCreated`, `dateUpdated`, `uid`) VALUES ('8', 'redactor', '2.4.0', '2.3.0', 'unknown', NULL, '2019-12-16 10:23:00', '2019-12-16 10:23:00', '2020-01-02 20:16:02', '8a70aa5c-f7e9-4632-869d-5cfca2cddc42');
INSERT INTO `plugins` (`id`, `handle`, `version`, `schemaVersion`, `licenseKeyStatus`, `licensedEdition`, `installDate`, `dateCreated`, `dateUpdated`, `uid`) VALUES ('9', 'seomatic', '3.2.37', '3.0.8', 'invalid', NULL, '2019-12-16 10:23:08', '2019-12-16 10:23:08', '2020-01-02 20:16:02', 'f0068ceb-0594-4b21-8ad1-5d4867a759e7');
INSERT INTO `plugins` (`id`, `handle`, `version`, `schemaVersion`, `licenseKeyStatus`, `licensedEdition`, `installDate`, `dateCreated`, `dateUpdated`, `uid`) VALUES ('10', 'supersort', '3.0.1', '0.0.0.0', 'unknown', NULL, '2019-12-16 10:23:29', '2019-12-16 10:23:29', '2020-01-02 20:16:02', '42d36641-0017-4c25-b699-b71c7db82c64');
INSERT INTO `plugins` (`id`, `handle`, `version`, `schemaVersion`, `licenseKeyStatus`, `licensedEdition`, `installDate`, `dateCreated`, `dateUpdated`, `uid`) VALUES ('11', 'super-table', '2.3.1', '2.2.1', 'unknown', NULL, '2019-12-16 10:23:38', '2019-12-16 10:23:38', '2020-01-02 20:16:02', 'e5788ff4-8404-4876-9203-2f5d131fd779');
INSERT INTO `plugins` (`id`, `handle`, `version`, `schemaVersion`, `licenseKeyStatus`, `licensedEdition`, `installDate`, `dateCreated`, `dateUpdated`, `uid`) VALUES ('12', 'tablemaker', '2.0.1', '1.0.0', 'unknown', NULL, '2019-12-16 10:23:43', '2019-12-16 10:23:43', '2020-01-02 20:16:02', '0c14431d-221f-4ae7-8d00-7d32dfa98df2');
INSERT INTO `plugins` (`id`, `handle`, `version`, `schemaVersion`, `licenseKeyStatus`, `licensedEdition`, `installDate`, `dateCreated`, `dateUpdated`, `uid`) VALUES ('13', 'typogrify', '1.1.18', '1.0.0', 'unknown', NULL, '2019-12-16 10:23:48', '2019-12-16 10:23:48', '2020-01-02 20:16:02', '924e5032-f766-4fa9-94af-82e6a9ff9e8a');
INSERT INTO `plugins` (`id`, `handle`, `version`, `schemaVersion`, `licenseKeyStatus`, `licensedEdition`, `installDate`, `dateCreated`, `dateUpdated`, `uid`) VALUES ('14', 'linkit', '1.1.11', '1.0.8', 'invalid', NULL, '2019-12-16 11:09:47', '2019-12-16 11:09:47', '2020-01-02 20:16:02', '1e1d1751-4a8e-4ac8-8c6c-d78503db57d1');
INSERT INTO `plugins` (`id`, `handle`, `version`, `schemaVersion`, `licenseKeyStatus`, `licensedEdition`, `installDate`, `dateCreated`, `dateUpdated`, `uid`) VALUES ('15', 'simplemap', '3.7.6', '3.4.2', 'unknown', NULL, '2019-12-16 11:19:09', '2019-12-16 11:19:09', '2020-01-02 20:16:02', 'f68c6ebe-aac6-48cd-9f50-5f757e587a07');
INSERT INTO `plugins` (`id`, `handle`, `version`, `schemaVersion`, `licenseKeyStatus`, `licensedEdition`, `installDate`, `dateCreated`, `dateUpdated`, `uid`) VALUES ('16', 'video-embedder', '1.1.4', '1.0.0', 'unknown', NULL, '2019-12-16 11:19:15', '2019-12-16 11:19:15', '2020-01-02 20:16:02', 'fb62aa22-3c96-4489-b408-13b4af1d2406');
INSERT INTO `plugins` (`id`, `handle`, `version`, `schemaVersion`, `licenseKeyStatus`, `licensedEdition`, `installDate`, `dateCreated`, `dateUpdated`, `uid`) VALUES ('17', 'imager', 'v2.3.0', '2.0.0', 'unknown', NULL, '2019-12-16 11:27:26', '2019-12-16 11:27:26', '2020-01-02 20:16:02', '62c13843-d437-4a05-8209-6d4f0ef9c64a');
INSERT INTO `plugins` (`id`, `handle`, `version`, `schemaVersion`, `licenseKeyStatus`, `licensedEdition`, `installDate`, `dateCreated`, `dateUpdated`, `uid`) VALUES ('18', 'entriessubset', '1.2.2', '1.1.1', 'invalid', NULL, '2019-12-16 20:59:12', '2019-12-16 20:59:12', '2020-01-02 20:16:02', 'f594cad3-30b3-41d2-93a2-7c29939a96d1');
INSERT INTO `plugins` (`id`, `handle`, `version`, `schemaVersion`, `licenseKeyStatus`, `licensedEdition`, `installDate`, `dateCreated`, `dateUpdated`, `uid`) VALUES ('19', 'classnames', '1.0.0', '1.0.0', 'unknown', NULL, '2019-12-17 13:46:32', '2019-12-17 13:46:32', '2020-01-02 20:16:02', '403956dd-a902-476c-84cc-5f5b4763f35b');

INSERT INTO `resourcepaths` (`hash`, `path`) VALUES ('14ab9da0', '@verbb/supertable/resources/dist');
INSERT INTO `resourcepaths` (`hash`, `path`) VALUES ('1560f82d', '@lib/jquery.payment');
INSERT INTO `resourcepaths` (`hash`, `path`) VALUES ('1632d33', '@craft/web/assets/recententries/dist');
INSERT INTO `resourcepaths` (`hash`, `path`) VALUES ('17124691', '@app/web/assets/tablesettings/dist');
INSERT INTO `resourcepaths` (`hash`, `path`) VALUES ('18c8a0b8', '@bower/jquery/dist');
INSERT INTO `resourcepaths` (`hash`, `path`) VALUES ('1bd95b27', '@fruitstudios/linkit/assetbundles/field/build');
INSERT INTO `resourcepaths` (`hash`, `path`) VALUES ('1c6b7eb1', '@nystudio107/seomatic/assetbundles/seomatic/dist');
INSERT INTO `resourcepaths` (`hash`, `path`) VALUES ('1d1162e5', '@craft/web/assets/editentry/dist');
INSERT INTO `resourcepaths` (`hash`, `path`) VALUES ('1dee341a', '@lib/fabric');
INSERT INTO `resourcepaths` (`hash`, `path`) VALUES ('1e3828ce', '@app/web/assets/utilities/dist');
INSERT INTO `resourcepaths` (`hash`, `path`) VALUES ('1e9c6fdf', '@app/web/assets/dashboard/dist');
INSERT INTO `resourcepaths` (`hash`, `path`) VALUES ('227d4389', '@craft/web/assets/matrixsettings/dist');
INSERT INTO `resourcepaths` (`hash`, `path`) VALUES ('23889385', '@lib/selectize');
INSERT INTO `resourcepaths` (`hash`, `path`) VALUES ('25a7b6cc', '@craft/web/assets/cp/dist');
INSERT INTO `resourcepaths` (`hash`, `path`) VALUES ('29e4d70f', '@lib/xregexp');
INSERT INTO `resourcepaths` (`hash`, `path`) VALUES ('2d58d60d', '@lib/fileupload');
INSERT INTO `resourcepaths` (`hash`, `path`) VALUES ('3214eb31', '@lib/jquery-touch-events');
INSERT INTO `resourcepaths` (`hash`, `path`) VALUES ('3492758e', '@app/web/assets/matrixsettings/dist');
INSERT INTO `resourcepaths` (`hash`, `path`) VALUES ('35b0d7f3', '@lib/picturefill');
INSERT INTO `resourcepaths` (`hash`, `path`) VALUES ('37580b4d', '@lib/element-resize-detector');
INSERT INTO `resourcepaths` (`hash`, `path`) VALUES ('382d685b', '@craft/awss3/resources');
INSERT INTO `resourcepaths` (`hash`, `path`) VALUES ('3a2b3499', '@lib/datepicker-i18n');
INSERT INTO `resourcepaths` (`hash`, `path`) VALUES ('3b15f7a2', '@lib/d3');
INSERT INTO `resourcepaths` (`hash`, `path`) VALUES ('3b6736f7', '@Solspace/Freeform/Resources');
INSERT INTO `resourcepaths` (`hash`, `path`) VALUES ('3c6a051f', '@vendor/craftcms/redactor/lib/redactor-plugins/fullscreen');
INSERT INTO `resourcepaths` (`hash`, `path`) VALUES ('3db7a0e5', '@craft/web/assets/dashboard/dist');
INSERT INTO `resourcepaths` (`hash`, `path`) VALUES ('3fd96f5d', '@craft/web/assets/updateswidget/dist');
INSERT INTO `resourcepaths` (`hash`, `path`) VALUES ('44f4862e', '@craft/web/assets/feed/dist');
INSERT INTO `resourcepaths` (`hash`, `path`) VALUES ('466ffb3', '@craft/web/assets/updates/dist');
INSERT INTO `resourcepaths` (`hash`, `path`) VALUES ('47eecc60', '@lib/jquery-ui');
INSERT INTO `resourcepaths` (`hash`, `path`) VALUES ('4aee89d6', '@lib/garnishjs');
INSERT INTO `resourcepaths` (`hash`, `path`) VALUES ('4b9a73ed', '@nfourtythree/entriessubset/assetbundles/entriessubsetasset/dist');
INSERT INTO `resourcepaths` (`hash`, `path`) VALUES ('4d398c29', '@lib/axios');
INSERT INTO `resourcepaths` (`hash`, `path`) VALUES ('4fe15d83', '@app/web/assets/updater/dist');
INSERT INTO `resourcepaths` (`hash`, `path`) VALUES ('5126a37d', '@app/web/assets/craftsupport/dist');
INSERT INTO `resourcepaths` (`hash`, `path`) VALUES ('52427b40', '@ether/simplemap/web/assets/map');
INSERT INTO `resourcepaths` (`hash`, `path`) VALUES ('55821e1', '@app/web/assets/feed/dist');
INSERT INTO `resourcepaths` (`hash`, `path`) VALUES ('5623d86d', '@verbb/navigation/resources/dist');
INSERT INTO `resourcepaths` (`hash`, `path`) VALUES ('59507dd1', '@craft/web/assets/plugins/dist');
INSERT INTO `resourcepaths` (`hash`, `path`) VALUES ('5fa85de8', '@lib/fabric');
INSERT INTO `resourcepaths` (`hash`, `path`) VALUES ('5fb40fbc', '@app/web/assets/updateswidget/dist');
INSERT INTO `resourcepaths` (`hash`, `path`) VALUES ('60d22f5c', '@lib/vue');
INSERT INTO `resourcepaths` (`hash`, `path`) VALUES ('610e4dd2', '@app/web/assets/recententries/dist');
INSERT INTO `resourcepaths` (`hash`, `path`) VALUES ('61cefa77', '@lib/selectize');
INSERT INTO `resourcepaths` (`hash`, `path`) VALUES ('6ba2befd', '@lib/xregexp');
INSERT INTO `resourcepaths` (`hash`, `path`) VALUES ('6f1ebfff', '@lib/fileupload');
INSERT INTO `resourcepaths` (`hash`, `path`) VALUES ('705282c3', '@lib/jquery-touch-events');
INSERT INTO `resourcepaths` (`hash`, `path`) VALUES ('73e70ca7', '@craft/web/assets/login/dist');
INSERT INTO `resourcepaths` (`hash`, `path`) VALUES ('7612df0c', '@app/web/assets/edituser/dist');
INSERT INTO `resourcepaths` (`hash`, `path`) VALUES ('77f6be01', '@lib/picturefill');
INSERT INTO `resourcepaths` (`hash`, `path`) VALUES ('781bbbe2', '@fruitstudios/linkit/assetbundles/fieldsettings/build');
INSERT INTO `resourcepaths` (`hash`, `path`) VALUES ('786d5d6b', '@lib/datepicker-i18n');
INSERT INTO `resourcepaths` (`hash`, `path`) VALUES ('787d7f21', '@app/web/assets/login/dist');
INSERT INTO `resourcepaths` (`hash`, `path`) VALUES ('79539e50', '@lib/d3');
INSERT INTO `resourcepaths` (`hash`, `path`) VALUES ('7be1bb6a', '@craft/web/assets/craftsupport/dist');
INSERT INTO `resourcepaths` (`hash`, `path`) VALUES ('7c436a5f', '@app/web/assets/cp/dist');
INSERT INTO `resourcepaths` (`hash`, `path`) VALUES ('7f558e06', '@craft/web/assets/utilities/dist');
INSERT INTO `resourcepaths` (`hash`, `path`) VALUES ('81bab86f', '@vendor/craftcms/redactor/lib/redactor');
INSERT INTO `resourcepaths` (`hash`, `path`) VALUES ('8a06b6c', '@craft/web/assets/updater/dist');
INSERT INTO `resourcepaths` (`hash`, `path`) VALUES ('8a8e024', '@lib/garnishjs');
INSERT INTO `resourcepaths` (`hash`, `path`) VALUES ('8c8a9dc1', '@lib/fileupload');
INSERT INTO `resourcepaths` (`hash`, `path`) VALUES ('90732e99', '@craft/web/assets/login/dist');
INSERT INTO `resourcepaths` (`hash`, `path`) VALUES ('9140aa74', '@lib/prismjs');
INSERT INTO `resourcepaths` (`hash`, `path`) VALUES ('93c6a0fd', '@lib/jquery-touch-events');
INSERT INTO `resourcepaths` (`hash`, `path`) VALUES ('94629c3f', '@lib/picturefill');
INSERT INTO `resourcepaths` (`hash`, `path`) VALUES ('94757c5', '@lib/velocity');
INSERT INTO `resourcepaths` (`hash`, `path`) VALUES ('94eb044e', '@craft/web/assets/tablesettings/dist');
INSERT INTO `resourcepaths` (`hash`, `path`) VALUES ('968a4081', '@lib/element-resize-detector');
INSERT INTO `resourcepaths` (`hash`, `path`) VALUES ('98759954', '@craft/web/assets/craftsupport/dist');
INSERT INTO `resourcepaths` (`hash`, `path`) VALUES ('99ba5cbd', '@supercool/tablemaker/assetbundles/field/dist');
INSERT INTO `resourcepaths` (`hash`, `path`) VALUES ('9ac7bc6e', '@lib/d3');
INSERT INTO `resourcepaths` (`hash`, `path`) VALUES ('9cc1ac38', '@craft/web/assets/utilities/dist');
INSERT INTO `resourcepaths` (`hash`, `path`) VALUES ('9fe8e613', '@app/web/assets/editentry/dist');
INSERT INTO `resourcepaths` (`hash`, `path`) VALUES ('a0b3eb62', '@app/web/assets/updates/dist');
INSERT INTO `resourcepaths` (`hash`, `path`) VALUES ('a24259a', '@simplemap/web/assets/map');
INSERT INTO `resourcepaths` (`hash`, `path`) VALUES ('a47aee5e', '@lib/jquery-ui');
INSERT INTO `resourcepaths` (`hash`, `path`) VALUES ('a48a6a2d', '@app/web/assets/feed/dist');
INSERT INTO `resourcepaths` (`hash`, `path`) VALUES ('a760a410', '@craft/web/assets/feed/dist');
INSERT INTO `resourcepaths` (`hash`, `path`) VALUES ('a8951c09', '@lib/velocity');
INSERT INTO `resourcepaths` (`hash`, `path`) VALUES ('a97aabe8', '@lib/garnishjs');
INSERT INTO `resourcepaths` (`hash`, `path`) VALUES ('aeadae17', '@lib/axios');
INSERT INTO `resourcepaths` (`hash`, `path`) VALUES ('b3ffff9', '@vendor/craftcms/redactor/lib/redactor-plugins/video');
INSERT INTO `resourcepaths` (`hash`, `path`) VALUES ('b41e2d00', '@spicyweb/embeddedassets/resources');
INSERT INTO `resourcepaths` (`hash`, `path`) VALUES ('b4b2b3e1', '@lib/jquery.payment');
INSERT INTO `resourcepaths` (`hash`, `path`) VALUES ('b8290a5d', '@app/web/assets/fields/dist');
INSERT INTO `resourcepaths` (`hash`, `path`) VALUES ('b91aeb74', '@bower/jquery/dist');
INSERT INTO `resourcepaths` (`hash`, `path`) VALUES ('bc3c7fd6', '@lib/fabric');
INSERT INTO `resourcepaths` (`hash`, `path`) VALUES ('bcda975d', '@craft/web/assets/graphiql/dist');
INSERT INTO `resourcepaths` (`hash`, `path`) VALUES ('bcf9b63b', '@craft/web/assets/fields/dist');
INSERT INTO `resourcepaths` (`hash`, `path`) VALUES ('bf4e2413', '@app/web/assets/dashboard/dist');
INSERT INTO `resourcepaths` (`hash`, `path`) VALUES ('c01cb1bb', '@lib/selectize');
INSERT INTO `resourcepaths` (`hash`, `path`) VALUES ('c0dc061e', '@app/web/assets/recententries/dist');
INSERT INTO `resourcepaths` (`hash`, `path`) VALUES ('c63394f2', '@craft/web/assets/cp/dist');
INSERT INTO `resourcepaths` (`hash`, `path`) VALUES ('c9967690', '@spicyweb/fieldlabels/resources');
INSERT INTO `resourcepaths` (`hash`, `path`) VALUES ('ca70f531', '@lib/xregexp');
INSERT INTO `resourcepaths` (`hash`, `path`) VALUES ('cf48a48f', '@craft/web/assets/pluginstore/dist');
INSERT INTO `resourcepaths` (`hash`, `path`) VALUES ('d4cc2973', '@lib/element-resize-detector');
INSERT INTO `resourcepaths` (`hash`, `path`) VALUES ('d9af34ed', '@app/web/assets/login/dist');
INSERT INTO `resourcepaths` (`hash`, `path`) VALUES ('d9bf16a7', '@lib/datepicker-i18n');
INSERT INTO `resourcepaths` (`hash`, `path`) VALUES ('dc4d4d63', '@craft/web/assets/updateswidget/dist');
INSERT INTO `resourcepaths` (`hash`, `path`) VALUES ('dd912193', '@app/web/assets/cp/dist');
INSERT INTO `resourcepaths` (`hash`, `path`) VALUES ('de2382db', '@craft/web/assets/dashboard/dist');
INSERT INTO `resourcepaths` (`hash`, `path`) VALUES ('e2f70f0d', '@craft/web/assets/recententries/dist');
INSERT INTO `resourcepaths` (`hash`, `path`) VALUES ('e63c87ac', '@lib/jquery-ui');
INSERT INTO `resourcepaths` (`hash`, `path`) VALUES ('e7f2dd8d', '@craft/web/assets/updates/dist');
INSERT INTO `resourcepaths` (`hash`, `path`) VALUES ('e84fbb50', '@spicyweb/fieldlabels/resources/js');
INSERT INTO `resourcepaths` (`hash`, `path`) VALUES ('ead375fb', '@lib/velocity');
INSERT INTO `resourcepaths` (`hash`, `path`) VALUES ('ecebc7e5', '@lib/axios');
INSERT INTO `resourcepaths` (`hash`, `path`) VALUES ('f0f4e8b1', '@app/web/assets/craftsupport/dist');
INSERT INTO `resourcepaths` (`hash`, `path`) VALUES ('f58fad44', '@lib/timepicker');
INSERT INTO `resourcepaths` (`hash`, `path`) VALUES ('f6f4da13', '@lib/jquery.payment');
INSERT INTO `resourcepaths` (`hash`, `path`) VALUES ('f7baa238', '@app/web/assets/editsection/dist');
INSERT INTO `resourcepaths` (`hash`, `path`) VALUES ('fb5c8286', '@bower/jquery/dist');
INSERT INTO `resourcepaths` (`hash`, `path`) VALUES ('fce025ef', '@craft/redactor/assets/field/dist');
INSERT INTO `resourcepaths` (`hash`, `path`) VALUES ('fd856900', '@app/web/assets/plugins/dist');
INSERT INTO `resourcepaths` (`hash`, `path`) VALUES ('fe664470', '@app/web/assets/updateswidget/dist');
INSERT INTO `resourcepaths` (`hash`, `path`) VALUES ('ff756203', '@benf/neo/resources');

INSERT INTO `revisions` (`id`, `sourceId`, `creatorId`, `num`, `notes`) VALUES ('1', '3', '1', '1', NULL);
INSERT INTO `revisions` (`id`, `sourceId`, `creatorId`, `num`, `notes`) VALUES ('2', '6', '1', '1', NULL);
INSERT INTO `revisions` (`id`, `sourceId`, `creatorId`, `num`, `notes`) VALUES ('3', '9', '1', '1', NULL);
INSERT INTO `revisions` (`id`, `sourceId`, `creatorId`, `num`, `notes`) VALUES ('4', '16', '1', '1', NULL);
INSERT INTO `revisions` (`id`, `sourceId`, `creatorId`, `num`, `notes`) VALUES ('5', '16', '1', '2', NULL);
INSERT INTO `revisions` (`id`, `sourceId`, `creatorId`, `num`, `notes`) VALUES ('6', '19', '1', '1', NULL);
INSERT INTO `revisions` (`id`, `sourceId`, `creatorId`, `num`, `notes`) VALUES ('7', '19', '1', '2', NULL);
INSERT INTO `revisions` (`id`, `sourceId`, `creatorId`, `num`, `notes`) VALUES ('8', '19', '1', '3', NULL);
INSERT INTO `revisions` (`id`, `sourceId`, `creatorId`, `num`, `notes`) VALUES ('9', '19', '1', '4', NULL);
INSERT INTO `revisions` (`id`, `sourceId`, `creatorId`, `num`, `notes`) VALUES ('10', '16', '1', '3', NULL);

INSERT INTO `searchindex` (`elementId`, `attribute`, `fieldId`, `siteId`, `keywords`) VALUES ('1', 'email', '0', '2', ' support fostercommerce com ');
INSERT INTO `searchindex` (`elementId`, `attribute`, `fieldId`, `siteId`, `keywords`) VALUES ('1', 'firstname', '0', '2', ' foster commerce ');
INSERT INTO `searchindex` (`elementId`, `attribute`, `fieldId`, `siteId`, `keywords`) VALUES ('1', 'fullname', '0', '2', ' foster commerce support ');
INSERT INTO `searchindex` (`elementId`, `attribute`, `fieldId`, `siteId`, `keywords`) VALUES ('1', 'lastname', '0', '2', ' support ');
INSERT INTO `searchindex` (`elementId`, `attribute`, `fieldId`, `siteId`, `keywords`) VALUES ('1', 'slug', '0', '2', '');
INSERT INTO `searchindex` (`elementId`, `attribute`, `fieldId`, `siteId`, `keywords`) VALUES ('1', 'username', '0', '2', ' support fostercommerce com ');
INSERT INTO `searchindex` (`elementId`, `attribute`, `fieldId`, `siteId`, `keywords`) VALUES ('3', 'field', '8', '2', '');
INSERT INTO `searchindex` (`elementId`, `attribute`, `fieldId`, `siteId`, `keywords`) VALUES ('3', 'field', '21', '2', '');
INSERT INTO `searchindex` (`elementId`, `attribute`, `fieldId`, `siteId`, `keywords`) VALUES ('3', 'field', '27', '2', '');
INSERT INTO `searchindex` (`elementId`, `attribute`, `fieldId`, `siteId`, `keywords`) VALUES ('3', 'field', '30', '2', '');
INSERT INTO `searchindex` (`elementId`, `attribute`, `fieldId`, `siteId`, `keywords`) VALUES ('3', 'slug', '0', '2', ' about us ');
INSERT INTO `searchindex` (`elementId`, `attribute`, `fieldId`, `siteId`, `keywords`) VALUES ('3', 'title', '0', '2', ' about us ');
INSERT INTO `searchindex` (`elementId`, `attribute`, `fieldId`, `siteId`, `keywords`) VALUES ('6', 'field', '8', '2', '');
INSERT INTO `searchindex` (`elementId`, `attribute`, `fieldId`, `siteId`, `keywords`) VALUES ('6', 'field', '21', '2', '');
INSERT INTO `searchindex` (`elementId`, `attribute`, `fieldId`, `siteId`, `keywords`) VALUES ('6', 'field', '27', '2', '');
INSERT INTO `searchindex` (`elementId`, `attribute`, `fieldId`, `siteId`, `keywords`) VALUES ('6', 'slug', '0', '2', ' news ');
INSERT INTO `searchindex` (`elementId`, `attribute`, `fieldId`, `siteId`, `keywords`) VALUES ('6', 'title', '0', '2', ' news ');
INSERT INTO `searchindex` (`elementId`, `attribute`, `fieldId`, `siteId`, `keywords`) VALUES ('9', 'field', '8', '2', '');
INSERT INTO `searchindex` (`elementId`, `attribute`, `fieldId`, `siteId`, `keywords`) VALUES ('9', 'field', '21', '2', '');
INSERT INTO `searchindex` (`elementId`, `attribute`, `fieldId`, `siteId`, `keywords`) VALUES ('9', 'field', '27', '2', '');
INSERT INTO `searchindex` (`elementId`, `attribute`, `fieldId`, `siteId`, `keywords`) VALUES ('9', 'field', '30', '2', '');
INSERT INTO `searchindex` (`elementId`, `attribute`, `fieldId`, `siteId`, `keywords`) VALUES ('9', 'slug', '0', '2', ' contact ');
INSERT INTO `searchindex` (`elementId`, `attribute`, `fieldId`, `siteId`, `keywords`) VALUES ('9', 'title', '0', '2', ' contact ');
INSERT INTO `searchindex` (`elementId`, `attribute`, `fieldId`, `siteId`, `keywords`) VALUES ('11', 'slug', '0', '2', ' 2 ');
INSERT INTO `searchindex` (`elementId`, `attribute`, `fieldId`, `siteId`, `keywords`) VALUES ('11', 'title', '0', '2', ' about us ');
INSERT INTO `searchindex` (`elementId`, `attribute`, `fieldId`, `siteId`, `keywords`) VALUES ('12', 'slug', '0', '2', ' 2 ');
INSERT INTO `searchindex` (`elementId`, `attribute`, `fieldId`, `siteId`, `keywords`) VALUES ('12', 'title', '0', '2', ' news ');
INSERT INTO `searchindex` (`elementId`, `attribute`, `fieldId`, `siteId`, `keywords`) VALUES ('13', 'slug', '0', '2', ' 2 ');
INSERT INTO `searchindex` (`elementId`, `attribute`, `fieldId`, `siteId`, `keywords`) VALUES ('13', 'title', '0', '2', ' contact ');
INSERT INTO `searchindex` (`elementId`, `attribute`, `fieldId`, `siteId`, `keywords`) VALUES ('14', 'field', '26', '2', ' 14 2 26 15 ');
INSERT INTO `searchindex` (`elementId`, `attribute`, `fieldId`, `siteId`, `keywords`) VALUES ('14', 'field', '32', '2', '');
INSERT INTO `searchindex` (`elementId`, `attribute`, `fieldId`, `siteId`, `keywords`) VALUES ('14', 'field', '39', '2', '');
INSERT INTO `searchindex` (`elementId`, `attribute`, `fieldId`, `siteId`, `keywords`) VALUES ('14', 'field', '40', '2', '');
INSERT INTO `searchindex` (`elementId`, `attribute`, `fieldId`, `siteId`, `keywords`) VALUES ('14', 'slug', '0', '2', '');
INSERT INTO `searchindex` (`elementId`, `attribute`, `fieldId`, `siteId`, `keywords`) VALUES ('15', 'field', '27', '2', '');
INSERT INTO `searchindex` (`elementId`, `attribute`, `fieldId`, `siteId`, `keywords`) VALUES ('15', 'field', '35', '2', '');
INSERT INTO `searchindex` (`elementId`, `attribute`, `fieldId`, `siteId`, `keywords`) VALUES ('15', 'slug', '0', '2', '');
INSERT INTO `searchindex` (`elementId`, `attribute`, `fieldId`, `siteId`, `keywords`) VALUES ('16', 'field', '8', '2', '');
INSERT INTO `searchindex` (`elementId`, `attribute`, `fieldId`, `siteId`, `keywords`) VALUES ('16', 'field', '21', '2', '');
INSERT INTO `searchindex` (`elementId`, `attribute`, `fieldId`, `siteId`, `keywords`) VALUES ('16', 'field', '27', '2', '');
INSERT INTO `searchindex` (`elementId`, `attribute`, `fieldId`, `siteId`, `keywords`) VALUES ('16', 'field', '30', '2', ' blue large medium left my header text h1 white huge left lorem ipsum dolor sit amet consectetur adipiscing elit vestibulum vestibulum tincidunt libero eu ornare eros mattis et white medium white medium medium left heading here h2 black medium left lorem ipsum dolor sit amet consectetur adipiscing elit vestibulum vestibulum tincidunt libero eu ornare eros mattis et in pellentesque volutpat libero tempor congue enim venenatis quis aenean cursus convallis lacus sit amet sodales suspendisse potenti donec pellentesque neque non feugiat interdum etiam eget fermentum ipsum proin sapien orci lacinia vel lectus quis pulvinar vestibulum purus integer est diam imperdiet sed lacus a efficitur interdum eros duis dignissim dui nisi nec ullamcorper enim facilisis in nulla mattis lobortis mauris a interdum erat pulvinar at curabitur sagittis odio non enim luctus hendrerit nullam id venenatis odio praesent purus lacus cursus id laoreet non aliquet sit amet nisl curabitur vulputate condimentum neque vestibulum pretium sed magna non suscipit aliquam varius risus nec ipsum feugiat ac sodales risus blandit vivamus eu leo ac nibh venenatis fringilla vestibulum sed erat scelerisque interdum mauris quis vulputate dui mauris libero lectus venenatis sit amet lectus suscipit laoreet dignissim neque pellentesque felis mi imperdiet vel maximus vitae cursus id turpis maecenas lacinia metus aliquet bibendum justo sit amet tincidunt magna mauris finibus magna ex eget accumsan ipsum consectetur at ut tristique massa sapien et lacinia est facilisis non integer non nibh justo suspendisse ornare urna sit amet arcu finibus id tristique mi sodales vivamus vel orci ac eros pellentesque egestas porttitor nec lacus black medium ');
INSERT INTO `searchindex` (`elementId`, `attribute`, `fieldId`, `siteId`, `keywords`) VALUES ('16', 'slug', '0', '2', ' homepage ');
INSERT INTO `searchindex` (`elementId`, `attribute`, `fieldId`, `siteId`, `keywords`) VALUES ('16', 'title', '0', '2', ' homepage ');
INSERT INTO `searchindex` (`elementId`, `attribute`, `fieldId`, `siteId`, `keywords`) VALUES ('19', 'field', '8', '2', '');
INSERT INTO `searchindex` (`elementId`, `attribute`, `fieldId`, `siteId`, `keywords`) VALUES ('19', 'field', '21', '2', '');
INSERT INTO `searchindex` (`elementId`, `attribute`, `fieldId`, `siteId`, `keywords`) VALUES ('19', 'field', '27', '2', '');
INSERT INTO `searchindex` (`elementId`, `attribute`, `fieldId`, `siteId`, `keywords`) VALUES ('19', 'field', '30', '2', '');
INSERT INTO `searchindex` (`elementId`, `attribute`, `fieldId`, `siteId`, `keywords`) VALUES ('19', 'slug', '0', '2', ' page not found ');
INSERT INTO `searchindex` (`elementId`, `attribute`, `fieldId`, `siteId`, `keywords`) VALUES ('19', 'title', '0', '2', ' page not found ');
INSERT INTO `searchindex` (`elementId`, `attribute`, `fieldId`, `siteId`, `keywords`) VALUES ('24', 'field', '27', '2', '');
INSERT INTO `searchindex` (`elementId`, `attribute`, `fieldId`, `siteId`, `keywords`) VALUES ('24', 'slug', '0', '2', '');
INSERT INTO `searchindex` (`elementId`, `attribute`, `fieldId`, `siteId`, `keywords`) VALUES ('25', 'field', '3', '2', ' my header text ');
INSERT INTO `searchindex` (`elementId`, `attribute`, `fieldId`, `siteId`, `keywords`) VALUES ('25', 'slug', '0', '2', '');
INSERT INTO `searchindex` (`elementId`, `attribute`, `fieldId`, `siteId`, `keywords`) VALUES ('26', 'field', '4', '2', ' lorem ipsum dolor sit amet consectetur adipiscing elit vestibulum vestibulum tincidunt libero eu ornare eros mattis et ');
INSERT INTO `searchindex` (`elementId`, `attribute`, `fieldId`, `siteId`, `keywords`) VALUES ('26', 'slug', '0', '2', '');
INSERT INTO `searchindex` (`elementId`, `attribute`, `fieldId`, `siteId`, `keywords`) VALUES ('27', 'field', '27', '2', '');
INSERT INTO `searchindex` (`elementId`, `attribute`, `fieldId`, `siteId`, `keywords`) VALUES ('27', 'slug', '0', '2', '');
INSERT INTO `searchindex` (`elementId`, `attribute`, `fieldId`, `siteId`, `keywords`) VALUES ('28', 'field', '3', '2', ' heading here ');
INSERT INTO `searchindex` (`elementId`, `attribute`, `fieldId`, `siteId`, `keywords`) VALUES ('28', 'slug', '0', '2', '');
INSERT INTO `searchindex` (`elementId`, `attribute`, `fieldId`, `siteId`, `keywords`) VALUES ('29', 'field', '4', '2', ' lorem ipsum dolor sit amet consectetur adipiscing elit vestibulum vestibulum tincidunt libero eu ornare eros mattis et in pellentesque volutpat libero tempor congue enim venenatis quis aenean cursus convallis lacus sit amet sodales suspendisse potenti donec pellentesque neque non feugiat interdum etiam eget fermentum ipsum proin sapien orci lacinia vel lectus quis pulvinar vestibulum purus integer est diam imperdiet sed lacus a efficitur interdum eros duis dignissim dui nisi nec ullamcorper enim facilisis in nulla mattis lobortis mauris a interdum erat pulvinar at curabitur sagittis odio non enim luctus hendrerit nullam id venenatis odio praesent purus lacus cursus id laoreet non aliquet sit amet nisl curabitur vulputate condimentum neque vestibulum pretium sed magna non suscipit aliquam varius risus nec ipsum feugiat ac sodales risus blandit vivamus eu leo ac nibh venenatis fringilla vestibulum sed erat scelerisque interdum mauris quis vulputate dui mauris libero lectus venenatis sit amet lectus suscipit laoreet dignissim neque pellentesque felis mi imperdiet vel maximus vitae cursus id turpis maecenas lacinia metus aliquet bibendum justo sit amet tincidunt magna mauris finibus magna ex eget accumsan ipsum consectetur at ut tristique massa sapien et lacinia est facilisis non integer non nibh justo suspendisse ornare urna sit amet arcu finibus id tristique mi sodales vivamus vel orci ac eros pellentesque egestas porttitor nec lacus ');
INSERT INTO `searchindex` (`elementId`, `attribute`, `fieldId`, `siteId`, `keywords`) VALUES ('29', 'slug', '0', '2', '');

INSERT INTO `sections` (`id`, `structureId`, `name`, `handle`, `type`, `enableVersioning`, `propagationMethod`, `previewTargets`, `dateCreated`, `dateUpdated`, `dateDeleted`, `uid`) VALUES ('1', '2', 'Pages', 'pages', 'structure', '1', 'all', NULL, '2019-12-16 09:53:47', '2019-12-17 00:45:52', NULL, '2e7aaa5a-bc25-4e9a-8efd-dd29ee0fcec2');
INSERT INTO `sections` (`id`, `structureId`, `name`, `handle`, `type`, `enableVersioning`, `propagationMethod`, `previewTargets`, `dateCreated`, `dateUpdated`, `dateDeleted`, `uid`) VALUES ('2', NULL, 'News', 'news', 'channel', '1', 'all', NULL, '2019-12-16 21:04:58', '2019-12-16 21:20:36', NULL, 'eef60044-7c15-4709-90ea-0c8035e7b0cd');
INSERT INTO `sections` (`id`, `structureId`, `name`, `handle`, `type`, `enableVersioning`, `propagationMethod`, `previewTargets`, `dateCreated`, `dateUpdated`, `dateDeleted`, `uid`) VALUES ('3', NULL, 'Homepage', 'homepage', 'single', '1', 'all', NULL, '2019-12-16 21:21:32', '2019-12-16 21:22:54', NULL, '1e3c4cbe-0bc4-42ec-85db-1b75ad0e2492');
INSERT INTO `sections` (`id`, `structureId`, `name`, `handle`, `type`, `enableVersioning`, `propagationMethod`, `previewTargets`, `dateCreated`, `dateUpdated`, `dateDeleted`, `uid`) VALUES ('4', NULL, 'Page Not Found', 'pageNotFound', 'single', '1', 'all', NULL, '2019-12-16 21:26:21', '2019-12-16 21:28:07', NULL, '5994676d-ccf0-4430-a764-e4e059e1b605');

INSERT INTO `sections_sites` (`id`, `sectionId`, `siteId`, `hasUrls`, `uriFormat`, `template`, `enabledByDefault`, `dateCreated`, `dateUpdated`, `uid`) VALUES ('1', '1', '2', '1', '{parent.uri}/{slug}', 'page/_type', '1', '2019-12-16 09:53:47', '2019-12-17 00:45:52', 'eee6e3a3-f240-4d9d-a3f3-e0b39e299527');
INSERT INTO `sections_sites` (`id`, `sectionId`, `siteId`, `hasUrls`, `uriFormat`, `template`, `enabledByDefault`, `dateCreated`, `dateUpdated`, `uid`) VALUES ('2', '2', '2', '1', 'news/{slug}', 'news/_entry', '1', '2019-12-16 21:04:58', '2019-12-16 21:20:36', '8243661d-dd28-4fbe-a950-6af2ca6c88bf');
INSERT INTO `sections_sites` (`id`, `sectionId`, `siteId`, `hasUrls`, `uriFormat`, `template`, `enabledByDefault`, `dateCreated`, `dateUpdated`, `uid`) VALUES ('3', '3', '2', '1', '__home__', 'index', '1', '2019-12-16 21:21:32', '2019-12-16 21:22:54', '40e7124d-5fa9-463d-8a0e-d60533c3c10a');
INSERT INTO `sections_sites` (`id`, `sectionId`, `siteId`, `hasUrls`, `uriFormat`, `template`, `enabledByDefault`, `dateCreated`, `dateUpdated`, `uid`) VALUES ('4', '4', '2', '1', 'page-not-found', '404', '1', '2019-12-16 21:26:21', '2019-12-16 21:28:07', 'affb1f7b-e173-4a05-9c97-51fc7b75921a');

INSERT INTO `seomatic_metabundles` (`id`, `dateCreated`, `dateUpdated`, `uid`, `bundleVersion`, `sourceBundleType`, `sourceId`, `sourceName`, `sourceHandle`, `sourceType`, `sourceTemplate`, `sourceSiteId`, `sourceAltSiteSettings`, `sourceDateUpdated`, `metaGlobalVars`, `metaSiteVars`, `metaSitemapVars`, `metaContainers`, `redirectsContainer`, `frontendTemplatesContainer`, `metaBundleSettings`) VALUES ('1', '2019-12-16 10:23:08', '2019-12-16 21:36:55', '5cd68b35-ccd5-4695-9035-fe091c2d4a22', '1.0.46', '__GLOBAL_BUNDLE__', '1', '__GLOBAL_BUNDLE__', '__GLOBAL_BUNDLE__', '__GLOBAL_BUNDLE__', '', '2', '[]', '2019-12-16 21:36:55', '{\"language\":null,\"mainEntityOfPage\":\"WebSite\",\"seoTitle\":\"\",\"siteNamePosition\":\"after\",\"seoDescription\":\"\",\"seoKeywords\":\"\",\"seoImage\":\"\",\"seoImageWidth\":\"\",\"seoImageHeight\":\"\",\"seoImageDescription\":\"\",\"canonicalUrl\":\"{seomatic.helper.safeCanonicalUrl()}\",\"robots\":\"all\",\"ogType\":\"website\",\"ogTitle\":\"{seomatic.meta.seoTitle}\",\"ogSiteNamePosition\":\"none\",\"ogDescription\":\"{seomatic.meta.seoDescription}\",\"ogImage\":\"\",\"ogImageWidth\":\"\",\"ogImageHeight\":\"\",\"ogImageDescription\":\"{seomatic.meta.seoImageDescription}\",\"twitterCard\":\"summary\",\"twitterCreator\":\"{seomatic.site.twitterHandle}\",\"twitterTitle\":\"{seomatic.meta.seoTitle}\",\"twitterSiteNamePosition\":\"none\",\"twitterDescription\":\"{seomatic.meta.seoDescription}\",\"twitterImage\":\"\",\"twitterImageWidth\":\"\",\"twitterImageHeight\":\"\",\"twitterImageDescription\":\"{seomatic.meta.seoImageDescription}\"}', '{\"siteName\":\"FWORK Plus\",\"identity\":{\"siteType\":\"Organization\",\"siteSubType\":\"LocalBusiness\",\"siteSpecificType\":\"\",\"computedType\":\"Organization\",\"genericName\":\"\",\"genericAlternateName\":\"\",\"genericDescription\":\"\",\"genericUrl\":\"\",\"genericImage\":\"\",\"genericImageWidth\":\"\",\"genericImageHeight\":\"\",\"genericImageIds\":[],\"genericTelephone\":\"\",\"genericEmail\":\"\",\"genericStreetAddress\":\"\",\"genericAddressLocality\":\"\",\"genericAddressRegion\":\"\",\"genericPostalCode\":\"\",\"genericAddressCountry\":\"\",\"genericGeoLatitude\":\"\",\"genericGeoLongitude\":\"\",\"personGender\":\"\",\"personBirthPlace\":\"\",\"organizationDuns\":\"\",\"organizationFounder\":\"\",\"organizationFoundingDate\":\"\",\"organizationFoundingLocation\":\"\",\"organizationContactPoints\":[],\"corporationTickerSymbol\":\"\",\"localBusinessPriceRange\":\"\",\"localBusinessOpeningHours\":[],\"restaurantServesCuisine\":\"\",\"restaurantMenuUrl\":\"\",\"restaurantReservationsUrl\":\"\"},\"creator\":{\"siteType\":\"Organization\",\"siteSubType\":\"LocalBusiness\",\"siteSpecificType\":\"\",\"computedType\":\"Organization\",\"genericName\":\"\",\"genericAlternateName\":\"\",\"genericDescription\":\"\",\"genericUrl\":\"\",\"genericImage\":\"\",\"genericImageWidth\":\"\",\"genericImageHeight\":\"\",\"genericImageIds\":[],\"genericTelephone\":\"\",\"genericEmail\":\"\",\"genericStreetAddress\":\"\",\"genericAddressLocality\":\"\",\"genericAddressRegion\":\"\",\"genericPostalCode\":\"\",\"genericAddressCountry\":\"\",\"genericGeoLatitude\":\"\",\"genericGeoLongitude\":\"\",\"personGender\":\"\",\"personBirthPlace\":\"\",\"organizationDuns\":\"\",\"organizationFounder\":\"\",\"organizationFoundingDate\":\"\",\"organizationFoundingLocation\":\"\",\"organizationContactPoints\":[],\"corporationTickerSymbol\":\"\",\"localBusinessPriceRange\":\"\",\"localBusinessOpeningHours\":[],\"restaurantServesCuisine\":\"\",\"restaurantMenuUrl\":\"\",\"restaurantReservationsUrl\":\"\"},\"twitterHandle\":\"\",\"facebookProfileId\":\"\",\"facebookAppId\":\"\",\"googleSiteVerification\":\"\",\"bingSiteVerification\":\"\",\"pinterestSiteVerification\":\"\",\"sameAsLinks\":{\"twitter\":{\"siteName\":\"Twitter\",\"handle\":\"twitter\",\"url\":\"\"},\"facebook\":{\"siteName\":\"Facebook\",\"handle\":\"facebook\",\"url\":\"\"},\"wikipedia\":{\"siteName\":\"Wikipedia\",\"handle\":\"wikipedia\",\"url\":\"\"},\"linkedin\":{\"siteName\":\"LinkedIn\",\"handle\":\"linkedin\",\"url\":\"\"},\"googleplus\":{\"siteName\":\"Google+\",\"handle\":\"googleplus\",\"url\":\"\"},\"youtube\":{\"siteName\":\"YouTube\",\"handle\":\"youtube\",\"url\":\"\"},\"instagram\":{\"siteName\":\"Instagram\",\"handle\":\"instagram\",\"url\":\"\"},\"pinterest\":{\"siteName\":\"Pinterest\",\"handle\":\"pinterest\",\"url\":\"\"},\"github\":{\"siteName\":\"GitHub\",\"handle\":\"github\",\"url\":\"\"},\"vimeo\":{\"siteName\":\"Vimeo\",\"handle\":\"vimeo\",\"url\":\"\"}},\"siteLinksSearchTarget\":\"\",\"siteLinksQueryInput\":\"\",\"additionalSitemapUrls\":[],\"additionalSitemapUrlsDateUpdated\":null,\"additionalSitemaps\":[]}', '{\"sitemapUrls\":true,\"sitemapAssets\":true,\"sitemapFiles\":true,\"sitemapAltLinks\":true,\"sitemapChangeFreq\":\"weekly\",\"sitemapPriority\":0.5,\"sitemapLimit\":null,\"structureDepth\":null,\"sitemapImageFieldMap\":[{\"property\":\"title\",\"field\":\"title\"},{\"property\":\"caption\",\"field\":\"\"},{\"property\":\"geo_location\",\"field\":\"\"},{\"property\":\"license\",\"field\":\"\"}],\"sitemapVideoFieldMap\":[{\"property\":\"title\",\"field\":\"title\"},{\"property\":\"description\",\"field\":\"\"},{\"property\":\"thumbnailLoc\",\"field\":\"\"},{\"property\":\"duration\",\"field\":\"\"},{\"property\":\"category\",\"field\":\"\"}]}', '{\"MetaTagContainergeneral\":{\"data\":{\"generator\":{\"charset\":\"\",\"content\":\"SEOmatic\",\"httpEquiv\":\"\",\"name\":\"generator\",\"property\":null,\"include\":true,\"key\":\"generator\",\"environment\":null,\"dependencies\":{\"config\":[\"generatorEnabled\"]}},\"keywords\":{\"charset\":\"\",\"content\":\"{seomatic.meta.seoKeywords}\",\"httpEquiv\":\"\",\"name\":\"keywords\",\"property\":null,\"include\":true,\"key\":\"keywords\",\"environment\":null,\"dependencies\":null},\"description\":{\"charset\":\"\",\"content\":\"{seomatic.meta.seoDescription}\",\"httpEquiv\":\"\",\"name\":\"description\",\"property\":null,\"include\":true,\"key\":\"description\",\"environment\":null,\"dependencies\":null},\"referrer\":{\"charset\":\"\",\"content\":\"no-referrer-when-downgrade\",\"httpEquiv\":\"\",\"name\":\"referrer\",\"property\":null,\"include\":true,\"key\":\"referrer\",\"environment\":null,\"dependencies\":null},\"robots\":{\"charset\":\"\",\"content\":\"none\",\"httpEquiv\":\"\",\"name\":\"robots\",\"property\":null,\"include\":true,\"key\":\"robots\",\"environment\":{\"live\":{\"content\":\"{seomatic.meta.robots}\"},\"staging\":{\"content\":\"none\"},\"local\":{\"content\":\"none\"}},\"dependencies\":null}},\"name\":\"General\",\"description\":\"General Meta Tags\",\"class\":\"nystudio107\\\\seomatic\\\\models\\\\MetaTagContainer\",\"handle\":\"general\",\"include\":true,\"dependencies\":[],\"clearCache\":false},\"MetaTagContaineropengraph\":{\"data\":{\"fb:profile_id\":{\"charset\":\"\",\"content\":\"{seomatic.site.facebookProfileId}\",\"httpEquiv\":\"\",\"name\":\"\",\"property\":\"fb:profile_id\",\"include\":true,\"key\":\"fb:profile_id\",\"environment\":null,\"dependencies\":null},\"fb:app_id\":{\"charset\":\"\",\"content\":\"{seomatic.site.facebookAppId}\",\"httpEquiv\":\"\",\"name\":\"\",\"property\":\"fb:app_id\",\"include\":true,\"key\":\"fb:app_id\",\"environment\":null,\"dependencies\":null},\"og:locale\":{\"charset\":\"\",\"content\":\"{{ craft.app.language |replace({\\\"-\\\": \\\"_\\\"}) }}\",\"httpEquiv\":\"\",\"name\":\"\",\"property\":\"og:locale\",\"include\":true,\"key\":\"og:locale\",\"environment\":null,\"dependencies\":null},\"og:locale:alternate\":{\"charset\":\"\",\"content\":\"\",\"httpEquiv\":\"\",\"name\":\"\",\"property\":\"og:locale:alternate\",\"include\":true,\"key\":\"og:locale:alternate\",\"environment\":null,\"dependencies\":null},\"og:site_name\":{\"charset\":\"\",\"content\":\"{seomatic.site.siteName}\",\"httpEquiv\":\"\",\"name\":\"\",\"property\":\"og:site_name\",\"include\":true,\"key\":\"og:site_name\",\"environment\":null,\"dependencies\":null},\"og:type\":{\"charset\":\"\",\"content\":\"{seomatic.meta.ogType}\",\"httpEquiv\":\"\",\"name\":\"\",\"property\":\"og:type\",\"include\":true,\"key\":\"og:type\",\"environment\":null,\"dependencies\":null},\"og:url\":{\"charset\":\"\",\"content\":\"{seomatic.meta.canonicalUrl}\",\"httpEquiv\":\"\",\"name\":\"\",\"property\":\"og:url\",\"include\":true,\"key\":\"og:url\",\"environment\":null,\"dependencies\":null},\"og:title\":{\"siteName\":\"{seomatic.site.siteName}\",\"siteNamePosition\":\"{seomatic.meta.ogSiteNamePosition}\",\"separatorChar\":\"{seomatic.config.separatorChar}\",\"charset\":\"\",\"content\":\"{seomatic.meta.ogTitle}\",\"httpEquiv\":\"\",\"name\":\"\",\"property\":\"og:title\",\"include\":true,\"key\":\"og:title\",\"environment\":null,\"dependencies\":null},\"og:description\":{\"charset\":\"\",\"content\":\"{seomatic.meta.ogDescription}\",\"httpEquiv\":\"\",\"name\":\"\",\"property\":\"og:description\",\"include\":true,\"key\":\"og:description\",\"environment\":null,\"dependencies\":null},\"og:image\":{\"charset\":\"\",\"content\":\"{seomatic.meta.ogImage}\",\"httpEquiv\":\"\",\"name\":\"\",\"property\":\"og:image\",\"include\":true,\"key\":\"og:image\",\"environment\":null,\"dependencies\":null},\"og:image:width\":{\"charset\":\"\",\"content\":\"{seomatic.meta.ogImageWidth}\",\"httpEquiv\":\"\",\"name\":\"\",\"property\":\"og:image:width\",\"include\":true,\"key\":\"og:image:width\",\"environment\":null,\"dependencies\":{\"tag\":[\"og:image\"]}},\"og:image:height\":{\"charset\":\"\",\"content\":\"{seomatic.meta.ogImageHeight}\",\"httpEquiv\":\"\",\"name\":\"\",\"property\":\"og:image:height\",\"include\":true,\"key\":\"og:image:height\",\"environment\":null,\"dependencies\":{\"tag\":[\"og:image\"]}},\"og:image:alt\":{\"charset\":\"\",\"content\":\"{seomatic.meta.ogImageDescription}\",\"httpEquiv\":\"\",\"name\":\"\",\"property\":\"og:image:alt\",\"include\":true,\"key\":\"og:image:alt\",\"environment\":null,\"dependencies\":{\"tag\":[\"og:image\"]}},\"og:see_also\":{\"charset\":\"\",\"content\":\"\",\"httpEquiv\":\"\",\"name\":\"\",\"property\":\"og:see_also\",\"include\":true,\"key\":\"og:see_also\",\"environment\":null,\"dependencies\":null}},\"name\":\"Facebook\",\"description\":\"Facebook OpenGraph Meta Tags\",\"class\":\"nystudio107\\\\seomatic\\\\models\\\\MetaTagContainer\",\"handle\":\"opengraph\",\"include\":true,\"dependencies\":[],\"clearCache\":false},\"MetaTagContainertwitter\":{\"data\":{\"twitter:card\":{\"charset\":\"\",\"content\":\"{seomatic.meta.twitterCard}\",\"httpEquiv\":\"\",\"name\":\"twitter:card\",\"property\":null,\"include\":true,\"key\":\"twitter:card\",\"environment\":null,\"dependencies\":null},\"twitter:site\":{\"charset\":\"\",\"content\":\"@{seomatic.site.twitterHandle}\",\"httpEquiv\":\"\",\"name\":\"twitter:site\",\"property\":null,\"include\":true,\"key\":\"twitter:site\",\"environment\":null,\"dependencies\":{\"site\":[\"twitterHandle\"]}},\"twitter:creator\":{\"charset\":\"\",\"content\":\"@{seomatic.meta.twitterCreator}\",\"httpEquiv\":\"\",\"name\":\"twitter:creator\",\"property\":null,\"include\":true,\"key\":\"twitter:creator\",\"environment\":null,\"dependencies\":{\"meta\":[\"twitterCreator\"]}},\"twitter:title\":{\"siteName\":\"{seomatic.site.siteName}\",\"siteNamePosition\":\"{seomatic.meta.twitterSiteNamePosition}\",\"separatorChar\":\"{seomatic.config.separatorChar}\",\"charset\":\"\",\"content\":\"{seomatic.meta.twitterTitle}\",\"httpEquiv\":\"\",\"name\":\"twitter:title\",\"property\":null,\"include\":true,\"key\":\"twitter:title\",\"environment\":null,\"dependencies\":null},\"twitter:description\":{\"charset\":\"\",\"content\":\"{seomatic.meta.twitterDescription}\",\"httpEquiv\":\"\",\"name\":\"twitter:description\",\"property\":null,\"include\":true,\"key\":\"twitter:description\",\"environment\":null,\"dependencies\":null},\"twitter:image\":{\"charset\":\"\",\"content\":\"{seomatic.meta.twitterImage}\",\"httpEquiv\":\"\",\"name\":\"twitter:image\",\"property\":null,\"include\":true,\"key\":\"twitter:image\",\"environment\":null,\"dependencies\":null},\"twitter:image:width\":{\"charset\":\"\",\"content\":\"{seomatic.meta.twitterImageWidth}\",\"httpEquiv\":\"\",\"name\":\"twitter:image:width\",\"property\":null,\"include\":true,\"key\":\"twitter:image:width\",\"environment\":null,\"dependencies\":{\"tag\":[\"twitter:image\"]}},\"twitter:image:height\":{\"charset\":\"\",\"content\":\"{seomatic.meta.twitterImageHeight}\",\"httpEquiv\":\"\",\"name\":\"twitter:image:height\",\"property\":null,\"include\":true,\"key\":\"twitter:image:height\",\"environment\":null,\"dependencies\":{\"tag\":[\"twitter:image\"]}},\"twitter:image:alt\":{\"charset\":\"\",\"content\":\"{seomatic.meta.twitterImageDescription}\",\"httpEquiv\":\"\",\"name\":\"twitter:image:alt\",\"property\":null,\"include\":true,\"key\":\"twitter:image:alt\",\"environment\":null,\"dependencies\":{\"tag\":[\"twitter:image\"]}}},\"name\":\"Twitter\",\"description\":\"Twitter Card Meta Tags\",\"class\":\"nystudio107\\\\seomatic\\\\models\\\\MetaTagContainer\",\"handle\":\"twitter\",\"include\":true,\"dependencies\":{\"site\":[\"twitterHandle\"]},\"clearCache\":false},\"MetaTagContainermiscellaneous\":{\"data\":{\"google-site-verification\":{\"charset\":\"\",\"content\":\"{seomatic.site.googleSiteVerification}\",\"httpEquiv\":\"\",\"name\":\"google-site-verification\",\"property\":null,\"include\":true,\"key\":\"google-site-verification\",\"environment\":null,\"dependencies\":{\"site\":[\"googleSiteVerification\"]}},\"bing-site-verification\":{\"charset\":\"\",\"content\":\"{seomatic.site.bingSiteVerification}\",\"httpEquiv\":\"\",\"name\":\"msvalidate.01\",\"property\":null,\"include\":true,\"key\":\"bing-site-verification\",\"environment\":null,\"dependencies\":{\"site\":[\"bingSiteVerification\"]}},\"pinterest-site-verification\":{\"charset\":\"\",\"content\":\"{seomatic.site.pinterestSiteVerification}\",\"httpEquiv\":\"\",\"name\":\"p:domain_verify\",\"property\":null,\"include\":true,\"key\":\"pinterest-site-verification\",\"environment\":null,\"dependencies\":{\"site\":[\"pinterestSiteVerification\"]}}},\"name\":\"Miscellaneous\",\"description\":\"Miscellaneous Meta Tags\",\"class\":\"nystudio107\\\\seomatic\\\\models\\\\MetaTagContainer\",\"handle\":\"miscellaneous\",\"include\":true,\"dependencies\":[],\"clearCache\":false},\"MetaLinkContainergeneral\":{\"data\":{\"canonical\":{\"crossorigin\":\"\",\"href\":\"{seomatic.meta.canonicalUrl}\",\"hreflang\":\"\",\"media\":\"\",\"rel\":\"canonical\",\"sizes\":\"\",\"type\":\"\",\"include\":true,\"key\":\"canonical\",\"environment\":null,\"dependencies\":null},\"home\":{\"crossorigin\":\"\",\"href\":\"{{ siteUrl }}\",\"hreflang\":\"\",\"media\":\"\",\"rel\":\"home\",\"sizes\":\"\",\"type\":\"\",\"include\":true,\"key\":\"home\",\"environment\":null,\"dependencies\":null},\"author\":{\"crossorigin\":\"\",\"href\":\"{{ seomatic.helper.siteUrl(\\\"/humans.txt\\\") }}\",\"hreflang\":\"\",\"media\":\"\",\"rel\":\"author\",\"sizes\":\"\",\"type\":\"text/plain\",\"include\":true,\"key\":\"author\",\"environment\":null,\"dependencies\":{\"frontend_template\":[\"humans\"]}},\"publisher\":{\"crossorigin\":\"\",\"href\":\"{seomatic.site.googlePublisherLink}\",\"hreflang\":\"\",\"media\":\"\",\"rel\":\"publisher\",\"sizes\":\"\",\"type\":\"\",\"include\":true,\"key\":\"publisher\",\"environment\":null,\"dependencies\":{\"site\":[\"googlePublisherLink\"]}}},\"name\":\"General\",\"description\":\"Link Tags\",\"class\":\"nystudio107\\\\seomatic\\\\models\\\\MetaLinkContainer\",\"handle\":\"general\",\"include\":true,\"dependencies\":[],\"clearCache\":false},\"MetaScriptContainergeneral\":{\"data\":{\"googleAnalytics\":{\"name\":\"Google Analytics\",\"description\":\"Google Analytics gives you the digital analytics tools you need to analyze data from all touchpoints in one place, for a deeper understanding of the customer experience. You can then share the insights that matter with your whole organization. [Learn More](https://www.google.com/analytics/analytics/)\",\"templatePath\":\"_frontend/scripts/googleAnalytics.twig\",\"templateString\":\"{% if trackingId.value is defined and trackingId.value %}\\n(function(i,s,o,g,r,a,m){i[\'GoogleAnalyticsObject\']=r;i[r]=i[r]||function(){\\n(i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),\\nm=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)\\n})(window,document,\'script\',\'{{ analyticsUrl.value }}\',\'ga\');\\nga(\'create\', \'{{ trackingId.value |raw }}\', \'auto\'{% if linker.value %}, {allowLinker: true}{% endif %});\\n{% if ipAnonymization.value %}\\nga(\'set\', \'anonymizeIp\', true);\\n{% endif %}\\n{% if displayFeatures.value %}\\nga(\'require\', \'displayfeatures\');\\n{% endif %}\\n{% if ecommerce.value %}\\nga(\'require\', \'ecommerce\');\\n{% endif %}\\n{% if enhancedEcommerce.value %}\\nga(\'require\', \'ec\');\\n{% endif %}\\n{% if enhancedLinkAttribution.value %}\\nga(\'require\', \'linkid\');\\n{% endif %}\\n{% if enhancedLinkAttribution.value %}\\nga(\'require\', \'linker\');\\n{% endif %}\\n{% set pageView = (sendPageView.value and not craft.app.request.isLivePreview) %}\\n{% if pageView %}\\nga(\'send\', \'pageview\');\\n{% endif %}\\n{% endif %}\\n\",\"position\":1,\"bodyTemplatePath\":null,\"bodyTemplateString\":null,\"bodyPosition\":2,\"vars\":{\"trackingId\":{\"title\":\"Google Analytics Tracking ID\",\"instructions\":\"Only enter the ID, e.g.: `UA-XXXXXX-XX`, not the entire script code. [Learn More](https://support.google.com/analytics/answer/1032385?hl=e)\",\"type\":\"string\",\"value\":\"\"},\"sendPageView\":{\"title\":\"Automatically send Google Analytics PageView\",\"instructions\":\"Controls whether the Google Analytics script automatically sends a PageView to Google Analytics when your pages are loaded.\",\"type\":\"bool\",\"value\":true},\"ipAnonymization\":{\"title\":\"Google Analytics IP Anonymization\",\"instructions\":\"When a customer of Analytics requests IP address anonymization, Analytics anonymizes the address as soon as technically feasible at the earliest possible stage of the collection network.\",\"type\":\"bool\",\"value\":false},\"displayFeatures\":{\"title\":\"Display Features\",\"instructions\":\"The display features plugin for analytics.js can be used to enable Advertising Features in Google Analytics, such as Remarketing, Demographics and Interest Reporting, and more. [Learn More](https://developers.google.com/analytics/devguides/collection/analyticsjs/display-features)\",\"type\":\"bool\",\"value\":false},\"ecommerce\":{\"title\":\"Ecommerce\",\"instructions\":\"Ecommerce tracking allows you to measure the number of transactions and revenue that your website generates. [Learn More](https://developers.google.com/analytics/devguides/collection/analyticsjs/ecommerce)\",\"type\":\"bool\",\"value\":false},\"enhancedEcommerce\":{\"title\":\"Enhanced Ecommerce\",\"instructions\":\"The enhanced ecommerce plug-in for analytics.js enables the measurement of user interactions with products on ecommerce websites across the user\'s shopping experience, including: product impressions, product clicks, viewing product details, adding a product to a shopping cart, initiating the checkout process, transactions, and refunds. [Learn More](https://developers.google.com/analytics/devguides/collection/analyticsjs/enhanced-ecommerce)\",\"type\":\"bool\",\"value\":false},\"enhancedLinkAttribution\":{\"title\":\"Enhanced Link Attribution\",\"instructions\":\"Enhanced Link Attribution improves the accuracy of your In-Page Analytics report by automatically differentiating between multiple links to the same URL on a single page by using link element IDs. [Learn More](https://developers.google.com/analytics/devguides/collection/analyticsjs/enhanced-link-attribution)\",\"type\":\"bool\",\"value\":false},\"linker\":{\"title\":\"Linker\",\"instructions\":\"The linker plugin simplifies the process of implementing cross-domain tracking as described in the Cross-domain Tracking guide for analytics.js. [Learn More](https://developers.google.com/analytics/devguides/collection/analyticsjs/linker)\",\"type\":\"bool\",\"value\":false},\"analyticsUrl\":{\"title\":\"Google Analytics Script URL\",\"instructions\":\"The URL to the Google Analytics tracking script. Normally this should not be changed, unless you locally cache it.\",\"type\":\"string\",\"value\":\"https://www.google-analytics.com/analytics.js\"}},\"dataLayer\":[],\"include\":false,\"key\":\"googleAnalytics\",\"environment\":{\"staging\":{\"include\":false},\"local\":{\"include\":false}},\"dependencies\":null},\"gtag\":{\"name\":\"Google gtag.js\",\"description\":\"The global site tag (gtag.js) is a JavaScript tagging framework and API that allows you to send event data to AdWords, DoubleClick, and Google Analytics. Instead of having to manage multiple tags for different products, you can use gtag.js and more easily benefit from the latest tracking features and integrations as they become available. [Learn More](https://developers.google.com/gtagjs/)\",\"templatePath\":\"_frontend/scripts/gtagHead.twig\",\"templateString\":\"{% set gtagProperty = googleAnalyticsId.value ?? googleAdWordsId.value ?? dcFloodlightId.value ?? null %}\\n{% if gtagProperty %}\\nwindow.dataLayer = window.dataLayer || [{% if dataLayer is defined and dataLayer %}{{ dataLayer |json_encode() |raw }}{% endif %}];\\nfunction gtag(){dataLayer.push(arguments)};\\ngtag(\'js\', new Date());\\n{% set pageView = (sendPageView.value and not craft.app.request.isLivePreview) %}\\n{% if googleAnalyticsId.value %}\\n{%- set gtagConfig = \\\"{\\\"\\n    ~ \\\"\'send_page_view\': #{pageView ? \'true\' : \'false\'},\\\"\\n    ~ \\\"\'anonymize_ip\': #{ipAnonymization.value ? \'true\' : \'false\'},\\\"\\n    ~ \\\"\'link_attribution\': #{enhancedLinkAttribution.value ? \'true\' : \'false\'},\\\"\\n    ~ \\\"\'allow_display_features\': #{displayFeatures.value ? \'true\' : \'false\'}\\\"\\n    ~ \\\"}\\\"\\n-%}\\ngtag(\'config\', \'{{ googleAnalyticsId.value }}\', {{ gtagConfig }});\\n{% endif %}\\n{% if googleAdWordsId.value %}\\n{%- set gtagConfig = \\\"{\\\"\\n    ~ \\\"\'send_page_view\': #{pageView ? \'true\' : \'false\'}\\\"\\n    ~ \\\"}\\\"\\n-%}\\ngtag(\'config\', \'{{ googleAdWordsId.value }}\', {{ gtagConfig }});\\n{% endif %}\\n{% if dcFloodlightId.value %}\\n{%- set gtagConfig = \\\"{\\\"\\n    ~ \\\"\'send_page_view\': #{pageView ? \'true\' : \'false\'}\\\"\\n    ~ \\\"}\\\"\\n-%}\\ngtag(\'config\', \'{{ dcFloodlightId.value }}\', {{ gtagConfig }});\\n{% endif %}\\n{% endif %}\\n\",\"position\":1,\"bodyTemplatePath\":\"_frontend/scripts/gtagBody.twig\",\"bodyTemplateString\":\"{% set gtagProperty = googleAnalyticsId.value ?? googleAdWordsId.value ?? dcFloodlightId.value ?? null %}\\n{% if gtagProperty %}\\n<script async src=\\\"{{ gtagScriptUrl.value }}?id={{ gtagProperty }}\\\"></script>\\n{% endif %}\\n\",\"bodyPosition\":2,\"vars\":{\"googleAnalyticsId\":{\"title\":\"Google Analytics Tracking ID\",\"instructions\":\"Only enter the ID, e.g.: `UA-XXXXXX-XX`, not the entire script code. [Learn More](https://support.google.com/analytics/answer/1032385?hl=e)\",\"type\":\"string\",\"value\":\"\"},\"googleAdWordsId\":{\"title\":\"AdWords Conversion ID\",\"instructions\":\"Only enter the ID, e.g.: `AW-XXXXXXXX`, not the entire script code. [Learn More](https://developers.google.com/adwords-remarketing-tag/)\",\"type\":\"string\",\"value\":\"\"},\"dcFloodlightId\":{\"title\":\"DoubleClick Floodlight ID\",\"instructions\":\"Only enter the ID, e.g.: `DC-XXXXXXXX`, not the entire script code. [Learn More](https://support.google.com/dcm/partner/answer/7568534)\",\"type\":\"string\",\"value\":\"\"},\"sendPageView\":{\"title\":\"Automatically send PageView\",\"instructions\":\"Controls whether the `gtag.js` script automatically sends a PageView to Google Analytics, AdWords, and DoubleClick Floodlight when your pages are loaded.\",\"type\":\"bool\",\"value\":true},\"ipAnonymization\":{\"title\":\"Google Analytics IP Anonymization\",\"instructions\":\"In some cases, you might need to anonymize the IP addresses of hits sent to Google Analytics. [Learn More](https://developers.google.com/analytics/devguides/collection/gtagjs/ip-anonymization)\",\"type\":\"bool\",\"value\":false},\"displayFeatures\":{\"title\":\"Google Analytics Display Features\",\"instructions\":\"The display features plugin for gtag.js can be used to enable Advertising Features in Google Analytics, such as Remarketing, Demographics and Interest Reporting, and more. [Learn More](https://developers.google.com/analytics/devguides/collection/gtagjs/display-features)\",\"type\":\"bool\",\"value\":false},\"enhancedLinkAttribution\":{\"title\":\"Google Analytics Enhanced Link Attribution\",\"instructions\":\"Enhanced link attribution improves click track reporting by automatically differentiating between multiple link clicks that have the same URL on a given page. [Learn More](https://developers.google.com/analytics/devguides/collection/gtagjs/enhanced-link-attribution)\",\"type\":\"bool\",\"value\":false},\"gtagScriptUrl\":{\"title\":\"Google gtag.js Script URL\",\"instructions\":\"The URL to the Google gtag.js tracking script. Normally this should not be changed, unless you locally cache it. The JavaScript `dataLayer` will automatically be set to the `dataLayer` Twig template variable.\",\"type\":\"string\",\"value\":\"https://www.googletagmanager.com/gtag/js\"}},\"dataLayer\":[],\"include\":false,\"key\":\"gtag\",\"environment\":{\"staging\":{\"include\":false},\"local\":{\"include\":false}},\"dependencies\":null},\"googleTagManager\":{\"name\":\"Google Tag Manager\",\"description\":\"Google Tag Manager is a tag management system that allows you to quickly and easily update tags and code snippets on your website. Once the Tag Manager snippet has been added to your website or mobile app, you can configure tags via a web-based user interface without having to alter and deploy additional code. [Learn More](https://support.google.com/tagmanager/answer/6102821?hl=en)\",\"templatePath\":\"_frontend/scripts/googleTagManagerHead.twig\",\"templateString\":\"{% if googleTagManagerId.value is defined and googleTagManagerId.value and not craft.app.request.isLivePreview %}\\n{{ dataLayerVariableName.value }} = [{% if dataLayer is defined and dataLayer %}{{ dataLayer |json_encode() |raw }}{% endif %}];\\n(function(w,d,s,l,i){w[l]=w[l]||[];w[l].push({\'gtm.start\':\\nnew Date().getTime(),event:\'gtm.js\'});var f=d.getElementsByTagName(s)[0],\\nj=d.createElement(s),dl=l!=\'dataLayer\'?\'&l=\'+l:\'\';j.async=true;j.src=\\n\'{{ googleTagManagerUrl.value }}?id=\'+i+dl;f.parentNode.insertBefore(j,f);\\n})(window,document,\'script\',\'{{ dataLayerVariableName.value }}\',\'{{ googleTagManagerId.value }}\');\\n{% endif %}\\n\",\"position\":1,\"bodyTemplatePath\":\"_frontend/scripts/googleTagManagerBody.twig\",\"bodyTemplateString\":\"{% if googleTagManagerId.value is defined and googleTagManagerId.value and not craft.app.request.isLivePreview %}\\n<noscript><iframe src=\\\"{{ googleTagManagerNoScriptUrl.value }}?id={{ googleTagManagerId.value }}\\\"\\nheight=\\\"0\\\" width=\\\"0\\\" style=\\\"display:none;visibility:hidden\\\"></iframe></noscript>\\n{% endif %}\\n\",\"bodyPosition\":2,\"vars\":{\"googleTagManagerId\":{\"title\":\"Google Tag Manager ID\",\"instructions\":\"Only enter the ID, e.g.: `GTM-XXXXXX`, not the entire script code. [Learn More](https://developers.google.com/tag-manager/quickstart)\",\"type\":\"string\",\"value\":\"\"},\"dataLayerVariableName\":{\"title\":\"DataLayer Variable Name\",\"instructions\":\"The name to use for the JavaScript DataLayer variable. The value of this variable will be set to the `dataLayer` Twig template variable.\",\"type\":\"string\",\"value\":\"dataLayer\"},\"googleTagManagerUrl\":{\"title\":\"Google Tag Manager Script URL\",\"instructions\":\"The URL to the Google Tag Manager script. Normally this should not be changed, unless you locally cache it.\",\"type\":\"string\",\"value\":\"https://www.googletagmanager.com/gtm.js\"},\"googleTagManagerNoScriptUrl\":{\"title\":\"Google Tag Manager Script &lt;noscript&gt; URL\",\"instructions\":\"The URL to the Google Tag Manager `&lt;noscript&gt;`. Normally this should not be changed, unless you locally cache it.\",\"type\":\"string\",\"value\":\"https://www.googletagmanager.com/ns.html\"}},\"dataLayer\":[],\"include\":false,\"key\":\"googleTagManager\",\"environment\":{\"staging\":{\"include\":false},\"local\":{\"include\":false}},\"dependencies\":null},\"facebookPixel\":{\"name\":\"Facebook Pixel\",\"description\":\"The Facebook pixel is an analytics tool that helps you measure the effectiveness of your advertising. You can use the Facebook pixel to understand the actions people are taking on your website and reach audiences you care about. [Learn More](https://www.facebook.com/business/help/651294705016616)\",\"templatePath\":\"_frontend/scripts/facebookPixelHead.twig\",\"templateString\":\"{% if facebookPixelId.value is defined and facebookPixelId.value %}\\n!function(f,b,e,v,n,t,s){if(f.fbq)return;n=f.fbq=function(){n.callMethod?\\nn.callMethod.apply(n,arguments):n.queue.push(arguments)};if(!f._fbq)f._fbq=n;\\nn.push=n;n.loaded=!0;n.version=\'2.0\';n.queue=[];t=b.createElement(e);t.async=!0;\\nt.src=v;s=b.getElementsByTagName(e)[0];s.parentNode.insertBefore(t,s)}(window,\\ndocument,\'script\',\'{{ facebookPixelUrl.value }}\');\\nfbq(\'init\', \'{{ facebookPixelId.value }}\');\\n{% set pageView = (sendPageView.value and not craft.app.request.isLivePreview) %}\\n{% if pageView %}\\nfbq(\'track\', \'PageView\');\\n{% endif %}\\n{% endif %}\\n\",\"position\":1,\"bodyTemplatePath\":\"_frontend/scripts/facebookPixelBody.twig\",\"bodyTemplateString\":\"{% if facebookPixelId.value is defined and facebookPixelId.value %}\\n<noscript><img height=\\\"1\\\" width=\\\"1\\\" style=\\\"display:none\\\"\\nsrc=\\\"{{ facebookPixelNoScriptUrl.value }}?id={{ facebookPixelId.value }}&ev=PageView&noscript=1\\\" /></noscript>\\n{% endif %}\\n\",\"bodyPosition\":2,\"vars\":{\"facebookPixelId\":{\"title\":\"Facebook Pixel ID\",\"instructions\":\"Only enter the ID, e.g.: `XXXXXXXXXX`, not the entire script code. [Learn More](https://developers.facebook.com/docs/facebook-pixel/api-reference)\",\"type\":\"string\",\"value\":\"\"},\"sendPageView\":{\"title\":\"Automatically send Facebook Pixel PageView\",\"instructions\":\"Controls whether the Facebook Pixel script automatically sends a PageView to Facebook Analytics when your pages are loaded.\",\"type\":\"bool\",\"value\":true},\"facebookPixelUrl\":{\"title\":\"Facebook Pixel Script URL\",\"instructions\":\"The URL to the Facebook Pixel script. Normally this should not be changed, unless you locally cache it.\",\"type\":\"string\",\"value\":\"https://connect.facebook.net/en_US/fbevents.js\"},\"facebookPixelNoScriptUrl\":{\"title\":\"Facebook Pixel Script &lt;noscript&gt; URL\",\"instructions\":\"The URL to the Facebook Pixel `&lt;noscript&gt;`. Normally this should not be changed, unless you locally cache it.\",\"type\":\"string\",\"value\":\"https://www.facebook.com/tr\"}},\"dataLayer\":[],\"include\":false,\"key\":\"facebookPixel\",\"environment\":{\"staging\":{\"include\":false},\"local\":{\"include\":false}},\"dependencies\":null},\"linkedInInsight\":{\"name\":\"LinkedIn Insight\",\"description\":\"The LinkedIn Insight Tag is a lightweight JavaScript tag that powers conversion tracking, retargeting, and web analytics for LinkedIn ad campaigns.\",\"templatePath\":\"_frontend/scripts/linkedInInsightHead.twig\",\"templateString\":\"{% if dataPartnerId.value is defined and dataPartnerId.value %}\\n_linkedin_data_partner_id = \\\"{{ dataPartnerId.value }}\\\";\\n{% endif %}\\n\",\"position\":1,\"bodyTemplatePath\":\"_frontend/scripts/linkedInInsightBody.twig\",\"bodyTemplateString\":\"{% if dataPartnerId.value is defined and dataPartnerId.value %}\\n<script type=\\\"text/javascript\\\">\\n(function(){var s = document.getElementsByTagName(\\\"script\\\")[0];\\n    var b = document.createElement(\\\"script\\\");\\n    b.type = \\\"text/javascript\\\";b.async = true;\\n    b.src = \\\"{{ linkedInInsightUrl.value }}\\\";\\n    s.parentNode.insertBefore(b, s);})();\\n</script>\\n<noscript>\\n<img height=\\\"1\\\" width=\\\"1\\\" style=\\\"display:none;\\\" alt=\\\"\\\" src=\\\"{{ linkedInInsightNoScriptUrl.value }}?pid={{ dataPartnerId.value }}&fmt=gif\\\" />\\n</noscript>\\n{% endif %}\\n\",\"bodyPosition\":3,\"vars\":{\"dataPartnerId\":{\"title\":\"LinkedIn Data Partner ID\",\"instructions\":\"Only enter the ID, e.g.: `XXXXXXXXXX`, not the entire script code. [Learn More](https://www.linkedin.com/help/lms/answer/65513/adding-the-linkedin-insight-tag-to-your-website?lang=en)\",\"type\":\"string\",\"value\":\"\"},\"linkedInInsightUrl\":{\"title\":\"LinkedIn Insight Script URL\",\"instructions\":\"The URL to the LinkedIn Insight script. Normally this should not be changed, unless you locally cache it.\",\"type\":\"string\",\"value\":\"https://snap.licdn.com/li.lms-analytics/insight.min.js\"},\"linkedInInsightNoScriptUrl\":{\"title\":\"LinkedIn Insight &lt;noscript&gt; URL\",\"instructions\":\"The URL to the LinkedIn Insight `&lt;noscript&gt;`. Normally this should not be changed, unless you locally cache it.\",\"type\":\"string\",\"value\":\"https://dc.ads.linkedin.com/collect/\"}},\"dataLayer\":[],\"include\":false,\"key\":\"linkedInInsight\",\"environment\":{\"staging\":{\"include\":false},\"local\":{\"include\":false}},\"dependencies\":null},\"hubSpot\":{\"name\":\"HubSpot\",\"description\":\"If you\'re not hosting your entire website on HubSpot, or have pages on your website that are not hosted on HubSpot, you\'ll need to install the HubSpot tracking code on your non-HubSpot pages in order to capture those analytics.\",\"templatePath\":null,\"templateString\":null,\"position\":1,\"bodyTemplatePath\":\"_frontend/scripts/hubSpotBody.twig\",\"bodyTemplateString\":\"{% if hubSpotId.value is defined and hubSpotId.value %}\\n<script type=\\\"text/javascript\\\" id=\\\"hs-script-loader\\\" async defer src=\\\"{{ hubSpotUrl.value }}{{ hubSpotId.value }}.js\\\"></script>\\n{% endif %}\\n\",\"bodyPosition\":3,\"vars\":{\"hubSpotId\":{\"title\":\"HubSpot ID\",\"instructions\":\"Only enter the ID, e.g.: `XXXXXXXXXX`, not the entire script code. [Learn More](https://knowledge.hubspot.com/articles/kcs_article/reports/install-the-hubspot-tracking-code)\",\"type\":\"string\",\"value\":\"\"},\"hubSpotUrl\":{\"title\":\"HubSpot Script URL\",\"instructions\":\"The URL to the HubSpot script. Normally this should not be changed, unless you locally cache it.\",\"type\":\"string\",\"value\":\"//js.hs-scripts.com/\"}},\"dataLayer\":[],\"include\":false,\"key\":\"hubSpot\",\"environment\":{\"staging\":{\"include\":false},\"local\":{\"include\":false}},\"dependencies\":null}},\"position\":1,\"name\":\"General\",\"description\":\"Script Tags\",\"class\":\"nystudio107\\\\seomatic\\\\models\\\\MetaScriptContainer\",\"handle\":\"general\",\"include\":true,\"dependencies\":[],\"clearCache\":false},\"MetaJsonLdContainergeneral\":{\"data\":{\"mainEntityOfPage\":{\"issn\":null,\"about\":null,\"accessMode\":null,\"accessModeSufficient\":null,\"accessibilityAPI\":null,\"accessibilityControl\":null,\"accessibilityFeature\":null,\"accessibilityHazard\":null,\"accessibilitySummary\":null,\"accountablePerson\":null,\"aggregateRating\":null,\"alternativeHeadline\":null,\"associatedMedia\":null,\"audience\":null,\"audio\":null,\"author\":{\"id\":\"{seomatic.site.identity.genericUrl}#identity\"},\"award\":null,\"character\":null,\"citation\":null,\"comment\":null,\"commentCount\":null,\"contentLocation\":null,\"contentRating\":null,\"contentReferenceTime\":null,\"contributor\":null,\"copyrightHolder\":{\"id\":\"{seomatic.site.identity.genericUrl}#identity\"},\"copyrightYear\":null,\"correction\":null,\"creator\":{\"id\":\"{seomatic.site.creator.genericUrl}#creator\"},\"dateCreated\":null,\"dateModified\":null,\"datePublished\":null,\"discussionUrl\":null,\"editor\":null,\"educationalAlignment\":null,\"educationalUse\":null,\"encoding\":null,\"encodingFormat\":null,\"exampleOfWork\":null,\"expires\":null,\"funder\":null,\"genre\":null,\"hasPart\":null,\"headline\":null,\"inLanguage\":\"{seomatic.meta.language}\",\"interactionStatistic\":null,\"interactivityType\":null,\"isAccessibleForFree\":null,\"isBasedOn\":null,\"isFamilyFriendly\":null,\"isPartOf\":null,\"keywords\":null,\"learningResourceType\":null,\"license\":null,\"locationCreated\":null,\"mainEntity\":null,\"material\":null,\"materialExtent\":null,\"mentions\":null,\"offers\":null,\"position\":null,\"producer\":null,\"provider\":null,\"publication\":null,\"publisher\":null,\"publisherImprint\":null,\"publishingPrinciples\":null,\"recordedAt\":null,\"releasedEvent\":null,\"review\":null,\"schemaVersion\":null,\"sdDatePublished\":null,\"sdLicense\":null,\"sdPublisher\":null,\"sourceOrganization\":null,\"spatial\":null,\"spatialCoverage\":null,\"sponsor\":null,\"temporal\":null,\"temporalCoverage\":null,\"text\":null,\"thumbnailUrl\":null,\"timeRequired\":null,\"translationOfWork\":null,\"translator\":null,\"typicalAgeRange\":null,\"version\":null,\"video\":null,\"workExample\":null,\"workTranslation\":null,\"additionalType\":null,\"alternateName\":null,\"description\":\"{seomatic.meta.seoDescription}\",\"disambiguatingDescription\":null,\"identifier\":null,\"image\":{\"type\":\"ImageObject\",\"url\":\"{seomatic.meta.seoImage}\"},\"mainEntityOfPage\":\"{seomatic.meta.canonicalUrl}\",\"name\":\"{seomatic.meta.seoTitle}\",\"potentialAction\":{\"type\":\"SearchAction\",\"target\":\"{seomatic.site.siteLinksSearchTarget}\",\"query-input\":\"{seomatic.helper.siteLinksQueryInput()}\"},\"sameAs\":null,\"subjectOf\":null,\"url\":\"{seomatic.meta.canonicalUrl}\",\"context\":\"http://schema.org\",\"type\":\"{seomatic.meta.mainEntityOfPage}\",\"id\":null,\"graph\":null,\"include\":true,\"key\":\"mainEntityOfPage\",\"environment\":null,\"dependencies\":null},\"identity\":{\"actionableFeedbackPolicy\":null,\"address\":{\"type\":\"PostalAddress\",\"streetAddress\":\"{seomatic.site.identity.genericStreetAddress}\",\"addressLocality\":\"{seomatic.site.identity.genericAddressLocality}\",\"addressRegion\":\"{seomatic.site.identity.genericAddressRegion}\",\"postalCode\":\"{seomatic.site.identity.genericPostalCode}\",\"addressCountry\":\"{seomatic.site.identity.genericAddressCountry}\"},\"aggregateRating\":null,\"alumni\":null,\"areaServed\":null,\"award\":null,\"brand\":null,\"contactPoint\":null,\"correctionsPolicy\":null,\"department\":null,\"dissolutionDate\":null,\"diversityPolicy\":null,\"diversityStaffingReport\":null,\"duns\":\"{seomatic.site.identity.organizationDuns}\",\"email\":\"{seomatic.site.identity.genericEmail}\",\"employee\":null,\"ethicsPolicy\":null,\"event\":null,\"faxNumber\":null,\"founder\":\"{seomatic.site.identity.organizationFounder}\",\"foundingDate\":\"{seomatic.site.identity.organizationFoundingDate}\",\"foundingLocation\":\"{seomatic.site.identity.organizationFoundingLocation}\",\"funder\":null,\"globalLocationNumber\":null,\"hasOfferCatalog\":null,\"hasPOS\":null,\"isicV4\":null,\"knowsAbout\":null,\"knowsLanguage\":null,\"legalName\":null,\"leiCode\":null,\"location\":null,\"logo\":{\"type\":\"ImageObject\",\"url\":\"{seomatic.helper.socialTransform(seomatic.site.identity.genericImageIds[0], \\\"schema-logo\\\")}\",\"width\":\"{seomatic.helper.socialTransformWidth(seomatic.site.identity.genericImageIds[0], \\\"schema-logo\\\")}\",\"height\":\"{seomatic.helper.socialTransformHeight(seomatic.site.identity.genericImageIds[0], \\\"schema-logo\\\")}\"},\"makesOffer\":null,\"member\":null,\"memberOf\":null,\"naics\":null,\"numberOfEmployees\":null,\"ownershipFundingInfo\":null,\"owns\":null,\"parentOrganization\":null,\"publishingPrinciples\":null,\"review\":null,\"seeks\":null,\"slogan\":null,\"sponsor\":null,\"subOrganization\":null,\"taxID\":null,\"telephone\":\"{seomatic.site.identity.genericTelephone}\",\"unnamedSourcesPolicy\":null,\"vatID\":null,\"additionalType\":null,\"alternateName\":\"{seomatic.site.identity.genericAlternateName}\",\"description\":\"{seomatic.site.identity.genericDescription}\",\"disambiguatingDescription\":null,\"identifier\":null,\"image\":{\"type\":\"ImageObject\",\"url\":\"{seomatic.site.identity.genericImage}\",\"width\":\"{seomatic.site.identity.genericImageWidth}\",\"height\":\"{seomatic.site.identity.genericImageHeight}\"},\"mainEntityOfPage\":null,\"name\":\"{seomatic.site.identity.genericName}\",\"potentialAction\":null,\"sameAs\":null,\"subjectOf\":null,\"url\":\"{seomatic.site.identity.genericUrl}\",\"context\":\"http://schema.org\",\"type\":\"{seomatic.site.identity.computedType}\",\"id\":\"{seomatic.site.identity.genericUrl}#identity\",\"graph\":null,\"include\":true,\"key\":\"identity\",\"environment\":null,\"dependencies\":null},\"creator\":{\"actionableFeedbackPolicy\":null,\"address\":{\"type\":\"PostalAddress\",\"streetAddress\":\"{seomatic.site.creator.genericStreetAddress}\",\"addressLocality\":\"{seomatic.site.creator.genericAddressLocality}\",\"addressRegion\":\"{seomatic.site.creator.genericAddressRegion}\",\"postalCode\":\"{seomatic.site.creator.genericPostalCode}\",\"addressCountry\":\"{seomatic.site.creator.genericAddressCountry}\"},\"aggregateRating\":null,\"alumni\":null,\"areaServed\":null,\"award\":null,\"brand\":null,\"contactPoint\":null,\"correctionsPolicy\":null,\"department\":null,\"dissolutionDate\":null,\"diversityPolicy\":null,\"diversityStaffingReport\":null,\"duns\":\"{seomatic.site.creator.organizationDuns}\",\"email\":\"{seomatic.site.creator.genericEmail}\",\"employee\":null,\"ethicsPolicy\":null,\"event\":null,\"faxNumber\":null,\"founder\":\"{seomatic.site.creator.organizationFounder}\",\"foundingDate\":\"{seomatic.site.creator.organizationFoundingDate}\",\"foundingLocation\":\"{seomatic.site.creator.organizationFoundingLocation}\",\"funder\":null,\"globalLocationNumber\":null,\"hasOfferCatalog\":null,\"hasPOS\":null,\"isicV4\":null,\"knowsAbout\":null,\"knowsLanguage\":null,\"legalName\":null,\"leiCode\":null,\"location\":null,\"logo\":{\"type\":\"ImageObject\",\"url\":\"{seomatic.helper.socialTransform(seomatic.site.creator.genericImageIds[0], \\\"schema-logo\\\")}\",\"width\":\"{seomatic.helper.socialTransformWidth(seomatic.site.creator.genericImageIds[0], \\\"schema-logo\\\")}\",\"height\":\"{seomatic.helper.socialTransformHeight(seomatic.site.creator.genericImageIds[0], \\\"schema-logo\\\")}\"},\"makesOffer\":null,\"member\":null,\"memberOf\":null,\"naics\":null,\"numberOfEmployees\":null,\"ownershipFundingInfo\":null,\"owns\":null,\"parentOrganization\":null,\"publishingPrinciples\":null,\"review\":null,\"seeks\":null,\"slogan\":null,\"sponsor\":null,\"subOrganization\":null,\"taxID\":null,\"telephone\":\"{seomatic.site.creator.genericTelephone}\",\"unnamedSourcesPolicy\":null,\"vatID\":null,\"additionalType\":null,\"alternateName\":\"{seomatic.site.creator.genericAlternateName}\",\"description\":\"{seomatic.site.creator.genericDescription}\",\"disambiguatingDescription\":null,\"identifier\":null,\"image\":{\"type\":\"ImageObject\",\"url\":\"{seomatic.site.creator.genericImage}\",\"width\":\"{seomatic.site.creator.genericImageWidth}\",\"height\":\"{seomatic.site.creator.genericImageHeight}\"},\"mainEntityOfPage\":null,\"name\":\"{seomatic.site.creator.genericName}\",\"potentialAction\":null,\"sameAs\":null,\"subjectOf\":null,\"url\":\"{seomatic.site.creator.genericUrl}\",\"context\":\"http://schema.org\",\"type\":\"{seomatic.site.creator.computedType}\",\"id\":\"{seomatic.site.creator.genericUrl}#creator\",\"graph\":null,\"include\":true,\"key\":\"creator\",\"environment\":null,\"dependencies\":null}},\"name\":\"General\",\"description\":\"JsonLd Tags\",\"class\":\"nystudio107\\\\seomatic\\\\models\\\\MetaJsonLdContainer\",\"handle\":\"general\",\"include\":true,\"dependencies\":[],\"clearCache\":false},\"MetaTitleContainergeneral\":{\"data\":{\"title\":{\"title\":\"{seomatic.meta.seoTitle}\",\"siteName\":\"{seomatic.site.siteName}\",\"siteNamePosition\":\"{seomatic.meta.siteNamePosition}\",\"separatorChar\":\"{seomatic.config.separatorChar}\",\"include\":true,\"key\":\"title\",\"environment\":null,\"dependencies\":null}},\"name\":\"General\",\"description\":\"Meta Title Tag\",\"class\":\"nystudio107\\\\seomatic\\\\models\\\\MetaTitleContainer\",\"handle\":\"general\",\"include\":true,\"dependencies\":[],\"clearCache\":false}}', '[]', '{\"data\":{\"humans\":{\"templateVersion\":\"1.0.0\",\"templateString\":\"/* TEAM */\\n\\nCreator: {{ seomatic.site.creator.genericName ?? \\\"n/a\\\" }}\\nURL: {{ seomatic.site.creator.genericUrl ?? \\\"n/a\\\" }}\\nDescription: {{ seomatic.site.creator.genericDescription ?? \\\"n/a\\\" }}\\n\\n/* THANKS */\\n\\nCraft CMS - https://craftcms.com\\nPixel & Tonic - https://pixelandtonic.com\\n\\n/* SITE */\\n\\nStandards: HTML5, CSS3\\nComponents: Craft CMS 3, Yii2, PHP, JavaScript, SEOmatic\\n\",\"siteId\":null,\"include\":true,\"handle\":\"humans\",\"path\":\"humans.txt\",\"template\":\"_frontend/pages/humans.twig\",\"controller\":\"frontend-template\",\"action\":\"humans\"},\"robots\":{\"templateVersion\":\"1.0.0\",\"templateString\":\"# robots.txt for {{ siteUrl }}\\n\\nSitemap: {{ seomatic.helper.sitemapIndexForSiteId() }}\\n{% switch seomatic.config.environment %}\\n\\n{% case \\\"live\\\" %}\\n\\n# live - don\'t allow web crawlers to index cpresources/ or vendor/\\n\\nUser-agent: *\\nDisallow: /cpresources/\\nDisallow: /vendor/\\nDisallow: /.env\\nDisallow: /cache/\\n\\n{% case \\\"staging\\\" %}\\n\\n# staging - disallow all\\n\\nUser-agent: *\\nDisallow: /\\n\\n{% case \\\"local\\\" %}\\n\\n# local - disallow all\\n\\nUser-agent: *\\nDisallow: /\\n\\n{% default %}\\n\\n# default - don\'t allow web crawlers to index cpresources/ or vendor/\\n\\nUser-agent: *\\nDisallow: /cpresources/\\nDisallow: /vendor/\\nDisallow: /.env\\nDisallow: /cache/\\n\\n{% endswitch %}\\n\",\"siteId\":null,\"include\":true,\"handle\":\"robots\",\"path\":\"robots.txt\",\"template\":\"_frontend/pages/robots.twig\",\"controller\":\"frontend-template\",\"action\":\"robots\"},\"ads\":{\"templateVersion\":\"1.0.0\",\"templateString\":\"# ads.txt file for {{ siteUrl }}\\n# More info: https://support.google.com/admanager/answer/7441288?hl=en\\n{{ siteUrl }},123,DIRECT\\n\",\"siteId\":null,\"include\":true,\"handle\":\"ads\",\"path\":\"ads.txt\",\"template\":\"_frontend/pages/ads.twig\",\"controller\":\"frontend-template\",\"action\":\"ads\"}},\"name\":\"Frontend Templates\",\"description\":\"Templates that are rendered on the frontend\",\"class\":\"nystudio107\\\\seomatic\\\\models\\\\FrontendTemplateContainer\",\"handle\":\"SeomaticEditableTemplate\",\"include\":true,\"dependencies\":null,\"clearCache\":false}', '{\"siteType\":\"CreativeWork\",\"siteSubType\":\"WebSite\",\"siteSpecificType\":\"none\",\"seoTitleSource\":\"fromCustom\",\"seoTitleField\":\"general.phone\",\"siteNamePositionSource\":\"fromCustom\",\"seoDescriptionSource\":\"fromCustom\",\"seoDescriptionField\":\"general.phone\",\"seoKeywordsSource\":\"fromCustom\",\"seoKeywordsField\":\"general.phone\",\"seoImageIds\":\"\",\"seoImageSource\":\"fromAsset\",\"seoImageField\":\"sections.image\",\"seoImageTransform\":\"1\",\"seoImageTransformMode\":\"crop\",\"seoImageDescriptionSource\":\"fromCustom\",\"seoImageDescriptionField\":\"general.phone\",\"twitterCreatorSource\":\"sameAsSite\",\"twitterCreatorField\":\"\",\"twitterTitleSource\":\"sameAsSeo\",\"twitterTitleField\":\"\",\"twitterSiteNamePositionSource\":\"fromCustom\",\"twitterDescriptionSource\":\"sameAsSeo\",\"twitterDescriptionField\":\"\",\"twitterImageIds\":\"\",\"twitterImageSource\":\"sameAsSeo\",\"twitterImageField\":\"sections.image\",\"twitterImageTransform\":\"1\",\"twitterImageTransformMode\":\"crop\",\"twitterImageDescriptionSource\":\"sameAsSeo\",\"twitterImageDescriptionField\":\"\",\"ogTitleSource\":\"sameAsSeo\",\"ogTitleField\":\"\",\"ogSiteNamePositionSource\":\"fromCustom\",\"ogDescriptionSource\":\"sameAsSeo\",\"ogDescriptionField\":\"\",\"ogImageIds\":\"\",\"ogImageSource\":\"sameAsSeo\",\"ogImageField\":\"sections.image\",\"ogImageTransform\":\"1\",\"ogImageTransformMode\":\"crop\",\"ogImageDescriptionSource\":\"sameAsSeo\",\"ogImageDescriptionField\":\"\"}');
INSERT INTO `seomatic_metabundles` (`id`, `dateCreated`, `dateUpdated`, `uid`, `bundleVersion`, `sourceBundleType`, `sourceId`, `sourceName`, `sourceHandle`, `sourceType`, `sourceTemplate`, `sourceSiteId`, `sourceAltSiteSettings`, `sourceDateUpdated`, `metaGlobalVars`, `metaSiteVars`, `metaSitemapVars`, `metaContainers`, `redirectsContainer`, `frontendTemplatesContainer`, `metaBundleSettings`) VALUES ('2', '2019-12-16 10:23:08', '2019-12-17 00:45:52', '388c18a4-8d39-4fb1-b312-845691ec174a', '1.0.28', 'section', '1', 'Pages', 'pages', 'structure', 'page/_type', '2', '{\"2\":{\"id\":\"1\",\"sectionId\":\"1\",\"siteId\":\"2\",\"enabledByDefault\":\"1\",\"hasUrls\":\"1\",\"uriFormat\":\"{parent.uri}/{slug}\",\"template\":\"page/_type\",\"language\":\"en-us\"}}', '2019-12-16 10:00:07', '{\"language\":null,\"mainEntityOfPage\":\"WebPage\",\"seoTitle\":\"{seomatic.helper.extractTextFromField(object.entry.title)}\",\"siteNamePosition\":\"\",\"seoDescription\":\"{seomatic.helper.extractTextFromField(object.entry.summary)}\",\"seoKeywords\":\"{seomatic.helper.extractTextFromField(object.entry.keywords)}\",\"seoImage\":\"{seomatic.helper.socialTransform(object.entry.image[0], \\\"base\\\", 2, \\\"crop\\\")}\",\"seoImageWidth\":\"{seomatic.helper.socialTransformWidth(object.entry.image[0], \\\"base\\\", 2, \\\"crop\\\")}\",\"seoImageHeight\":\"{seomatic.helper.socialTransformHeight(object.entry.image[0], \\\"base\\\", 2, \\\"crop\\\")}\",\"seoImageDescription\":\"\",\"canonicalUrl\":\"{entry.url}\",\"robots\":\"all\",\"ogType\":\"website\",\"ogTitle\":\"{seomatic.meta.seoTitle}\",\"ogSiteNamePosition\":\"\",\"ogDescription\":\"{seomatic.meta.seoDescription}\",\"ogImage\":\"{seomatic.helper.socialTransform(object.entry.image[0], \\\"facebook\\\", 2, \\\"crop\\\")}\",\"ogImageWidth\":\"{seomatic.helper.socialTransformWidth(object.entry.image[0], \\\"facebook\\\", 2, \\\"crop\\\")}\",\"ogImageHeight\":\"{seomatic.helper.socialTransformHeight(object.entry.image[0], \\\"facebook\\\", 2, \\\"crop\\\")}\",\"ogImageDescription\":\"{seomatic.meta.seoImageDescription}\",\"twitterCard\":\"summary_large_image\",\"twitterCreator\":\"{seomatic.site.twitterHandle}\",\"twitterTitle\":\"{seomatic.meta.seoTitle}\",\"twitterSiteNamePosition\":\"\",\"twitterDescription\":\"{seomatic.meta.seoDescription}\",\"twitterImage\":\"{seomatic.helper.socialTransform(object.entry.image[0], seomatic.helper.twitterTransform(), 2, \\\"crop\\\")}\",\"twitterImageWidth\":\"{seomatic.helper.socialTransformWidth(object.entry.image[0], seomatic.helper.twitterTransform(), 2, \\\"crop\\\")}\",\"twitterImageHeight\":\"{seomatic.helper.socialTransformHeight(object.entry.image[0], seomatic.helper.twitterTransform(), 2, \\\"crop\\\")}\",\"twitterImageDescription\":\"{seomatic.meta.seoImageDescription}\"}', '{\"siteName\":\"FWORK Plus\",\"identity\":null,\"creator\":null,\"twitterHandle\":\"\",\"facebookProfileId\":\"\",\"facebookAppId\":\"\",\"googleSiteVerification\":\"\",\"bingSiteVerification\":\"\",\"pinterestSiteVerification\":\"\",\"sameAsLinks\":[],\"siteLinksSearchTarget\":\"\",\"siteLinksQueryInput\":\"\",\"additionalSitemapUrls\":[],\"additionalSitemapUrlsDateUpdated\":null,\"additionalSitemaps\":[]}', '{\"sitemapUrls\":true,\"sitemapAssets\":true,\"sitemapFiles\":true,\"sitemapAltLinks\":true,\"sitemapChangeFreq\":\"weekly\",\"sitemapPriority\":0.5,\"sitemapLimit\":null,\"structureDepth\":null,\"sitemapImageFieldMap\":[{\"property\":\"title\",\"field\":\"title\"},{\"property\":\"caption\",\"field\":\"\"},{\"property\":\"geo_location\",\"field\":\"\"},{\"property\":\"license\",\"field\":\"\"}],\"sitemapVideoFieldMap\":[{\"property\":\"title\",\"field\":\"title\"},{\"property\":\"description\",\"field\":\"\"},{\"property\":\"thumbnailLoc\",\"field\":\"\"},{\"property\":\"duration\",\"field\":\"\"},{\"property\":\"category\",\"field\":\"\"}]}', '{\"MetaTagContainergeneral\":{\"data\":[],\"name\":\"General\",\"description\":\"General Meta Tags\",\"class\":\"nystudio107\\\\seomatic\\\\models\\\\MetaTagContainer\",\"handle\":\"general\",\"include\":true,\"dependencies\":[],\"clearCache\":false},\"MetaTagContaineropengraph\":{\"data\":[],\"name\":\"Facebook\",\"description\":\"Facebook OpenGraph Meta Tags\",\"class\":\"nystudio107\\\\seomatic\\\\models\\\\MetaTagContainer\",\"handle\":\"opengraph\",\"include\":true,\"dependencies\":[],\"clearCache\":false},\"MetaTagContainertwitter\":{\"data\":[],\"name\":\"Twitter\",\"description\":\"Twitter Card Meta Tags\",\"class\":\"nystudio107\\\\seomatic\\\\models\\\\MetaTagContainer\",\"handle\":\"twitter\",\"include\":true,\"dependencies\":[],\"clearCache\":false},\"MetaTagContainermiscellaneous\":{\"data\":[],\"name\":\"Miscellaneous\",\"description\":\"Miscellaneous Meta Tags\",\"class\":\"nystudio107\\\\seomatic\\\\models\\\\MetaTagContainer\",\"handle\":\"miscellaneous\",\"include\":true,\"dependencies\":[],\"clearCache\":false},\"MetaLinkContainergeneral\":{\"data\":[],\"name\":\"General\",\"description\":\"Link Tags\",\"class\":\"nystudio107\\\\seomatic\\\\models\\\\MetaLinkContainer\",\"handle\":\"general\",\"include\":true,\"dependencies\":[],\"clearCache\":false},\"MetaScriptContainergeneral\":{\"data\":[],\"position\":1,\"name\":\"General\",\"description\":\"Script Tags\",\"class\":\"nystudio107\\\\seomatic\\\\models\\\\MetaScriptContainer\",\"handle\":\"general\",\"include\":true,\"dependencies\":[],\"clearCache\":false},\"MetaJsonLdContainergeneral\":{\"data\":{\"mainEntityOfPage\":{\"breadcrumb\":null,\"lastReviewed\":null,\"mainContentOfPage\":null,\"primaryImageOfPage\":null,\"relatedLink\":null,\"reviewedBy\":null,\"significantLink\":null,\"speakable\":null,\"specialty\":null,\"about\":null,\"accessMode\":null,\"accessModeSufficient\":null,\"accessibilityAPI\":null,\"accessibilityControl\":null,\"accessibilityFeature\":null,\"accessibilityHazard\":null,\"accessibilitySummary\":null,\"accountablePerson\":null,\"aggregateRating\":null,\"alternativeHeadline\":null,\"associatedMedia\":null,\"audience\":null,\"audio\":null,\"author\":{\"id\":\"{seomatic.site.identity.genericUrl}#identity\"},\"award\":null,\"character\":null,\"citation\":null,\"comment\":null,\"commentCount\":null,\"contentLocation\":null,\"contentRating\":null,\"contentReferenceTime\":null,\"contributor\":null,\"copyrightHolder\":{\"id\":\"{seomatic.site.identity.genericUrl}#identity\"},\"copyrightYear\":\"{entry.postDate | date(\\\"Y\\\")}\",\"correction\":null,\"creator\":{\"id\":\"{seomatic.site.identity.genericUrl}#creator\"},\"dateCreated\":false,\"dateModified\":\"{entry.dateUpdated |atom}\",\"datePublished\":\"{entry.postDate |atom}\",\"discussionUrl\":null,\"editor\":null,\"educationalAlignment\":null,\"educationalUse\":null,\"encoding\":null,\"encodingFormat\":null,\"exampleOfWork\":null,\"expires\":null,\"funder\":null,\"genre\":null,\"hasPart\":null,\"headline\":\"{seomatic.meta.seoTitle}\",\"inLanguage\":\"{seomatic.meta.language}\",\"interactionStatistic\":null,\"interactivityType\":null,\"isAccessibleForFree\":null,\"isBasedOn\":null,\"isFamilyFriendly\":null,\"isPartOf\":null,\"keywords\":null,\"learningResourceType\":null,\"license\":null,\"locationCreated\":null,\"mainEntity\":null,\"material\":null,\"materialExtent\":null,\"mentions\":null,\"offers\":null,\"position\":null,\"producer\":null,\"provider\":null,\"publication\":null,\"publisher\":{\"id\":\"{seomatic.site.identity.genericUrl}#creator\"},\"publisherImprint\":null,\"publishingPrinciples\":null,\"recordedAt\":null,\"releasedEvent\":null,\"review\":null,\"schemaVersion\":null,\"sdDatePublished\":null,\"sdLicense\":null,\"sdPublisher\":null,\"sourceOrganization\":null,\"spatial\":null,\"spatialCoverage\":null,\"sponsor\":null,\"temporal\":null,\"temporalCoverage\":null,\"text\":null,\"thumbnailUrl\":null,\"timeRequired\":null,\"translationOfWork\":null,\"translator\":null,\"typicalAgeRange\":null,\"version\":null,\"video\":null,\"workExample\":null,\"workTranslation\":null,\"additionalType\":null,\"alternateName\":null,\"description\":\"{seomatic.meta.seoDescription}\",\"disambiguatingDescription\":null,\"identifier\":null,\"image\":{\"type\":\"ImageObject\",\"url\":\"{seomatic.meta.seoImage}\"},\"mainEntityOfPage\":\"{seomatic.meta.canonicalUrl}\",\"name\":\"{seomatic.meta.seoTitle}\",\"potentialAction\":{\"type\":\"SearchAction\",\"target\":\"{seomatic.site.siteLinksSearchTarget}\",\"query-input\":\"{seomatic.helper.siteLinksQueryInput()}\"},\"sameAs\":null,\"subjectOf\":null,\"url\":\"{seomatic.meta.canonicalUrl}\",\"context\":\"http://schema.org\",\"type\":\"{seomatic.meta.mainEntityOfPage}\",\"id\":null,\"graph\":null,\"include\":true,\"key\":\"mainEntityOfPage\",\"environment\":null,\"dependencies\":null}},\"name\":\"General\",\"description\":\"JsonLd Tags\",\"class\":\"nystudio107\\\\seomatic\\\\models\\\\MetaJsonLdContainer\",\"handle\":\"general\",\"include\":true,\"dependencies\":[],\"clearCache\":false},\"MetaTitleContainergeneral\":{\"data\":{\"title\":{\"title\":\"{seomatic.meta.seoTitle}\",\"siteName\":\"{seomatic.site.siteName}\",\"siteNamePosition\":\"{seomatic.meta.siteNamePosition}\",\"separatorChar\":\"{seomatic.config.separatorChar}\",\"include\":true,\"key\":\"title\",\"environment\":null,\"dependencies\":null}},\"name\":\"General\",\"description\":\"Meta Title Tag\",\"class\":\"nystudio107\\\\seomatic\\\\models\\\\MetaTitleContainer\",\"handle\":\"general\",\"include\":true,\"dependencies\":[],\"clearCache\":false}}', '[]', '{\"data\":[],\"name\":null,\"description\":null,\"class\":\"nystudio107\\\\seomatic\\\\models\\\\FrontendTemplateContainer\",\"handle\":null,\"include\":true,\"dependencies\":null,\"clearCache\":false}', '{\"siteType\":\"CreativeWork\",\"siteSubType\":\"WebPage\",\"siteSpecificType\":\"none\",\"seoTitleSource\":\"fromField\",\"seoTitleField\":\"title\",\"siteNamePositionSource\":\"sameAsGlobal\",\"seoDescriptionSource\":\"fromField\",\"seoDescriptionField\":\"summary\",\"seoKeywordsSource\":\"fromField\",\"seoKeywordsField\":\"keywords\",\"seoImageIds\":\"\",\"seoImageSource\":\"fromField\",\"seoImageField\":\"image\",\"seoImageTransform\":\"1\",\"seoImageTransformMode\":\"crop\",\"seoImageDescriptionSource\":\"fromCustom\",\"seoImageDescriptionField\":\"title\",\"twitterCreatorSource\":\"sameAsSite\",\"twitterCreatorField\":\"\",\"twitterTitleSource\":\"sameAsSeo\",\"twitterTitleField\":\"\",\"twitterSiteNamePositionSource\":\"sameAsGlobal\",\"twitterDescriptionSource\":\"sameAsSeo\",\"twitterDescriptionField\":\"\",\"twitterImageIds\":\"\",\"twitterImageSource\":\"sameAsSeo\",\"twitterImageField\":\"image\",\"twitterImageTransform\":\"1\",\"twitterImageTransformMode\":\"crop\",\"twitterImageDescriptionSource\":\"sameAsSeo\",\"twitterImageDescriptionField\":\"\",\"ogTitleSource\":\"sameAsSeo\",\"ogTitleField\":\"\",\"ogSiteNamePositionSource\":\"sameAsGlobal\",\"ogDescriptionSource\":\"sameAsSeo\",\"ogDescriptionField\":\"\",\"ogImageIds\":\"\",\"ogImageSource\":\"sameAsSeo\",\"ogImageField\":\"image\",\"ogImageTransform\":\"1\",\"ogImageTransformMode\":\"crop\",\"ogImageDescriptionSource\":\"sameAsSeo\",\"ogImageDescriptionField\":\"\"}');
INSERT INTO `seomatic_metabundles` (`id`, `dateCreated`, `dateUpdated`, `uid`, `bundleVersion`, `sourceBundleType`, `sourceId`, `sourceName`, `sourceHandle`, `sourceType`, `sourceTemplate`, `sourceSiteId`, `sourceAltSiteSettings`, `sourceDateUpdated`, `metaGlobalVars`, `metaSiteVars`, `metaSitemapVars`, `metaContainers`, `redirectsContainer`, `frontendTemplatesContainer`, `metaBundleSettings`) VALUES ('3', '2019-12-16 20:51:28', '2019-12-16 21:35:56', 'ca2d1a18-3694-488a-8bc4-512d7134f1b7', '1.0.25', 'categorygroup', '1', 'News Categories', 'newsCategories', 'category', 'news/category', '2', '{\"2\":{\"id\":1,\"groupId\":1,\"siteId\":2,\"hasUrls\":1,\"uriFormat\":\"news/category/{slug}\",\"template\":\"news/category\",\"language\":\"en-us\"}}', '2019-12-16 21:35:56', '{\"language\":null,\"mainEntityOfPage\":\"WebPage\",\"seoTitle\":\"{seomatic.helper.extractTextFromField(object.category.title)}\",\"siteNamePosition\":\"\",\"seoDescription\":\"{seomatic.helper.extractTextFromField(object.category.summary)}\",\"seoKeywords\":\"{seomatic.helper.extractTextFromField(object.category.keywords)}\",\"seoImage\":\"{seomatic.helper.socialTransform(object.category.image[0], \\\"base\\\", 2, \\\"crop\\\")}\",\"seoImageWidth\":\"{seomatic.helper.socialTransformWidth(object.category.image[0], \\\"base\\\", 2, \\\"crop\\\")}\",\"seoImageHeight\":\"{seomatic.helper.socialTransformHeight(object.category.image[0], \\\"base\\\", 2, \\\"crop\\\")}\",\"seoImageDescription\":\"\",\"canonicalUrl\":\"{category.url}\",\"robots\":\"all\",\"ogType\":\"website\",\"ogTitle\":\"{seomatic.meta.seoTitle}\",\"ogSiteNamePosition\":\"\",\"ogDescription\":\"{seomatic.meta.seoDescription}\",\"ogImage\":\"{seomatic.helper.socialTransform(object.category.image[0], \\\"facebook\\\", 2, \\\"crop\\\")}\",\"ogImageWidth\":\"{seomatic.helper.socialTransformWidth(object.category.image[0], \\\"facebook\\\", 2, \\\"crop\\\")}\",\"ogImageHeight\":\"{seomatic.helper.socialTransformHeight(object.category.image[0], \\\"facebook\\\", 2, \\\"crop\\\")}\",\"ogImageDescription\":\"{seomatic.meta.seoImageDescription}\",\"twitterCard\":\"summary_large_image\",\"twitterCreator\":\"{seomatic.site.twitterHandle}\",\"twitterTitle\":\"{seomatic.meta.seoTitle}\",\"twitterSiteNamePosition\":\"\",\"twitterDescription\":\"{seomatic.meta.seoDescription}\",\"twitterImage\":\"{seomatic.helper.socialTransform(object.category.image[0], seomatic.helper.twitterTransform(), 2, \\\"crop\\\")}\",\"twitterImageWidth\":\"{seomatic.helper.socialTransformWidth(object.category.image[0], seomatic.helper.twitterTransform(), 2, \\\"crop\\\")}\",\"twitterImageHeight\":\"{seomatic.helper.socialTransformHeight(object.category.image[0], seomatic.helper.twitterTransform(), 2, \\\"crop\\\")}\",\"twitterImageDescription\":\"{seomatic.meta.seoImageDescription}\"}', '{\"siteName\":\"FWORK Plus\",\"identity\":null,\"creator\":null,\"twitterHandle\":\"\",\"facebookProfileId\":\"\",\"facebookAppId\":\"\",\"googleSiteVerification\":\"\",\"bingSiteVerification\":\"\",\"pinterestSiteVerification\":\"\",\"sameAsLinks\":[],\"siteLinksSearchTarget\":\"\",\"siteLinksQueryInput\":\"\",\"additionalSitemapUrls\":[],\"additionalSitemapUrlsDateUpdated\":null,\"additionalSitemaps\":[]}', '{\"sitemapUrls\":true,\"sitemapAssets\":true,\"sitemapFiles\":true,\"sitemapAltLinks\":true,\"sitemapChangeFreq\":\"weekly\",\"sitemapPriority\":0.5,\"sitemapLimit\":null,\"structureDepth\":null,\"sitemapImageFieldMap\":[{\"property\":\"title\",\"field\":\"title\"},{\"property\":\"caption\",\"field\":\"\"},{\"property\":\"geo_location\",\"field\":\"\"},{\"property\":\"license\",\"field\":\"\"}],\"sitemapVideoFieldMap\":[{\"property\":\"title\",\"field\":\"title\"},{\"property\":\"description\",\"field\":\"\"},{\"property\":\"thumbnailLoc\",\"field\":\"\"},{\"property\":\"duration\",\"field\":\"\"},{\"property\":\"category\",\"field\":\"\"}]}', '{\"MetaTagContainergeneral\":{\"data\":[],\"name\":\"General\",\"description\":\"General Meta Tags\",\"class\":\"nystudio107\\\\seomatic\\\\models\\\\MetaTagContainer\",\"handle\":\"general\",\"include\":true,\"dependencies\":[],\"clearCache\":false},\"MetaTagContaineropengraph\":{\"data\":[],\"name\":\"Facebook\",\"description\":\"Facebook OpenGraph Meta Tags\",\"class\":\"nystudio107\\\\seomatic\\\\models\\\\MetaTagContainer\",\"handle\":\"opengraph\",\"include\":true,\"dependencies\":[],\"clearCache\":false},\"MetaTagContainertwitter\":{\"data\":[],\"name\":\"Twitter\",\"description\":\"Twitter Card Meta Tags\",\"class\":\"nystudio107\\\\seomatic\\\\models\\\\MetaTagContainer\",\"handle\":\"twitter\",\"include\":true,\"dependencies\":[],\"clearCache\":false},\"MetaTagContainermiscellaneous\":{\"data\":[],\"name\":\"Miscellaneous\",\"description\":\"Miscellaneous Meta Tags\",\"class\":\"nystudio107\\\\seomatic\\\\models\\\\MetaTagContainer\",\"handle\":\"miscellaneous\",\"include\":true,\"dependencies\":[],\"clearCache\":false},\"MetaLinkContainergeneral\":{\"data\":[],\"name\":\"General\",\"description\":\"Link Tags\",\"class\":\"nystudio107\\\\seomatic\\\\models\\\\MetaLinkContainer\",\"handle\":\"general\",\"include\":true,\"dependencies\":[],\"clearCache\":false},\"MetaScriptContainergeneral\":{\"data\":[],\"position\":1,\"name\":\"General\",\"description\":\"Script Tags\",\"class\":\"nystudio107\\\\seomatic\\\\models\\\\MetaScriptContainer\",\"handle\":\"general\",\"include\":true,\"dependencies\":[],\"clearCache\":false},\"MetaJsonLdContainergeneral\":{\"data\":{\"mainEntityOfPage\":{\"breadcrumb\":null,\"lastReviewed\":null,\"mainContentOfPage\":null,\"primaryImageOfPage\":null,\"relatedLink\":null,\"reviewedBy\":null,\"significantLink\":null,\"speakable\":null,\"specialty\":null,\"about\":null,\"accessMode\":null,\"accessModeSufficient\":null,\"accessibilityAPI\":null,\"accessibilityControl\":null,\"accessibilityFeature\":null,\"accessibilityHazard\":null,\"accessibilitySummary\":null,\"accountablePerson\":null,\"aggregateRating\":null,\"alternativeHeadline\":null,\"associatedMedia\":null,\"audience\":null,\"audio\":null,\"author\":{\"id\":\"{seomatic.site.identity.genericUrl}#identity\"},\"award\":null,\"character\":null,\"citation\":null,\"comment\":null,\"commentCount\":null,\"contentLocation\":null,\"contentRating\":null,\"contentReferenceTime\":null,\"contributor\":null,\"copyrightHolder\":{\"id\":\"{seomatic.site.identity.genericUrl}#identity\"},\"copyrightYear\":\"{category.postDate |date(\\\"Y\\\")}\",\"correction\":null,\"creator\":{\"id\":\"{seomatic.site.identity.genericUrl}#creator\"},\"dateCreated\":false,\"dateModified\":\"{category.dateUpdated |atom}\",\"datePublished\":\"{category.postDate |atom}\",\"discussionUrl\":null,\"editor\":null,\"educationalAlignment\":null,\"educationalUse\":null,\"encoding\":null,\"encodingFormat\":null,\"exampleOfWork\":null,\"expires\":null,\"funder\":null,\"genre\":null,\"hasPart\":null,\"headline\":\"{seomatic.meta.seoTitle}\",\"inLanguage\":\"{seomatic.meta.language}\",\"interactionStatistic\":null,\"interactivityType\":null,\"isAccessibleForFree\":null,\"isBasedOn\":null,\"isFamilyFriendly\":null,\"isPartOf\":null,\"keywords\":null,\"learningResourceType\":null,\"license\":null,\"locationCreated\":null,\"mainEntity\":null,\"material\":null,\"materialExtent\":null,\"mentions\":null,\"offers\":null,\"position\":null,\"producer\":null,\"provider\":null,\"publication\":null,\"publisher\":{\"id\":\"{seomatic.site.identity.genericUrl}#creator\"},\"publisherImprint\":null,\"publishingPrinciples\":null,\"recordedAt\":null,\"releasedEvent\":null,\"review\":null,\"schemaVersion\":null,\"sdDatePublished\":null,\"sdLicense\":null,\"sdPublisher\":null,\"sourceOrganization\":null,\"spatial\":null,\"spatialCoverage\":null,\"sponsor\":null,\"temporal\":null,\"temporalCoverage\":null,\"text\":null,\"thumbnailUrl\":null,\"timeRequired\":null,\"translationOfWork\":null,\"translator\":null,\"typicalAgeRange\":null,\"version\":null,\"video\":null,\"workExample\":null,\"workTranslation\":null,\"additionalType\":null,\"alternateName\":null,\"description\":\"{seomatic.meta.seoDescription}\",\"disambiguatingDescription\":null,\"identifier\":null,\"image\":{\"type\":\"ImageObject\",\"url\":\"{seomatic.meta.seoImage}\"},\"mainEntityOfPage\":\"{seomatic.meta.canonicalUrl}\",\"name\":\"{seomatic.meta.seoTitle}\",\"potentialAction\":{\"type\":\"SearchAction\",\"target\":\"{seomatic.site.siteLinksSearchTarget}\",\"query-input\":\"{seomatic.helper.siteLinksQueryInput()}\"},\"sameAs\":null,\"subjectOf\":null,\"url\":\"{seomatic.meta.canonicalUrl}\",\"context\":\"http://schema.org\",\"type\":\"{seomatic.meta.mainEntityOfPage}\",\"id\":null,\"graph\":null,\"include\":true,\"key\":\"mainEntityOfPage\",\"environment\":null,\"dependencies\":null}},\"name\":\"General\",\"description\":\"JsonLd Tags\",\"class\":\"nystudio107\\\\seomatic\\\\models\\\\MetaJsonLdContainer\",\"handle\":\"general\",\"include\":true,\"dependencies\":[],\"clearCache\":false},\"MetaTitleContainergeneral\":{\"data\":{\"title\":{\"title\":\"{seomatic.meta.seoTitle}\",\"siteName\":\"{seomatic.site.siteName}\",\"siteNamePosition\":\"{seomatic.meta.siteNamePosition}\",\"separatorChar\":\"{seomatic.config.separatorChar}\",\"include\":true,\"key\":\"title\",\"environment\":null,\"dependencies\":null}},\"name\":\"General\",\"description\":\"Meta Title Tag\",\"class\":\"nystudio107\\\\seomatic\\\\models\\\\MetaTitleContainer\",\"handle\":\"general\",\"include\":true,\"dependencies\":[],\"clearCache\":false}}', '[]', '{\"data\":[],\"name\":null,\"description\":null,\"class\":\"nystudio107\\\\seomatic\\\\models\\\\FrontendTemplateContainer\",\"handle\":null,\"include\":true,\"dependencies\":null,\"clearCache\":false}', '{\"siteType\":\"CreativeWork\",\"siteSubType\":\"WebPage\",\"siteSpecificType\":\"none\",\"seoTitleSource\":\"fromField\",\"seoTitleField\":\"title\",\"siteNamePositionSource\":\"sameAsGlobal\",\"seoDescriptionSource\":\"fromField\",\"seoDescriptionField\":\"summary\",\"seoKeywordsSource\":\"fromField\",\"seoKeywordsField\":\"keywords\",\"seoImageIds\":\"\",\"seoImageSource\":\"fromField\",\"seoImageField\":\"image\",\"seoImageTransform\":\"1\",\"seoImageTransformMode\":\"crop\",\"seoImageDescriptionSource\":\"fromCustom\",\"seoImageDescriptionField\":\"title\",\"twitterCreatorSource\":\"sameAsSite\",\"twitterCreatorField\":\"\",\"twitterTitleSource\":\"sameAsSeo\",\"twitterTitleField\":\"\",\"twitterSiteNamePositionSource\":\"sameAsGlobal\",\"twitterDescriptionSource\":\"sameAsSeo\",\"twitterDescriptionField\":\"\",\"twitterImageIds\":\"\",\"twitterImageSource\":\"sameAsSeo\",\"twitterImageField\":\"image\",\"twitterImageTransform\":\"1\",\"twitterImageTransformMode\":\"crop\",\"twitterImageDescriptionSource\":\"sameAsSeo\",\"twitterImageDescriptionField\":\"\",\"ogTitleSource\":\"sameAsSeo\",\"ogTitleField\":\"\",\"ogSiteNamePositionSource\":\"sameAsGlobal\",\"ogDescriptionSource\":\"sameAsSeo\",\"ogDescriptionField\":\"\",\"ogImageIds\":\"\",\"ogImageSource\":\"sameAsSeo\",\"ogImageField\":\"image\",\"ogImageTransform\":\"1\",\"ogImageTransformMode\":\"crop\",\"ogImageDescriptionSource\":\"sameAsSeo\",\"ogImageDescriptionField\":\"\"}');
INSERT INTO `seomatic_metabundles` (`id`, `dateCreated`, `dateUpdated`, `uid`, `bundleVersion`, `sourceBundleType`, `sourceId`, `sourceName`, `sourceHandle`, `sourceType`, `sourceTemplate`, `sourceSiteId`, `sourceAltSiteSettings`, `sourceDateUpdated`, `metaGlobalVars`, `metaSiteVars`, `metaSitemapVars`, `metaContainers`, `redirectsContainer`, `frontendTemplatesContainer`, `metaBundleSettings`) VALUES ('4', '2019-12-16 21:04:58', '2019-12-16 21:37:55', '6273d2f0-a32f-4b82-b1d5-919ece10b0a7', '1.0.28', 'section', '2', 'News', 'news', 'channel', 'news/_entry', '2', '{\"2\":{\"id\":\"2\",\"sectionId\":\"2\",\"siteId\":\"2\",\"enabledByDefault\":\"1\",\"hasUrls\":\"1\",\"uriFormat\":\"news/{slug}\",\"template\":\"news/_entry\",\"language\":\"en-us\"}}', '2019-12-16 21:37:55', '{\"language\":null,\"mainEntityOfPage\":\"Article\",\"seoTitle\":\"{seomatic.helper.extractTextFromField(object.entry.title)}\",\"siteNamePosition\":\"\",\"seoDescription\":\"{seomatic.helper.extractTextFromField(object.entry.summary)}\",\"seoKeywords\":\"{seomatic.helper.extractTextFromField(object.entry.keywords)}\",\"seoImage\":\"{seomatic.helper.socialTransform(object.entry.image[0], \\\"base\\\", 2, \\\"crop\\\")}\",\"seoImageWidth\":\"{seomatic.helper.socialTransformWidth(object.entry.image[0], \\\"base\\\", 2, \\\"crop\\\")}\",\"seoImageHeight\":\"{seomatic.helper.socialTransformHeight(object.entry.image[0], \\\"base\\\", 2, \\\"crop\\\")}\",\"seoImageDescription\":\"\",\"canonicalUrl\":\"{entry.url}\",\"robots\":\"all\",\"ogType\":\"website\",\"ogTitle\":\"{seomatic.meta.seoTitle}\",\"ogSiteNamePosition\":\"\",\"ogDescription\":\"{seomatic.meta.seoDescription}\",\"ogImage\":\"{seomatic.helper.socialTransform(object.entry.image[0], \\\"facebook\\\", 2, \\\"crop\\\")}\",\"ogImageWidth\":\"{seomatic.helper.socialTransformWidth(object.entry.image[0], \\\"facebook\\\", 2, \\\"crop\\\")}\",\"ogImageHeight\":\"{seomatic.helper.socialTransformHeight(object.entry.image[0], \\\"facebook\\\", 2, \\\"crop\\\")}\",\"ogImageDescription\":\"{seomatic.meta.seoImageDescription}\",\"twitterCard\":\"summary_large_image\",\"twitterCreator\":\"{seomatic.site.twitterHandle}\",\"twitterTitle\":\"{seomatic.meta.seoTitle}\",\"twitterSiteNamePosition\":\"\",\"twitterDescription\":\"{seomatic.meta.seoDescription}\",\"twitterImage\":\"{seomatic.helper.socialTransform(object.entry.image[0], seomatic.helper.twitterTransform(), 2, \\\"crop\\\")}\",\"twitterImageWidth\":\"{seomatic.helper.socialTransformWidth(object.entry.image[0], seomatic.helper.twitterTransform(), 2, \\\"crop\\\")}\",\"twitterImageHeight\":\"{seomatic.helper.socialTransformHeight(object.entry.image[0], seomatic.helper.twitterTransform(), 2, \\\"crop\\\")}\",\"twitterImageDescription\":\"{seomatic.meta.seoImageDescription}\"}', '{\"siteName\":\"FWORK Plus\",\"identity\":null,\"creator\":null,\"twitterHandle\":\"\",\"facebookProfileId\":\"\",\"facebookAppId\":\"\",\"googleSiteVerification\":\"\",\"bingSiteVerification\":\"\",\"pinterestSiteVerification\":\"\",\"sameAsLinks\":[],\"siteLinksSearchTarget\":\"\",\"siteLinksQueryInput\":\"\",\"additionalSitemapUrls\":[],\"additionalSitemapUrlsDateUpdated\":null,\"additionalSitemaps\":[]}', '{\"sitemapUrls\":true,\"sitemapAssets\":true,\"sitemapFiles\":true,\"sitemapAltLinks\":true,\"sitemapChangeFreq\":\"weekly\",\"sitemapPriority\":0.5,\"sitemapLimit\":null,\"structureDepth\":null,\"sitemapImageFieldMap\":[{\"property\":\"title\",\"field\":\"title\"},{\"property\":\"caption\",\"field\":\"\"},{\"property\":\"geo_location\",\"field\":\"\"},{\"property\":\"license\",\"field\":\"\"}],\"sitemapVideoFieldMap\":[{\"property\":\"title\",\"field\":\"title\"},{\"property\":\"description\",\"field\":\"\"},{\"property\":\"thumbnailLoc\",\"field\":\"\"},{\"property\":\"duration\",\"field\":\"\"},{\"property\":\"category\",\"field\":\"\"}]}', '{\"MetaTagContainergeneral\":{\"data\":[],\"name\":\"General\",\"description\":\"General Meta Tags\",\"class\":\"nystudio107\\\\seomatic\\\\models\\\\MetaTagContainer\",\"handle\":\"general\",\"include\":true,\"dependencies\":[],\"clearCache\":false},\"MetaTagContaineropengraph\":{\"data\":[],\"name\":\"Facebook\",\"description\":\"Facebook OpenGraph Meta Tags\",\"class\":\"nystudio107\\\\seomatic\\\\models\\\\MetaTagContainer\",\"handle\":\"opengraph\",\"include\":true,\"dependencies\":[],\"clearCache\":false},\"MetaTagContainertwitter\":{\"data\":[],\"name\":\"Twitter\",\"description\":\"Twitter Card Meta Tags\",\"class\":\"nystudio107\\\\seomatic\\\\models\\\\MetaTagContainer\",\"handle\":\"twitter\",\"include\":true,\"dependencies\":[],\"clearCache\":false},\"MetaTagContainermiscellaneous\":{\"data\":[],\"name\":\"Miscellaneous\",\"description\":\"Miscellaneous Meta Tags\",\"class\":\"nystudio107\\\\seomatic\\\\models\\\\MetaTagContainer\",\"handle\":\"miscellaneous\",\"include\":true,\"dependencies\":[],\"clearCache\":false},\"MetaLinkContainergeneral\":{\"data\":[],\"name\":\"General\",\"description\":\"Link Tags\",\"class\":\"nystudio107\\\\seomatic\\\\models\\\\MetaLinkContainer\",\"handle\":\"general\",\"include\":true,\"dependencies\":[],\"clearCache\":false},\"MetaScriptContainergeneral\":{\"data\":[],\"position\":1,\"name\":\"General\",\"description\":\"Script Tags\",\"class\":\"nystudio107\\\\seomatic\\\\models\\\\MetaScriptContainer\",\"handle\":\"general\",\"include\":true,\"dependencies\":[],\"clearCache\":false},\"MetaJsonLdContainergeneral\":{\"data\":{\"mainEntityOfPage\":{\"articleBody\":null,\"articleSection\":null,\"backstory\":null,\"pageEnd\":null,\"pageStart\":null,\"pagination\":null,\"speakable\":null,\"wordCount\":null,\"about\":null,\"accessMode\":null,\"accessModeSufficient\":null,\"accessibilityAPI\":null,\"accessibilityControl\":null,\"accessibilityFeature\":null,\"accessibilityHazard\":null,\"accessibilitySummary\":null,\"accountablePerson\":null,\"aggregateRating\":null,\"alternativeHeadline\":null,\"associatedMedia\":null,\"audience\":null,\"audio\":null,\"author\":{\"id\":\"{seomatic.site.identity.genericUrl}#identity\"},\"award\":null,\"character\":null,\"citation\":null,\"comment\":null,\"commentCount\":null,\"contentLocation\":null,\"contentRating\":null,\"contentReferenceTime\":null,\"contributor\":null,\"copyrightHolder\":{\"id\":\"{seomatic.site.identity.genericUrl}#identity\"},\"copyrightYear\":\"{entry.postDate | date(\\\"Y\\\")}\",\"correction\":null,\"creator\":{\"id\":\"{seomatic.site.identity.genericUrl}#creator\"},\"dateCreated\":false,\"dateModified\":\"{entry.dateUpdated |atom}\",\"datePublished\":\"{entry.postDate |atom}\",\"discussionUrl\":null,\"editor\":null,\"educationalAlignment\":null,\"educationalUse\":null,\"encoding\":null,\"encodingFormat\":null,\"exampleOfWork\":null,\"expires\":null,\"funder\":null,\"genre\":null,\"hasPart\":null,\"headline\":\"{seomatic.meta.seoTitle}\",\"inLanguage\":\"{seomatic.meta.language}\",\"interactionStatistic\":null,\"interactivityType\":null,\"isAccessibleForFree\":null,\"isBasedOn\":null,\"isFamilyFriendly\":null,\"isPartOf\":null,\"keywords\":null,\"learningResourceType\":null,\"license\":null,\"locationCreated\":null,\"mainEntity\":null,\"material\":null,\"materialExtent\":null,\"mentions\":null,\"offers\":null,\"position\":null,\"producer\":null,\"provider\":null,\"publication\":null,\"publisher\":{\"id\":\"{seomatic.site.identity.genericUrl}#creator\"},\"publisherImprint\":null,\"publishingPrinciples\":null,\"recordedAt\":null,\"releasedEvent\":null,\"review\":null,\"schemaVersion\":null,\"sdDatePublished\":null,\"sdLicense\":null,\"sdPublisher\":null,\"sourceOrganization\":null,\"spatial\":null,\"spatialCoverage\":null,\"sponsor\":null,\"temporal\":null,\"temporalCoverage\":null,\"text\":null,\"thumbnailUrl\":null,\"timeRequired\":null,\"translationOfWork\":null,\"translator\":null,\"typicalAgeRange\":null,\"version\":null,\"video\":null,\"workExample\":null,\"workTranslation\":null,\"additionalType\":null,\"alternateName\":null,\"description\":\"{seomatic.meta.seoDescription}\",\"disambiguatingDescription\":null,\"identifier\":null,\"image\":{\"type\":\"ImageObject\",\"url\":\"{seomatic.meta.seoImage}\"},\"mainEntityOfPage\":\"{seomatic.meta.canonicalUrl}\",\"name\":\"{seomatic.meta.seoTitle}\",\"potentialAction\":{\"type\":\"SearchAction\",\"target\":\"{seomatic.site.siteLinksSearchTarget}\",\"query-input\":\"{seomatic.helper.siteLinksQueryInput()}\"},\"sameAs\":null,\"subjectOf\":null,\"url\":\"{seomatic.meta.canonicalUrl}\",\"context\":\"http://schema.org\",\"type\":\"{seomatic.meta.mainEntityOfPage}\",\"id\":null,\"graph\":null,\"include\":true,\"key\":\"mainEntityOfPage\",\"environment\":null,\"dependencies\":null}},\"name\":\"General\",\"description\":\"JsonLd Tags\",\"class\":\"nystudio107\\\\seomatic\\\\models\\\\MetaJsonLdContainer\",\"handle\":\"general\",\"include\":true,\"dependencies\":[],\"clearCache\":false},\"MetaTitleContainergeneral\":{\"data\":{\"title\":{\"title\":\"{seomatic.meta.seoTitle}\",\"siteName\":\"{seomatic.site.siteName}\",\"siteNamePosition\":\"{seomatic.meta.siteNamePosition}\",\"separatorChar\":\"{seomatic.config.separatorChar}\",\"include\":true,\"key\":\"title\",\"environment\":null,\"dependencies\":null}},\"name\":\"General\",\"description\":\"Meta Title Tag\",\"class\":\"nystudio107\\\\seomatic\\\\models\\\\MetaTitleContainer\",\"handle\":\"general\",\"include\":true,\"dependencies\":[],\"clearCache\":false}}', '[]', '{\"data\":[],\"name\":null,\"description\":null,\"class\":\"nystudio107\\\\seomatic\\\\models\\\\FrontendTemplateContainer\",\"handle\":null,\"include\":true,\"dependencies\":null,\"clearCache\":false}', '{\"siteType\":\"CreativeWork\",\"siteSubType\":\"Article\",\"siteSpecificType\":\"none\",\"seoTitleSource\":\"fromField\",\"seoTitleField\":\"title\",\"siteNamePositionSource\":\"sameAsGlobal\",\"seoDescriptionSource\":\"fromField\",\"seoDescriptionField\":\"summary\",\"seoKeywordsSource\":\"fromField\",\"seoKeywordsField\":\"keywords\",\"seoImageIds\":\"\",\"seoImageSource\":\"fromField\",\"seoImageField\":\"image\",\"seoImageTransform\":\"1\",\"seoImageTransformMode\":\"crop\",\"seoImageDescriptionSource\":\"fromCustom\",\"seoImageDescriptionField\":\"title\",\"twitterCreatorSource\":\"sameAsSite\",\"twitterCreatorField\":\"\",\"twitterTitleSource\":\"sameAsSeo\",\"twitterTitleField\":\"\",\"twitterSiteNamePositionSource\":\"sameAsGlobal\",\"twitterDescriptionSource\":\"sameAsSeo\",\"twitterDescriptionField\":\"\",\"twitterImageIds\":\"\",\"twitterImageSource\":\"sameAsSeo\",\"twitterImageField\":\"image\",\"twitterImageTransform\":\"1\",\"twitterImageTransformMode\":\"crop\",\"twitterImageDescriptionSource\":\"sameAsSeo\",\"twitterImageDescriptionField\":\"\",\"ogTitleSource\":\"sameAsSeo\",\"ogTitleField\":\"\",\"ogSiteNamePositionSource\":\"sameAsGlobal\",\"ogDescriptionSource\":\"sameAsSeo\",\"ogDescriptionField\":\"\",\"ogImageIds\":\"\",\"ogImageSource\":\"sameAsSeo\",\"ogImageField\":\"image\",\"ogImageTransform\":\"1\",\"ogImageTransformMode\":\"crop\",\"ogImageDescriptionSource\":\"sameAsSeo\",\"ogImageDescriptionField\":\"\"}');
INSERT INTO `seomatic_metabundles` (`id`, `dateCreated`, `dateUpdated`, `uid`, `bundleVersion`, `sourceBundleType`, `sourceId`, `sourceName`, `sourceHandle`, `sourceType`, `sourceTemplate`, `sourceSiteId`, `sourceAltSiteSettings`, `sourceDateUpdated`, `metaGlobalVars`, `metaSiteVars`, `metaSitemapVars`, `metaContainers`, `redirectsContainer`, `frontendTemplatesContainer`, `metaBundleSettings`) VALUES ('5', '2019-12-16 21:21:33', '2019-12-24 17:47:06', 'eb6a584d-05eb-4eb8-a853-b994a367c1a3', '1.0.28', 'section', '3', 'Homepage', 'homepage', 'single', 'index', '2', '{\"2\":{\"id\":\"3\",\"sectionId\":\"3\",\"siteId\":\"2\",\"enabledByDefault\":\"1\",\"hasUrls\":\"1\",\"uriFormat\":\"__home__\",\"template\":\"index\",\"language\":\"en-us\"}}', '2019-12-24 17:47:06', '{\"language\":null,\"mainEntityOfPage\":\"WebPage\",\"seoTitle\":\"{seomatic.helper.extractTextFromField(object.entry.title)}\",\"siteNamePosition\":\"\",\"seoDescription\":\"{seomatic.helper.extractSummary(seomatic.helper.extractTextFromField(object.entry.summary))}\",\"seoKeywords\":\"{seomatic.helper.extractKeywords(seomatic.helper.extractTextFromField(object.entry.keywords))}\",\"seoImage\":\"{seomatic.helper.socialTransform(object.entry.image[0], \\\"base\\\", 2, \\\"crop\\\")}\",\"seoImageWidth\":\"{seomatic.helper.socialTransformWidth(object.entry.image[0], \\\"base\\\", 2, \\\"crop\\\")}\",\"seoImageHeight\":\"{seomatic.helper.socialTransformHeight(object.entry.image[0], \\\"base\\\", 2, \\\"crop\\\")}\",\"seoImageDescription\":\"\",\"canonicalUrl\":\"{entry.url}\",\"robots\":\"all\",\"ogType\":\"website\",\"ogTitle\":\"{seomatic.meta.seoTitle}\",\"ogSiteNamePosition\":\"\",\"ogDescription\":\"{seomatic.meta.seoDescription}\",\"ogImage\":\"{seomatic.helper.socialTransform(object.entry.image[0], \\\"facebook\\\", 2, \\\"crop\\\")}\",\"ogImageWidth\":\"{seomatic.helper.socialTransformWidth(object.entry.image[0], \\\"facebook\\\", 2, \\\"crop\\\")}\",\"ogImageHeight\":\"{seomatic.helper.socialTransformHeight(object.entry.image[0], \\\"facebook\\\", 2, \\\"crop\\\")}\",\"ogImageDescription\":\"{seomatic.meta.seoImageDescription}\",\"twitterCard\":\"summary_large_image\",\"twitterCreator\":\"{seomatic.site.twitterHandle}\",\"twitterTitle\":\"{seomatic.meta.seoTitle}\",\"twitterSiteNamePosition\":\"\",\"twitterDescription\":\"{seomatic.meta.seoDescription}\",\"twitterImage\":\"{seomatic.helper.socialTransform(object.entry.image[0], seomatic.helper.twitterTransform(), 2, \\\"crop\\\")}\",\"twitterImageWidth\":\"{seomatic.helper.socialTransformWidth(object.entry.image[0], seomatic.helper.twitterTransform(), 2, \\\"crop\\\")}\",\"twitterImageHeight\":\"{seomatic.helper.socialTransformHeight(object.entry.image[0], seomatic.helper.twitterTransform(), 2, \\\"crop\\\")}\",\"twitterImageDescription\":\"{seomatic.meta.seoImageDescription}\"}', '{\"siteName\":\"FWORK Plus\",\"identity\":null,\"creator\":null,\"twitterHandle\":\"\",\"facebookProfileId\":\"\",\"facebookAppId\":\"\",\"googleSiteVerification\":\"\",\"bingSiteVerification\":\"\",\"pinterestSiteVerification\":\"\",\"sameAsLinks\":[],\"siteLinksSearchTarget\":\"\",\"siteLinksQueryInput\":\"\",\"additionalSitemapUrls\":[],\"additionalSitemapUrlsDateUpdated\":null,\"additionalSitemaps\":[]}', '{\"sitemapUrls\":true,\"sitemapAssets\":true,\"sitemapFiles\":true,\"sitemapAltLinks\":true,\"sitemapChangeFreq\":\"weekly\",\"sitemapPriority\":0.5,\"sitemapLimit\":null,\"structureDepth\":null,\"sitemapImageFieldMap\":[{\"property\":\"title\",\"field\":\"title\"},{\"property\":\"caption\",\"field\":\"\"},{\"property\":\"geo_location\",\"field\":\"\"},{\"property\":\"license\",\"field\":\"\"}],\"sitemapVideoFieldMap\":[{\"property\":\"title\",\"field\":\"title\"},{\"property\":\"description\",\"field\":\"\"},{\"property\":\"thumbnailLoc\",\"field\":\"\"},{\"property\":\"duration\",\"field\":\"\"},{\"property\":\"category\",\"field\":\"\"}]}', '{\"MetaTagContainergeneral\":{\"data\":[],\"name\":\"General\",\"description\":\"General Meta Tags\",\"class\":\"nystudio107\\\\seomatic\\\\models\\\\MetaTagContainer\",\"handle\":\"general\",\"include\":true,\"dependencies\":[],\"clearCache\":false},\"MetaTagContaineropengraph\":{\"data\":[],\"name\":\"Facebook\",\"description\":\"Facebook OpenGraph Meta Tags\",\"class\":\"nystudio107\\\\seomatic\\\\models\\\\MetaTagContainer\",\"handle\":\"opengraph\",\"include\":true,\"dependencies\":[],\"clearCache\":false},\"MetaTagContainertwitter\":{\"data\":[],\"name\":\"Twitter\",\"description\":\"Twitter Card Meta Tags\",\"class\":\"nystudio107\\\\seomatic\\\\models\\\\MetaTagContainer\",\"handle\":\"twitter\",\"include\":true,\"dependencies\":[],\"clearCache\":false},\"MetaTagContainermiscellaneous\":{\"data\":[],\"name\":\"Miscellaneous\",\"description\":\"Miscellaneous Meta Tags\",\"class\":\"nystudio107\\\\seomatic\\\\models\\\\MetaTagContainer\",\"handle\":\"miscellaneous\",\"include\":true,\"dependencies\":[],\"clearCache\":false},\"MetaLinkContainergeneral\":{\"data\":[],\"name\":\"General\",\"description\":\"Link Tags\",\"class\":\"nystudio107\\\\seomatic\\\\models\\\\MetaLinkContainer\",\"handle\":\"general\",\"include\":true,\"dependencies\":[],\"clearCache\":false},\"MetaScriptContainergeneral\":{\"data\":[],\"position\":1,\"name\":\"General\",\"description\":\"Script Tags\",\"class\":\"nystudio107\\\\seomatic\\\\models\\\\MetaScriptContainer\",\"handle\":\"general\",\"include\":true,\"dependencies\":[],\"clearCache\":false},\"MetaJsonLdContainergeneral\":{\"data\":{\"mainEntityOfPage\":{\"breadcrumb\":null,\"lastReviewed\":null,\"mainContentOfPage\":null,\"primaryImageOfPage\":null,\"relatedLink\":null,\"reviewedBy\":null,\"significantLink\":null,\"speakable\":null,\"specialty\":null,\"about\":null,\"accessMode\":null,\"accessModeSufficient\":null,\"accessibilityAPI\":null,\"accessibilityControl\":null,\"accessibilityFeature\":null,\"accessibilityHazard\":null,\"accessibilitySummary\":null,\"accountablePerson\":null,\"aggregateRating\":null,\"alternativeHeadline\":null,\"associatedMedia\":null,\"audience\":null,\"audio\":null,\"author\":{\"id\":\"{seomatic.site.identity.genericUrl}#identity\"},\"award\":null,\"character\":null,\"citation\":null,\"comment\":null,\"commentCount\":null,\"contentLocation\":null,\"contentRating\":null,\"contentReferenceTime\":null,\"contributor\":null,\"copyrightHolder\":{\"id\":\"{seomatic.site.identity.genericUrl}#identity\"},\"copyrightYear\":\"{entry.postDate | date(\\\"Y\\\")}\",\"correction\":null,\"creator\":{\"id\":\"{seomatic.site.identity.genericUrl}#creator\"},\"dateCreated\":false,\"dateModified\":\"{entry.dateUpdated |atom}\",\"datePublished\":\"{entry.postDate |atom}\",\"discussionUrl\":null,\"editor\":null,\"educationalAlignment\":null,\"educationalUse\":null,\"encoding\":null,\"encodingFormat\":null,\"exampleOfWork\":null,\"expires\":null,\"funder\":null,\"genre\":null,\"hasPart\":null,\"headline\":\"{seomatic.meta.seoTitle}\",\"inLanguage\":\"{seomatic.meta.language}\",\"interactionStatistic\":null,\"interactivityType\":null,\"isAccessibleForFree\":null,\"isBasedOn\":null,\"isFamilyFriendly\":null,\"isPartOf\":null,\"keywords\":null,\"learningResourceType\":null,\"license\":null,\"locationCreated\":null,\"mainEntity\":null,\"material\":null,\"materialExtent\":null,\"mentions\":null,\"offers\":null,\"position\":null,\"producer\":null,\"provider\":null,\"publication\":null,\"publisher\":{\"id\":\"{seomatic.site.identity.genericUrl}#creator\"},\"publisherImprint\":null,\"publishingPrinciples\":null,\"recordedAt\":null,\"releasedEvent\":null,\"review\":null,\"schemaVersion\":null,\"sdDatePublished\":null,\"sdLicense\":null,\"sdPublisher\":null,\"sourceOrganization\":null,\"spatial\":null,\"spatialCoverage\":null,\"sponsor\":null,\"temporal\":null,\"temporalCoverage\":null,\"text\":null,\"thumbnailUrl\":null,\"timeRequired\":null,\"translationOfWork\":null,\"translator\":null,\"typicalAgeRange\":null,\"version\":null,\"video\":null,\"workExample\":null,\"workTranslation\":null,\"additionalType\":null,\"alternateName\":null,\"description\":\"{seomatic.meta.seoDescription}\",\"disambiguatingDescription\":null,\"identifier\":null,\"image\":{\"type\":\"ImageObject\",\"url\":\"{seomatic.meta.seoImage}\"},\"mainEntityOfPage\":\"{seomatic.meta.canonicalUrl}\",\"name\":\"{seomatic.meta.seoTitle}\",\"potentialAction\":{\"type\":\"SearchAction\",\"target\":\"{seomatic.site.siteLinksSearchTarget}\",\"query-input\":\"{seomatic.helper.siteLinksQueryInput()}\"},\"sameAs\":null,\"subjectOf\":null,\"url\":\"{seomatic.meta.canonicalUrl}\",\"context\":\"http://schema.org\",\"type\":\"{seomatic.meta.mainEntityOfPage}\",\"id\":null,\"graph\":null,\"include\":true,\"key\":\"mainEntityOfPage\",\"environment\":null,\"dependencies\":null}},\"name\":\"General\",\"description\":\"JsonLd Tags\",\"class\":\"nystudio107\\\\seomatic\\\\models\\\\MetaJsonLdContainer\",\"handle\":\"general\",\"include\":true,\"dependencies\":[],\"clearCache\":false},\"MetaTitleContainergeneral\":{\"data\":{\"title\":{\"title\":\"{seomatic.meta.seoTitle}\",\"siteName\":\"{seomatic.site.siteName}\",\"siteNamePosition\":\"{seomatic.meta.siteNamePosition}\",\"separatorChar\":\"{seomatic.config.separatorChar}\",\"include\":true,\"key\":\"title\",\"environment\":null,\"dependencies\":null}},\"name\":\"General\",\"description\":\"Meta Title Tag\",\"class\":\"nystudio107\\\\seomatic\\\\models\\\\MetaTitleContainer\",\"handle\":\"general\",\"include\":true,\"dependencies\":[],\"clearCache\":false}}', '[]', '{\"data\":[],\"name\":null,\"description\":null,\"class\":\"nystudio107\\\\seomatic\\\\models\\\\FrontendTemplateContainer\",\"handle\":null,\"include\":true,\"dependencies\":null,\"clearCache\":false}', '{\"siteType\":\"CreativeWork\",\"siteSubType\":\"WebPage\",\"siteSpecificType\":\"none\",\"seoTitleSource\":\"fromField\",\"seoTitleField\":\"title\",\"siteNamePositionSource\":\"sameAsGlobal\",\"seoDescriptionSource\":\"summaryFromField\",\"seoDescriptionField\":\"summary\",\"seoKeywordsSource\":\"keywordsFromField\",\"seoKeywordsField\":\"keywords\",\"seoImageIds\":\"\",\"seoImageSource\":\"fromField\",\"seoImageField\":\"image\",\"seoImageTransform\":\"1\",\"seoImageTransformMode\":\"crop\",\"seoImageDescriptionSource\":\"fromCustom\",\"seoImageDescriptionField\":\"title\",\"twitterCreatorSource\":\"sameAsSite\",\"twitterCreatorField\":\"\",\"twitterTitleSource\":\"sameAsSeo\",\"twitterTitleField\":\"\",\"twitterSiteNamePositionSource\":\"sameAsGlobal\",\"twitterDescriptionSource\":\"sameAsSeo\",\"twitterDescriptionField\":\"\",\"twitterImageIds\":\"\",\"twitterImageSource\":\"sameAsSeo\",\"twitterImageField\":\"image\",\"twitterImageTransform\":\"1\",\"twitterImageTransformMode\":\"crop\",\"twitterImageDescriptionSource\":\"sameAsSeo\",\"twitterImageDescriptionField\":\"\",\"ogTitleSource\":\"sameAsSeo\",\"ogTitleField\":\"\",\"ogSiteNamePositionSource\":\"sameAsGlobal\",\"ogDescriptionSource\":\"sameAsSeo\",\"ogDescriptionField\":\"\",\"ogImageIds\":\"\",\"ogImageSource\":\"sameAsSeo\",\"ogImageField\":\"image\",\"ogImageTransform\":\"1\",\"ogImageTransformMode\":\"crop\",\"ogImageDescriptionSource\":\"sameAsSeo\",\"ogImageDescriptionField\":\"\"}');
INSERT INTO `seomatic_metabundles` (`id`, `dateCreated`, `dateUpdated`, `uid`, `bundleVersion`, `sourceBundleType`, `sourceId`, `sourceName`, `sourceHandle`, `sourceType`, `sourceTemplate`, `sourceSiteId`, `sourceAltSiteSettings`, `sourceDateUpdated`, `metaGlobalVars`, `metaSiteVars`, `metaSitemapVars`, `metaContainers`, `redirectsContainer`, `frontendTemplatesContainer`, `metaBundleSettings`) VALUES ('6', '2019-12-16 21:26:21', '2019-12-16 21:33:08', '6c03da2b-0d0c-46f4-be20-38f6cb6d4bf9', '1.0.28', 'section', '4', 'Page Not Found', 'pageNotFound', 'single', '404', '2', '{\"2\":{\"id\":\"4\",\"sectionId\":\"4\",\"siteId\":\"2\",\"enabledByDefault\":\"1\",\"hasUrls\":\"1\",\"uriFormat\":\"page-not-found\",\"template\":\"404\",\"language\":\"en-us\"}}', '2019-12-16 21:28:08', '{\"language\":null,\"mainEntityOfPage\":\"WebPage\",\"seoTitle\":\"{seomatic.helper.extractTextFromField(object.entry.title)}\",\"siteNamePosition\":\"\",\"seoDescription\":\"{seomatic.helper.extractTextFromField(object.entry.summary)}\",\"seoKeywords\":\"{seomatic.helper.extractTextFromField(object.entry.keywords)}\",\"seoImage\":\"{seomatic.helper.socialTransform(object.entry.image[0], \\\"base\\\", 2, \\\"crop\\\")}\",\"seoImageWidth\":\"{seomatic.helper.socialTransformWidth(object.entry.image[0], \\\"base\\\", 2, \\\"crop\\\")}\",\"seoImageHeight\":\"{seomatic.helper.socialTransformHeight(object.entry.image[0], \\\"base\\\", 2, \\\"crop\\\")}\",\"seoImageDescription\":\"\",\"canonicalUrl\":\"{entry.url}\",\"robots\":\"all\",\"ogType\":\"website\",\"ogTitle\":\"{seomatic.meta.seoTitle}\",\"ogSiteNamePosition\":\"\",\"ogDescription\":\"{seomatic.meta.seoDescription}\",\"ogImage\":\"{seomatic.helper.socialTransform(object.entry.image[0], \\\"facebook\\\", 2, \\\"crop\\\")}\",\"ogImageWidth\":\"{seomatic.helper.socialTransformWidth(object.entry.image[0], \\\"facebook\\\", 2, \\\"crop\\\")}\",\"ogImageHeight\":\"{seomatic.helper.socialTransformHeight(object.entry.image[0], \\\"facebook\\\", 2, \\\"crop\\\")}\",\"ogImageDescription\":\"{seomatic.meta.seoImageDescription}\",\"twitterCard\":\"summary_large_image\",\"twitterCreator\":\"{seomatic.site.twitterHandle}\",\"twitterTitle\":\"{seomatic.meta.seoTitle}\",\"twitterSiteNamePosition\":\"\",\"twitterDescription\":\"{seomatic.meta.seoDescription}\",\"twitterImage\":\"{seomatic.helper.socialTransform(object.entry.image[0], seomatic.helper.twitterTransform(), 2, \\\"crop\\\")}\",\"twitterImageWidth\":\"{seomatic.helper.socialTransformWidth(object.entry.image[0], seomatic.helper.twitterTransform(), 2, \\\"crop\\\")}\",\"twitterImageHeight\":\"{seomatic.helper.socialTransformHeight(object.entry.image[0], seomatic.helper.twitterTransform(), 2, \\\"crop\\\")}\",\"twitterImageDescription\":\"{seomatic.meta.seoImageDescription}\"}', '{\"siteName\":\"FWORK Plus\",\"identity\":null,\"creator\":null,\"twitterHandle\":\"\",\"facebookProfileId\":\"\",\"facebookAppId\":\"\",\"googleSiteVerification\":\"\",\"bingSiteVerification\":\"\",\"pinterestSiteVerification\":\"\",\"sameAsLinks\":[],\"siteLinksSearchTarget\":\"\",\"siteLinksQueryInput\":\"\",\"additionalSitemapUrls\":[],\"additionalSitemapUrlsDateUpdated\":null,\"additionalSitemaps\":[]}', '{\"sitemapUrls\":true,\"sitemapAssets\":true,\"sitemapFiles\":true,\"sitemapAltLinks\":true,\"sitemapChangeFreq\":\"weekly\",\"sitemapPriority\":0.5,\"sitemapLimit\":null,\"structureDepth\":null,\"sitemapImageFieldMap\":[{\"property\":\"title\",\"field\":\"title\"},{\"property\":\"caption\",\"field\":\"\"},{\"property\":\"geo_location\",\"field\":\"\"},{\"property\":\"license\",\"field\":\"\"}],\"sitemapVideoFieldMap\":[{\"property\":\"title\",\"field\":\"title\"},{\"property\":\"description\",\"field\":\"\"},{\"property\":\"thumbnailLoc\",\"field\":\"\"},{\"property\":\"duration\",\"field\":\"\"},{\"property\":\"category\",\"field\":\"\"}]}', '{\"MetaTagContainergeneral\":{\"data\":[],\"name\":\"General\",\"description\":\"General Meta Tags\",\"class\":\"nystudio107\\\\seomatic\\\\models\\\\MetaTagContainer\",\"handle\":\"general\",\"include\":true,\"dependencies\":[],\"clearCache\":false},\"MetaTagContaineropengraph\":{\"data\":[],\"name\":\"Facebook\",\"description\":\"Facebook OpenGraph Meta Tags\",\"class\":\"nystudio107\\\\seomatic\\\\models\\\\MetaTagContainer\",\"handle\":\"opengraph\",\"include\":true,\"dependencies\":[],\"clearCache\":false},\"MetaTagContainertwitter\":{\"data\":[],\"name\":\"Twitter\",\"description\":\"Twitter Card Meta Tags\",\"class\":\"nystudio107\\\\seomatic\\\\models\\\\MetaTagContainer\",\"handle\":\"twitter\",\"include\":true,\"dependencies\":[],\"clearCache\":false},\"MetaTagContainermiscellaneous\":{\"data\":[],\"name\":\"Miscellaneous\",\"description\":\"Miscellaneous Meta Tags\",\"class\":\"nystudio107\\\\seomatic\\\\models\\\\MetaTagContainer\",\"handle\":\"miscellaneous\",\"include\":true,\"dependencies\":[],\"clearCache\":false},\"MetaLinkContainergeneral\":{\"data\":[],\"name\":\"General\",\"description\":\"Link Tags\",\"class\":\"nystudio107\\\\seomatic\\\\models\\\\MetaLinkContainer\",\"handle\":\"general\",\"include\":true,\"dependencies\":[],\"clearCache\":false},\"MetaScriptContainergeneral\":{\"data\":[],\"position\":1,\"name\":\"General\",\"description\":\"Script Tags\",\"class\":\"nystudio107\\\\seomatic\\\\models\\\\MetaScriptContainer\",\"handle\":\"general\",\"include\":true,\"dependencies\":[],\"clearCache\":false},\"MetaJsonLdContainergeneral\":{\"data\":{\"mainEntityOfPage\":{\"breadcrumb\":null,\"lastReviewed\":null,\"mainContentOfPage\":null,\"primaryImageOfPage\":null,\"relatedLink\":null,\"reviewedBy\":null,\"significantLink\":null,\"speakable\":null,\"specialty\":null,\"about\":null,\"accessMode\":null,\"accessModeSufficient\":null,\"accessibilityAPI\":null,\"accessibilityControl\":null,\"accessibilityFeature\":null,\"accessibilityHazard\":null,\"accessibilitySummary\":null,\"accountablePerson\":null,\"aggregateRating\":null,\"alternativeHeadline\":null,\"associatedMedia\":null,\"audience\":null,\"audio\":null,\"author\":{\"id\":\"{seomatic.site.identity.genericUrl}#identity\"},\"award\":null,\"character\":null,\"citation\":null,\"comment\":null,\"commentCount\":null,\"contentLocation\":null,\"contentRating\":null,\"contentReferenceTime\":null,\"contributor\":null,\"copyrightHolder\":{\"id\":\"{seomatic.site.identity.genericUrl}#identity\"},\"copyrightYear\":\"{entry.postDate | date(\\\"Y\\\")}\",\"correction\":null,\"creator\":{\"id\":\"{seomatic.site.identity.genericUrl}#creator\"},\"dateCreated\":false,\"dateModified\":\"{entry.dateUpdated |atom}\",\"datePublished\":\"{entry.postDate |atom}\",\"discussionUrl\":null,\"editor\":null,\"educationalAlignment\":null,\"educationalUse\":null,\"encoding\":null,\"encodingFormat\":null,\"exampleOfWork\":null,\"expires\":null,\"funder\":null,\"genre\":null,\"hasPart\":null,\"headline\":\"{seomatic.meta.seoTitle}\",\"inLanguage\":\"{seomatic.meta.language}\",\"interactionStatistic\":null,\"interactivityType\":null,\"isAccessibleForFree\":null,\"isBasedOn\":null,\"isFamilyFriendly\":null,\"isPartOf\":null,\"keywords\":null,\"learningResourceType\":null,\"license\":null,\"locationCreated\":null,\"mainEntity\":null,\"material\":null,\"materialExtent\":null,\"mentions\":null,\"offers\":null,\"position\":null,\"producer\":null,\"provider\":null,\"publication\":null,\"publisher\":{\"id\":\"{seomatic.site.identity.genericUrl}#creator\"},\"publisherImprint\":null,\"publishingPrinciples\":null,\"recordedAt\":null,\"releasedEvent\":null,\"review\":null,\"schemaVersion\":null,\"sdDatePublished\":null,\"sdLicense\":null,\"sdPublisher\":null,\"sourceOrganization\":null,\"spatial\":null,\"spatialCoverage\":null,\"sponsor\":null,\"temporal\":null,\"temporalCoverage\":null,\"text\":null,\"thumbnailUrl\":null,\"timeRequired\":null,\"translationOfWork\":null,\"translator\":null,\"typicalAgeRange\":null,\"version\":null,\"video\":null,\"workExample\":null,\"workTranslation\":null,\"additionalType\":null,\"alternateName\":null,\"description\":\"{seomatic.meta.seoDescription}\",\"disambiguatingDescription\":null,\"identifier\":null,\"image\":{\"type\":\"ImageObject\",\"url\":\"{seomatic.meta.seoImage}\"},\"mainEntityOfPage\":\"{seomatic.meta.canonicalUrl}\",\"name\":\"{seomatic.meta.seoTitle}\",\"potentialAction\":{\"type\":\"SearchAction\",\"target\":\"{seomatic.site.siteLinksSearchTarget}\",\"query-input\":\"{seomatic.helper.siteLinksQueryInput()}\"},\"sameAs\":null,\"subjectOf\":null,\"url\":\"{seomatic.meta.canonicalUrl}\",\"context\":\"http://schema.org\",\"type\":\"{seomatic.meta.mainEntityOfPage}\",\"id\":null,\"graph\":null,\"include\":true,\"key\":\"mainEntityOfPage\",\"environment\":null,\"dependencies\":null}},\"name\":\"General\",\"description\":\"JsonLd Tags\",\"class\":\"nystudio107\\\\seomatic\\\\models\\\\MetaJsonLdContainer\",\"handle\":\"general\",\"include\":true,\"dependencies\":[],\"clearCache\":false},\"MetaTitleContainergeneral\":{\"data\":{\"title\":{\"title\":\"{seomatic.meta.seoTitle}\",\"siteName\":\"{seomatic.site.siteName}\",\"siteNamePosition\":\"{seomatic.meta.siteNamePosition}\",\"separatorChar\":\"{seomatic.config.separatorChar}\",\"include\":true,\"key\":\"title\",\"environment\":null,\"dependencies\":null}},\"name\":\"General\",\"description\":\"Meta Title Tag\",\"class\":\"nystudio107\\\\seomatic\\\\models\\\\MetaTitleContainer\",\"handle\":\"general\",\"include\":true,\"dependencies\":[],\"clearCache\":false}}', '[]', '{\"data\":[],\"name\":null,\"description\":null,\"class\":\"nystudio107\\\\seomatic\\\\models\\\\FrontendTemplateContainer\",\"handle\":null,\"include\":true,\"dependencies\":null,\"clearCache\":false}', '{\"siteType\":\"CreativeWork\",\"siteSubType\":\"WebPage\",\"siteSpecificType\":\"none\",\"seoTitleSource\":\"fromField\",\"seoTitleField\":\"title\",\"siteNamePositionSource\":\"sameAsGlobal\",\"seoDescriptionSource\":\"fromField\",\"seoDescriptionField\":\"summary\",\"seoKeywordsSource\":\"fromField\",\"seoKeywordsField\":\"keywords\",\"seoImageIds\":\"\",\"seoImageSource\":\"fromField\",\"seoImageField\":\"image\",\"seoImageTransform\":\"1\",\"seoImageTransformMode\":\"crop\",\"seoImageDescriptionSource\":\"fromCustom\",\"seoImageDescriptionField\":\"title\",\"twitterCreatorSource\":\"sameAsSite\",\"twitterCreatorField\":\"\",\"twitterTitleSource\":\"sameAsSeo\",\"twitterTitleField\":\"\",\"twitterSiteNamePositionSource\":\"sameAsGlobal\",\"twitterDescriptionSource\":\"sameAsSeo\",\"twitterDescriptionField\":\"\",\"twitterImageIds\":\"\",\"twitterImageSource\":\"sameAsSeo\",\"twitterImageField\":\"image\",\"twitterImageTransform\":\"1\",\"twitterImageTransformMode\":\"crop\",\"twitterImageDescriptionSource\":\"sameAsSeo\",\"twitterImageDescriptionField\":\"\",\"ogTitleSource\":\"sameAsSeo\",\"ogTitleField\":\"\",\"ogSiteNamePositionSource\":\"sameAsGlobal\",\"ogDescriptionSource\":\"sameAsSeo\",\"ogDescriptionField\":\"\",\"ogImageIds\":\"\",\"ogImageSource\":\"sameAsSeo\",\"ogImageField\":\"image\",\"ogImageTransform\":\"1\",\"ogImageTransformMode\":\"crop\",\"ogImageDescriptionSource\":\"sameAsSeo\",\"ogImageDescriptionField\":\"\"}');

INSERT INTO `sitegroups` (`id`, `name`, `dateCreated`, `dateUpdated`, `dateDeleted`, `uid`) VALUES ('1', 'Craft Vue Tailwind', '2019-12-12 12:18:01', '2019-12-16 09:53:47', '2019-12-16 09:53:47', 'a97fa10c-e615-4dc8-8d1e-6c25721a13e1');
INSERT INTO `sitegroups` (`id`, `name`, `dateCreated`, `dateUpdated`, `dateDeleted`, `uid`) VALUES ('2', 'Craft Vue Tailwind', '2019-12-16 09:53:47', '2019-12-16 09:53:47', NULL, '88d38408-5360-4f46-b37c-026f929f9307');

INSERT INTO `sites` (`id`, `groupId`, `primary`, `name`, `handle`, `language`, `hasUrls`, `baseUrl`, `sortOrder`, `dateCreated`, `dateUpdated`, `dateDeleted`, `uid`) VALUES ('1', '1', '0', 'Craft Vue Tailwind', 'default', 'en-US', '1', '$DEFAULT_SITE_URL', '1', '2019-12-12 12:18:01', '2019-12-16 09:53:47', '2019-12-16 09:53:47', 'a5ce728f-b001-490e-9485-2d5463118d30');
INSERT INTO `sites` (`id`, `groupId`, `primary`, `name`, `handle`, `language`, `hasUrls`, `baseUrl`, `sortOrder`, `dateCreated`, `dateUpdated`, `dateDeleted`, `uid`) VALUES ('2', '2', '1', 'FWORK Plus', 'default', 'en-US', '1', '$DEFAULT_SITE_URL', '1', '2019-12-16 09:53:47', '2019-12-16 09:53:47', NULL, 'ab67a472-afac-4525-a8c9-08a909f0d281');

INSERT INTO `structureelements` (`id`, `structureId`, `elementId`, `root`, `lft`, `rgt`, `level`, `dateCreated`, `dateUpdated`, `uid`) VALUES ('1', '2', NULL, '1', '1', '14', '0', '2019-12-16 09:59:30', '2019-12-16 10:00:07', '887cd400-1329-4d60-b51f-9f04547cd9ca');
INSERT INTO `structureelements` (`id`, `structureId`, `elementId`, `root`, `lft`, `rgt`, `level`, `dateCreated`, `dateUpdated`, `uid`) VALUES ('3', '2', '3', '1', '2', '3', '1', '2019-12-16 09:59:38', '2019-12-16 09:59:38', 'cbe53fd5-cea2-4bbf-9d36-a5fc5e731653');
INSERT INTO `structureelements` (`id`, `structureId`, `elementId`, `root`, `lft`, `rgt`, `level`, `dateCreated`, `dateUpdated`, `uid`) VALUES ('4', '2', '4', '1', '4', '5', '1', '2019-12-16 09:59:38', '2019-12-16 09:59:38', '0fb48f8f-533a-4f73-9d7c-fa75364c7487');
INSERT INTO `structureelements` (`id`, `structureId`, `elementId`, `root`, `lft`, `rgt`, `level`, `dateCreated`, `dateUpdated`, `uid`) VALUES ('6', '2', '6', '1', '6', '7', '1', '2019-12-16 09:59:57', '2019-12-16 09:59:57', '73855f1c-07db-42cb-b3d7-692e1c9463da');
INSERT INTO `structureelements` (`id`, `structureId`, `elementId`, `root`, `lft`, `rgt`, `level`, `dateCreated`, `dateUpdated`, `uid`) VALUES ('7', '2', '7', '1', '8', '9', '1', '2019-12-16 09:59:57', '2019-12-16 09:59:57', 'bb6417e9-9e9a-4abc-92ea-ff253b131664');
INSERT INTO `structureelements` (`id`, `structureId`, `elementId`, `root`, `lft`, `rgt`, `level`, `dateCreated`, `dateUpdated`, `uid`) VALUES ('9', '2', '9', '1', '10', '11', '1', '2019-12-16 10:00:07', '2019-12-16 10:00:07', '8cb45ba9-ae08-43e8-b20d-651f30bbcfee');
INSERT INTO `structureelements` (`id`, `structureId`, `elementId`, `root`, `lft`, `rgt`, `level`, `dateCreated`, `dateUpdated`, `uid`) VALUES ('10', '2', '10', '1', '12', '13', '1', '2019-12-16 10:00:07', '2019-12-16 10:00:07', '34a36dce-898d-4f78-b768-f8a3621a5468');
INSERT INTO `structureelements` (`id`, `structureId`, `elementId`, `root`, `lft`, `rgt`, `level`, `dateCreated`, `dateUpdated`, `uid`) VALUES ('11', '1', NULL, '11', '1', '8', '0', '2019-12-16 10:06:29', '2019-12-16 10:06:41', '51914fc3-8100-4d1c-8827-c1b5fa35954e');
INSERT INTO `structureelements` (`id`, `structureId`, `elementId`, `root`, `lft`, `rgt`, `level`, `dateCreated`, `dateUpdated`, `uid`) VALUES ('12', '1', '11', '11', '2', '3', '1', '2019-12-16 10:06:29', '2019-12-16 10:06:29', '21d2610e-562e-4c70-9682-7319969b35ca');
INSERT INTO `structureelements` (`id`, `structureId`, `elementId`, `root`, `lft`, `rgt`, `level`, `dateCreated`, `dateUpdated`, `uid`) VALUES ('13', '1', '12', '11', '4', '5', '1', '2019-12-16 10:06:36', '2019-12-16 10:06:36', '78a88e87-3c6d-42ce-889f-6e03211f40a8');
INSERT INTO `structureelements` (`id`, `structureId`, `elementId`, `root`, `lft`, `rgt`, `level`, `dateCreated`, `dateUpdated`, `uid`) VALUES ('14', '1', '13', '11', '6', '7', '1', '2019-12-16 10:06:41', '2019-12-16 10:06:41', '9491d10d-b2da-4f91-a117-3fba31cb4eb5');
INSERT INTO `structureelements` (`id`, `structureId`, `elementId`, `root`, `lft`, `rgt`, `level`, `dateCreated`, `dateUpdated`, `uid`) VALUES ('15', '4', NULL, '15', '1', '14', '0', '2019-12-24 17:47:06', '2019-12-24 17:47:06', 'c4aee6a3-c989-4cc1-b697-950793a56fa8');
INSERT INTO `structureelements` (`id`, `structureId`, `elementId`, `root`, `lft`, `rgt`, `level`, `dateCreated`, `dateUpdated`, `uid`) VALUES ('16', '4', '24', '15', '2', '7', '1', '2019-12-24 17:47:06', '2019-12-24 17:47:06', 'e7cf3774-45e1-48c0-ab2d-acc3406919a9');
INSERT INTO `structureelements` (`id`, `structureId`, `elementId`, `root`, `lft`, `rgt`, `level`, `dateCreated`, `dateUpdated`, `uid`) VALUES ('17', '4', '25', '15', '3', '4', '2', '2019-12-24 17:47:06', '2019-12-24 17:47:06', '5a7fd429-9384-4eae-8069-3ab1ebc410a3');
INSERT INTO `structureelements` (`id`, `structureId`, `elementId`, `root`, `lft`, `rgt`, `level`, `dateCreated`, `dateUpdated`, `uid`) VALUES ('18', '4', '26', '15', '5', '6', '2', '2019-12-24 17:47:06', '2019-12-24 17:47:06', '64276800-9b3c-41c1-a7cb-f8d72fc17d0c');
INSERT INTO `structureelements` (`id`, `structureId`, `elementId`, `root`, `lft`, `rgt`, `level`, `dateCreated`, `dateUpdated`, `uid`) VALUES ('19', '4', '27', '15', '8', '13', '1', '2019-12-24 17:47:06', '2019-12-24 17:47:06', '03e6eabb-992a-4e3b-a3b9-18a8ddc70c20');
INSERT INTO `structureelements` (`id`, `structureId`, `elementId`, `root`, `lft`, `rgt`, `level`, `dateCreated`, `dateUpdated`, `uid`) VALUES ('20', '4', '28', '15', '9', '10', '2', '2019-12-24 17:47:06', '2019-12-24 17:47:06', 'a54b4d33-0e31-4056-943f-8669088a91dc');
INSERT INTO `structureelements` (`id`, `structureId`, `elementId`, `root`, `lft`, `rgt`, `level`, `dateCreated`, `dateUpdated`, `uid`) VALUES ('21', '4', '29', '15', '11', '12', '2', '2019-12-24 17:47:06', '2019-12-24 17:47:06', 'b0c52d76-7f0f-4d33-97f2-a507cb4263b6');
INSERT INTO `structureelements` (`id`, `structureId`, `elementId`, `root`, `lft`, `rgt`, `level`, `dateCreated`, `dateUpdated`, `uid`) VALUES ('22', '5', NULL, '22', '1', '14', '0', '2019-12-24 17:47:06', '2019-12-24 17:47:06', '6900a8a1-faf4-4df7-a49b-4b159c78088c');
INSERT INTO `structureelements` (`id`, `structureId`, `elementId`, `root`, `lft`, `rgt`, `level`, `dateCreated`, `dateUpdated`, `uid`) VALUES ('23', '5', '31', '22', '2', '7', '1', '2019-12-24 17:47:06', '2019-12-24 17:47:06', 'e1ac4749-14a7-4c0f-b23f-dd9c4732dcf6');
INSERT INTO `structureelements` (`id`, `structureId`, `elementId`, `root`, `lft`, `rgt`, `level`, `dateCreated`, `dateUpdated`, `uid`) VALUES ('24', '5', '32', '22', '3', '4', '2', '2019-12-24 17:47:06', '2019-12-24 17:47:06', '1355b054-c5a4-4eba-b4e7-ef3aa9f0dec0');
INSERT INTO `structureelements` (`id`, `structureId`, `elementId`, `root`, `lft`, `rgt`, `level`, `dateCreated`, `dateUpdated`, `uid`) VALUES ('25', '5', '33', '22', '5', '6', '2', '2019-12-24 17:47:06', '2019-12-24 17:47:06', 'a2e6e622-aeb2-4c4a-a69c-2f0cf6c938a4');
INSERT INTO `structureelements` (`id`, `structureId`, `elementId`, `root`, `lft`, `rgt`, `level`, `dateCreated`, `dateUpdated`, `uid`) VALUES ('26', '5', '34', '22', '8', '13', '1', '2019-12-24 17:47:06', '2019-12-24 17:47:06', 'fd1355b1-b5cd-43aa-bf0d-7cd62ee69e84');
INSERT INTO `structureelements` (`id`, `structureId`, `elementId`, `root`, `lft`, `rgt`, `level`, `dateCreated`, `dateUpdated`, `uid`) VALUES ('27', '5', '35', '22', '9', '10', '2', '2019-12-24 17:47:06', '2019-12-24 17:47:06', '3d30d9e2-5a06-4f8b-9e9c-19c269d3484a');
INSERT INTO `structureelements` (`id`, `structureId`, `elementId`, `root`, `lft`, `rgt`, `level`, `dateCreated`, `dateUpdated`, `uid`) VALUES ('28', '5', '36', '22', '11', '12', '2', '2019-12-24 17:47:06', '2019-12-24 17:47:06', '379546b1-dd18-4b10-be08-d77bd93e9443');

INSERT INTO `structures` (`id`, `maxLevels`, `dateCreated`, `dateUpdated`, `dateDeleted`, `uid`) VALUES ('1', NULL, '2019-12-16 09:53:47', '2019-12-16 09:53:47', NULL, '3f9f861e-2ea7-4b48-a3d6-0281910f3a61');
INSERT INTO `structures` (`id`, `maxLevels`, `dateCreated`, `dateUpdated`, `dateDeleted`, `uid`) VALUES ('2', NULL, '2019-12-16 09:53:47', '2019-12-16 09:53:47', NULL, 'a15327eb-2c4f-4f73-9be3-6c4b6e228b47');
INSERT INTO `structures` (`id`, `maxLevels`, `dateCreated`, `dateUpdated`, `dateDeleted`, `uid`) VALUES ('3', NULL, '2019-12-16 20:51:28', '2019-12-16 20:51:28', NULL, 'e9e93210-f319-4d40-aec7-d642796aad61');
INSERT INTO `structures` (`id`, `maxLevels`, `dateCreated`, `dateUpdated`, `dateDeleted`, `uid`) VALUES ('4', NULL, '2019-12-24 17:47:06', '2019-12-24 17:47:06', NULL, '12a74401-c6ce-4ba9-abb6-5fb7921c8167');
INSERT INTO `structures` (`id`, `maxLevels`, `dateCreated`, `dateUpdated`, `dateDeleted`, `uid`) VALUES ('5', NULL, '2019-12-24 17:47:06', '2019-12-24 17:47:06', NULL, '009d5385-ae5f-4251-888f-69d4e4fa1350');

INSERT INTO `userpreferences` (`userId`, `preferences`) VALUES ('1', '{\"language\":\"en-US\",\"weekStartDay\":\"1\",\"enableDebugToolbarForSite\":false,\"enableDebugToolbarForCp\":false,\"showExceptionView\":false,\"profileTemplates\":false}');

INSERT INTO `users` (`id`, `username`, `photoId`, `firstName`, `lastName`, `email`, `password`, `admin`, `locked`, `suspended`, `pending`, `lastLoginDate`, `lastLoginAttemptIp`, `invalidLoginWindowStart`, `invalidLoginCount`, `lastInvalidLoginDate`, `lockoutDate`, `hasDashboard`, `verificationCode`, `verificationCodeIssuedDate`, `unverifiedEmail`, `passwordResetRequired`, `lastPasswordChangeDate`, `dateCreated`, `dateUpdated`, `uid`) VALUES ('1', 'support@fostercommerce.com', NULL, 'Foster Commerce', 'Support', 'support@fostercommerce.com', '$2y$13$WUNuZKX2LDk8ns74vXLoSOCwP6JY481Rm8vU7d4Vb3cCLhX.VOYne', '1', '0', '0', '0', '2020-01-02 20:15:56', NULL, NULL, NULL, NULL, NULL, '1', NULL, NULL, NULL, '0', '2019-12-12 12:18:02', '2019-12-12 12:18:02', '2020-01-02 20:15:56', '63644898-b726-4390-b7f0-fbf961bd7c79');

INSERT INTO `volumefolders` (`id`, `parentId`, `volumeId`, `name`, `path`, `dateCreated`, `dateUpdated`, `uid`) VALUES ('1', NULL, NULL, 'Temporary source', NULL, '2019-12-16 11:11:38', '2019-12-16 11:11:38', '652e97e0-1602-403f-a71b-edf03172b6b0');
INSERT INTO `volumefolders` (`id`, `parentId`, `volumeId`, `name`, `path`, `dateCreated`, `dateUpdated`, `uid`) VALUES ('2', '1', NULL, 'user_1', 'user_1/', '2019-12-16 11:11:38', '2019-12-16 11:11:38', '161d49d9-124f-4249-86c9-bc8c424146c0');
INSERT INTO `volumefolders` (`id`, `parentId`, `volumeId`, `name`, `path`, `dateCreated`, `dateUpdated`, `uid`) VALUES ('3', NULL, '1', 'Local Images', '', '2019-12-16 11:23:29', '2019-12-16 11:23:49', '445af6cd-37aa-4bbd-8fef-7f103348624c');
INSERT INTO `volumefolders` (`id`, `parentId`, `volumeId`, `name`, `path`, `dateCreated`, `dateUpdated`, `uid`) VALUES ('4', NULL, '2', 'Local Videos', '', '2019-12-16 11:24:50', '2019-12-16 21:40:04', '2b6a70aa-ddcd-4749-83ef-187d64295a7a');
INSERT INTO `volumefolders` (`id`, `parentId`, `volumeId`, `name`, `path`, `dateCreated`, `dateUpdated`, `uid`) VALUES ('5', NULL, '3', 'Local Files', '', '2019-12-16 11:25:46', '2019-12-16 11:25:46', '69c7ff12-d018-4af6-9653-fe7836160abf');

INSERT INTO `volumes` (`id`, `fieldLayoutId`, `name`, `handle`, `type`, `hasUrls`, `url`, `settings`, `sortOrder`, `dateCreated`, `dateUpdated`, `dateDeleted`, `uid`) VALUES ('1', '1', 'Local Images', 'localImages', 'craft\\volumes\\Local', '1', '@web/uploads/images', '{\"path\":\"@webroot/uploads/images\"}', '1', '2019-12-16 11:23:29', '2019-12-16 11:23:49', NULL, '31bc6e28-f82b-4d59-8e21-a33325447c9d');
INSERT INTO `volumes` (`id`, `fieldLayoutId`, `name`, `handle`, `type`, `hasUrls`, `url`, `settings`, `sortOrder`, `dateCreated`, `dateUpdated`, `dateDeleted`, `uid`) VALUES ('2', '2', 'Local Videos', 'localVideos', 'craft\\volumes\\Local', '1', '@web/uploads/videos', '{\"path\":\"@webroot/uploads/videos\"}', '2', '2019-12-16 11:24:50', '2019-12-16 21:40:04', NULL, 'e1c0dfb7-b877-4184-8f8d-c8121e74c039');
INSERT INTO `volumes` (`id`, `fieldLayoutId`, `name`, `handle`, `type`, `hasUrls`, `url`, `settings`, `sortOrder`, `dateCreated`, `dateUpdated`, `dateDeleted`, `uid`) VALUES ('3', NULL, 'Local Files', 'localFiles', 'craft\\volumes\\Local', '1', '@web/uploads/files', '{\"path\":\"@webroot/uploads/files\"}', '3', '2019-12-16 11:25:46', '2019-12-16 11:25:46', NULL, 'b4623a75-4ffd-4637-bd4d-36ffbe88a935');

INSERT INTO `widgets` (`id`, `userId`, `type`, `sortOrder`, `colspan`, `settings`, `enabled`, `dateCreated`, `dateUpdated`, `uid`) VALUES ('1', '1', 'craft\\widgets\\RecentEntries', '1', NULL, '{\"section\":\"*\",\"siteId\":\"1\",\"limit\":10}', '1', '2019-12-12 12:20:45', '2019-12-12 12:20:45', 'f84f6cc7-27a3-4349-9799-bea3eebef743');
INSERT INTO `widgets` (`id`, `userId`, `type`, `sortOrder`, `colspan`, `settings`, `enabled`, `dateCreated`, `dateUpdated`, `uid`) VALUES ('2', '1', 'craft\\widgets\\CraftSupport', '2', NULL, '[]', '1', '2019-12-12 12:20:45', '2019-12-12 12:20:45', 'f042fccc-33cd-441e-b5c2-c1465c404bba');
INSERT INTO `widgets` (`id`, `userId`, `type`, `sortOrder`, `colspan`, `settings`, `enabled`, `dateCreated`, `dateUpdated`, `uid`) VALUES ('3', '1', 'craft\\widgets\\Updates', '3', NULL, '[]', '1', '2019-12-12 12:20:45', '2019-12-12 12:20:45', '3c5318a8-6877-48ac-bf32-26fe7bb83bbc');
INSERT INTO `widgets` (`id`, `userId`, `type`, `sortOrder`, `colspan`, `settings`, `enabled`, `dateCreated`, `dateUpdated`, `uid`) VALUES ('4', '1', 'craft\\widgets\\Feed', '4', NULL, '{\"url\":\"https://craftcms.com/news.rss\",\"title\":\"Craft News\",\"limit\":5}', '1', '2019-12-12 12:20:45', '2019-12-12 12:20:45', 'f659ac45-2661-4886-84c6-b427db11c2e7');




/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;